<?php
/**
 * Router script for PHP Built-in Server
 */

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Serve static assets directly if they exist
$filePath = __DIR__ . $uri;
if ($uri !== '/' && file_exists($filePath) && !is_dir($filePath)) {
    return false;
}

// Route root to index.php
if ($uri === '/' || $uri === '') {
    require __DIR__ . '/index.php';
    return;
}

// Directory index fallback (e.g. /admin or /admin/)
if (is_dir($filePath) && file_exists(rtrim($filePath, '/') . '/index.php')) {
    require rtrim($filePath, '/') . '/index.php';
    return;
}

// Clean extensionless php files
if (file_exists(__DIR__ . $uri . '.php')) {
    require __DIR__ . $uri . '.php';
    return;
}

// If direct php file requested
if (file_exists($filePath) && str_ends_with($filePath, '.php')) {
    require $filePath;
    return;
}

// Default fallback to index.php
require __DIR__ . '/index.php';
