<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Core Application Configuration
 */

// Enable output buffering to prevent "headers already sent" warnings during redirects & session regeneration
if (!ob_get_level()) {
    ob_start();
}

// Prevent direct script execution without standard definitions
if (session_status() === PHP_SESSION_NONE) {
    // Configure secure session parameters before starting
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

// Application Information
define('APP_NAME_AR', 'منصة إيوان لحجز قاعات الأفراح والمناسبات');
define('APP_NAME_EN', 'Iwan Event & Wedding Halls Booking');
define('APP_VERSION', '1.2.0');
define('APP_ENV', 'development'); // 'development' or 'production'

// Default Timezone (Yemen - Asia/Aden, GMT+3)
date_default_timezone_set('Asia/Aden');

// Default Currency and Multi-currency Support
define('DEFAULT_CURRENCY', 'YER'); // YER = Yemeni Rial, SAR = Saudi Riyal, USD = US Dollar
define('CURRENCY_SYMBOL_AR', 'ر.ي');
define('CURRENCY_SYMBOL_EN', 'YER');

// Exchange Rates relative to YER (Configurable by admin)
$currency_rates = [
    'YER' => 1.0,
    'SAR' => 140.0,
    'USD' => 530.0
];

// Determine base path for clean relative or subfolder routing (e.g. /wedding_halls in XAMPP or / in root)
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
if (preg_match('#/(admin|includes|api|database)$#', $scriptDir, $matches)) {
    $scriptDir = substr($scriptDir, 0, -strlen($matches[0]));
}
$basePath = ($scriptDir === '/' || $scriptDir === '.' || $scriptDir === '') ? '' : rtrim($scriptDir, '/');

// Base URL: use root-relative path by default to prevent hardcoded port/host issues across devices & proxies
define('BASE_PATH', $basePath);
define('BASE_URL', $basePath); // When at root, this is "" which yields clean "/index.php" or "assets/..."

define('ROOT_PATH', dirname(__DIR__));
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('UPLOADS_URL', BASE_URL . '/uploads');

// Error Reporting according to Environment
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', ROOT_PATH . '/logs/error.log');
}
