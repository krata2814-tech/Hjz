<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Centralized Database Connection using PDO
 * Supports MySQL / MariaDB (XAMPP / Production) with auto-fallback to SQLite for zero-config testing.
 */

// Database Configuration Constants for XAMPP / Production
define('DB_DRIVER', getenv('DB_DRIVER') ?: 'mysql'); // 'mysql' or 'sqlite'
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'wedding_halls_db');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

class Database {
    private static ?PDO $instance = null;

    /**
     * Get the PDO Database Instance (Singleton pattern)
     */
    public static function getInstance(): PDO {
        if (self::$instance === null) {
            self::$instance = self::connect();
        }
        return self::$instance;
    }

    /**
     * Establish the PDO connection with resilient fallback
     */
    private static function connect(): PDO {
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        // 1. Try MySQL/MariaDB if configured
        if (DB_DRIVER === 'mysql') {
            try {
                $dsn = sprintf(
                    "mysql:host=%s;port=%s;dbname=%s;charset=%s",
                    DB_HOST,
                    DB_PORT,
                    DB_NAME,
                    DB_CHARSET
                );
                $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                $pdo->exec("SET NAMES 'utf8mb4'");
                $pdo->exec("SET time_zone = '+03:00'"); // Yemen timezone
                return $pdo;
            } catch (PDOException $e) {
                // If MySQL connection fails, silently fall back to SQLite for preview/demo
                $sqlitePath = dirname(__DIR__) . '/database/wedding_halls.sqlite';
                if (file_exists($sqlitePath)) {
                    $sqlitePdo = new PDO("sqlite:" . $sqlitePath, null, null, $options);
                    $sqlitePdo->exec("PRAGMA foreign_keys = ON;");
                    return $sqlitePdo;
                }

                // If SQLite does not exist or strictly MySQL mode, rethrow exception
                throw new PDOException("Database Connection Error (MySQL): " . $e->getMessage());
            }
        }

        // 2. Direct SQLite Mode
        $sqlitePath = dirname(__DIR__) . '/database/wedding_halls.sqlite';
        $pdo = new PDO("sqlite:" . $sqlitePath, null, null, $options);
        $pdo->exec("PRAGMA foreign_keys = ON;");
        return $pdo;
    }

    /**
     * Helper: Execute a prepared query safely
     */
    public static function query(string $sql, array $params = []): PDOStatement {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Helper: Fetch all rows
     */
    public static function fetchAll(string $sql, array $params = []): array {
        return self::query($sql, $params)->fetchAll();
    }

    /**
     * Helper: Fetch single row
     */
    public static function fetchOne(string $sql, array $params = []): ?array {
        $res = self::query($sql, $params)->fetch();
        return $res ?: null;
    }

    /**
     * Helper: Insert and get last inserted ID
     */
    public static function insert(string $sql, array $params = []): string {
        $pdo = self::getInstance();
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $pdo->lastInsertId();
    }

    /**
     * Helper: Get last inserted ID from active PDO instance
     */
    public static function lastInsertId(): string {
        return self::getInstance()->lastInsertId();
    }

    /**
     * Helper: Run database operations in an ACID transaction
     */
    public static function transaction(callable $callback) {
        $pdo = self::getInstance();
        $pdo->beginTransaction();
        try {
            $result = $callback($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
