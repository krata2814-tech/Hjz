<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Terms & Conditions Page
 */

$page_title = 'الشروط والأحكام | وثيقة الاستخدام وضمانات الحجز';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero Header -->
<section class="py-5 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
    <div class="container text-center py-3">
        <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i class="bi bi-file-earmark-text me-1 ms-1"></i> <?= Lang::isRtl() ? 'اتفاقية الاستخدام الرسمية' : 'Terms of Service' ?>
        </span>
        <h1 class="display-6 fw-bold text-white mb-2"><?= Lang::isRtl() ? 'الشروط والأحكام العامة' : 'Terms and Conditions' ?></h1>
        <p class="text-white-50 mx-auto small fs-6" style="max-width: 650px;">
            <?= Lang::isRtl() 
                ? 'تحكم هذه الوثيقة العلاقة بين منصة إيوان لحجز قاعات الأفراح، والعملاء الباحثين عن حجز القاعات، وملاك ومسؤولي القاعات والقصور المعتمدة.' 
                : 'These terms govern the use of the platform by customers and venue partners.' ?>
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-9 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white leading-relaxed">
                
                <div class="d-flex justify-content-between align-items-center pb-3 mb-4 border-bottom">
                    <div>
                        <span class="text-muted small"><?= Lang::isRtl() ? 'تاريخ آخر تحديث:' : 'Last updated:' ?></span>
                        <strong class="text-dark-green">1 يناير 2026</strong>
                    </div>
                    <span class="badge bg-light text-dark-green border">نسخة رقم 2.4</span>
                </div>

                <!-- 1. Definitions -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-bookmark-check-fill text-gold"></i>
                        <?= Lang::isRtl() ? '1. التعريفات والأحكام التمهيدية' : '1. Definitions' ?>
                    </h3>
                    <p class="text-secondary small">
                        يقصد بالعبارات الآتية المعاني الموضحة قرين كل منها ما لم يقتضِ السياق خلاف ذلك:
                    </p>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li><strong>المنصة / إيوان:</strong> موقع وتطبيق "منصة حجز قاعات الأفراح والمناسبات" وكافة الأنظمة الرقمية التابعة لها.</li>
                        <li><strong>العميل / المستخدم:</strong> كل شخص طبيعي أو اعتباري يتصفح المنصة أو يقوم بإنشاء حساب للاستفسار عن قاعة أو حجزها.</li>
                        <li><strong>مالك القاعة / المزود:</strong> الشخص الطبيعي أو الاعتباري المرخص له بإدارة وتشغيل قاعة الأفراح أو قصر المناسبات والمعتمد بالمنصة.</li>
                        <li><strong>طلب الحجز:</strong> الطلب الإلكتروني المبدئي الذي يقدمه العميل عبر المنصة لاختيار تاريخ وفترة محددة لإقامة مناسبته.</li>
                    </ul>
                </div>

                <!-- 2. Account Registration -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-person-badge-fill text-gold"></i>
                        <?= Lang::isRtl() ? '2. حسابات المستخدمين والمسؤولية' : '2. User Accounts & Security' ?>
                    </h3>
                    <p class="text-secondary small">
                        يلتزم المستخدم بتقديم بيانات دقيقة وصحيحة عند التسجيل بما في ذلك الاسم الحقيقي ورقم الهاتف المفعل. يتحمل المستخدم المسؤولية الكاملة عن سرية بيانات حسابه وكلمة المرور، وعن جميع العمليات والطلبات التي تتم عبر حسابه.
                    </p>
                    <p class="text-secondary small mb-0">
                        يحظر التسجيل بهويات وهمية أو انتحال شخصيات الغير، وتحتفظ إدارة المنصة بالحق في إيقاف أو إلغاء أي حساب يخالف قواعد النزاهة والمصداقية.
                    </p>
                </div>

                <!-- 3. Reservation & Shifts -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-calendar-event-fill text-gold"></i>
                        <?= Lang::isRtl() ? '3. آلية الحجز والفترات التشغيلية' : '3. Reservations & Operating Shifts' ?>
                    </h3>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li><strong>الفترة الصباحية:</strong> تبدأ عادة من الساعة 8:00 صباحاً وحتى الساعة 2:00 ظهراً، وتخصص للندوات، حفلات التخرج والمؤتمرات.</li>
                        <li><strong>الفترة المسائية:</strong> تبدأ من الساعة 4:00 عصراً وحتى الساعة 12:00 منتصف الليل، وتخصص للأفراح، وحفلات الزفاف الكبرى.</li>
                        <li><strong>تثبيت الموعد:</strong> يعتبر طلب الحجز عبر المنصة مبدئياً ولا يصبح ملزماً ونهائياً لإدارة القاعة إلا بعد سداد مبلغ العربون المتفق عليه وتوقيع العقد المعتمد بين الطرفين.</li>
                    </ul>
                </div>

                <!-- 4. Deposits & Cancellation -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-cash-coin text-gold"></i>
                        <?= Lang::isRtl() ? '4. الرسوم، العربون، وسياسة الإلغاء' : '4. Fees, Deposits & Cancellations' ?>
                    </h3>
                    <p class="text-secondary small">
                        تسري على دفع العربون وإلغاء الحجز القواعد التالية:
                    </p>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li><strong>مبلغ العربون:</strong> يمثل تأكيداً جدياً للارتباط بالميعاد المحدد، وتحدد نسبة العربون من قبل مالك القاعة (بين 25% و 50% عادة).</li>
                        <li><strong>التأجيل وتعديل التاريخ:</strong> يحق للعميل طلب تعديل تاريخ المناسبة قبل 30 يوماً على الأقل من التاريخ المحدد شريطة توفر تاريخ بديل شاغر بنفس القاعة.</li>
                        <li><strong>إلغاء الحجز:</strong> في حال إلغاء الحجز من طرف العميل قبل الموعد بأقل من 30 يوماً، يخضع استرداد العربون لسياسة إدارة الصالة وعقد الإيجار المبرم.</li>
                        <li><strong>إلغاء القاعة للحجز:</strong> في حال تعذر القاعة عن استضافة المناسبة لأسباب قاهرة، يلتزم مالك القاعة برد كامل المبالغ المدفوعة فوراً دون أي استقطاع ومساعدة العميل في إيجاد بديل مناسب.</li>
                    </ul>
                </div>

                <!-- 5. Venue Guarantees -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-shield-fill-check text-gold"></i>
                        <?= Lang::isRtl() ? '5. التزامات ملاك القاعات وضمانات التشغيل' : '5. Venue Owner Obligations' ?>
                    </h3>
                    <p class="text-secondary small">
                        يلتزم ملاك القاعات المسجلون بالمنصة بتوفير أعلى معايير الجودة والراحة وتشمل:
                    </p>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li>تشغيل المولدات الكهربائية المركزية والتأكد من وفرة الوقود الكافي للتشغيل المتواصل طوال ساعات المناسبة.</li>
                        <li>صيانة وجاهزية أنظمة التكييف والتهوية والإضاءة والصوتيات قبل موعد المناسبة بوقت كافٍ.</li>
                        <li>توفير طاقم التنظيف، الحراسة، ومشرفات الصالة النسائية للحفاظ على النظام وخصوصية المناسبة.</li>
                        <li>مطابقة القاعة ومرافقها للمواصفات والصور والخدمات المنشورة في صفحتها الرسمية على المنصة.</li>
                    </ul>
                </div>

                <!-- 6. Legal Jurisdiction -->
                <div>
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-bank text-gold"></i>
                        <?= Lang::isRtl() ? '6. القانون الواجب التطبيق وتسوية النزاعات' : '6. Applicable Law & Jurisdiction' ?>
                    </h3>
                    <p class="text-secondary small mb-0">
                        تخضع هذه الشروط والأحكام وتفسر وفقاً للقوانين والأنظمة السارية في الجمهورية اليمنية. وفي حال نشوء أي خلاف بين أطراف الحجز، يتم بذل المساعي الودية للتسوية عبر لجنة التوفيق بالمنصة، وإذا تعذر ذلك يختص القضاء اليمني بالفصل في النزاع.
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
