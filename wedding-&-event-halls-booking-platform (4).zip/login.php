<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * User Login
 */

$page_title = 'تسجيل الدخول';
require_once __DIR__ . '/includes/auth.php';

if (Auth::check()) {
    redirect(Auth::isSuperAdmin() ? (BASE_URL . '/admin/index.php') : (BASE_URL . '/dashboard.php'));
}

$error = null;

if (isPost()) {
    CSRF::verifyOrDie();
    $email = sanitize(post('email'));
    $password = post('password', '');

    if (empty($email) || empty($password)) {
        $error = 'يرجى إدخال البريد الإلكتروني وكلمة المرور.';
    } else {
        if (Auth::attempt($email, $password)) {
            setFlash('success', __('login_success'));
            redirect(Auth::isSuperAdmin() ? (BASE_URL . '/admin/index.php') : (BASE_URL . '/dashboard.php'));
        } else {
            $error = __('invalid_credentials');
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div class="container py-4 py-md-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white">
                <div class="text-center mb-4">
                    <div class="brand-icon-wrapper mx-auto mb-3" style="width: 52px; height: 52px; font-size: 1.5rem;">
                        <i class="bi bi-box-arrow-in-left"></i>
                    </div>
                    <h2 class="h4 fw-bold text-dark-green"><?= e(__('login')) ?></h2>
                    <p class="text-muted small"><?= Lang::isRtl() ? 'أهلاً بك مجدداً في منصة حجز قاعات المناسبات' : 'Welcome back to your account' ?></p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger py-2 small shadow-sm rounded-3"><?= e($error) ?></div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/login.php" method="POST" class="needs-validation" novalidate>
                    <?= CSRF::getFormField() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('email')) ?></label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-envelope"></i></span>
                            <input type="email" name="email" class="form-control border-start-0" placeholder="user@example.com" value="<?= e(post('email')) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('password')) ?></label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-shield-lock"></i></span>
                            <input type="password" name="password" class="form-control border-start-0" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember" name="remember">
                            <label class="form-check-label small text-muted" for="remember">
                                <?= e(__('remember_me')) ?>
                            </label>
                        </div>
                        <a href="<?= BASE_URL ?>/forgot-password.php" class="small text-gold text-decoration-none fw-bold"><?= Lang::isRtl() ? 'نسيت كلمة المرور؟' : 'Forgot Password?' ?></a>
                    </div>

                    <button type="submit" class="btn btn-gold w-100 py-2 fw-bold">
                        <i class="bi bi-box-arrow-in-left me-1 ms-1"></i> <?= e(__('login')) ?>
                    </button>
                </form>

                <!-- Quick Demo Login Credentials -->
                <div class="mt-4 pt-3 border-top">
                    <div class="small fw-bold text-dark-green mb-2 text-center"><?= Lang::isRtl() ? 'حسابات تجريبية سريعة بنقرة واحدة:' : 'Demo Quick Credentials:' ?></div>
                    <div class="d-flex flex-column gap-2 small">
                        <button type="button" class="btn btn-sm btn-light border text-start d-flex justify-content-between align-items-center p-2" onclick="fillLogin('krata2814@gmail.com', '781802671')">
                            <span><strong class="text-danger">المدير العام (Super Admin):</strong> krata2814@gmail.com</span>
                            <span class="badge bg-secondary">781802671</span>
                        </button>
                        <button type="button" class="btn btn-sm btn-light border text-start d-flex justify-content-between align-items-center p-2" onclick="fillLogin('owner@tajsanaa.ye', 'owner123')">
                            <span><strong class="text-dark-green">مالك قاعة (صنعاء):</strong> owner@tajsanaa.ye</span>
                            <span class="badge bg-secondary">owner123</span>
                        </button>
                        <button type="button" class="btn btn-sm btn-light border text-start d-flex justify-content-between align-items-center p-2" onclick="fillLogin('customer@gmail.com', 'customer123')">
                            <span><strong class="text-primary">عميل حجز:</strong> customer@gmail.com</span>
                            <span class="badge bg-secondary">customer123</span>
                        </button>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <p class="small text-muted mb-0">
                        <?= e(__('dont_have_account')) ?> 
                        <a href="<?= BASE_URL ?>/register.php" class="text-gold fw-bold"><?= e(__('register')) ?></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function fillLogin(email, password) {
    document.querySelector('input[name="email"]').value = email;
    document.querySelector('input[name="password"]').value = password;
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
