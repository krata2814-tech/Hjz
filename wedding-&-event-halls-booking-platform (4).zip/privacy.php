<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Privacy Policy Page
 */

$page_title = 'سياسة الخصوصية | حماية وسرية بياناتك';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero Header -->
<section class="py-5 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
    <div class="container text-center py-3">
        <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i class="bi bi-shield-lock me-1 ms-1"></i> <?= Lang::isRtl() ? 'أمان وسرية تامة' : 'Data Privacy & Security' ?>
        </span>
        <h1 class="display-6 fw-bold text-white mb-2"><?= Lang::isRtl() ? 'سياسة الخصوصية وسرية البيانات' : 'Privacy Policy' ?></h1>
        <p class="text-white-50 mx-auto small fs-6" style="max-width: 650px;">
            <?= Lang::isRtl() 
                ? 'نحن نولي خصوصية بياناتك الشخصية وتفاصيل مناسباتك العائلية أقصى درجات الاهتمام والسرية وفق أرقى المعايير الأمنية.' 
                : 'We prioritize your personal privacy and event records with rigorous data security standards.' ?>
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-9 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white leading-relaxed">
                
                <div class="d-flex justify-content-between align-items-center pb-3 mb-4 border-bottom">
                    <div>
                        <span class="text-muted small"><?= Lang::isRtl() ? 'تاريخ السريان:' : 'Effective Date:' ?></span>
                        <strong class="text-dark-green">1 يناير 2026</strong>
                    </div>
                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25">
                        <i class="bi bi-shield-check me-1 ms-1"></i> تشفير كامل لكلمات المرور
                    </span>
                </div>

                <!-- 1. What Data We Collect -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-person-lines-fill text-gold"></i>
                        <?= Lang::isRtl() ? '1. البيانات التي نجمعها' : '1. Data We Collect' ?>
                    </h3>
                    <p class="text-secondary small">
                        عند استخدامك لمنصة إيوان، قد نجمع البيانات الضرورية لتنفيذ حجوزاتك وتقديم الخدمة على أكمل وجه:
                    </p>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li><strong>بيانات التسجيل والحساب:</strong> تشمل الاسم الكامل، رقم الهاتف الجوال، عنوان البريد الإلكتروني، ونوع الحساب (عميل أو مالك قاعة).</li>
                        <li><strong>بيانات المناسبة والحجز:</strong> تاريخ المناسبة المطلوب، الفترة (صباحية أو مسائية)، عدد الضيوف المتوقع، وأي متطلبات خاصة.</li>
                        <li><strong>بيانات القاعات (لملاك القاعات):</strong> اسم القاعة، السجل التجاري، الموقع الجغرافي، قائمة الأسعار، الصور والمرافق.</li>
                        <li><strong>التقييمات والرسائل:</strong> المراجعات الحقيقية التي تكتبها حول تجربتك، ونصوص الاستفسارات الموجهة لإدارة الصالة.</li>
                    </ul>
                </div>

                <!-- 2. How We Use Data -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-gear-fill text-gold"></i>
                        <?= Lang::isRtl() ? '2. كيف نستخدم بياناتك الشخصية' : '2. How We Use Your Data' ?>
                    </h3>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li>تسهيل التواصل المباشر بينك وبين إدارة القاعة لتأكيد تواريخ الحجز وتنسيق المعاينة الميدانية.</li>
                        <li>إرسال إشعارات الحجز، الفواتير المبدئية، وتأكيد المعاملات عبر الرسائل أو البريد الإلكتروني.</li>
                        <li>تحسين وتخصيص نتائج البحث بناءً على مدينتك ونوع المناسبة المفضلة.</li>
                        <li>حماية المنصة من محاولات التلاعب أو الحجوزات الوهمية وضمان أمان جميع المستخدمين.</li>
                    </ul>
                </div>

                <!-- 3. Information Sharing -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-share-fill text-gold"></i>
                        <?= Lang::isRtl() ? '3. مشاركة البيانات مع أطراف ثالثة' : '3. Data Sharing' ?>
                    </h3>
                    <p class="text-secondary small">
                        <strong>نحن نضمن عدم بيع أو تأجير أو مشاركة بياناتك الشخصية لأي أغراض تسويقية أو جهات تجارية خارجية.</strong>
                    </p>
                    <p class="text-secondary small mb-0">
                        يتم مشاركة بيانات الاتصال الخاصة بك (الاسم ورقم الهاتف) حصراً مع إدارة القاعة التي تختار بنفسك إرسال استفسار أو طلب حجز إليها، وذلك لتمكينهم من التواصل معك وتثبيت المناسبة.
                    </p>
                </div>

                <!-- 4. Security Measures -->
                <div class="mb-5">
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-lock-fill text-gold"></i>
                        <?= Lang::isRtl() ? '4. الإجراءات الأمنية وحماية البيانات' : '4. Security Measures' ?>
                    </h3>
                    <p class="text-secondary small">
                        نطبق تدابير تقنية وإدارية متقدمة لحماية بياناتك:
                    </p>
                    <ul class="text-secondary small d-flex flex-column gap-2 mb-0">
                        <li>تشفير كلمات المرور باستخدام خوارزميات التجزئة أحادية الاتجاه (BCrypt) عالية الأمان.</li>
                        <li>حماية استعلامات قواعد البيانات باستخدام تقنية Prepared Statements لمنع هجمات حقن SQL.</li>
                        <li>تفعيل رموز الحماية من تزوير الطلبات عبر المواقع (CSRF Protection) على كافة النماذج.</li>
                        <li>استخدام اتصالات مشفرة لتأمين نقل البيانات عبر الإنترنت.</li>
                    </ul>
                </div>

                <!-- 5. User Rights -->
                <div>
                    <h3 class="h5 fw-bold text-dark-green d-flex align-items-center gap-2 mb-3">
                        <i class="bi bi-check2-circle text-gold"></i>
                        <?= Lang::isRtl() ? '5. حقوق المستخدم والتحكم في البيانات' : '5. Your Rights' ?>
                    </h3>
                    <p class="text-secondary small mb-0">
                        يحق لك في أي وقت الدخول إلى لوحة التحكم الخاصة بك لتحديث بياناتك، تعديل رقم هاتفك، مراجعة سجل حجوزاتك، أو التواصل مع فريق الدعم الفني لحذف حسابك نهائياً من سجلات المنصة.
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
