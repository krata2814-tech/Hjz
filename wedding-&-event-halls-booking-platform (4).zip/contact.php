<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Contact Us & Customer Support Page
 */

$page_title = 'اتصل بنا | الدعم الفني وخدمة العملاء';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

$successMessage = null;
$errorMessage = null;

if (isPost()) {
    CSRF::verifyOrDie();
    $name = sanitize(post('name'));
    $email = strtolower(sanitize(post('email')));
    $phone = sanitize(post('phone'));
    $subject = sanitize(post('subject'));
    $message = sanitize(post('message'));

    if (empty($name) || empty($phone) || empty($subject) || empty($message)) {
        $errorMessage = Lang::isRtl() 
            ? 'يرجى ملء جميع الحقول المطلوبة (الاسم، الهاتف، موضوع الرسالة، ونص الاستفسار).' 
            : 'Please fill in all required fields (Name, Phone, Subject, and Message).';
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = Lang::isRtl() ? 'يرجى إدخال عنوان بريد إلكتروني صالح.' : 'Please enter a valid email address.';
    } else {
        try {
            Database::insert("
                INSERT INTO contact_messages (name, email, phone, subject, message, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'new', CURRENT_TIMESTAMP)
            ", [$name, $email, $phone, $subject, $message]);

            $successMessage = Lang::isRtl() 
                ? 'شكراً لتواصلك معنا! تم استلام رسالتك بنجاح وسيقوم فريق الدعم الفني بالرد عليك خلال ساعات العمل.' 
                : 'Thank you for reaching out! Your message has been received and our team will get back to you shortly.';
        } catch (Exception $e) {
            $errorMessage = Lang::isRtl() ? 'حدث خطأ أثناء إرسال الرسالة، يرجى المحاولة لاحقاً.' : 'An error occurred while sending your message. Please try again.';
        }
    }
}
?>

<!-- Hero Header -->
<section class="py-5 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
    <div class="container text-center py-3">
        <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i class="bi bi-headset me-1 ms-1"></i> <?= Lang::isRtl() ? 'خدمة العملاء على مدار الساعة' : '24/7 Customer Care' ?>
        </span>
        <h1 class="display-6 fw-bold text-white mb-2"><?= Lang::isRtl() ? 'تواصل مع فريق منصة إيوان' : 'Contact Iwan Platform Team' ?></h1>
        <p class="text-white-50 mx-auto small fs-6" style="max-width: 650px;">
            <?= Lang::isRtl() 
                ? 'سواء كنت عريساً تبحث عن استشارة لاختيار القاعة المثالية، أو مالك قاعة ترغب في الانضمام للمنصة، نحن هنا للإجابة على جميع استفساراتك.' 
                : 'Whether you are planning your wedding or a venue owner looking to partner with us, our team is always ready to assist.' ?>
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row g-4">
        <!-- Contact Form Column -->
        <div class="col-lg-7 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white h-100">
                <div class="mb-4">
                    <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'نموذج المراسلة المباشر' : 'Direct Message Form' ?></span>
                    <h2 class="h4 fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'أرسل لنا استفسارك أو اقتراحك' : 'Send Us Your Inquiry or Feedback' ?></h2>
                    <p class="text-muted small"><?= Lang::isRtl() ? 'سنقوم بمراجعة طلبك والرد عليك عبر الهاتف أو الواتساب في أسرع وقت.' : 'We will review your message and reply via phone or WhatsApp.' ?></p>
                </div>

                <?php if ($successMessage): ?>
                    <div class="alert alert-success d-flex align-items-center gap-2 py-3 rounded-3 mb-4 shadow-sm">
                        <i class="bi bi-check-circle-fill fs-4 flex-shrink-0"></i>
                        <div><?= e($successMessage) ?></div>
                    </div>
                <?php endif; ?>

                <?php if ($errorMessage): ?>
                    <div class="alert alert-danger d-flex align-items-center gap-2 py-3 rounded-3 mb-4 shadow-sm">
                        <i class="bi bi-exclamation-triangle-fill fs-4 flex-shrink-0"></i>
                        <div><?= e($errorMessage) ?></div>
                    </div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/contact.php" method="POST" class="needs-validation">
                    <?= CSRF::getFormField() ?>

                    <div class="row g-3">
                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green">
                                <?= Lang::isRtl() ? 'الاسم الكامل' : 'Full Name' ?> <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-person"></i></span>
                                <input type="text" name="name" class="form-control" placeholder="<?= Lang::isRtl() ? 'مثال: محمد علي' : 'e.g. John Doe' ?>" value="<?= e(post('name', Auth::name() ?? '')) ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green">
                                <?= Lang::isRtl() ? 'رقم الهاتف / الواتساب' : 'Phone / WhatsApp' ?> <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-telephone"></i></span>
                                <input type="tel" name="phone" class="form-control" placeholder="<?= Lang::isRtl() ? 'مثال: 770000000' : '+967...' ?>" value="<?= e(post('phone', Auth::user()['phone'] ?? '')) ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green">
                                <?= Lang::isRtl() ? 'البريد الإلكتروني' : 'Email Address' ?>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control" placeholder="user@example.com" value="<?= e(post('email', Auth::user()['email'] ?? '')) ?>">
                            </div>
                        </div>

                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green">
                                <?= Lang::isRtl() ? 'موضوع الرسالة' : 'Subject' ?> <span class="text-danger">*</span>
                            </label>
                            <select name="subject" class="form-select" required>
                                <option value=""><?= Lang::isRtl() ? 'اختر موضوع الاستفسار...' : 'Select topic...' ?></option>
                                <option value="booking_help"><?= Lang::isRtl() ? 'مساعدة في اختيار قاعة مناسبة' : 'Assistance in selecting a venue' ?></option>
                                <option value="hall_registration"><?= Lang::isRtl() ? 'استفسار عن تسجيل قاعة جديدة' : 'Hall owner partnership inquiry' ?></option>
                                <option value="booking_inquiry"><?= Lang::isRtl() ? 'متابعة حجز قائم' : 'Existing booking follow-up' ?></option>
                                <option value="technical_support"><?= Lang::isRtl() ? 'دعم فني واستخدام المنصة' : 'Technical support' ?></option>
                                <option value="complaint_suggestion"><?= Lang::isRtl() ? 'شكوى أو مقترح تحسين' : 'Feedback or complaint' ?></option>
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-bold text-dark-green">
                                <?= Lang::isRtl() ? 'نص الرسالة أو الاستفسار' : 'Your Message' ?> <span class="text-danger">*</span>
                            </label>
                            <textarea name="message" rows="5" class="form-control" placeholder="<?= Lang::isRtl() ? 'اكتب تفاصيل استفسارك أو تاريخ مناسبتك وعدد الضيوف لمساعدتك...' : 'Provide details regarding your date, guest count, or requirements...' ?>" required><?= e(post('message')) ?></textarea>
                        </div>

                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-gold w-100 py-2 fw-bold d-flex align-items-center justify-content-center gap-2">
                                <i class="bi bi-send-fill"></i>
                                <span><?= Lang::isRtl() ? 'إرسال الرسالة الآن' : 'Send Message' ?></span>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Contact Channels & Office Info -->
        <div class="col-lg-5 col-12">
            <div class="d-flex flex-column gap-3">
                <!-- Direct Channels Card -->
                <div class="bg-white p-4 rounded-3 border shadow-sm">
                    <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-telephone-inbound-fill text-gold"></i>
                        <?= Lang::isRtl() ? 'قنوات الاتصال المباشرة' : 'Direct Channels' ?>
                    </h5>
                    
                    <div class="d-flex align-items-start gap-3 py-2 border-bottom">
                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-gold fs-4" style="width: 48px; height: 48px;">
                            <i class="bi bi-telephone-fill"></i>
                        </div>
                        <div>
                            <div class="text-muted small"><?= Lang::isRtl() ? 'الرقم الموحد المباشر' : 'Customer Hotline' ?></div>
                            <div class="fw-bold fs-6 text-dark-green" dir="ltr">+967-1-445566</div>
                            <div class="text-muted" style="font-size: 0.75rem;"><?= Lang::isRtl() ? 'يومياً من 8:00 صباحاً وحتى 10:00 مساءً' : 'Daily 8:00 AM - 10:00 PM' ?></div>
                        </div>
                    </div>

                    <div class="d-flex align-items-start gap-3 py-2 border-bottom">
                        <div class="rounded-circle bg-success bg-opacity-10 d-flex align-items-center justify-content-center text-success fs-4" style="width: 48px; height: 48px;">
                            <i class="bi bi-whatsapp"></i>
                        </div>
                        <div>
                            <div class="text-muted small"><?= Lang::isRtl() ? 'خدمة الواتساب الفورية' : 'WhatsApp Support' ?></div>
                            <div class="fw-bold fs-6 text-dark-green" dir="ltr">+967 770 000 001</div>
                            <a href="https://wa.me/967770000001?text=<?= urlencode('مرحباً منصة إيوان، أرغب في الاستفسار عن قاعات الأعراس والمناسبات') ?>" target="_blank" class="btn btn-sm btn-outline-success mt-1 py-1 px-2 d-inline-flex align-items-center gap-1">
                                <i class="bi bi-chat-dots-fill"></i>
                                <span><?= Lang::isRtl() ? 'محادثة واتساب فورية' : 'Chat on WhatsApp' ?></span>
                            </a>
                        </div>
                    </div>

                    <div class="d-flex align-items-start gap-3 py-2">
                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-gold fs-4" style="width: 48px; height: 48px;">
                            <i class="bi bi-envelope-at-fill"></i>
                        </div>
                        <div>
                            <div class="text-muted small"><?= Lang::isRtl() ? 'البريد الإلكتروني للإدارة' : 'Official Email' ?></div>
                            <div class="fw-bold fs-6 text-dark-green">support@wedding.ye</div>
                            <div class="text-muted" style="font-size: 0.75rem;">admin@wedding.ye</div>
                        </div>
                    </div>
                </div>

                <!-- City Branches -->
                <div class="bg-white p-4 rounded-3 border shadow-sm">
                    <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt-fill text-gold"></i>
                        <?= Lang::isRtl() ? 'مكاتب وفروع التنسيق' : 'Coordination Offices' ?>
                    </h5>
                    <ul class="list-unstyled mb-0 d-flex flex-column gap-3 small">
                        <li class="d-flex gap-2">
                            <i class="bi bi-pin-map-fill text-danger fs-5 flex-shrink-0"></i>
                            <div>
                                <strong class="text-dark-green"><?= Lang::isRtl() ? 'صنعاء (المركز الرئيسي):' : 'Sana\'a (HQ):' ?></strong>
                                <div class="text-muted"><?= Lang::isRtl() ? 'شارع الستين الجنوبي - جوار فندق سبأ، برج إيوان الدور الثالث' : 'Southern Sixtieth St, Iwan Tower 3rd Floor' ?></div>
                            </div>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-pin-map-fill text-danger fs-5 flex-shrink-0"></i>
                            <div>
                                <strong class="text-dark-green"><?= Lang::isRtl() ? 'عدن:' : 'Aden:' ?></strong>
                                <div class="text-muted"><?= Lang::isRtl() ? 'خور مكسر - حي السفارات، مجمع النور للأعمال' : 'Khor Maksar, Al-Noor Business Center' ?></div>
                            </div>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-pin-map-fill text-danger fs-5 flex-shrink-0"></i>
                            <div>
                                <strong class="text-dark-green"><?= Lang::isRtl() ? 'تعز:' : 'Taiz:' ?></strong>
                                <div class="text-muted"><?= Lang::isRtl() ? 'شارع جمال عبد الناصر - مركز الأعمال الموحد' : 'Jamal Abdulnasser St, Business Center' ?></div>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Quick Help / FAQ Banner -->
                <div class="p-3 rounded-3 bg-light border text-center">
                    <i class="bi bi-question-circle-fill text-gold fs-3 mb-2 d-block"></i>
                    <h6 class="fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'هل تبحث عن إجابات سريعة؟' : 'Looking for Quick Answers?' ?></h6>
                    <p class="text-muted small mb-2"><?= Lang::isRtl() ? 'راجع قسم الأسئلة الشائعة لمعرفة شروط الحجز، سياسة العربون، والضمانات.' : 'Check our FAQ for booking terms, deposits, and venue policies.' ?></p>
                    <a href="<?= BASE_URL ?>/faq.php" class="btn btn-sm btn-outline-dark-green">
                        <?= Lang::isRtl() ? 'عرض الأسئلة الشائعة' : 'Browse FAQs' ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
