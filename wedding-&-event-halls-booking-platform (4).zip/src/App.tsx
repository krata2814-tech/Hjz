import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Search,
  Heart,
  Star,
  Calendar,
  Users,
  ShieldCheck,
  Globe,
  LogOut,
  X,
  Building2,
} from 'lucide-react';
import {
  Hall,
  Locale,
  CurrencyCode,
  UserSession,
  HALL_TYPES,
  SUITABILITY_TYPES,
  YEMEN_GOVERNORATES,
  formatMoney,
  getCityLabel,
  getHallTypeLabel,
  getSuitabilityLabel,
  computeConsecutiveDatesClient,
} from './types.ts';
import { VenueImage } from './components/VenueImage.tsx';
import { VenueDetailModal } from './components/VenueDetailModal.tsx';
import { CustomerDashboard } from './components/CustomerDashboard.tsx';
import { OwnerPortal } from './components/OwnerPortal.tsx';
import { SupportPortal } from './components/SupportPortal.tsx';
import { SuperAdminPortal } from './components/SuperAdminPortal.tsx';

export function App() {
  const [locale, setLocale] = useState<Locale>('ar');
  const [currency, setCurrency] = useState<CurrencyCode>('YER');
  const [activeView, setActiveView] = useState<
    'marketplace' | 'customer_portal' | 'owner_portal' | 'support_portal' | 'admin_portal'
  >('marketplace');

  // Auth Session State
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('munasabati_token'));
  const [csrfToken, setCsrfToken] = useState<string | null>(() => localStorage.getItem('munasabati_csrf'));
  const [user, setUser] = useState<UserSession | null>(null);

  // Marketplace State
  const [halls, setHalls] = useState<Hall[]>([]);
  const [reviews, setReviews] = useState<Array<Record<string, unknown>>>([]);
  const [demoPersonas, setDemoPersonas] = useState<Array<Record<string, unknown>>>([]);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [selectedHall, setSelectedHall] = useState<Hall | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [cityFilter, setCityFilter] = useState('all');
  const [suitabilityFilter, setSuitabilityFilter] = useState<string>('all');
  const [hallTypeFilter, setHallTypeFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('');
  const [bookedDaysFilter, setBookedDaysFilter] = useState<number>(1);
  const [shiftFilter, setShiftFilter] = useState('evening');
  const [minGuests, setMinGuests] = useState<number>(0);
  const [maxPriceFilter, setMaxPriceFilter] = useState<number>(0);
  const [facilityFilter, setFacilityFilter] = useState<string>('all');

  // Venue Comparison State
  const [compareIds, setCompareIds] = useState<number[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);

  // Auth Modal State
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regAccountType, setRegAccountType] = useState<'customer' | 'hall_owner'>('customer');
  const [regBusinessName, setRegBusinessName] = useState('');
  const [regCrNo, setRegCrNo] = useState('');
  const [regDocUrl, setRegDocUrl] = useState('/uploads/docs/commercial-ownership-license.pdf');
  const [regTermsAccepted, setRegTermsAccepted] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const isAr = locale === 'ar';

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = isAr ? 'rtl' : 'ltr';
  }, [locale, isAr]);

  const apiFetch = useCallback(
    async (url: string, options: RequestInit = {}) => {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(options.headers as Record<string, string>),
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      if (csrfToken) {
        headers['X-CSRF-Token'] = csrfToken;
      }
      const res = await fetch(url, { ...options, headers });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Request failed');
      }
      return data;
    },
    [token, csrfToken]
  );

  const bootstrapMarketplace = useCallback(async () => {
    try {
      const data = (await apiFetch('/api/init')) as {
        halls: Hall[];
        reviews: Array<Record<string, unknown>>;
        demoPersonas: Array<Record<string, unknown>>;
        user: UserSession | null;
      };
      setHalls(data.halls);
      setReviews(data.reviews);
      setDemoPersonas(data.demoPersonas);
      if (data.user) {
        setUser(data.user);
        setFavorites(data.user.favorites || []);
      }
    } catch {
      // ignore initial error
    } finally {
      setLoading(false);
    }
  }, [apiFetch]);

  useEffect(() => {
    bootstrapMarketplace();
  }, [bootstrapMarketplace]);

  async function handlePersonaSwitch(userId: number) {
    try {
      const res = (await apiFetch('/api/auth/persona-switch', {
        method: 'POST',
        body: JSON.stringify({ userId }),
      })) as { token: string; csrfToken: string; user: UserSession };

      localStorage.setItem('munasabati_token', res.token);
      localStorage.setItem('munasabati_csrf', res.csrfToken);
      setToken(res.token);
      setCsrfToken(res.csrfToken);
      setUser(res.user);

      if (res.user.role_slug === 'super_admin' || res.user.role_slug === 'employee') {
        setActiveView('admin_portal');
      } else if (res.user.role_slug === 'hall_owner') {
        setActiveView('owner_portal');
      } else if (res.user.role_slug === 'support_agent') {
        setActiveView('support_portal');
      } else {
        setActiveView('customer_portal');
      }
    } catch (err: unknown) {
      setAuthError(err instanceof Error ? err.message : 'Switch failed');
    }
  }

  async function handleAuthSubmit(e: React.FormEvent) {
    e.preventDefault();
    setAuthError(null);
    try {
      if (authMode === 'login') {
        const res = (await apiFetch('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email: authEmail, password: authPassword }),
        })) as { token: string; csrfToken: string; user: UserSession };
        localStorage.setItem('munasabati_token', res.token);
        localStorage.setItem('munasabati_csrf', res.csrfToken);
        setToken(res.token);
        setCsrfToken(res.csrfToken);
        setUser(res.user);
        setShowAuthModal(false);
        if (res.user.role_slug === 'super_admin' || res.user.role_slug === 'employee') {
          setActiveView('admin_portal');
        } else if (res.user.role_slug === 'hall_owner') {
          setActiveView('owner_portal');
        } else if (res.user.role_slug === 'support_agent') {
          setActiveView('support_portal');
        }
      } else {
        const res = (await apiFetch('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            name: regName,
            email: authEmail,
            phone: regPhone,
            password: authPassword,
            accountType: regAccountType,
            businessName: regBusinessName,
            commercialRegNo: regCrNo,
            verificationDocumentUrl: regDocUrl,
            termsAccepted: regTermsAccepted,
          }),
        })) as { token: string; csrfToken: string; user: UserSession };
        localStorage.setItem('munasabati_token', res.token);
        localStorage.setItem('munasabati_csrf', res.csrfToken);
        setToken(res.token);
        setCsrfToken(res.csrfToken);
        setUser(res.user);
        setShowAuthModal(false);
        if (res.user.role_slug === 'hall_owner') {
          setActiveView('owner_portal');
        }
      }
    } catch (err: unknown) {
      setAuthError(err instanceof Error ? err.message : 'فشل التحقق');
    }
  }

  function handleLogout() {
    localStorage.removeItem('munasabati_token');
    localStorage.removeItem('munasabati_csrf');
    setToken(null);
    setCsrfToken(null);
    setUser(null);
    setActiveView('marketplace');
  }

  async function handleToggleFavorite(hallId: number, e: React.MouseEvent) {
    e.stopPropagation();
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    const res = (await apiFetch('/api/favorites/toggle', {
      method: 'POST',
      body: JSON.stringify({ hallId }),
    })) as { favorites: number[] };
    setFavorites(res.favorites);
  }

  function handleToggleCompare(hallId: number, e: React.MouseEvent) {
    e.stopPropagation();
    setCompareIds((prev) => {
      if (prev.includes(hallId)) return prev.filter((id) => id !== hallId);
      if (prev.length >= 3) return [...prev.slice(1), hallId];
      return [...prev, hallId];
    });
  }

  const filteredHalls = useMemo(() => {
    return halls.filter((h) => {
      if (cityFilter !== 'all' && h.city !== cityFilter) return false;
      if (suitabilityFilter !== 'all' && (h.suitability_type || 'MIXED') !== suitabilityFilter) return false;
      if (hallTypeFilter !== 'all' && h.hall_type !== hallTypeFilter) return false;
      if (minGuests > 0 && h.capacity_max < minGuests) return false;
      if (maxPriceFilter > 0 && h.starting_price > maxPriceFilter) return false;
      if (facilityFilter !== 'all') {
        const hasFac = h.facilities.some((f) => String(f.category) === facilityFilter || String(f.facility_id) === facilityFilter);
        if (!hasFac) return false;
      }
      if (dateFilter) {
        const reqDates = computeConsecutiveDatesClient(dateFilter, bookedDaysFilter);
        const hasConflict = reqDates.some((reqDate) =>
          h.unavailableSlots.some(
            (s) =>
              s.date === reqDate &&
              (s.status === 'booked' || s.status === 'blocked') &&
              (s.shift === shiftFilter || s.shift === 'full_day' || shiftFilter === 'full_day')
          )
        );
        if (hasConflict) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchAr = h.name_ar.toLowerCase().includes(q) || h.description_ar.toLowerCase().includes(q);
        const matchEn = (h.name_en || '').toLowerCase().includes(q) || (h.address || '').toLowerCase().includes(q);
        if (!matchAr && !matchEn) return false;
      }
      return true;
    });
  }, [
    halls,
    cityFilter,
    suitabilityFilter,
    hallTypeFilter,
    minGuests,
    maxPriceFilter,
    facilityFilter,
    dateFilter,
    bookedDaysFilter,
    shiftFilter,
    searchQuery,
  ]);

  // Keep selectedHall synced when halls refresh
  useEffect(() => {
    if (selectedHall) {
      const updated = halls.find((h) => h.id === selectedHall.id);
      if (updated) setSelectedHall(updated);
    }
  }, [halls, selectedHall]);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#0B241C]">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 flex items-center justify-between gap-8 border-b border-[#0B3B2B]/12 bg-[#FAF8F5]/95 px-6 py-4 backdrop-blur-xs">
        {/* Zone 1: Single text element Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveView('marketplace');
          }}
          className="font-display text-2xl font-bold tracking-tight text-[#0B3B2B] whitespace-nowrap shrink-0"
        >
          {isAr ? 'مناسبتي · Munasabati' : 'Munasabati · مناسبتي'}
        </a>

        {/* Zone 2: 5 Single-Line Navigation Links */}
        <nav className="hidden items-center gap-7 text-sm font-medium text-[#1E352D] md:flex">
          <button
            type="button"
            onClick={() => setActiveView('marketplace')}
            className={`transition-colors hover:text-[#0B3B2B] whitespace-nowrap shrink-0 ${
              activeView === 'marketplace' ? 'font-bold text-[#0B3B2B] underline underline-offset-8' : ''
            }`}
          >
            {isAr ? 'استكشاف القاعات' : 'Explore Venues'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (!user) {
                handlePersonaSwitch(4); // Switch to Customer demo if not signed in
              } else {
                setActiveView('customer_portal');
              }
            }}
            className={`transition-colors hover:text-[#0B3B2B] whitespace-nowrap shrink-0 ${
              activeView === 'customer_portal' ? 'font-bold text-[#0B3B2B] underline underline-offset-8' : ''
            }`}
          >
            {isAr ? 'حجوزاتي وعقودي' : 'My Bookings'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'hall_owner' || user?.role_slug === 'super_admin') {
                setActiveView('owner_portal');
              } else {
                handlePersonaSwitch(2); // Switch to verified Hall Owner
              }
            }}
            className={`transition-colors hover:text-[#0B3B2B] whitespace-nowrap shrink-0 ${
              activeView === 'owner_portal' ? 'font-bold text-[#0B3B2B] underline underline-offset-8' : ''
            }`}
          >
            {isAr ? 'استوديو الملاك' : 'Hall Owner Studio'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'support_agent' || user?.role_slug === 'super_admin') {
                setActiveView('support_portal');
              } else {
                handlePersonaSwitch(6); // Switch to Support Agent
              }
            }}
            className={`transition-colors hover:text-[#0B3B2B] whitespace-nowrap shrink-0 ${
              activeView === 'support_portal' ? 'font-bold text-[#0B3B2B] underline underline-offset-8' : ''
            }`}
          >
            {isAr ? 'مركز دعم العملاء' : 'Support Desk'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'super_admin' || user?.role_slug === 'employee') {
                setActiveView('admin_portal');
              } else {
                handlePersonaSwitch(1); // Switch to Super Admin
              }
            }}
            className={`transition-colors hover:text-[#0B3B2B] whitespace-nowrap shrink-0 ${
              activeView === 'admin_portal' ? 'font-bold text-[#0B3B2B] underline underline-offset-8' : ''
            }`}
          >
            {user?.role_slug === 'employee'
              ? isAr
                ? 'بوابة الموظفين'
                : 'Employee Desk'
              : isAr
              ? 'الإدارة العامة'
              : 'General Manager'}
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action Button */}
        <div className="flex items-center shrink-0">
          {user ? (
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#0F4C3A] whitespace-nowrap shrink-0"
            >
              {user.name.split('(')[0].trim()} · {isAr ? user.role_name_ar : user.role_name_en}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setShowAuthModal(true)}
              className="rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#0F4C3A] whitespace-nowrap shrink-0"
            >
              {isAr ? 'تسجيل الدخول / إنشاء حساب' : 'Sign In / Register'}
            </button>
          )}
        </div>
      </header>

      {/* Secondary Workspace Role, Language & Currency Toolbar (Below Top Bar) */}
      <div className="border-b border-[#0B3B2B]/10 bg-[#F3EFEA] px-6 py-2.5">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 text-xs">
          {/* Instant Role Switcher for Testing all 5 Personas */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-semibold text-[#52635B]">
              {isAr ? 'تبديل فوري لحسابات الاختبار:' : 'Quick Role Switcher:'}
            </span>
            {demoPersonas.map((p) => {
              const pid = Number(p.id);
              const isActive = user?.id === pid;
              return (
                <button
                  key={pid}
                  type="button"
                  onClick={() => handlePersonaSwitch(pid)}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[#0B3B2B] text-white'
                      : 'bg-white text-[#0B241C] hover:border-[#0B3B2B]/30'
                  }`}
                >
                  {isAr ? String(p.role_name_ar) : String(p.role_name_en)}
                </button>
              );
            })}
          </div>

          {/* Language (RTL/LTR) & Currency Controls */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 rounded-md bg-white p-0.5">
              {(['YER', 'SAR', 'USD'] as CurrencyCode[]).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCurrency(c)}
                  className={`rounded px-2 py-1 font-mono text-[11px] font-semibold tabular-nums ${
                    currency === c ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setLocale(isAr ? 'en' : 'ar')}
              className="inline-flex items-center gap-1.5 rounded-md bg-white px-3 py-1 font-semibold text-[#0B241C] hover:bg-[#FAF8F5]"
            >
              <Globe className="h-3.5 w-3.5 text-[#0B3B2B]" />
              <span>{isAr ? 'English (LTR)' : 'العربية (RTL)'}</span>
            </button>

            {user && (
              <button
                type="button"
                onClick={handleLogout}
                className="inline-flex items-center gap-1 text-red-800 hover:underline"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>{isAr ? 'خروج' : 'Logout'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile / Android Responsive Navigation Strip (No horizontal page overflow) */}
        <nav className="mt-2.5 flex items-center gap-2 overflow-x-auto border-t border-[#0B3B2B]/10 pt-2.5 text-xs font-semibold md:hidden">
          <button
            type="button"
            onClick={() => setActiveView('marketplace')}
            className={`rounded-md px-3 py-1.5 whitespace-nowrap shrink-0 ${
              activeView === 'marketplace' ? 'bg-[#0B3B2B] text-white' : 'bg-white text-[#0B241C]'
            }`}
          >
            {isAr ? 'استكشاف القاعات' : 'Explore'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (!user) handlePersonaSwitch(4);
              else setActiveView('customer_portal');
            }}
            className={`rounded-md px-3 py-1.5 whitespace-nowrap shrink-0 ${
              activeView === 'customer_portal' ? 'bg-[#0B3B2B] text-white' : 'bg-white text-[#0B241C]'
            }`}
          >
            {isAr ? 'حجوزاتي وعقودي' : 'My Bookings'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'hall_owner' || user?.role_slug === 'super_admin') {
                setActiveView('owner_portal');
              } else {
                handlePersonaSwitch(2);
              }
            }}
            className={`rounded-md px-3 py-1.5 whitespace-nowrap shrink-0 ${
              activeView === 'owner_portal' ? 'bg-[#0B3B2B] text-white' : 'bg-white text-[#0B241C]'
            }`}
          >
            {isAr ? 'استوديو الملاك' : 'Owner Studio'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'support_agent' || user?.role_slug === 'super_admin') {
                setActiveView('support_portal');
              } else {
                handlePersonaSwitch(6);
              }
            }}
            className={`rounded-md px-3 py-1.5 whitespace-nowrap shrink-0 ${
              activeView === 'support_portal' ? 'bg-[#0B3B2B] text-white' : 'bg-white text-[#0B241C]'
            }`}
          >
            {isAr ? 'مركز الدعم' : 'Support'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (user?.role_slug === 'super_admin' || user?.role_slug === 'employee') {
                setActiveView('admin_portal');
              } else {
                handlePersonaSwitch(1);
              }
            }}
            className={`rounded-md px-3 py-1.5 whitespace-nowrap shrink-0 ${
              activeView === 'admin_portal' ? 'bg-[#0B3B2B] text-white' : 'bg-white text-[#0B241C]'
            }`}
          >
            {isAr ? 'الإدارة العامة' : 'Admin'}
          </button>
        </nav>
      </div>

      {/* Main Viewport Router */}
      {activeView === 'customer_portal' && (
        <CustomerDashboard
          locale={locale}
          currency={currency}
          halls={halls}
          onSelectHall={(hall) => setSelectedHall(hall)}
          onToggleFavorite={handleToggleFavorite}
          apiFetch={apiFetch}
        />
      )}

      {activeView === 'owner_portal' && (
        <OwnerPortal
          locale={locale}
          currency={currency}
          apiFetch={apiFetch}
          onMarketplaceRefresh={bootstrapMarketplace}
        />
      )}

      {activeView === 'support_portal' && <SupportPortal locale={locale} apiFetch={apiFetch} />}

      {activeView === 'admin_portal' && (
        <SuperAdminPortal
          locale={locale}
          currency={currency}
          apiFetch={apiFetch}
          onMarketplaceRefresh={bootstrapMarketplace}
        />
      )}

      {activeView === 'marketplace' && (
        <main>
          {/* Section 1: Storefront Split Hero Showcase */}
          <section className="bg-[#071D15] text-[#FAF8F5]">
            <div className="mx-auto grid max-w-7xl grid-cols-1 items-stretch gap-10 px-6 py-14 lg:grid-cols-12">
              <div className="flex flex-col justify-center space-y-6 lg:col-span-7">
                <div className="text-xs font-medium tracking-wide text-[#C5A059]">
                  {isAr
                    ? 'المنصة المعتمدة لقصور الأفراح والفعاليات الكبرى · عقود موثقة وتقويم توفر فوري'
                    : 'Premier Luxury Wedding & Event Venue Marketplace · Verified Contracts & Real-Time Availability'}
                </div>

                <h1 className="font-display text-4xl leading-tight font-bold text-[#FAF8F5] sm:text-5xl">
                  {isAr
                    ? 'احجز أرقى قصور الأفراح وقاعات المناسبات بثقة ملكية وتأكيد فوري'
                    : 'Reserve Extraordinary Wedding Palaces & Event Venues with Instant Confirmation'}
                </h1>

                <p className="max-w-2xl text-base leading-relaxed text-[#D5DFDA]">
                  {isAr
                    ? 'تجمع منصة مناسبتي أفخم القاعات الموثقة في صنعاء، عدن، تعز، وإب مع تصنيف دقيق لملاءمة القاعة (للنساء فقط، للرجال فقط، أو مشتركة) ودعم كامل للحجوزات ليوم واحد أو عدة أيام متتالية.'
                    : 'Discover architecturally distinguished ballrooms and coastal palaces with exact suitability classification (WOMEN_ONLY, MEN_ONLY, MIXED) and true multi-day reservation support.'}
                </p>

                {/* Live Availability & Venue Search Bar */}
                <div className="rounded-xl border border-[#C5A059]/30 bg-[#0B2920] p-4 shadow-xl">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
                    <div>
                      <label className="mb-1 block text-[11px] text-[#C5A059]">
                        {isAr ? 'المحافظة / المدينة' : 'Governorate / City'}
                      </label>
                      <select
                        value={cityFilter}
                        onChange={(e) => setCityFilter(e.target.value)}
                        className="w-full rounded-lg border border-white/15 bg-[#071D15] px-3 py-2 text-xs text-white"
                      >
                        <option value="all">{isAr ? 'جميع محافظات ومدن اليمن' : 'All Yemeni Governorates'}</option>
                        {YEMEN_GOVERNORATES.map((gov) => (
                          <option key={gov.code} value={gov.code}>
                            {isAr ? gov.ar : gov.en}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] text-[#C5A059]">
                        {isAr ? 'ملاءمة القاعة' : 'Hall Suitability'}
                      </label>
                      <select
                        value={suitabilityFilter}
                        onChange={(e) => setSuitabilityFilter(e.target.value)}
                        className="w-full rounded-lg border border-white/15 bg-[#071D15] px-3 py-2 text-xs text-white"
                      >
                        <option value="all">{isAr ? 'الكل (نساء / رجال / مشتركة)' : 'All Suitability Types'}</option>
                        {SUITABILITY_TYPES.map((st) => (
                          <option key={st.slug} value={st.slug}>
                            {isAr ? st.label_ar : st.label_en}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] text-[#C5A059]">
                        {isAr ? 'تاريخ البداية' : 'Start Date'}
                      </label>
                      <input
                        type="date"
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value)}
                        className="w-full rounded-lg border border-white/15 bg-[#071D15] px-2.5 py-2 font-mono text-xs text-white tabular-nums"
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] text-[#C5A059]">
                        {isAr ? 'عدد الأيام المتتالية' : 'Consecutive Days'}
                      </label>
                      <select
                        value={bookedDaysFilter}
                        onChange={(e) => setBookedDaysFilter(Number(e.target.value))}
                        className="w-full rounded-lg border border-white/15 bg-[#071D15] px-3 py-2 font-mono text-xs text-white tabular-nums"
                      >
                        {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                          <option key={d} value={d}>
                            {d} {isAr ? (d === 1 ? 'يوم واحد' : 'أيام متتالية') : d === 1 ? '1 Day' : 'Days'}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] text-[#C5A059]">
                        {isAr ? 'عدد الضيوف' : 'Guest Count'}
                      </label>
                      <select
                        value={minGuests}
                        onChange={(e) => setMinGuests(Number(e.target.value))}
                        className="w-full rounded-lg border border-white/15 bg-[#071D15] px-3 py-2 font-mono text-xs text-white tabular-nums"
                      >
                        <option value={0}>{isAr ? 'أي سعة' : 'Any Capacity'}</option>
                        <option value={300}>300+ {isAr ? 'ضيف' : 'Guests'}</option>
                        <option value={500}>500+ {isAr ? 'ضيف' : 'Guests'}</option>
                        <option value={800}>800+ {isAr ? 'ضيف' : 'Guests'}</option>
                      </select>
                    </div>

                    <div className="flex items-end">
                      <a
                        href="#venues-grid"
                        className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-[#C5A059] px-4 py-2 text-xs font-bold text-[#071D15] transition-colors hover:bg-[#D4AF37]"
                      >
                        <Search className="h-3.5 w-3.5" />
                        <span>{isAr ? 'عرض القاعات' : 'Find Venues'}</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Hero Architectural Palace Showcase */}
              <div className="flex flex-col justify-between overflow-hidden rounded-2xl border border-[#C5A059]/30 bg-[#0B2920] lg:col-span-5">
                <VenueImage
                  src="/api/artwork/taj-royal-palace"
                  alt={isAr ? 'قصر التاج الملكي للمناسبات والأفراح' : 'Royal Crown Grand Palace'}
                  loading="eager"
                  className="aspect-[16/10] w-full lg:h-full"
                />
                <div className="flex items-center justify-between border-t border-white/10 bg-[#071D15]/90 px-5 py-3.5 text-xs">
                  <div>
                    <div className="font-display text-base font-bold text-[#FAF8F5]">
                      {isAr ? 'قصر التاج الملكي — صنعاء' : "Royal Crown Palace — Sana'a"}
                    </div>
                    <div className="text-[#C5A059]">
                      {isAr ? 'تصميم أندلسي ملكي · سعة حتى 1,000 ضيف' : 'Andalusian Grandeur · Up to 1,000 Guests'}
                    </div>
                  </div>
                  {halls[0] && (
                    <button
                      type="button"
                      onClick={() => setSelectedHall(halls[0])}
                      className="rounded-lg border border-[#C5A059]/50 px-3.5 py-1.5 text-xs font-semibold text-[#F3E5AB] hover:bg-[#C5A059]/15"
                    >
                      {isAr ? 'استعراض وحجز' : 'Inspect Venue'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </section>

          {/* Section 2: Featured Venue Collection Grid (3-Column Desktop) */}
          <section id="venues-grid" className="mx-auto max-w-7xl px-6 py-14">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4 border-b border-[#0B3B2B]/12 pb-5">
              <div>
                <div className="text-xs font-semibold text-[#8A6829]">
                  {isAr ? 'القاعات والقصور المعتمدة رسمياً' : 'Verified Luxury Venues & Ballrooms'}
                </div>
                <h2 className="font-display text-3xl font-bold text-[#0B241C]">
                  {isAr
                    ? `مجموعة القاعات المتاحة للحجز (${filteredHalls.length})`
                    : `Available Curated Venues (${filteredHalls.length})`}
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Governorate / City Filter (All 22 Yemeni Governorates) */}
                <select
                  value={cityFilter}
                  onChange={(e) => setCityFilter(e.target.value)}
                  aria-label="Filter by Governorate"
                  className="rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs font-semibold text-[#0B241C]"
                >
                  <option value="all">{isAr ? 'المحافظة / المدينة (جميع محافظات اليمن)' : 'All Yemeni Governorates'}</option>
                  {YEMEN_GOVERNORATES.map((gov) => (
                    <option key={gov.code} value={gov.code}>
                      {isAr ? gov.ar : gov.en}
                    </option>
                  ))}
                </select>

                {/* Primary Suitability Filter: WOMEN_ONLY, MEN_ONLY, MIXED */}
                <select
                  value={suitabilityFilter}
                  onChange={(e) => setSuitabilityFilter(e.target.value)}
                  aria-label="Filter by Hall Suitability Type"
                  className="rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs font-semibold text-[#0B241C]"
                >
                  <option value="all">{isAr ? 'جميع تصنيفات الملاءمة (WOMEN / MEN / MIXED)' : 'All Suitability Types'}</option>
                  {SUITABILITY_TYPES.map((st) => (
                    <option key={st.slug} value={st.slug}>
                      {isAr ? `${st.label_ar} (${st.slug})` : `${st.label_en} (${st.slug})`}
                    </option>
                  ))}
                </select>

                {/* Separate General Venue Category Filter */}
                <select
                  value={hallTypeFilter}
                  onChange={(e) => setHallTypeFilter(e.target.value)}
                  aria-label="Filter by Hall Type"
                  className="rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs text-[#0B241C]"
                >
                  <option value="all">{isAr ? 'جميع فئات القاعات' : 'All Venue Categories'}</option>
                  {HALL_TYPES.map((ht) => (
                    <option key={ht.slug} value={ht.slug}>
                      {isAr ? ht.label_ar : ht.label_en}
                    </option>
                  ))}
                </select>

                <select
                  value={maxPriceFilter}
                  onChange={(e) => setMaxPriceFilter(Number(e.target.value))}
                  className="rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs text-[#0B241C]"
                >
                  <option value={0}>{isAr ? 'جميع الأسعار' : 'Any Price'}</option>
                  <option value={300000}>{isAr ? 'أقل من 300,000 ر.ي' : 'Under 300,000 YER'}</option>
                  <option value={450000}>{isAr ? 'أقل من 450,000 ر.ي' : 'Under 450,000 YER'}</option>
                  <option value={650000}>{isAr ? 'أقل من 650,000 ر.ي' : 'Under 650,000 YER'}</option>
                </select>

                <select
                  value={facilityFilter}
                  onChange={(e) => setFacilityFilter(e.target.value)}
                  className="rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs text-[#0B241C]"
                >
                  <option value="all">{isAr ? 'جميع المرافق والتجهيزات' : 'All Facilities'}</option>
                  <option value="1">{isAr ? 'تكييف مركزي متطور' : 'Central A/C'}</option>
                  <option value="2">{isAr ? 'كوشة زفاف ملكية' : 'Bridal Stage'}</option>
                  <option value="3">{isAr ? 'نظام صوتيات وإضاءة احترافي' : 'Sound & Lighting System'}</option>
                  <option value="4">{isAr ? 'مواقف سيارات محروسة' : 'Valet & Guarded Parking'}</option>
                  <option value="5">{isAr ? 'جناح خاص للعروسين' : 'Bridal Suite'}</option>
                  <option value="6">{isAr ? 'مولدات كهربائية احتياطية' : 'Backup Generators'}</option>
                </select>

                <div className="relative">
                  <Search className="pointer-events-none absolute top-2.5 start-3 h-4 w-4 text-[#52635B]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={isAr ? 'ابحث باسم القاعة أو الحي...' : 'Search venue name or address...'}
                    className="w-56 rounded-lg border border-[#0B3B2B]/20 bg-white py-2 ps-9 pe-3 text-xs"
                  />
                </div>

                {compareIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowCompareModal(true)}
                    className="rounded-lg bg-[#0B3B2B] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                  >
                    {isAr ? `مقارنة القاعات (${compareIds.length})` : `Compare (${compareIds.length})`}
                  </button>
                )}

                {(cityFilter !== 'all' ||
                  suitabilityFilter !== 'all' ||
                  hallTypeFilter !== 'all' ||
                  dateFilter ||
                  minGuests > 0 ||
                  maxPriceFilter > 0 ||
                  facilityFilter !== 'all' ||
                  searchQuery) && (
                  <button
                    type="button"
                    onClick={() => {
                      setCityFilter('all');
                      setSuitabilityFilter('all');
                      setHallTypeFilter('all');
                      setDateFilter('');
                      setBookedDaysFilter(1);
                      setMinGuests(0);
                      setMaxPriceFilter(0);
                      setFacilityFilter('all');
                      setSearchQuery('');
                    }}
                    className="text-xs font-semibold text-[#8A6829] hover:underline"
                  >
                    {isAr ? 'إعادة ضبط الفلاتر' : 'Reset Filters'}
                  </button>
                )}
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3].map((n) => (
                  <div key={n} className="h-96 animate-pulse rounded-xl bg-[#F3EFEA]" />
                ))}
              </div>
            ) : filteredHalls.length === 0 ? (
              <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-12 text-center">
                <Building2 className="mx-auto mb-3 h-10 w-10 text-[#8A6829]" />
                <h3 className="font-display text-xl font-bold text-[#0B241C]">
                  {isAr ? 'لا توجد قاعات مطابقة لشروط البحث المحددة' : 'No venues match your current filter'}
                </h3>
                <p className="mt-1 text-xs text-[#52635B]">
                  {isAr
                    ? 'جرب اختيار تاريخ آخر أو عرض جميع المدن لاستكشاف القاعات المتاحة.'
                    : 'Try selecting another date or clearing the city filter.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {filteredHalls.map((hall) => {
                  const isFav = favorites.includes(hall.id);
                  const suitCode = hall.suitability_type || 'MIXED';
                  return (
                    <article
                      key={hall.id}
                      onClick={() => setSelectedHall(hall)}
                      className="group flex cursor-pointer flex-col overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white transition-transform duration-200 ease-out hover:-translate-y-0.5 hover:shadow-lg"
                    >
                      {/* Product Image (65%+ height ratio, 4:3 aspect) */}
                      <div className="relative">
                        <VenueImage
                          src={hall.images[0]?.image_url}
                          alt={isAr ? hall.name_ar : hall.name_en || hall.name_ar}
                          className="aspect-[4/3] w-full"
                        />
                        <div className="absolute top-3 end-3 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => handleToggleCompare(hall.id, e)}
                            className={`rounded-md px-2.5 py-1 text-[11px] font-semibold backdrop-blur-xs transition-colors ${
                              compareIds.includes(hall.id)
                                ? 'bg-[#C5A059] text-[#071D15]'
                                : 'bg-black/55 text-white hover:bg-black/75'
                            }`}
                          >
                            {compareIds.includes(hall.id)
                              ? isAr
                                ? 'مضافة للمقارنة ✓'
                                : 'Comparing ✓'
                              : isAr
                              ? '+ مقارنة'
                              : '+ Compare'}
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleToggleFavorite(hall.id, e)}
                            aria-label="Favorite"
                            className="rounded-full bg-black/45 p-2 text-white backdrop-blur-xs transition-colors hover:bg-black/70"
                          >
                            <Heart className={`h-4 w-4 ${isFav ? 'fill-[#C5A059] text-[#C5A059]' : 'text-white'}`} />
                          </button>
                        </div>
                      </div>

                      {/* Card Body: Zero-Pill Clean Unboxed Metadata */}
                      <div className="flex flex-1 flex-col justify-between p-5">
                        <div>
                          {/* Unboxed Metadata Line with Verified-Owner Indicator */}
                          <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#52635B]">
                            <span className="font-semibold text-[#0B3B2B]">{getCityLabel(hall.city, locale)}</span>
                            <span aria-hidden="true">·</span>
                            {hall.owner_verified !== 0 && (
                              <>
                                <span className="font-semibold text-emerald-800">
                                  {isAr ? 'مالك موثق ✓' : 'Verified Owner ✓'}
                                </span>
                                <span aria-hidden="true">·</span>
                              </>
                            )}
                            <span className="font-mono tabular-nums">
                              {hall.capacity_min}–{hall.capacity_max} {isAr ? 'ضيف' : 'Guests'}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="inline-flex items-center gap-1 font-mono text-[#8A6829] tabular-nums">
                              <Star className="h-3.5 w-3.5 fill-[#C5A059] text-[#C5A059]" />
                              {Number(hall.rating).toFixed(2)}
                            </span>
                          </div>

                          {/* Venue Title */}
                          <h3 className="mt-2 font-display text-xl font-bold text-[#0B241C] group-hover:text-[#0B3B2B]">
                            {isAr ? hall.name_ar : hall.name_en || hall.name_ar}
                          </h3>

                          {/* Exact Hall Suitability Classification (WOMEN_ONLY | MEN_ONLY | MIXED) + Venue Category */}
                          <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] font-semibold">
                            <span className="text-[#0B3B2B]">
                              {getSuitabilityLabel(suitCode, locale)} ({suitCode})
                            </span>
                            <span aria-hidden="true" className="text-[#52635B]">·</span>
                            <span className="text-[#8A6829]">
                              {getHallTypeLabel(hall.hall_type || 'wedding_hall', locale)}
                            </span>
                          </div>

                          <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-[#52635B]">
                            {isAr ? hall.description_ar : hall.description_en || hall.description_ar}
                          </p>

                          {/* Clear, Well-Spaced Facilities & Equipment (المرافق والتجهيزات) */}
                          {hall.facilities && hall.facilities.length > 0 && (
                            <div className="mt-3 pt-2.5 border-t border-[#0B3B2B]/8">
                              <div className="mb-1.5 text-[11px] font-bold tracking-normal text-[#0B3B2B]">
                                {isAr ? 'المرافق والتجهيزات:' : 'Facilities & Equipment:'}
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {hall.facilities.slice(0, 3).map((fac) => (
                                  <span
                                    key={fac.facility_id}
                                    className="inline-flex items-center rounded-md border border-[#0B3B2B]/15 bg-[#FAF8F5] px-2.5 py-1 text-xs font-medium leading-relaxed tracking-normal text-[#0B241C]"
                                  >
                                    {isAr ? fac.name_ar : fac.name_en}
                                  </span>
                                ))}
                                {hall.facilities.length > 3 && (
                                  <span className="inline-flex items-center rounded-md border border-[#C5A059]/40 bg-[#FAF8F5] px-2.5 py-1 text-xs font-semibold leading-relaxed tracking-normal text-[#8A6829]">
                                    +{hall.facilities.length - 3} {isAr ? 'مرافق إضافية' : 'more'}
                                  </span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Baseline Aligned Price & Action Row */}
                        <div className="mt-5 flex items-center justify-between border-t border-[#0B3B2B]/10 pt-3.5">
                          <div>
                            <span className="block text-[11px] text-[#52635B]">
                              {isAr ? 'السعر لليوم الواحد يبدأ من' : 'Price per day starting from'}
                            </span>
                            <span className="font-mono text-base font-bold text-[#0B241C] tabular-nums">
                              {formatMoney(hall.starting_price, currency, locale)}
                            </span>
                          </div>

                          <span className="rounded-lg bg-[#0B3B2B] px-3.5 py-2 text-xs font-semibold text-white transition-colors group-hover:bg-[#0F4C3A]">
                            {isAr ? 'فحص التوفر والحجز' : 'Check Availability'}
                          </span>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>

          {/* Section 3: Architectural Craftsmanship, Verified Proof & Attributable Testimonials */}
          <section className="border-t border-[#0B3B2B]/10 bg-[#F3EFEA] py-14">
            <div className="mx-auto max-w-7xl space-y-10 px-6">
              <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
                <div className="space-y-3 lg:col-span-5">
                  <div className="text-xs font-semibold text-[#8A6829]">
                    {isAr ? 'معايير الموثوقية والحوكمة' : 'Verified Marketplace Trust & Governance'}
                  </div>
                  <h2 className="font-display text-3xl font-bold text-[#0B241C]">
                    {isAr
                      ? 'لماذا يثق العرسان وملاك القصور بمنصة مناسبتي؟'
                      : 'Engineered for Zero-Conflict Reservations & Financial Transparency'}
                  </h2>
                  <p className="text-sm leading-relaxed text-[#52635B]">
                    {isAr
                      ? 'تخضع كل قاعة مدرجة للتدقيق القانوني والمعماري من قبل الإدارة العليا، وتُدار الحجوزات الفردية ومتعددة الأيام عبر محرك قواعد بيانات ذري يمنع ازدواجية الحجز.'
                      : 'Every venue undergoes strict commercial registration verification by our Super Admin team, backed by ACID transaction locks across single-day and multi-day bookings.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 lg:col-span-7">
                  <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
                    <ShieldCheck className="mb-2 h-6 w-6 text-[#0B3B2B]" />
                    <div className="font-display text-lg font-bold text-[#0B241C]">
                      {isAr ? 'حماية 100% من تضارب المواعيد' : '100% Conflict-Free Calendar'}
                    </div>
                    <p className="mt-1 text-xs text-[#52635B]">
                      {isAr
                        ? 'قفل فوري للفترة والتواريخ المتتالية بمجرد تأكيد العربون لمنع أي حجز مزدوج.'
                        : 'Atomic database locks prevent overlapping single-day and multi-day reservations.'}
                    </p>
                  </div>

                  <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
                    <Calendar className="mb-2 h-6 w-6 text-[#8A6829]" />
                    <div className="font-display text-lg font-bold text-[#0B241C]">
                      {isAr ? 'حجوزات متعددة الأيام بحساب خادم دقيق' : 'Server-Verified Multi-Day Pricing'}
                    </div>
                    <p className="mt-1 text-xs text-[#52635B]">
                      {isAr
                        ? 'حساب تلقائي على الخادم لتاريخ البداية والنهاية، عدد الأيام، الخصومات، الرسوم الإضافية، والضرائب.'
                        : 'Server-calculated start/end dates, consecutive day counts, discounts, and fees.'}
                    </p>
                  </div>

                  <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
                    <Users className="mb-2 h-6 w-6 text-[#0B3B2B]" />
                    <div className="font-display text-lg font-bold text-[#0B241C]">
                      {isAr ? 'تصنيف ملاءمة واضح ودقيق' : 'Exact Hall Suitability Classification'}
                    </div>
                    <p className="mt-1 text-xs text-[#52635B]">
                      {isAr
                        ? 'تصنيف رسمي مهيكل لكل قاعة: للنساء فقط (WOMEN_ONLY)، للرجال فقط (MEN_ONLY)، أو مشتركة (MIXED).'
                        : 'Structured suitability classification: WOMEN_ONLY, MEN_ONLY, or MIXED.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Attributable Customer Testimonials */}
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                {reviews.slice(0, 2).map((rev, idx) => (
                  <div key={idx} className="rounded-xl border border-[#0B3B2B]/12 bg-white p-6">
                    <div className="mb-2 flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#0B3B2B]">{String(rev.hall_name_ar)}</span>
                      <span className="font-mono text-[#8A6829] tabular-nums">★★★★★ (5.0)</span>
                    </div>
                    <p className="text-sm leading-relaxed text-[#0B241C]">“{String(rev.comment)}”</p>
                    <div className="mt-3 text-xs text-[#52635B]">
                      — {String(rev.customer_name)} · {isAr ? 'حجز موثق عبر منصة مناسبتي' : 'Verified Munasabati Booking'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </main>
      )}

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#0B3B2B]/12 bg-[#FAF8F5] px-6 py-8 text-xs text-[#52635B]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4">
          <div className="font-display text-base font-bold text-[#0B3B2B]">
            {isAr
              ? 'مناسبتي — المنصة الفاخرة لحجز قاعات الأفراح والمناسبات'
              : 'Munasabati — Luxury Wedding & Event Venue Marketplace'}
          </div>
          <div className="flex items-center gap-6">
            <button type="button" onClick={() => setActiveView('marketplace')} className="hover:text-[#0B241C]">
              {isAr ? 'القاعات المعتمدة' : 'Approved Venues'}
            </button>
            <button type="button" onClick={() => handlePersonaSwitch(2)} className="hover:text-[#0B241C]">
              {isAr ? 'بوابة ملاك القاعات' : 'Hall Owners'}
            </button>
            <button type="button" onClick={() => handlePersonaSwitch(6)} className="hover:text-[#0B241C]">
              {isAr ? 'مركز الدعم والشكاوى' : 'Support Center'}
            </button>
            <button type="button" onClick={() => handlePersonaSwitch(1)} className="hover:text-[#0B241C]">
              {isAr ? 'الإدارة العليا' : 'Super Admin'}
            </button>
          </div>
          <div className="font-mono tabular-nums">© 2026 Munasabati Marketplace</div>
        </div>
      </footer>

      {/* Venue Detail & Contiguous Booking Modal */}
      {selectedHall && (
        <VenueDetailModal
          hall={selectedHall}
          locale={locale}
          currency={currency}
          user={user}
          reviews={reviews}
          onClose={() => setSelectedHall(null)}
          onRequireLogin={() => {
            setSelectedHall(null);
            setShowAuthModal(true);
          }}
          onBookingCreated={bootstrapMarketplace}
          apiFetch={apiFetch}
        />
      )}

      {/* Login / Registration Modal — Login uses Email & Password ONLY (no account-role selector on login page) */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl border border-[#0B3B2B]/15 bg-[#FAF8F5] p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between border-b border-[#0B3B2B]/10 pb-3">
              <h3 className="font-display text-xl font-bold text-[#0B241C]">
                {authMode === 'login'
                  ? isAr
                    ? 'تسجيل الدخول إلى مناسبتي'
                    : 'Sign In to Munasabati'
                  : isAr
                  ? 'إنشاء حساب جديد (عميل أو مالك قاعة)'
                  : 'Create Account (Customer or Hall Owner)'}
              </h3>
              <button onClick={() => setShowAuthModal(false)} className="rounded p-1 hover:bg-[#F3EFEA]">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mb-4 flex rounded-lg bg-[#F3EFEA] p-1">
              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className={`flex-1 rounded-md py-1.5 text-xs font-semibold ${
                  authMode === 'login' ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                }`}
              >
                {isAr ? 'تسجيل الدخول' : 'Sign In'}
              </button>
              <button
                type="button"
                onClick={() => setAuthMode('register')}
                className={`flex-1 rounded-md py-1.5 text-xs font-semibold ${
                  authMode === 'register' ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                }`}
              >
                {isAr ? 'تسجيل حساب جديد' : 'Register'}
              </button>
            </div>

            {authMode === 'login' && (
              <p className="mb-3 text-xs text-[#52635B]">
                {isAr
                  ? 'أدخل بريدك الإلكتروني وكلمة المرور فقط؛ يقوم الخادم تلقائياً بتحديد دور حسابك وصلاحياتك المعتمدة.'
                  : 'Sign in with your email and password; the server automatically determines your role and authorized permissions.'}
              </p>
            )}

            {authError && (
              <div className="mb-3 rounded-lg border border-red-800/30 bg-red-950/5 p-2.5 text-xs text-red-800">
                {authError}
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-3">
              {authMode === 'register' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setRegAccountType('customer')}
                      className={`rounded-lg border py-2 text-xs font-semibold ${
                        regAccountType === 'customer'
                          ? 'border-[#0B3B2B] bg-[#0B3B2B]/10 text-[#0B3B2B]'
                          : 'border-[#0B3B2B]/15 text-[#52635B]'
                      }`}
                    >
                      {isAr ? 'حساب عميل (حجز قاعة)' : 'Customer Account'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegAccountType('hall_owner')}
                      className={`rounded-lg border py-2 text-xs font-semibold ${
                        regAccountType === 'hall_owner'
                          ? 'border-[#0B3B2B] bg-[#0B3B2B]/10 text-[#0B3B2B]'
                          : 'border-[#0B3B2B]/15 text-[#52635B]'
                      }`}
                    >
                      {isAr ? 'حساب مالك قاعة' : 'Hall Owner Account'}
                    </button>
                  </div>

                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder={isAr ? 'الاسم الكامل *' : 'Full Name *'}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs"
                  />

                  <input
                    type="text"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder={isAr ? 'رقم الجوال (+967...) *' : 'Phone Number *'}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 font-mono text-xs tabular-nums"
                  />

                  {regAccountType === 'hall_owner' && (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          required
                          value={regBusinessName}
                          onChange={(e) => setRegBusinessName(e.target.value)}
                          placeholder={isAr ? 'الاسم التجاري للقاعة *' : 'Business Name *'}
                          className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 text-xs"
                        />
                        <input
                          type="text"
                          required
                          value={regCrNo}
                          onChange={(e) => setRegCrNo(e.target.value)}
                          placeholder={isAr ? 'رقم السجل التجاري *' : 'Commercial Reg # *'}
                          className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 font-mono text-xs"
                        />
                      </div>
                      <input
                        type="text"
                        required
                        value={regDocUrl}
                        onChange={(e) => setRegDocUrl(e.target.value)}
                        placeholder={isAr ? 'مرجع وثيقة الملكية أو التفويض الرسمي *' : 'Ownership / Authorization Document Ref *'}
                        className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 font-mono text-xs"
                      />
                    </div>
                  )}
                </>
              )}

              <input
                type="email"
                required
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                placeholder={isAr ? 'البريد الإلكتروني *' : 'Email Address *'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 font-mono text-xs"
              />

              <input
                type="password"
                required
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                placeholder={isAr ? 'كلمة المرور *' : 'Password *'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-2 font-mono text-xs"
              />

              {authMode === 'register' && (
                <label className="flex items-center gap-2 text-xs text-[#52635B]">
                  <input
                    type="checkbox"
                    checked={regTermsAccepted}
                    onChange={(e) => setRegTermsAccepted(e.target.checked)}
                    required
                    className="h-3.5 w-3.5 accent-[#0B3B2B]"
                  />
                  <span>
                    {isAr
                      ? 'أوافق على شروط وأحكام منصة مناسبتي وسياسة التوثيق والعربون'
                      : 'I accept the Munasabati Platform Terms & Verification Policy'}
                  </span>
                </label>
              )}

              <button
                type="submit"
                className="w-full rounded-lg bg-[#0B3B2B] py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
              >
                {authMode === 'login'
                  ? isAr
                    ? 'دخول إلى المنصة'
                    : 'Sign In'
                  : isAr
                  ? 'إنشاء الحساب الآن'
                  : 'Create Account'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Side-by-Side Venue Comparison Modal */}
      {showCompareModal && compareIds.length > 0 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs">
          <div className="w-full max-w-5xl rounded-2xl border border-[#0B3B2B]/15 bg-[#FAF8F5] p-6 shadow-2xl">
            <div className="mb-5 flex items-center justify-between border-b border-[#0B3B2B]/10 pb-3">
              <div>
                <h3 className="font-display text-2xl font-bold text-[#0B241C]">
                  {isAr ? 'مقارنة القاعات والقصور المختارة' : 'Side-by-Side Venue Comparison'}
                </h3>
                <p className="text-xs text-[#52635B]">
                  {isAr
                    ? 'قارن بين الملاءمة، السعة، الأسعار الرسمية، التجهيزات، والتقييم لاختيار القاعة الأنسب لمناسبتك'
                    : 'Compare suitability classification, guest capacity, package pricing, ratings, and included facilities'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setCompareIds([]);
                    setShowCompareModal(false);
                  }}
                  className="text-xs font-semibold text-red-800 hover:underline"
                >
                  {isAr ? 'مسح الكل' : 'Clear All'}
                </button>
                <button onClick={() => setShowCompareModal(false)} className="rounded p-1 hover:bg-[#F3EFEA]">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {halls
                .filter((h) => compareIds.includes(h.id))
                .map((h) => (
                  <div key={h.id} className="flex flex-col justify-between rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
                    <div className="space-y-3">
                      <VenueImage
                        src={h.images[0]?.image_url}
                        alt={isAr ? h.name_ar : h.name_en || h.name_ar}
                        className="aspect-[16/10] w-full rounded-lg"
                      />
                      <div>
                        <div className="text-xs font-semibold text-[#8A6829]">{getCityLabel(h.city, locale)}</div>
                        <h4 className="font-display text-lg font-bold text-[#0B241C]">
                          {isAr ? h.name_ar : h.name_en || h.name_ar}
                        </h4>
                      </div>
                      <div className="space-y-1.5 border-t border-[#0B3B2B]/10 pt-2.5 text-xs">
                        <div className="flex justify-between">
                          <span className="text-[#52635B]">{isAr ? 'ملاءمة القاعة:' : 'Suitability:'}</span>
                          <span className="font-semibold text-[#0B3B2B]">
                            {getSuitabilityLabel(h.suitability_type || 'MIXED', locale)} ({h.suitability_type || 'MIXED'})
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#52635B]">{isAr ? 'السعة:' : 'Capacity:'}</span>
                          <span className="font-mono font-semibold tabular-nums">
                            {h.capacity_min}–{h.capacity_max} {isAr ? 'ضيف' : 'Guests'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#52635B]">{isAr ? 'تبدأ الباقة من:' : 'Starting Price:'}</span>
                          <span className="font-mono font-bold text-[#0B3B2B] tabular-nums">
                            {formatMoney(h.starting_price, currency, locale)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#52635B]">{isAr ? 'التقييم العام:' : 'Rating:'}</span>
                          <span className="font-mono font-semibold text-[#8A6829] tabular-nums">
                            ★ {Number(h.rating).toFixed(2)} ({h.reviews_count})
                          </span>
                        </div>
                        <div className="pt-1.5">
                          <span className="block font-semibold text-[#52635B]">{isAr ? 'أبرز المرافق والتجهيزات:' : 'Included Facilities:'}</span>
                          <div className="mt-1.5 flex flex-wrap gap-1.5">
                            {h.facilities.slice(0, 4).map((f) => (
                              <span
                                key={f.facility_id}
                                className="rounded-md border border-[#0B3B2B]/15 bg-[#FAF8F5] px-2.5 py-1 text-xs font-medium leading-relaxed tracking-normal text-[#0B241C]"
                              >
                                {isAr ? f.name_ar : f.name_en}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setShowCompareModal(false);
                        setSelectedHall(h);
                      }}
                      className="mt-4 w-full rounded-lg bg-[#0B3B2B] py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                    >
                      {isAr ? 'فحص التوفر وحجز هذه القاعة' : 'Select & Book Venue'}
                    </button>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
