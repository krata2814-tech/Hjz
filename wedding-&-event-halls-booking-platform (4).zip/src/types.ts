export type Locale = 'ar' | 'en';
export type CurrencyCode = 'YER' | 'SAR' | 'USD';

export interface HallImage {
  id: number;
  hall_id: number;
  image_url: string;
  is_primary: number;
  caption?: string;
}

export interface HallPricing {
  id: number;
  hall_id: number;
  title_ar: string;
  title_en?: string;
  shift: 'morning' | 'evening' | 'full_day' | 'hourly';
  day_type: string;
  base_price: number;
  deposit_required: number;
  currency: string;
}

export interface HallFacility {
  hall_id: number;
  facility_id: number;
  name_ar: string;
  name_en: string;
  category: string;
  details?: string;
  is_complimentary: number;
  extra_charge: number;
}

export interface UnavailableSlot {
  hall_id: number;
  date: string;
  shift: string;
  status: string;
  reason?: string;
  start_time?: string;
  end_time?: string;
}

export type HallTypeSlug =
  | 'wedding_hall'
  | 'wedding'
  | 'mens_hall'
  | 'womens_hall'
  | 'engagement_hall'
  | 'engagement'
  | 'conference_hall'
  | 'conference'
  | 'graduation_hall'
  | 'graduation'
  | 'corporate_hall'
  | 'corporate'
  | 'open_garden'
  | 'garden'
  | 'multi_purpose';

export type SuitabilityType = 'WOMEN_ONLY' | 'MEN_ONLY' | 'MIXED';

export type GenderPolicySlug = SuitabilityType | 'separated_sections' | 'women_only' | 'men_only' | 'mixed_family' | 'mixed' | 'separate_sections';

export interface Hall {
  id: number;
  owner_id: number;
  owner_name: string;
  business_name?: string;
  owner_verified?: number;
  name_ar: string;
  name_en?: string;
  slug: string;
  description_ar: string;
  description_en?: string;
  city: string;
  district?: string;
  address: string;
  capacity_min: number;
  capacity_max: number;
  hall_type: HallTypeSlug | string;
  suitability_type: SuitabilityType;
  supported_event_types?: string;
  gender_policy?: GenderPolicySlug | string;
  booking_mode?: 'shifts_only' | 'hourly_only' | 'both' | string;
  morning_start_time?: string;
  morning_end_time?: string;
  evening_start_time?: string;
  evening_end_time?: string;
  full_day_start_time?: string;
  full_day_end_time?: string;
  min_booking_hours?: number;
  max_booking_hours?: number;
  overtime_hour_rate?: number;
  multi_day_discount_pct?: number;
  additional_fees?: number;
  featured: number;
  status: 'active' | 'pending' | 'rejected' | 'suspended';
  rejection_reason?: string;
  rating: number;
  reviews_count: number;
  starting_price: number;
  event_duration_hours?: number;
  prep_buffer_hours?: number;
  cleanup_buffer_hours?: number;
  hourly_rate?: number;
  supports_hourly?: number;
  supports_full_day?: number;
  images: HallImage[];
  pricing: HallPricing[];
  facilities: HallFacility[];
  unavailableSlots: UnavailableSlot[];
  created_at?: string;
}

export interface PermissionItem {
  id: number;
  slug: string;
  name_ar: string;
  name_en: string;
  module: string;
}

export interface EmployeeRecord {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive' | 'suspended';
  role_id: number;
  role_slug: string;
  role_name_ar: string;
  role_name_en: string;
  job_title: string;
  department: string;
  hire_date?: string;
  last_login_at?: string;
  created_at?: string;
  permissions: string[];
}

export interface UserSession {
  id: number;
  name: string;
  email: string;
  phone: string;
  role_id: number;
  role_slug: 'super_admin' | 'hall_owner' | 'customer' | 'support_agent' | 'employee';
  role_name_ar: string;
  role_name_en: string;
  status: string;
  job_title?: string;
  department?: string;
  permissions?: string[];
  favorites?: number[];
  notifications?: NotificationItem[];
}

export interface NotificationItem {
  id: number;
  user_id: number;
  title_ar: string;
  title_en?: string;
  message_ar: string;
  message_en?: string;
  type: string;
  is_read: number;
  created_at: string;
}

export interface ReviewItem {
  id: number;
  hall_id: number;
  customer_id: number;
  customer_name: string;
  hall_name_ar: string;
  hall_name_en?: string;
  rating_overall: number;
  comment: string;
  status: string;
  created_at: string;
}

export interface BookingQuote {
  hallId: number;
  pricingId: number | null;
  suitabilityType: SuitabilityType;
  startDate: string;
  endDate: string;
  bookedDays: number;
  dates: string[];
  shift: string;
  startTime: string;
  endTime: string;
  durationHours: number;
  pricePerDay: number;
  subtotalAmount: number;
  discountPercent: number;
  discountAmount: number;
  additionalFees: number;
  taxAmount: number;
  totalAmount: number;
  depositRequired: number;
  currency: string;
  available: boolean;
  conflictingDates: string[];
  conflictReason: string | null;
}

export interface BookingRecord {
  id: number;
  booking_code: string;
  hall_id: number;
  hall_name_ar: string;
  hall_name_en?: string;
  suitability_type?: SuitabilityType;
  hall_suitability_type?: SuitabilityType;
  hall_type?: string;
  city?: string;
  address?: string;
  customer_id: number;
  customer_name?: string;
  customer_phone?: string;
  customer_email?: string;
  owner_name?: string;
  event_date: string;
  start_date?: string;
  end_date?: string;
  days_count?: number;
  booked_days?: number;
  booked_dates?: string[];
  price_per_day?: number;
  base_price?: number;
  discount_percent?: number;
  additional_fees?: number;
  booked_dates_json?: string;
  shift: 'morning' | 'evening' | 'full_day' | 'hourly';
  event_type?: string;
  duration_hours?: number;
  start_time?: string;
  end_time?: string;
  prep_buffer_hours?: number;
  cleanup_buffer_hours?: number;
  guest_count: number;
  subtotal_amount: number;
  discount_amount?: number;
  tax_amount: number;
  total_amount: number;
  deposit_amount: number;
  remaining_amount: number;
  currency: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  payment_status: 'unpaid' | 'deposit_paid' | 'paid' | 'refunded';
  customer_notes?: string;
  created_at: string;
}

export interface PaymentRecord {
  id: number;
  payment_reference: string;
  booking_id: number;
  booking_code?: string;
  hall_name_ar?: string;
  payer_name?: string;
  payer_email?: string;
  amount: number;
  currency: string;
  payment_method: string;
  transaction_number: string;
  payment_type: string;
  status: 'verified' | 'pending_verification' | 'refunded';
  created_at: string;
}

export interface SupportTicket {
  id: number;
  ticket_code: string;
  user_id: number;
  customer_name?: string;
  customer_email?: string;
  customer_phone?: string;
  booking_id?: number;
  booking_code?: string;
  hall_id?: number;
  hall_name_ar?: string;
  category: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  subject: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  resolution_notes?: string;
  created_at: string;
  messages: Array<{
    id: number;
    ticket_id: number;
    sender_id: number;
    sender_name: string;
    sender_role: string;
    message: string;
    created_at: string;
  }>;
}

export interface InquiryRecord {
  id: number;
  inquiry_code: string;
  hall_id: number;
  hall_name_ar: string;
  sender_name: string;
  sender_phone: string;
  sender_email?: string;
  event_type: string;
  event_date?: string;
  guest_estimate?: number;
  subject: string;
  status: 'new' | 'replied' | 'closed';
  created_at: string;
  messages: Array<{
    id: number;
    inquiry_id: number;
    is_owner_reply: number;
    message: string;
    created_at: string;
  }>;
}

export interface GovernorateOption {
  code: string;
  ar: string;
  en: string;
}

/**
 * All 22 Yemeni Governorates (جميع محافظات الجمهورية اليمنية - 22 محافظة)
 */
export const YEMEN_GOVERNORATES: GovernorateOption[] = [
  { code: 'sanaa', ar: 'أمانة العاصمة صنعاء', en: "Sana'a Capital" },
  { code: 'sanaa_gov', ar: 'محافظة صنعاء', en: "Sana'a Governorate" },
  { code: 'aden', ar: 'عدن', en: 'Aden' },
  { code: 'taiz', ar: 'تعز', en: 'Taiz' },
  { code: 'ibb', ar: 'إب', en: 'Ibb' },
  { code: 'hadhramaut', ar: 'حضرموت (المكلا / سيئون)', en: 'Hadhramaut (Mukalla / Seiyun)' },
  { code: 'hodeidah', ar: 'الحديدة', en: 'Al Hodeidah' },
  { code: 'dhamar', ar: 'ذمار', en: 'Dhamar' },
  { code: 'marib', ar: 'مأرب', en: 'Marib' },
  { code: 'amran', ar: 'عمران', en: 'Amran' },
  { code: 'hajjah', ar: 'حجة', en: 'Hajjah' },
  { code: 'sadah', ar: 'صعدة', en: "Sa'dah" },
  { code: 'albayda', ar: 'البيضاء', en: 'Al Bayda' },
  { code: 'aldhale', ar: 'الضالع', en: "Al Dhale'e" },
  { code: 'lahj', ar: 'لحج', en: 'Lahj' },
  { code: 'abyan', ar: 'أبين', en: 'Abyan' },
  { code: 'shabwah', ar: 'شبوة', en: 'Shabwah' },
  { code: 'almahrah', ar: 'المهرة', en: 'Al Mahrah' },
  { code: 'aljawf', ar: 'الجوف', en: 'Al Jawf' },
  { code: 'raymah', ar: 'ريمة', en: 'Raymah' },
  { code: 'almahwit', ar: 'المحويت', en: 'Al Mahwit' },
  { code: 'socotra', ar: 'أرخبيل سقطرى', en: 'Socotra' },
];

export const CITIES: Record<string, { ar: string; en: string }> = {
  all: { ar: 'جميع محافظات ومدن اليمن', en: 'All Yemeni Governorates' },
  sanaa: { ar: 'أمانة العاصمة صنعاء', en: "Sana'a Capital" },
  sanaa_gov: { ar: 'محافظة صنعاء', en: "Sana'a Governorate" },
  aden: { ar: 'عدن', en: 'Aden' },
  taiz: { ar: 'تعز', en: 'Taiz' },
  ibb: { ar: 'إب', en: 'Ibb' },
  hadhramaut: { ar: 'حضرموت (المكلا / سيئون)', en: 'Hadhramaut (Mukalla / Seiyun)' },
  mukalla: { ar: 'حضرموت (المكلا)', en: 'Hadhramaut (Mukalla)' },
  hadramout: { ar: 'حضرموت', en: 'Hadhramaut' },
  hodeidah: { ar: 'الحديدة', en: 'Al Hodeidah' },
  dhamar: { ar: 'ذمار', en: 'Dhamar' },
  marib: { ar: 'مأرب', en: 'Marib' },
  amran: { ar: 'عمران', en: 'Amran' },
  hajjah: { ar: 'حجة', en: 'Hajjah' },
  sadah: { ar: 'صعدة', en: "Sa'dah" },
  albayda: { ar: 'البيضاء', en: 'Al Bayda' },
  aldhale: { ar: 'الضالع', en: "Al Dhale'e" },
  lahj: { ar: 'لحج', en: 'Lahj' },
  abyan: { ar: 'أبين', en: 'Abyan' },
  shabwah: { ar: 'شبوة', en: 'Shabwah' },
  almahrah: { ar: 'المهرة', en: 'Al Mahrah' },
  aljawf: { ar: 'الجوف', en: 'Al Jawf' },
  raymah: { ar: 'ريمة', en: 'Raymah' },
  almahwit: { ar: 'المحويت', en: 'Al Mahwit' },
  socotra: { ar: 'أرخبيل سقطرى', en: 'Socotra' },
};

export interface HallTypeOption {
  slug: string;
  label_ar: string;
  label_en: string;
  ar: string;
  en: string;
}

export interface SuitabilityOption {
  slug: SuitabilityType;
  label_ar: string;
  label_en: string;
  ar: string;
  en: string;
}

/**
 * Exact 3 Primary Hall Suitability Types (Requirement 1 of Part 5):
 * - WOMEN_ONLY: Exclusively intended for women's events
 * - MEN_ONLY: Exclusively intended for men's events
 * - MIXED: Suitable for both men's and women's events
 */
export const SUITABILITY_TYPES: SuitabilityOption[] = [
  {
    slug: 'WOMEN_ONLY',
    label_ar: 'مخصصة للنساء فقط (WOMEN_ONLY)',
    label_en: "Women's Events Only (WOMEN_ONLY)",
    ar: 'مخصصة للنساء فقط (WOMEN_ONLY)',
    en: "Women's Events Only (WOMEN_ONLY)",
  },
  {
    slug: 'MEN_ONLY',
    label_ar: 'مخصصة للرجال فقط (MEN_ONLY)',
    label_en: "Men's Events Only (MEN_ONLY)",
    ar: 'مخصصة للرجال فقط (MEN_ONLY)',
    en: "Men's Events Only (MEN_ONLY)",
  },
  {
    slug: 'MIXED',
    label_ar: 'مناسبة للرجال والنساء (MIXED)',
    label_en: 'Mixed / Men & Women Events (MIXED)',
    ar: 'مناسبة للرجال والنساء (MIXED)',
    en: 'Mixed / Men & Women Events (MIXED)',
  },
];

// Alias for backward compatibility while enforcing exact 3 values
export const GENDER_POLICIES: HallTypeOption[] = SUITABILITY_TYPES;

export const HALL_TYPES: HallTypeOption[] = [
  { slug: 'wedding_hall', label_ar: 'قاعة أفراح وزفاف ملكية', label_en: 'Royal Wedding Ballroom', ar: 'قاعة أفراح وزفاف ملكية', en: 'Royal Wedding Ballroom' },
  { slug: 'wedding', label_ar: 'قاعة أفراح كبرى', label_en: 'Grand Wedding Hall', ar: 'قاعة أفراح كبرى', en: 'Grand Wedding Hall' },
  { slug: 'mens_hall', label_ar: 'قاعة وصالة رجال ومقيل ملكي', label_en: "Men's Wedding & Diwan Hall", ar: 'قاعة وصالة رجال ومقيل ملكي', en: "Men's Wedding & Diwan Hall" },
  { slug: 'womens_hall', label_ar: 'قاعة وصالة احتفالات نساء', label_en: "Women's Celebration Hall", ar: 'قاعة وصالة احتفالات نساء', en: "Women's Celebration Hall" },
  { slug: 'engagement_hall', label_ar: 'قاعة خطوبة وعقد قران وحناء', label_en: 'Engagement & Henna Venue', ar: 'قاعة خطوبة وعقد قران وحناء', en: 'Engagement & Henna Venue' },
  { slug: 'conference_hall', label_ar: 'قاعة مؤتمرات وندوات وورش عمل', label_en: 'Conference & Seminar Center', ar: 'قاعة مؤتمرات وندوات وورش عمل', en: 'Conference & Seminar Center' },
  { slug: 'graduation_hall', label_ar: 'قاعة حفلات تخرج وتكريم', label_en: 'Graduation & Gala Hall', ar: 'قاعة حفلات تخرج وتكريم', en: 'Graduation & Gala Hall' },
  { slug: 'corporate_hall', label_ar: 'قاعة مناسبات الشركات وكبار الشخصيات', label_en: 'Corporate & VIP Events Venue', ar: 'قاعة مناسبات الشركات وكبار الشخصيات', en: 'Corporate & VIP Events Venue' },
  { slug: 'open_garden', label_ar: 'حديقة مفتوحة وجناح ملكي خارجي', label_en: 'Open Garden & Outdoor Pavilion', ar: 'حديقة مفتوحة وجناح ملكي خارجي', en: 'Open Garden & Outdoor Pavilion' },
  { slug: 'multi_purpose', label_ar: 'قاعة متعددة الاستخدامات', label_en: 'Multi-Purpose Event Hall', ar: 'قاعة متعددة الاستخدامات', en: 'Multi-Purpose Event Hall' },
];

export const PERMISSION_MODULES: Record<string, { ar: string; en: string }> = {
  dashboard: { ar: 'أ. لوحة التحكم والتقارير (Dashboard)', en: 'A. Dashboard & Reports' },
  halls: { ar: 'ب. إدارة واعتماد القاعات (Hall Management)', en: 'B. Hall Management' },
  owner_verification: { ar: 'ج. توثيق ملاك القاعات (Owner Verification)', en: 'C. Hall Owner Verification' },
  bookings: { ar: 'د. إدارة الحجوزات والتعارضات (Booking Management)', en: 'D. Booking Management' },
  customers: { ar: 'هـ. إدارة العملاء (Customer Management)', en: 'E. Customer Management' },
  finance: { ar: 'و. المالية والمدفوعات والمرتجعات (Financial & Payments)', en: 'F. Financial & Payments' },
  support: { ar: 'ز. الدعم الفني والشكاوى (Support & Inquiries)', en: 'G. Customer Support & Inquiries' },
  content: { ar: 'ح. التقييمات والإشعارات (Reviews & Notifications)', en: 'H. Content & Notifications' },
};

export function formatMoney(amountYer: number, currency: CurrencyCode, locale: Locale): string {
  const rates: Record<CurrencyCode, number> = {
    YER: 1,
    SAR: 1 / 140,
    USD: 1 / 530,
  };
  const converted = Math.round(amountYer * rates[currency]);
  const formatted = converted.toLocaleString('en-US');
  if (locale === 'ar') {
    const labels: Record<CurrencyCode, string> = {
      YER: 'ر.ي',
      SAR: 'ر.س',
      USD: '$',
    };
    return `${formatted} ${labels[currency]}`;
  }
  return `${currency} ${formatted}`;
}

export function getShiftLabel(shift: string, locale: Locale): string {
  const map: Record<string, { ar: string; en: string }> = {
    morning: { ar: 'الفترة الصباحية (08:00 ص – 01:00 م)', en: 'Morning Shift (08:00 AM – 01:00 PM)' },
    evening: { ar: 'الفترة المسائية الملكية (04:00 م – 11:00 م)', en: 'Royal Evening Shift (04:00 PM – 11:00 PM)' },
    full_day: { ar: 'حجز اليوم الكامل (08:00 ص – 11:59 م)', en: 'Full Day Exclusive (08:00 AM – 11:59 PM)' },
    hourly: { ar: 'حجز بالساعات (مدة مرنة مخصصة)', en: 'Custom Hourly Booking' },
  };
  return map[shift]?.[locale] || shift;
}

export function getCityLabel(cityKey: string, locale: Locale): string {
  return CITIES[cityKey]?.[locale] || cityKey;
}

export function getHallTypeLabel(typeKey: string, locale: Locale): string {
  const found = HALL_TYPES.find((h) => h.slug === typeKey);
  if (found) return locale === 'ar' ? found.label_ar : found.label_en;
  return locale === 'ar' ? 'قاعة أفراح ومناسبات' : 'Wedding & Event Venue';
}

export function normalizeSuitabilityClient(raw?: string): SuitabilityType {
  const upper = String(raw || '').trim().toUpperCase();
  if (upper === 'WOMEN_ONLY' || upper === 'WOMENS_ONLY') return 'WOMEN_ONLY';
  if (upper === 'MEN_ONLY' || upper === 'MENS_ONLY') return 'MEN_ONLY';
  return 'MIXED';
}

export function getSuitabilityLabel(suitabilityKey: string | undefined, locale: Locale): string {
  const norm = normalizeSuitabilityClient(suitabilityKey);
  const found = SUITABILITY_TYPES.find((s) => s.slug === norm);
  if (found) return locale === 'ar' ? found.label_ar : found.label_en;
  return locale === 'ar' ? 'مناسبة للرجال والنساء (MIXED)' : 'Mixed Events (MIXED)';
}

export function getGenderPolicyLabel(policyKey: string, locale: Locale): string {
  return getSuitabilityLabel(policyKey, locale);
}

export function computeConsecutiveDatesClient(startDateStr: string, bookedDays: number): string[] {
  const clean = String(startDateStr || '').trim().slice(0, 10);
  const parts = clean.split('-').map((n) => parseInt(n, 10));
  if (parts.length !== 3 || parts.some((n) => Number.isNaN(n))) return clean ? [clean] : [];
  const days = Math.max(1, Math.min(30, Math.floor(Number(bookedDays || 1))));
  const [year, month, day] = parts;
  const baseUtcMs = Date.UTC(year, month - 1, day);
  const dates: string[] = [];
  for (let i = 0; i < days; i++) {
    dates.push(new Date(baseUtcMs + i * 86400000).toISOString().slice(0, 10));
  }
  return dates;
}

