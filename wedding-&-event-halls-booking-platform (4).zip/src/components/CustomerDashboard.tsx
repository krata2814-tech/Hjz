import React, { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  CreditCard,
  MessageSquare,
  Headphones,
  PlusCircle,
  Heart,
  Bell,
  Star,
  CheckCircle2,
  Building2,
} from 'lucide-react';
import {
  Hall,
  Locale,
  CurrencyCode,
  BookingRecord,
  PaymentRecord,
  InquiryRecord,
  SupportTicket,
  formatMoney,
  getCityLabel,
  getShiftLabel,
  getSuitabilityLabel,
} from '../types.ts';
import { VenueImage } from './VenueImage.tsx';

interface CustomerDashboardProps {
  locale: Locale;
  currency: CurrencyCode;
  halls: Hall[];
  onSelectHall: (hall: Hall) => void;
  onToggleFavorite: (hallId: number, e: React.MouseEvent) => void;
  apiFetch: (url: string, options?: RequestInit) => Promise<unknown>;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  locale,
  currency,
  halls,
  onSelectHall,
  onToggleFavorite,
  apiFetch,
}) => {
  const isAr = locale === 'ar';
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [inquiries, setInquiries] = useState<InquiryRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [notifications, setNotifications] = useState<
    Array<{
      id: number;
      title_ar: string;
      title_en?: string;
      message_ar: string;
      message_en?: string;
      type: string;
      is_read: number;
      created_at: string;
    }>
  >([]);
  const [favoriteIds, setFavoriteIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<
    'bookings' | 'payments' | 'saved' | 'inquiries' | 'notifications' | 'support'
  >('bookings');
  const [bookingFilter, setBookingFilter] = useState<'all' | 'upcoming' | 'history'>('all');

  // New Ticket Form
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'normal' | 'high'>('normal');
  const [selectedBookingId, setSelectedBookingId] = useState<string>('');
  const [banner, setBanner] = useState<string | null>(null);

  const loadCustomerData = useCallback(async () => {
    setLoading(true);
    try {
      const res = (await apiFetch('/api/customer/dashboard')) as {
        bookings: BookingRecord[];
        payments: PaymentRecord[];
        inquiries: InquiryRecord[];
        tickets: SupportTicket[];
        notifications?: typeof notifications;
        favorites?: number[];
      };
      setBookings(res.bookings);
      setPayments(res.payments);
      setInquiries(res.inquiries);
      setTickets(res.tickets);
      setNotifications(res.notifications || []);
      setFavoriteIds(res.favorites || []);
    } finally {
      setLoading(false);
    }
  }, [apiFetch]);

  useEffect(() => {
    loadCustomerData();
  }, [loadCustomerData]);

  async function handlePayRemainingBalance(bookingId: number) {
    try {
      const res = (await apiFetch(`/api/bookings/${bookingId}/pay-balance`, {
        method: 'POST',
        body: JSON.stringify({ paymentMethod: 'card_payment' }),
      })) as { paymentReference: string; amountPaid: number };
      setBanner(
        isAr
          ? `تم تسجيل دفعة الرصيد المتبقي بنجاح (رقم الإيصال: ${res.paymentReference}).`
          : `Remaining balance payment submitted (${res.paymentReference}).`
      );
      await loadCustomerData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تسجيل الدفعة');
    }
  }

  async function handleMarkNotificationsRead() {
    await apiFetch('/api/customer/notifications/read', { method: 'POST' });
    await loadCustomerData();
  }

  async function handleCreateTicket(e: React.FormEvent) {
    e.preventDefault();
    const res = (await apiFetch('/api/tickets', {
      method: 'POST',
      body: JSON.stringify({
        bookingId: selectedBookingId ? Number(selectedBookingId) : undefined,
        priority,
        subject,
        message,
      }),
    })) as { ticketCode: string };
    setSubject('');
    setMessage('');
    setBanner(
      isAr ? `تم فتح تذكرة الدعم بنجاح (${res.ticketCode}).` : `Support ticket created (${res.ticketCode}).`
    );
    await loadCustomerData();
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl space-y-6 px-6 py-12">
        <div className="h-24 animate-pulse rounded-xl bg-[#F3EFEA]" />
        <div className="h-64 animate-pulse rounded-xl bg-[#F3EFEA]" />
      </div>
    );
  }

  const savedVenues = halls.filter((h) => favoriteIds.includes(h.id));
  const unreadNotifCount = notifications.filter((n) => !n.is_read).length;

  const filteredBookings = bookings.filter((b) => {
    if (bookingFilter === 'upcoming') {
      return b.status === 'confirmed' || b.status === 'pending';
    }
    if (bookingFilter === 'history') {
      return b.status === 'completed' || b.status === 'cancelled';
    }
    return true;
  });

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-6 py-8">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#0B3B2B]/12 pb-5">
        <div>
          <div className="text-xs text-[#52635B]">
            {isAr
              ? 'بوابة العميل لإدارة العقود، المدفوعات، القاعات المحفوظة، والمراسلات'
              : 'Customer Reservation, Payment & Concierge Dashboard'}
          </div>
          <h1 className="font-display text-3xl font-bold text-[#0B241C]">
            {isAr ? 'حجوزاتي وعقود المناسبات' : 'My Venue Reservations & Contracts'}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-[#F3EFEA] p-1">
          {[
            {
              id: 'bookings',
              ar: `الحجوزات والسجل (${bookings.length})`,
              en: `Bookings (${bookings.length})`,
              icon: Calendar,
            },
            {
              id: 'payments',
              ar: `حالة الدفع (${payments.length})`,
              en: `Payments (${payments.length})`,
              icon: CreditCard,
            },
            {
              id: 'saved',
              ar: `القاعات المحفوظة (${savedVenues.length})`,
              en: `Saved Venues (${savedVenues.length})`,
              icon: Heart,
            },
            {
              id: 'inquiries',
              ar: `المراسلات (${inquiries.length})`,
              en: `Messages (${inquiries.length})`,
              icon: MessageSquare,
            },
            {
              id: 'notifications',
              ar: `الإشعارات (${unreadNotifCount > 0 ? unreadNotifCount : notifications.length})`,
              en: `Notifications (${notifications.length})`,
              icon: Bell,
            },
            {
              id: 'support',
              ar: `الدعم (${tickets.length})`,
              en: `Support (${tickets.length})`,
              icon: Headphones,
            },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id as typeof activeTab)}
                className={`inline-flex items-center gap-1.5 rounded-md px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeTab === t.id ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B] hover:text-[#0B241C]'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{isAr ? t.ar : t.en}</span>
              </button>
            );
          })}
        </div>
      </div>

      {banner && (
        <div className="flex items-center justify-between rounded-lg border border-[#C5A059]/40 bg-white px-4 py-3 text-xs font-semibold text-[#0B241C]">
          <span>{banner}</span>
          <button
            type="button"
            onClick={() => setBanner(null)}
            className="text-xs font-semibold text-[#8A6829] hover:underline"
          >
            {isAr ? 'إغلاق' : 'Dismiss'}
          </button>
        </div>
      )}

      {/* Tab 1: Upcoming Bookings & Booking History */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1 rounded-lg bg-[#F3EFEA] p-1 text-xs">
              {[
                { id: 'all', ar: `جميع العقود (${bookings.length})`, en: `All Contracts (${bookings.length})` },
                {
                  id: 'upcoming',
                  ar: `الحجوزات القادمة (${bookings.filter((b) => b.status === 'confirmed' || b.status === 'pending').length})`,
                  en: 'Upcoming Bookings',
                },
                {
                  id: 'history',
                  ar: `سجل الحجوزات السابقة (${bookings.filter((b) => b.status === 'completed' || b.status === 'cancelled').length})`,
                  en: 'Booking History',
                },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setBookingFilter(f.id as typeof bookingFilter)}
                  className={`rounded-md px-3 py-1.5 font-semibold transition-colors whitespace-nowrap ${
                    bookingFilter === f.id ? 'bg-white text-[#0B241C] shadow-xs' : 'text-[#52635B]'
                  }`}
                >
                  {isAr ? f.ar : f.en}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-[#0B3B2B]/12 bg-white">
            <table className="w-full text-start text-xs">
              <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                <tr>
                  <th className="px-4 py-3 text-start">{isAr ? 'رقم العقد' : 'Booking Code'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'القاعة والتصنيف' : 'Venue & Suitability'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'تواريخ الحجز وعدد الأيام' : 'Dates & Booked Days'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'الضيوف' : 'Guests'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'التفاصيل المالية والإجمالي' : 'Financial Breakdown'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'حالة الحجز والدفع' : 'Status & Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0B3B2B]/8">
                {filteredBookings.map((b) => {
                  const daysCount = Number(b.booked_days || 1);
                  const endDateStr = b.end_date || b.event_date;
                  return (
                    <tr key={b.id} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-3.5 font-mono font-bold text-[#0B3B2B] tabular-nums">{b.booking_code}</td>
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-[#0B241C]">{b.hall_name_ar}</div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-[#52635B]">
                          <span className="rounded bg-[#0B3B2B]/8 px-1.5 py-0.5 font-semibold text-[#0B3B2B]">
                            {getSuitabilityLabel(b.suitability_type, locale)} ({b.suitability_type || 'MIXED'})
                          </span>
                          <span>·</span>
                          <span>{b.address}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3.5 font-mono tabular-nums">
                        <div className="font-semibold text-[#0B241C]">
                          {daysCount > 1 ? `${b.event_date} → ${endDateStr}` : b.event_date}
                        </div>
                        <div className="font-sans text-[#52635B]">
                          {daysCount} {isAr ? (daysCount > 1 ? 'أيام تقويمية' : 'يوم') : 'day(s)'} ·{' '}
                          {getShiftLabel(b.shift, locale)}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 font-mono tabular-nums">{b.guest_count}</td>
                      <td className="px-4 py-3.5 font-mono tabular-nums">
                        <div className="font-bold text-[#0B241C]">{formatMoney(b.total_amount, currency, locale)}</div>
                        <div className="text-[11px] text-[#52635B]">
                          {isAr ? 'اليوم:' : 'Day:'}{' '}
                          {formatMoney(Number(b.price_per_day || b.base_price), currency, locale)}
                          {Number(b.discount_amount || 0) > 0
                            ? ` · ${isAr ? 'خصم:' : 'Disc:'} -${formatMoney(Number(b.discount_amount), currency, locale)}`
                            : ''}
                        </div>
                        <div className="text-[#8A6829]">
                          {isAr ? 'العربون:' : 'Deposit:'} {formatMoney(b.deposit_amount, currency, locale)} ·{' '}
                          {isAr ? 'المتبقي:' : 'Due:'} {formatMoney(b.remaining_amount, currency, locale)}
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <span
                              className={`font-semibold ${
                                b.status === 'confirmed'
                                  ? 'text-emerald-800'
                                  : b.status === 'cancelled'
                                  ? 'text-red-800'
                                  : 'text-amber-800'
                              }`}
                            >
                              {b.status === 'confirmed'
                                ? isAr
                                  ? 'حجز مؤكد ✓'
                                  : 'Confirmed ✓'
                                : b.status === 'pending'
                                ? isAr
                                  ? 'قيد التأكيد'
                                  : 'Pending'
                                : b.status}
                            </span>
                            <div className="font-mono text-[11px] text-[#52635B]">{b.payment_status}</div>
                          </div>

                          {b.remaining_amount > 0 && b.status !== 'cancelled' && (
                            <button
                              type="button"
                              onClick={() => handlePayRemainingBalance(b.id)}
                              className="rounded-md bg-[#0B3B2B] px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-[#0F4C3A] whitespace-nowrap"
                            >
                              {isAr ? 'سداد المتبقي' : 'Pay Balance'}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Payment Status & Verified Receipts */}
      {activeTab === 'payments' && (
        <div className="overflow-x-auto rounded-xl border border-[#0B3B2B]/12 bg-white">
          <table className="w-full text-start text-xs">
            <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
              <tr>
                <th className="px-4 py-3 text-start">{isAr ? 'رقم الإيصال' : 'Receipt Ref'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'رقم الحجز' : 'Booking'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'نوع الدفعة ووسيلة السداد' : 'Type & Method'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'المبلغ' : 'Amount'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'حالة التوثيق المالي' : 'Verification Status'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#0B3B2B]/8">
              {payments.map((p) => (
                <tr key={p.id} className="hover:bg-[#FAF8F5]">
                  <td className="px-4 py-3 font-mono font-bold text-[#0B3B2B] tabular-nums">{p.payment_reference}</td>
                  <td className="px-4 py-3 font-mono tabular-nums">{p.booking_code || '—'}</td>
                  <td className="px-4 py-3 font-mono tabular-nums">
                    {p.payment_type} · {p.payment_method} ({p.transaction_number})
                  </td>
                  <td className="px-4 py-3 font-mono font-bold tabular-nums">
                    {formatMoney(p.amount, currency, locale)}
                  </td>
                  <td className="px-4 py-3 font-semibold">
                    {p.status === 'verified' ? (
                      <span className="text-emerald-800">{isAr ? 'موثق ومعتمد ✓' : 'Verified ✓'}</span>
                    ) : p.status === 'refunded' ? (
                      <span className="text-red-800">{isAr ? 'مسترد (Refunded)' : 'Refunded'}</span>
                    ) : (
                      <span className="text-amber-800">{isAr ? 'قيد المراجعة المالية' : 'Pending Verification'}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 3: Saved Venues (Favorites) */}
      {activeTab === 'saved' && (
        <div>
          {savedVenues.length === 0 ? (
            <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-10 text-center">
              <Building2 className="mx-auto mb-2 h-8 w-8 text-[#8A6829]" />
              <div className="font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'لا توجد قاعات محفوظة في المفضلة حالياً' : 'No saved venues yet'}
              </div>
              <p className="mt-1 text-xs text-[#52635B]">
                {isAr
                  ? 'اضغط على أيقونة القلب على أي قاعة لحفظها هنا للمقارنة والحجز لاحقاً.'
                  : 'Click the heart icon on any venue card to save it here for quick access.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {savedVenues.map((hall) => (
                <article
                  key={hall.id}
                  onClick={() => onSelectHall(hall)}
                  className="group flex cursor-pointer flex-col overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-md"
                >
                  <div className="relative">
                    <VenueImage
                      src={hall.images[0]?.image_url}
                      alt={isAr ? hall.name_ar : hall.name_en || hall.name_ar}
                      className="aspect-[4/3] w-full"
                    />
                    <button
                      type="button"
                      onClick={(e) => {
                        onToggleFavorite(hall.id, e);
                        setFavoriteIds((prev) => prev.filter((id) => id !== hall.id));
                      }}
                      className="absolute top-3 end-3 rounded-full bg-black/55 p-2 text-white hover:bg-black/75"
                      aria-label="Remove Favorite"
                    >
                      <Heart className="h-4 w-4 fill-[#C5A059] text-[#C5A059]" />
                    </button>
                  </div>
                  <div className="flex flex-1 flex-col justify-between p-5">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-[#52635B]">
                        <span className="font-semibold text-[#0B3B2B]">{getCityLabel(hall.city, locale)}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">
                          {hall.capacity_min}–{hall.capacity_max} {isAr ? 'ضيف' : 'Guests'}
                        </span>
                        <span>·</span>
                        <span className="inline-flex items-center gap-1 font-mono text-[#8A6829] tabular-nums">
                          <Star className="h-3.5 w-3.5 fill-[#C5A059] text-[#C5A059]" />
                          {Number(hall.rating).toFixed(2)}
                        </span>
                      </div>
                      <h3 className="mt-1.5 font-display text-lg font-bold text-[#0B241C]">
                        {isAr ? hall.name_ar : hall.name_en || hall.name_ar}
                      </h3>
                    </div>
                    <div className="mt-4 flex items-center justify-between border-t border-[#0B3B2B]/10 pt-3">
                      <span className="font-mono text-sm font-bold text-[#0B241C] tabular-nums">
                        {formatMoney(hall.starting_price, currency, locale)}
                      </span>
                      <span className="rounded-lg bg-[#0B3B2B] px-3 py-1.5 text-xs font-semibold text-white">
                        {isAr ? 'استعراض وحجز' : 'Book Venue'}
                      </span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Customer Messages & Venue Conversations */}
      {activeTab === 'inquiries' && (
        <div className="space-y-4">
          {inquiries.map((inq) => (
            <div key={inq.id} className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
              <div className="flex items-center justify-between border-b border-[#0B3B2B]/8 pb-2.5 text-xs">
                <div>
                  <span className="font-mono font-bold text-[#8A6829] tabular-nums">{inq.inquiry_code}</span>
                  <span className="mx-2">·</span>
                  <span className="font-semibold text-[#0B241C]">{inq.subject}</span>
                </div>
                <span className="text-[#52635B]">{inq.hall_name_ar}</span>
              </div>
              <div className="mt-3 space-y-2">
                {inq.messages?.map((m) => (
                  <div
                    key={m.id}
                    className={`rounded-lg p-3 text-xs ${
                      m.is_owner_reply ? 'bg-[#0B3B2B]/8 text-[#0B241C]' : 'bg-[#FAF8F5] text-[#1E352D]'
                    }`}
                  >
                    <div className="mb-1 font-semibold text-[#0B3B2B]">
                      {m.is_owner_reply ? (isAr ? 'رد إدارة القاعة:' : 'Venue Reply:') : isAr ? 'رسالتك:' : 'You:'}
                    </div>
                    <p>{m.message}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 5: Real Database-Backed Notifications */}
      {activeTab === 'notifications' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-[#0B241C]">
              {isAr ? 'مركز الإشعارات والتنبيهات الفورية' : 'Notifications & Booking Alerts'}
            </h2>
            {unreadNotifCount > 0 && (
              <button
                type="button"
                onClick={handleMarkNotificationsRead}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#0B3B2B]/20 bg-white px-3 py-1.5 text-xs font-semibold text-[#0B3B2B] hover:bg-[#FAF8F5]"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{isAr ? 'تحديد الكل كمقروء' : 'Mark All as Read'}</span>
              </button>
            )}
          </div>

          <div className="divide-y divide-[#0B3B2B]/10 rounded-xl border border-[#0B3B2B]/12 bg-white">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#52635B]">
                {isAr ? 'لا توجد إشعارات جديدة حالياً.' : 'No notifications found.'}
              </div>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  className={`flex items-start justify-between gap-4 p-4 text-xs ${
                    !n.is_read ? 'bg-[#FAF8F5]' : 'bg-white'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-[#0B241C]">
                      {isAr ? n.title_ar : n.title_en || n.title_ar}
                      {!n.is_read && (
                        <span className="ms-2 text-[11px] font-bold text-[#8A6829]">
                          {isAr ? '· جديد' : '· Unread'}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-[#52635B]">{isAr ? n.message_ar : n.message_en || n.message_ar}</p>
                  </div>
                  <span className="font-mono text-[11px] text-[#52635B] tabular-nums whitespace-nowrap">
                    {n.created_at}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 6: Support Tickets */}
      {activeTab === 'support' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="space-y-4 lg:col-span-7">
            {tickets.map((t) => (
              <div key={t.id} className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
                <div className="flex items-center justify-between border-b border-[#0B3B2B]/8 pb-2.5 text-xs">
                  <div>
                    <span className="font-mono font-bold text-[#0B3B2B] tabular-nums">{t.ticket_code}</span>
                    <span className="mx-2">·</span>
                    <span className="font-semibold text-[#0B241C]">{t.subject}</span>
                  </div>
                  <span className="font-semibold text-[#8A6829]">{t.status}</span>
                </div>
                <div className="mt-3 space-y-2">
                  {t.messages?.map((m) => (
                    <div key={m.id} className="rounded-lg bg-[#FAF8F5] p-3 text-xs">
                      <div className="mb-1 font-semibold text-[#0B3B2B]">{m.sender_name}</div>
                      <p>{m.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <form
            onSubmit={handleCreateTicket}
            className="space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-5 lg:col-span-5"
          >
            <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
              <PlusCircle className="h-4 w-4 text-[#0B3B2B]" />
              <h3 className="font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'فتح تذكرة دعم فني أو شكوى' : 'Open Support or Dispute Ticket'}
              </h3>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'الحجز المرتبط (اختياري)' : 'Related Booking'}
              </label>
              <select
                value={selectedBookingId}
                onChange={(e) => setSelectedBookingId(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              >
                <option value="">{isAr ? 'استفسار عام بدون حجز محدد' : 'General Inquiry'}</option>
                {bookings.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.booking_code} — {b.hall_name_ar}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'درجة الأولوية' : 'Priority'}
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'normal' | 'high')}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              >
                <option value="normal">{isAr ? 'عادية' : 'Normal'}</option>
                <option value="high">{isAr ? 'عالية / عاجلة' : 'High / Urgent'}</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'عنوان الطلب أو الشكوى *' : 'Subject *'}
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder={isAr ? 'مثال: طلب تعديل موعد أو مطابقة حوالة...' : 'e.g., Date modification request'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'التفاصيل *' : 'Details *'}
              </label>
              <textarea
                rows={3}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-3 text-xs"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              {isAr ? 'إرسال تذكرة الدعم' : 'Submit Support Ticket'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
