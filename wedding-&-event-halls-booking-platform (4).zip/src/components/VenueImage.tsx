import React, { useState } from 'react';
import { Building2 } from 'lucide-react';

interface VenueImageProps {
  src?: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
}

export const VenueImage: React.FC<VenueImageProps> = ({
  src,
  alt,
  className = '',
  loading = 'lazy',
}) => {
  const [failed, setFailed] = useState(false);
  const resolvedSrc = !src || failed ? '/api/artwork/taj-royal-palace' : src;

  return (
    <div className={`relative overflow-hidden bg-[#0B2920] ${className}`}>
      {!failed ? (
        <img
          src={resolvedSrc}
          alt={alt}
          loading={loading}
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="h-full w-full object-cover transition-transform duration-200 ease-out group-hover:scale-[1.02]"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#071D15] via-[#0B3B2B] to-[#1A3B30] p-6 text-center text-[#FAF8F5]">
          <Building2 className="mb-2 h-10 w-10 text-[#C5A059]" />
          <span className="font-display text-sm tracking-wide text-[#F3E5AB]">{alt}</span>
        </div>
      )}
    </div>
  );
};
