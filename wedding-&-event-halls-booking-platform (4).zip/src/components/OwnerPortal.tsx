import React, { useState, useEffect, useCallback } from 'react';
import {
  Plus,
  Calendar,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Building2,
  ShieldCheck,
  Clock,
} from 'lucide-react';
import {
  Locale,
  CurrencyCode,
  BookingRecord,
  InquiryRecord,
  SuitabilityType,
  HALL_TYPES,
  SUITABILITY_TYPES,
  YEMEN_GOVERNORATES,
  formatMoney,
  getCityLabel,
  getShiftLabel,
  getHallTypeLabel,
  getSuitabilityLabel,
} from '../types.ts';

interface OwnerPortalProps {
  locale: Locale;
  currency: CurrencyCode;
  apiFetch: (url: string, options?: RequestInit) => Promise<unknown>;
  onMarketplaceRefresh: () => void;
}

export const OwnerPortal: React.FC<OwnerPortalProps> = ({
  locale,
  currency,
  apiFetch,
  onMarketplaceRefresh,
}) => {
  const isAr = locale === 'ar';
  const [activeTab, setActiveTab] = useState<'overview' | 'photos' | 'bookings' | 'calendar' | 'inquiries' | 'new_hall'>('overview');
  const [data, setData] = useState<{
    halls: Array<Record<string, unknown>>;
    bookings: BookingRecord[];
    availability: Array<Record<string, unknown>>;
    inquiries: InquiryRecord[];
    ownerProfile?: Record<string, unknown>;
    hallImages?: Array<Record<string, unknown>>;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [banner, setBanner] = useState<string | null>(null);

  // Photo Management State
  const [photoHallId, setPhotoHallId] = useState<number>(0);
  const [photoScene, setPhotoScene] = useState<string>('/api/artwork/andalus-heritage-palace');
  const [photoCaption, setPhotoCaption] = useState<string>('صالة الاستقبال الملكية والأقواس');
  const [confirmCancelBookingId, setConfirmCancelBookingId] = useState<number | null>(null);

  // New Venue Form State
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [city, setCity] = useState('sanaa');
  const [district, setDistrict] = useState('');
  const [address, setAddress] = useState('');
  const [hallType, setHallType] = useState('wedding');
  const [suitabilityType, setSuitabilityType] = useState<SuitabilityType>('MIXED');
  const [bookingMode, setBookingMode] = useState('both');
  const [minBookingHours, setMinBookingHours] = useState(3);
  const [maxBookingHours, setMaxBookingHours] = useState(12);
  const [capacityMin, setCapacityMin] = useState(200);
  const [capacityMax, setCapacityMax] = useState(850);
  const [eveningPrice, setEveningPrice] = useState(550000);
  const [morningPrice, setMorningPrice] = useState(300000);
  const [hourlyRate, setHourlyRate] = useState(85000);
  const [eventDurationHours, setEventDurationHours] = useState(6);
  const [prepBufferHours, setPrepBufferHours] = useState(2);
  const [cleanupBufferHours, setCleanupBufferHours] = useState(2);
  const [multiDayDiscountPct, setMultiDayDiscountPct] = useState(5);
  const [additionalFees, setAdditionalFees] = useState(25000);
  const [descriptionAr, setDescriptionAr] = useState('');

  // Calendar Block Form State
  const [calHallId, setCalHallId] = useState<number>(0);
  const [calDate, setCalDate] = useState('2026-11-29');
  const [calShift, setCalShift] = useState('evening');
  const [calStatus, setCalStatus] = useState<'blocked' | 'available'>('blocked');
  const [calReason, setCalReason] = useState('');

  // Inquiry Reply State
  const [replyText, setReplyText] = useState<Record<number, string>>({});

  const loadOwnerDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const res = (await apiFetch('/api/owner/dashboard')) as {
        halls: Array<Record<string, unknown>>;
        bookings: BookingRecord[];
        availability: Array<Record<string, unknown>>;
        inquiries: InquiryRecord[];
        ownerProfile?: Record<string, unknown>;
      };
      setData(res);
      if (res.halls.length > 0 && !calHallId) {
        setCalHallId(Number(res.halls[0].id));
      }
      if (res.halls.length > 0 && !photoHallId) {
        setPhotoHallId(Number(res.halls[0].id));
      }
    } finally {
      setLoading(false);
    }
  }, [apiFetch, calHallId, photoHallId]);

  useEffect(() => {
    loadOwnerDashboard();
  }, [loadOwnerDashboard]);

  async function handleCreateHall(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = (await apiFetch('/api/owner/halls', {
        method: 'POST',
        body: JSON.stringify({
          nameAr,
          nameEn,
          city,
          district,
          address,
          hallType,
          suitabilityType,
          bookingMode,
          minBookingHours,
          maxBookingHours,
          capacityMin,
          capacityMax,
          eveningPrice,
          morningPrice,
          hourlyRate,
          eventDurationHours,
          prepBufferHours,
          cleanupBufferHours,
          multiDayDiscountPct,
          additionalFees,
          descriptionAr,
        }),
      })) as { status: string };

      setBanner(
        isAr
          ? `تم إرسال بيانات القاعة بنجاح! الحالة الحالية: (${
              res.status === 'pending' ? 'بانتظار مراجعة واعتماد المدير العام' : 'نشطة'
            }).`
          : `Venue submitted successfully! Status: ${res.status}`
      );
      setNameAr('');
      setNameEn('');
      setDescriptionAr('');
      setAddress('');
      setActiveTab('overview');
      await loadOwnerDashboard();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر إضافة القاعة');
    }
  }

  async function handleUpdateHallSuitability(hallId: number, newSuitability: SuitabilityType) {
    try {
      await apiFetch(`/api/owner/halls/${hallId}`, {
        method: 'PUT',
        body: JSON.stringify({ suitabilityType: newSuitability }),
      });
      setBanner(
        isAr
          ? `تم تحديث تصنيف ملاءمة القاعة إلى (${getSuitabilityLabel(newSuitability, locale)}) بنجاح.`
          : `Hall suitability updated to ${newSuitability}.`
      );
      await loadOwnerDashboard();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث تصنيف القاعة');
    }
  }

  async function handleBookingStatus(bookingId: number, status: 'confirmed' | 'cancelled' | 'completed') {
    try {
      await apiFetch(`/api/owner/bookings/${bookingId}/status`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      setBanner(isAr ? 'تم تحديث حالة الحجز وتقويم التوفر لجميع الأيام بنجاح.' : 'Booking status updated.');
      await loadOwnerDashboard();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث الحجز');
    }
  }

  async function handleCalendarUpdate(e: React.FormEvent) {
    e.preventDefault();
    if (!calHallId) return;
    await apiFetch('/api/owner/availability', {
      method: 'POST',
      body: JSON.stringify({
        hallId: calHallId,
        date: calDate,
        shift: calShift,
        status: calStatus,
        reason: calReason,
      }),
    });
    setBanner(isAr ? 'تم تحديث تقويم توفر القاعة بنجاح.' : 'Venue availability updated.');
    setCalReason('');
    await loadOwnerDashboard();
    onMarketplaceRefresh();
  }

  async function handleReplyInquiry(inquiryId: number) {
    const text = replyText[inquiryId];
    if (!text) return;
    await apiFetch(`/api/owner/inquiries/${inquiryId}/reply`, {
      method: 'POST',
      body: JSON.stringify({ message: text }),
    });
    setReplyText((prev) => ({ ...prev, [inquiryId]: '' }));
    setBanner(isAr ? 'تم إرسال الرد للعميل بنجاح.' : 'Reply sent to customer.');
    await loadOwnerDashboard();
  }

  async function handleAddVenuePhoto(e: React.FormEvent) {
    e.preventDefault();
    if (!photoHallId) return;
    await apiFetch(`/api/owner/halls/${photoHallId}/config`, {
      method: 'POST',
      body: JSON.stringify({
        imageUrl: photoScene,
        imageCaption: photoCaption,
      }),
    });
    setBanner(isAr ? 'تمت إضافة الصورة الجديدة لألبوم القاعة بنجاح.' : 'New photograph added to venue gallery.');
    await loadOwnerDashboard();
    onMarketplaceRefresh();
  }

  if (loading || !data) {
    return (
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="h-32 animate-pulse rounded-xl bg-[#F3EFEA]" />
      </div>
    );
  }

  const confirmedRevenue = data.bookings
    .filter((b) => b.status === 'confirmed' || b.status === 'completed')
    .reduce((acc, b) => acc + Number(b.total_amount || 0), 0);

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-6 py-8">
      {/* Studio Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#0B3B2B]/12 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#52635B]">
            <span>{isAr ? 'استوديو إدارة القاعات والحجوزات' : 'Venue Owner Management Studio'}</span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 font-medium text-[#0B3B2B]">
              <ShieldCheck className="h-3.5 w-3.5 text-[#C5A059]" />
              {data.ownerProfile?.is_verified
                ? isAr
                  ? `سجل تجاري موثق (${data.ownerProfile.commercial_registration_no})`
                  : `Verified Business (${data.ownerProfile.commercial_registration_no})`
                : isAr
                ? 'حساب مالك بانتظار التوثيق'
                : 'Verification Pending'}
            </span>
          </div>
          <h1 className="font-display text-3xl font-bold text-[#0B241C]">
            {String(data.ownerProfile?.business_name || (isAr ? 'بوابة مالك القاعة' : 'Hall Owner Portal'))}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 rounded-lg bg-[#F3EFEA] p-1">
          {[
            { id: 'overview', ar: 'قاعاتي والتوثيق', en: 'My Venues' },
            { id: 'photos', ar: 'إدارة صور القاعات', en: 'Photo Gallery' },
            { id: 'bookings', ar: `الحجوزات (${data.bookings.length})`, en: `Bookings (${data.bookings.length})` },
            { id: 'calendar', ar: 'إدارة التقويم', en: 'Calendar Control' },
            { id: 'inquiries', ar: `المحادثات (${data.inquiries.length})`, en: `Conversations (${data.inquiries.length})` },
            { id: 'new_hall', ar: '+ إضافة قاعة جديدة', en: '+ Submit New Venue' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`rounded-md px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-[#0B3B2B] text-white'
                  : 'text-[#52635B] hover:text-[#0B241C]'
              }`}
            >
              {isAr ? tab.ar : tab.en}
            </button>
          ))}
        </div>
      </div>

      {banner && (
        <div className="flex items-center justify-between rounded-lg border border-[#C5A059]/40 bg-[#FAF8F5] px-4 py-3 text-sm text-[#0B241C]">
          <span>{banner}</span>
          <button onClick={() => setBanner(null)} className="text-xs font-semibold text-[#8A6829]">
            {isAr ? 'إغلاق' : 'Dismiss'}
          </button>
        </div>
      )}

      {/* KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
          <div className="text-xs text-[#52635B]">{isAr ? 'إجمالي القاعات المدرجة' : 'Total Listed Venues'}</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[#0B241C] tabular-nums">{data.halls.length}</div>
          <div className="mt-1 text-xs text-[#52635B]">
            {data.halls.filter((h) => h.status === 'active').length} {isAr ? 'نشطة' : 'Active'} ·{' '}
            {data.halls.filter((h) => h.status === 'pending').length} {isAr ? 'بانتظار الاعتماد' : 'Pending Approval'}
          </div>
        </div>
        <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
          <div className="text-xs text-[#52635B]">{isAr ? 'الحجوزات المؤكدة' : 'Confirmed Reservations'}</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[#0B3B2B] tabular-nums">
            {data.bookings.filter((b) => b.status === 'confirmed').length}
          </div>
          <div className="mt-1 text-xs text-[#52635B]">
            {data.bookings.filter((b) => b.status === 'pending').length} {isAr ? 'طلبات بانتظار التأكيد' : 'Pending Requests'}
          </div>
        </div>
        <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
          <div className="text-xs text-[#52635B]">{isAr ? 'قيمة عقود الحجوزات المؤكدة' : 'Confirmed Contracts Value'}</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[#8A6829] tabular-nums">
            {formatMoney(confirmedRevenue, currency, locale)}
          </div>
          <div className="mt-1 text-xs text-[#52635B]">{isAr ? 'شاملاً الضريبة والعربون' : 'Gross confirmed value'}</div>
        </div>
        <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
          <div className="text-xs text-[#52635B]">{isAr ? 'استفسارات العملاء' : 'Customer Inquiries'}</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[#0B241C] tabular-nums">{data.inquiries.length}</div>
          <div className="mt-1 text-xs text-[#52635B]">
            {data.inquiries.filter((i) => i.status === 'new').length} {isAr ? 'جديدة' : 'New'}
          </div>
        </div>
      </div>

      {/* Tab 1: My Halls Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-[#0B241C]">
              {isAr ? 'قاعاتي وحالة الاعتماد والتصنيف في المنصة' : 'My Venues, Suitability Classification & Status'}
            </h2>
            <button
              type="button"
              onClick={() => setActiveTab('new_hall')}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              <Plus className="h-4 w-4 text-[#C5A059]" />
              <span>{isAr ? 'إدراج قاعة جديدة' : 'Submit New Venue'}</span>
            </button>
          </div>

          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
            <table className="w-full text-start text-sm">
              <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-xs text-[#52635B]">
                <tr>
                  <th className="px-4 py-3 text-start">{isAr ? 'اسم القاعة والفئة' : 'Venue Name & Category'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'تصنيف الملاءمة (WOMEN / MEN / MIXED)' : 'Suitability Type'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'المدينة والعنوان' : 'City & Address'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'السعة' : 'Capacity'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'حالة النشر والاعتماد' : 'Approval Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0B3B2B]/8">
                {data.halls.map((h) => {
                  const currentSuitability = (String(h.suitability_type || 'MIXED') as SuitabilityType);
                  return (
                    <tr key={Number(h.id)} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-[#0B241C]">{String(h.name_ar)}</div>
                        <div className="text-xs font-medium text-[#8A6829]">
                          {getHallTypeLabel(String(h.hall_type || 'wedding'), locale)}
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <select
                          aria-label="Edit Hall Suitability Type"
                          value={currentSuitability}
                          onChange={(e) => handleUpdateHallSuitability(Number(h.id), e.target.value as SuitabilityType)}
                          className="rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 text-xs font-semibold text-[#0B3B2B]"
                        >
                          {SUITABILITY_TYPES.map((st) => (
                            <option key={st.slug} value={st.slug}>
                              {isAr ? st.label_ar : st.label_en}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-3.5 text-xs text-[#52635B]">
                        {getCityLabel(String(h.city), locale)} · {String(h.address)}
                      </td>
                      <td className="px-4 py-3.5 font-mono text-xs tabular-nums">
                        {String(h.capacity_min)}–{String(h.capacity_max)} {isAr ? 'ضيف' : 'Guests'}
                      </td>
                      <td className="px-4 py-3.5 text-xs">
                        {h.status === 'active' && (
                          <span className="font-semibold text-emerald-800">
                            {isAr ? 'معتمدة ومنشورة للجمهور' : 'Approved & Live'}
                          </span>
                        )}
                        {h.status === 'pending' && (
                          <span className="inline-flex items-center gap-1 font-semibold text-amber-800">
                            <Clock className="h-3.5 w-3.5" />
                            {isAr ? 'قيد المراجعة لدى المدير العام (مخفية عن البحث العام)' : 'Pending Super Admin Approval'}
                          </span>
                        )}
                        {h.status === 'rejected' && (
                          <div>
                            <span className="font-semibold text-red-800">
                              {isAr ? 'مرفوضة من الإدارة' : 'Rejected'}
                            </span>
                            {Boolean(h.rejection_reason) && (
                              <div className="mt-0.5 text-[11px] text-red-700">
                                {isAr ? 'السبب:' : 'Reason:'} {String(h.rejection_reason)}
                              </div>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Owner Verification Status Card */}
          <div className="rounded-xl border border-[#0B3B2B]/15 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-xs font-semibold text-[#8A6829]">
                  {isAr ? 'حالة توثيق المنشأة والسجل التجاري' : 'Commercial Registration & Verification Status'}
                </div>
                <div className="mt-1 font-display text-lg font-bold text-[#0B241C]">
                  {String(data.ownerProfile?.business_name || 'مؤسسة القصور الملكية للمناسبات')}
                </div>
                <div className="mt-1 text-xs text-[#52635B]">
                  {isAr ? 'رقم السجل التجاري:' : 'CR Number:'}{' '}
                  <span className="font-mono font-semibold text-[#0B241C] tabular-nums">
                    {String(data.ownerProfile?.commercial_registration_no || 'CR-2026-YEM')}
                  </span>{' '}
                  · {isAr ? 'وثيقة التفويض:' : 'Document:'}{' '}
                  <span className="font-mono text-[#0B3B2B]">
                    {String(data.ownerProfile?.verification_document_url || '/uploads/docs/commercial-ownership-license.pdf')}
                  </span>
                </div>
              </div>
              <div className="text-xs font-semibold">
                {data.ownerProfile?.is_verified ? (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-800/25 bg-emerald-950/5 px-3.5 py-2 text-emerald-800">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>{isAr ? 'حساب مالك موثق ومعتمد رسمياً ✓' : 'Verified Owner Account ✓'}</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-amber-800/25 bg-amber-950/5 px-3.5 py-2 text-amber-800">
                    <Clock className="h-4 w-4" />
                    <span>{isAr ? 'بانتظار مراجعة وثائق التوثيق من الإدارة العليا' : 'Pending Super Admin Verification'}</span>
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 1B: Photo Management */}
      {activeTab === 'photos' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={handleAddVenuePhoto}
            className="space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-5 lg:col-span-5"
          >
            <h3 className="font-display text-lg font-bold text-[#0B241C]">
              {isAr ? 'إضافة صورة جديدة لألبوم القاعة' : 'Upload / Attach Venue Photograph'}
            </h3>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'اختر القاعة' : 'Select Venue'}
              </label>
              <select
                value={photoHallId}
                onChange={(e) => setPhotoHallId(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              >
                {data.halls.map((h) => (
                  <option key={Number(h.id)} value={Number(h.id)}>
                    {String(h.name_ar)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'المشهد المعماري أو رابط الصورة' : 'Architectural Scene / Image URL'}
              </label>
              <select
                value={photoScene}
                onChange={(e) => setPhotoScene(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              >
                <option value="/api/artwork/taj-royal-palace">
                  {isAr ? 'المسرح الملكي والكوشة الأندلسية' : 'Royal Andalusian Bridal Stage'}
                </option>
                <option value="/api/artwork/aden-coastal-pearl">
                  {isAr ? 'إطلالة القصر الساحلي والبهو البانورامي' : 'Coastal Panoramic Ballroom'}
                </option>
                <option value="/api/artwork/princess-ibb-garden">
                  {isAr ? 'جناح الحدائق الزجاجي والشلالات' : 'Emerald Botanical Glass Pavilion'}
                </option>
                <option value="/api/artwork/andalus-heritage-palace">
                  {isAr ? 'الأقواس التراثية والقمريات الملكية' : 'Heritage Arches & Stained Glass Suite'}
                </option>
                <option value="/api/artwork/narjis-taiz-hall">
                  {isAr ? 'قاعة الولائم والقباب الذهبية' : 'Imperial Domed Banquet Hall'}
                </option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'وصف الصورة (Caption)' : 'Photo Caption'}
              </label>
              <input
                type="text"
                required
                value={photoCaption}
                onChange={(e) => setPhotoCaption(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              {isAr ? 'إضافة الصورة إلى معرض القاعة' : 'Add Photograph to Gallery'}
            </button>
          </form>

          <div className="space-y-4 rounded-xl border border-[#0B3B2B]/12 bg-white p-5 lg:col-span-7">
            <h3 className="font-display text-lg font-bold text-[#0B241C]">
              {isAr ? 'معرض صور قاعاتي الحالي' : 'Current Venue Photo Gallery'}
            </h3>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              {(data.hallImages || []).map((img, idx) => (
                <div key={idx} className="overflow-hidden rounded-lg border border-[#0B3B2B]/12 bg-[#FAF8F5]">
                  <img
                    src={String(img.image_url)}
                    alt={String(img.caption || 'صورة القاعة')}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="aspect-[4/3] w-full object-cover"
                  />
                  <div className="p-2 text-[11px] font-medium text-[#0B241C] truncate">
                    {String(img.caption || 'صورة القاعة الرسمية')}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Bookings Management */}
      {activeTab === 'bookings' && (
        <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
          <table className="w-full text-start text-sm">
            <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-xs text-[#52635B]">
              <tr>
                <th className="px-4 py-3 text-start">{isAr ? 'رقم الحجز' : 'Code'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'القاعة والتصنيف والعميل' : 'Venue, Suitability & Customer'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'التواريخ وعدد الأيام' : 'Dates & Days'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'الإجمالي / الدفع' : 'Total / Payment'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                <th className="px-4 py-3 text-start">{isAr ? 'إجراءات المالك' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#0B3B2B]/8">
              {data.bookings.map((b) => {
                const daysCount = Number(b.booked_days || 1);
                const endDateStr = b.end_date || b.event_date;
                return (
                  <tr key={b.id} className="hover:bg-[#FAF8F5]">
                    <td className="px-4 py-3 font-mono text-xs font-semibold text-[#0B3B2B] tabular-nums">
                      {b.booking_code}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-[#0B241C]">
                        {b.hall_name_ar}{' '}
                        <span className="rounded bg-[#0B3B2B]/8 px-1.5 py-0.5 text-[10px] font-semibold text-[#0B3B2B]">
                          {getSuitabilityLabel(b.suitability_type, locale)} ({b.suitability_type || 'MIXED'})
                        </span>
                      </div>
                      <div className="text-xs text-[#52635B]">
                        {b.customer_name} · <span className="font-mono tabular-nums">{b.customer_phone}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs tabular-nums">
                      <div>{daysCount > 1 ? `${b.event_date} → ${endDateStr}` : b.event_date}</div>
                      <div className="font-sans text-[#52635B]">
                        {daysCount} {isAr ? (daysCount > 1 ? 'أيام' : 'يوم') : 'day(s)'} · {getShiftLabel(b.shift, locale)}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs tabular-nums">
                      <div className="font-semibold text-[#0B241C]">{formatMoney(b.total_amount, currency, locale)}</div>
                      <div className="font-sans text-[11px] text-[#52635B]">{b.payment_status}</div>
                    </td>
                    <td className="px-4 py-3 text-xs font-semibold">
                      {b.status === 'confirmed' ? (
                        <span className="text-emerald-800">{isAr ? 'مؤكد' : 'Confirmed'}</span>
                      ) : b.status === 'pending' ? (
                        <span className="text-amber-800">{isAr ? 'بانتظار التأكيد' : 'Pending'}</span>
                      ) : b.status === 'completed' ? (
                        <span className="text-[#0B3B2B]">{isAr ? 'مكتمل' : 'Completed'}</span>
                      ) : (
                        <span className="text-red-800">{isAr ? 'ملغي' : 'Cancelled'}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {b.status === 'pending' && (
                          <button
                            type="button"
                            onClick={() => handleBookingStatus(b.id, 'confirmed')}
                            className="inline-flex items-center gap-1 rounded bg-[#0B3B2B] px-2.5 py-1 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            <span>{isAr ? 'تأكيد الحجز' : 'Confirm'}</span>
                          </button>
                        )}
                        {b.status === 'confirmed' && (
                          <button
                            type="button"
                            onClick={() => handleBookingStatus(b.id, 'completed')}
                            className="rounded border border-[#0B3B2B]/20 px-2.5 py-1 text-xs font-semibold text-[#0B3B2B] hover:bg-[#FAF8F5]"
                          >
                            {isAr ? 'إتمام المناسبة' : 'Mark Completed'}
                          </button>
                        )}
                        {b.status !== 'cancelled' && b.status !== 'completed' && (
                          confirmCancelBookingId === b.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  handleBookingStatus(b.id, 'cancelled');
                                  setConfirmCancelBookingId(null);
                                }}
                                className="rounded bg-red-800 px-2 py-1 text-[11px] font-semibold text-white"
                              >
                                {isAr ? 'تأكيد الإلغاء' : 'Confirm Cancel'}
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmCancelBookingId(null)}
                                className="rounded border border-[#0B3B2B]/20 px-2 py-1 text-[11px] text-[#52635B]"
                              >
                                {isAr ? 'تراجع' : 'Back'}
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmCancelBookingId(b.id)}
                              className="inline-flex items-center gap-1 rounded border border-red-800/20 px-2.5 py-1 text-xs font-semibold text-red-800 hover:bg-red-950/5"
                            >
                              <XCircle className="h-3.5 w-3.5" />
                              <span>{isAr ? 'إلغاء' : 'Cancel'}</span>
                            </button>
                          )
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 3: Calendar & Availability Control */}
      {activeTab === 'calendar' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={handleCalendarUpdate}
            className="space-y-4 rounded-xl border border-[#0B3B2B]/12 bg-white p-6 lg:col-span-5"
          >
            <h3 className="font-display text-lg font-bold text-[#0B241C]">
              {isAr ? 'إغلاق أو فتح تاريخ في تقويم القاعة' : 'Block or Release Venue Date'}
            </h3>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'اختر القاعة' : 'Select Venue'}
              </label>
              <select
                value={calHallId}
                onChange={(e) => setCalHallId(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              >
                {data.halls.map((h) => (
                  <option key={Number(h.id)} value={Number(h.id)}>
                    {String(h.name_ar)}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'التاريخ' : 'Date'}
                </label>
                <input
                  type="date"
                  value={calDate}
                  onChange={(e) => setCalDate(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'الفترة' : 'Shift'}
                </label>
                <select
                  value={calShift}
                  onChange={(e) => setCalShift(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
                >
                  <option value="evening">{isAr ? 'مسائية' : 'Evening'}</option>
                  <option value="morning">{isAr ? 'صباحية' : 'Morning'}</option>
                  <option value="full_day">{isAr ? 'يوم كامل' : 'Full Day'}</option>
                </select>
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'الإجراء' : 'Action'}
              </label>
              <select
                value={calStatus}
                onChange={(e) => setCalStatus(e.target.value as 'blocked' | 'available')}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              >
                <option value="blocked">{isAr ? 'إغلاق التاريخ (صيانة / حجز خارجي)' : 'Block Date'}</option>
                <option value="available">{isAr ? 'إعادة فتح التاريخ للحجز' : 'Release Date (Available)'}</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'السبب / الملاحظة' : 'Reason'}
              </label>
              <input
                type="text"
                value={calReason}
                onChange={(e) => setCalReason(e.target.value)}
                placeholder={isAr ? 'مثال: صيانة منظومة الصوتيات...' : 'e.g., Audio system maintenance'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              <Calendar className="h-4 w-4 text-[#C5A059]" />
              <span>{isAr ? 'تحديث تقويم القاعة' : 'Save Calendar Rule'}</span>
            </button>
          </form>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-6 lg:col-span-7">
            <h3 className="mb-4 font-display text-lg font-bold text-[#0B241C]">
              {isAr ? 'الفترات المحجوزة والمغلقة حالياً' : 'Currently Booked & Blocked Slots'}
            </h3>
            <div className="space-y-2.5">
              {data.availability.map((slot, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between border-b border-[#0B3B2B]/8 pb-2.5 text-xs"
                >
                  <div>
                    <span className="font-mono font-semibold text-[#0B241C] tabular-nums">{String(slot.date)}</span>
                    <span className="mx-2 text-[#52635B]">·</span>
                    <span>{getShiftLabel(String(slot.shift), locale)}</span>
                  </div>
                  <div className="text-[#52635B]">{String(slot.reason || slot.status)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Customer Inquiries */}
      {activeTab === 'inquiries' && (
        <div className="space-y-4">
          {data.inquiries.map((inq) => (
            <div key={inq.id} className="rounded-xl border border-[#0B3B2B]/12 bg-white p-5">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#0B3B2B]/8 pb-3">
                <div>
                  <span className="font-mono text-xs font-semibold text-[#8A6829] tabular-nums">{inq.inquiry_code}</span>
                  <span className="mx-2 text-[#52635B]">·</span>
                  <span className="font-semibold text-[#0B241C]">{inq.subject}</span>
                  <span className="mx-2 text-[#52635B]">·</span>
                  <span className="text-xs text-[#52635B]">{inq.hall_name_ar}</span>
                </div>
                <span className="text-xs text-[#52635B]">
                  {inq.sender_name} ({inq.sender_phone})
                </span>
              </div>

              <div className="my-3 space-y-2">
                {inq.messages?.map((m) => (
                  <div
                    key={m.id}
                    className={`rounded-lg p-3 text-xs ${
                      m.is_owner_reply
                        ? 'bg-[#0B3B2B]/8 text-[#0B241C]'
                        : 'bg-[#FAF8F5] text-[#1E352D]'
                    }`}
                  >
                    <div className="mb-1 font-semibold text-[#0B3B2B]">
                      {m.is_owner_reply ? (isAr ? 'رد إدارة القاعة:' : 'Venue Reply:') : inq.sender_name}
                    </div>
                    <p>{m.message}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={replyText[inq.id] || ''}
                  onChange={(e) => setReplyText((prev) => ({ ...prev, [inq.id]: e.target.value }))}
                  placeholder={isAr ? 'اكتب رد رسمي للعميل...' : 'Write an official reply...'}
                  className="flex-1 rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                />
                <button
                  type="button"
                  onClick={() => handleReplyInquiry(inq.id)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                >
                  <MessageSquare className="h-3.5 w-3.5 text-[#C5A059]" />
                  <span>{isAr ? 'إرسال الرد' : 'Reply'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 5: Submit New Venue Form */}
      {activeTab === 'new_hall' && (
        <form
          onSubmit={handleCreateHall}
          className="mx-auto max-w-3xl space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-6"
        >
          <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
            <Building2 className="h-5 w-5 text-[#0B3B2B]" />
            <h2 className="font-display text-xl font-bold text-[#0B241C]">
              {isAr
                ? 'إدراج قاعة أو قصر أفراح جديد (يخضع لمراجعة واعتماد المدير العام)'
                : 'Submit New Wedding or Event Venue (Requires Super Admin Approval)'}
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'اسم القاعة (بالعربية) *' : 'Venue Name (Arabic) *'}
              </label>
              <input
                type="text"
                required
                value={nameAr}
                onChange={(e) => setNameAr(e.target.value)}
                placeholder="مثال: قصر الزمرد الملكي للأفراح"
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'اسم القاعة (بالإنجليزية)' : 'Venue Name (English)'}
              </label>
              <input
                type="text"
                value={nameEn}
                onChange={(e) => setNameEn(e.target.value)}
                placeholder="e.g., Emerald Royal Banquet Palace"
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'المحافظة / المدينة *' : 'Governorate / City *'}
              </label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              >
                {YEMEN_GOVERNORATES.map((gov) => (
                  <option key={gov.code} value={gov.code}>
                    {isAr ? gov.ar : gov.en}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'الحي / المنطقة' : 'District'}
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="مثال: حي حدة"
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'العنوان التفصيلي *' : 'Detailed Address *'}
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="صنعاء - شارع حدة الرئيسي"
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'الحد الأدنى للضيوف' : 'Min Capacity'}
              </label>
              <input
                type="number"
                value={capacityMin}
                onChange={(e) => setCapacityMin(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'السعة القصوى' : 'Max Capacity'}
              </label>
              <input
                type="number"
                value={capacityMax}
                onChange={(e) => setCapacityMax(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'سعر الفترة المسائية (ر.ي)' : 'Evening Price (YER)'}
              </label>
              <input
                type="number"
                value={eveningPrice}
                onChange={(e) => setEveningPrice(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'سعر الفترة الصباحية (ر.ي)' : 'Morning Price (YER)'}
              </label>
              <input
                type="number"
                value={morningPrice}
                onChange={(e) => setMorningPrice(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'تصنيف ملاءمة القاعة الأساسي *' : 'Primary Hall Suitability Classification *'}
              </label>
              <select
                data-testid="owner-hall-suitability-select"
                value={suitabilityType}
                onChange={(e) => setSuitabilityType(e.target.value as SuitabilityType)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold text-[#0B3B2B]"
              >
                {SUITABILITY_TYPES.map((st) => (
                  <option key={st.slug} value={st.slug}>
                    {isAr ? st.label_ar : st.label_en}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'فئة الفعالية العامة *' : 'General Venue Category *'}
              </label>
              <select
                value={hallType}
                onChange={(e) => setHallType(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold"
              >
                {HALL_TYPES.map((ht) => (
                  <option key={ht.slug} value={ht.slug}>
                    {isAr ? ht.label_ar : ht.label_en}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'نظام مدد الحجز المتاح *' : 'Booking Mode *'}
              </label>
              <select
                value={bookingMode}
                onChange={(e) => setBookingMode(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold"
              >
                <option value="both">{isAr ? 'فترات (صباحي/مسائي/يوم كامل) + بالساعات' : 'Shifts + Custom Hourly'}</option>
                <option value="shifts_only">{isAr ? 'نظام الفترات فقط (صباحي/مسائي/يوم كامل)' : 'Shifts Only'}</option>
                <option value="hourly_only">{isAr ? 'نظام الحجز بالساعات فقط' : 'Hourly Slots Only'}</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'خصم الأيام المتعددة (% لكل يوم إضافي)' : 'Multi-Day Discount (%)'}
              </label>
              <input
                type="number"
                min={0}
                max={25}
                value={multiDayDiscountPct}
                onChange={(e) => setMultiDayDiscountPct(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'رسوم خدمات إضافية لليوم (ر.ي)' : 'Additional Daily Fees (YER)'}
              </label>
              <input
                type="number"
                min={0}
                value={additionalFees}
                onChange={(e) => setAdditionalFees(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'سعر الساعة (ر.ي)' : 'Hourly Rate'}
              </label>
              <input
                type="number"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'المدة الافتراضية (س)' : 'Default (Hrs)'}
              </label>
              <input
                type="number"
                value={eventDurationHours}
                onChange={(e) => setEventDurationHours(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'أقل ساعات حجز' : 'Min Hours'}
              </label>
              <input
                type="number"
                value={minBookingHours}
                onChange={(e) => setMinBookingHours(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'أقصى ساعات حجز' : 'Max Hours'}
              </label>
              <input
                type="number"
                value={maxBookingHours}
                onChange={(e) => setMaxBookingHours(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'تجهيز مسبق (س)' : 'Prep Buffer'}
              </label>
              <input
                type="number"
                value={prepBufferHours}
                onChange={(e) => setPrepBufferHours(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'تنظيف وإخلاء (س)' : 'Cleanup Buffer'}
              </label>
              <input
                type="number"
                value={cleanupBufferHours}
                onChange={(e) => setCleanupBufferHours(Number(e.target.value))}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-sm tabular-nums"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold text-[#52635B]">
              {isAr ? 'وصف القاعة والتجهيزات المعمارية *' : 'Architectural & Hospitality Description *'}
            </label>
            <textarea
              rows={3}
              required
              value={descriptionAr}
              onChange={(e) => setDescriptionAr(e.target.value)}
              placeholder="اكتب وصفاً شاملاً للقاعة، الكوشة، التكييف، ومواقف السيارات..."
              className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-3 text-sm"
            />
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-[#0B3B2B] px-5 py-3 text-sm font-semibold text-white hover:bg-[#0F4C3A]"
          >
            {isAr ? 'إرسال القاعة للمراجعة والاعتماد' : 'Submit Venue for Super Admin Approval'}
          </button>
        </form>
      )}
    </div>
  );
};
