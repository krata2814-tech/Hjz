import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  UserPlus,
  Search,
  Bell,
  Settings,
  FileText,
  Landmark,
  Star,
  KeyRound,
  ShieldCheck,
  Lock,
  UserCog,
  Trash2,
  PauseCircle,
  Edit3,
} from 'lucide-react';
import {
  Locale,
  CurrencyCode,
  BookingRecord,
  PaymentRecord,
  EmployeeRecord,
  PermissionItem,
  SuitabilityType,
  PERMISSION_MODULES,
  SUITABILITY_TYPES,
  formatMoney,
  getCityLabel,
  getHallTypeLabel,
  getSuitabilityLabel,
} from '../types.ts';

interface SuperAdminPortalProps {
  locale: Locale;
  currency: CurrencyCode;
  apiFetch: (url: string, options?: RequestInit) => Promise<unknown>;
  onMarketplaceRefresh: () => void;
}

export const SuperAdminPortal: React.FC<SuperAdminPortalProps> = ({
  locale,
  currency,
  apiFetch,
  onMarketplaceRefresh,
}) => {
  const isAr = locale === 'ar';
  const [activeTab, setActiveTab] = useState<
    'employees_rbac' | 'halls' | 'users' | 'financials' | 'bookings_reviews' | 'settings_plans' | 'audit_notifications'
  >('halls');

  const [data, setData] = useState<{
    stats: {
      totalUsers: number;
      totalCustomers: number;
      totalHallOwners: number;
      totalEmployees: number;
      totalHalls: number;
      pendingHallApprovals: number;
      activeHalls: number;
      rejectedHalls: number;
      pendingBookings: number;
      confirmedBookings: number;
      cancelledBookings: number;
      completedBookings: number;
      financials: {
        grossBookingValue: number;
        verifiedPaidAmount: number;
        platformCommission: number;
        hallOwnerNetRevenue: number;
        pendingPaymentsAmount: number;
        refundedAmount: number;
        commissionRatePercentage: number;
      };
    };
    users: Array<Record<string, unknown>>;
    employees?: EmployeeRecord[];
    permissionsCatalog?: PermissionItem[];
    currentUserPermissions?: string[];
    halls: Array<Record<string, unknown>>;
    bookings: BookingRecord[];
    payments: PaymentRecord[];
    reviews: Array<Record<string, unknown>>;
    inquiries: Array<Record<string, unknown>>;
    subscriptionPlans: Array<Record<string, unknown>>;
    auditLogs: Array<Record<string, unknown>>;
    settings: Array<{ setting_key: string; setting_value: string; setting_group: string; description: string }>;
    supportTickets?: Array<Record<string, unknown>>;
  } | null>(null);

  const [loading, setLoading] = useState(true);
  const [banner, setBanner] = useState<string | null>(null);

  // Filters & Modals
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('all');
  const [rejectReasons, setRejectReasons] = useState<Record<number, string>>({});

  // Create Employee State (General Manager Module)
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empPhone, setEmpPhone] = useState('');
  const [empJobTitle, setEmpJobTitle] = useState('مشرف الحجوزات واعتماد القاعات');
  const [empDepartment, setEmpDepartment] = useState('إدارة التشغيل والجودة');
  const [empRoleSlug, setEmpRoleSlug] = useState<'employee' | 'support_agent'>('employee');
  const [empPassword, setEmpPassword] = useState('Staff@2026');
  const [newEmpPermissions, setNewEmpPermissions] = useState<string[]>([
    'dashboard.view_stats',
    'halls.view',
    'halls.approve_reject',
    'bookings.view',
    'bookings.review',
    'bookings.confirm',
  ]);

  // Selected Employee for Granular Permissions Matrix & Profile Edit / Password Reset
  const [selectedEmpId, setSelectedEmpId] = useState<number>(5);
  const [editingPermSlugs, setEditingPermSlugs] = useState<string[]>([]);
  const [editEmpName, setEditEmpName] = useState('');
  const [editEmpEmail, setEditEmpEmail] = useState('');
  const [editEmpPhone, setEditEmpPhone] = useState('');
  const [editEmpJobTitle, setEditEmpJobTitle] = useState('');
  const [editEmpDepartment, setEditEmpDepartment] = useState('');
  const [resetPasswordText, setResetPasswordText] = useState('');

  // Create Authorized User / Owner State
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('Owner@2026');
  const [newUserRole, setNewUserRole] = useState('hall_owner');
  const [newBusinessName, setNewBusinessName] = useState('');

  // Settings Form State
  const [settingsMap, setSettingsMap] = useState<Record<string, string>>({});

  // Notification Broadcast State
  const [notifRole, setNotifRole] = useState('all');
  const [notifTitleAr, setNotifTitleAr] = useState('');
  const [notifMessageAr, setNotifMessageAr] = useState('');

  const hasPerm = useCallback(
    (slugs: string[]) => {
      const perms = data?.currentUserPermissions || [];
      if (perms.includes('*')) return true;
      return slugs.some((s) => perms.includes(s));
    },
    [data?.currentUserPermissions]
  );

  const isGeneralManager = Boolean(data?.currentUserPermissions?.includes('*'));

  const loadAdminData = useCallback(async () => {
    setLoading(true);
    try {
      const res = (await apiFetch('/api/admin/dashboard')) as NonNullable<typeof data>;
      setData(res);
      const map: Record<string, string> = {};
      for (const s of res.settings) {
        map[s.setting_key] = s.setting_value;
      }
      setSettingsMap(map);

      if (res.employees && res.employees.length > 0) {
        const target = res.employees.find((e) => Number(e.id) === selectedEmpId) || res.employees[0];
        setSelectedEmpId(Number(target.id));
        setEditingPermSlugs(target.permissions || []);
        setEditEmpName(String(target.name || ''));
        setEditEmpEmail(String(target.email || ''));
        setEditEmpPhone(String(target.phone || ''));
        setEditEmpJobTitle(String(target.job_title || ''));
        setEditEmpDepartment(String(target.department || ''));
      }
    } finally {
      setLoading(false);
    }
  }, [apiFetch, selectedEmpId]);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData]);

  function handleSelectEmployee(emp: EmployeeRecord) {
    setSelectedEmpId(Number(emp.id));
    setEditingPermSlugs(emp.permissions || []);
    setEditEmpName(emp.name);
    setEditEmpEmail(emp.email);
    setEditEmpPhone(emp.phone);
    setEditEmpJobTitle(emp.job_title);
    setEditEmpDepartment(emp.department);
    setResetPasswordText('');
  }

  async function handleCreateEmployee(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = (await apiFetch('/api/admin/employees', {
        method: 'POST',
        body: JSON.stringify({
          name: empName,
          email: empEmail,
          phone: empPhone,
          jobTitle: empJobTitle,
          department: empDepartment,
          roleSlug: empRoleSlug,
          password: empPassword,
          permissions: newEmpPermissions,
        }),
      })) as { employee: { id: number } };
      setEmpName('');
      setEmpEmail('');
      setEmpPhone('');
      setSelectedEmpId(Number(res.employee.id));
      setBanner(
        isAr
          ? 'تم إنشاء حساب الموظف المستقل وتخصيص صلاحياته الفردية وتوثيق العملية في سجل التدقيق.'
          : 'Employee account created with individual granular permissions.'
      );
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر إنشاء حساب الموظف');
    }
  }

  async function handleUpdateEmployeeInfo(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch(`/api/admin/employees/${selectedEmpId}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editEmpName,
          email: editEmpEmail,
          phone: editEmpPhone,
          jobTitle: editEmpJobTitle,
          department: editEmpDepartment,
        }),
      });
      setBanner(isAr ? 'تم تحديث البيانات الوظيفية للموظف بنجاح.' : 'Employee profile updated.');
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث بيانات الموظف');
    }
  }

  async function handleSetEmployeeStatus(empId: number, status: 'active' | 'inactive' | 'suspended') {
    try {
      await apiFetch(`/api/admin/employees/${empId}`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
      });
      setBanner(
        isAr
          ? `تم تحديث حالة حساب الموظف إلى (${status === 'active' ? 'نشط' : status === 'inactive' ? 'معطل' : 'معلق'}) فوراً.`
          : `Employee account status set to ${status}.`
      );
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تغيير حالة الموظف');
    }
  }

  async function handleResetEmployeePassword(e: React.FormEvent) {
    e.preventDefault();
    if (!resetPasswordText) return;
    try {
      await apiFetch(`/api/admin/employees/${selectedEmpId}/password`, {
        method: 'POST',
        body: JSON.stringify({ newPassword: resetPasswordText }),
      });
      setResetPasswordText('');
      setBanner(
        isAr
          ? 'تم إعادة تعيين كلمة مرور الموظف بشكل آمن وتوثيق العملية في سجل التدقيق.'
          : 'Employee password securely reset.'
      );
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر إعادة تعيين كلمة المرور');
    }
  }

  async function handleSaveEmployeePermissions(customList?: string[]) {
    const listToSave = customList !== undefined ? customList : editingPermSlugs;
    try {
      await apiFetch(`/api/admin/employees/${selectedEmpId}/permissions`, {
        method: 'POST',
        body: JSON.stringify({ permissions: listToSave }),
      });
      setEditingPermSlugs(listToSave);
      setBanner(
        listToSave.length === 0
          ? isAr
            ? 'تم سحب وإلغاء كافة الصلاحيات من الموظف فوراً.'
            : 'All permissions immediately revoked from employee.'
          : isAr
          ? `تم حفظ مصفوفة الصلاحيات للموظف (${listToSave.length} صلاحية مفعلة) وتطبيقها فوراً.`
          : `Saved ${listToSave.length} granular permissions for employee.`
      );
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث صلاحيات الموظف');
    }
  }

  async function handleModerateHall(hallId: number, status?: string, featured?: boolean, suitabilityType?: SuitabilityType) {
    try {
      const rejectionReason = rejectReasons[hallId] || '';
      await apiFetch(`/api/admin/halls/${hallId}/moderate`, {
        method: 'POST',
        body: JSON.stringify({ status, rejectionReason, featured, suitabilityType }),
      });
      setBanner(isAr ? 'تم تحديث بيانات واعتماد القاعة وتوثيق الإجراء في سجل التدقيق.' : 'Venue moderation updated.');
      await loadAdminData();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث حالة القاعة');
    }
  }

  async function handleDeleteHall(hallId: number) {
    try {
      await apiFetch(`/api/admin/halls/${hallId}`, { method: 'DELETE' });
      setBanner(isAr ? 'تم حذف القاعة بتفويض إداري وتوثيق العملية.' : 'Venue listing deleted.');
      await loadAdminData();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر حذف القاعة');
    }
  }

  async function handleToggleUserStatus(userId: number, currentStatus: string) {
    const nextStatus = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      await apiFetch(`/api/admin/users/${userId}/status`, {
        method: 'POST',
        body: JSON.stringify({ status: nextStatus }),
      });
      setBanner(isAr ? `تم تغيير حالة الحساب إلى (${nextStatus}) وتوثيق العملية.` : `Account status set to ${nextStatus}.`);
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تعديل حالة الحساب');
    }
  }

  async function handleVerifyOwner(userId: number, verified: boolean, action?: 'request_documents') {
    try {
      await apiFetch(`/api/admin/owners/${userId}/verify`, {
        method: 'POST',
        body: JSON.stringify({ verified, action }),
      });
      setBanner(
        action === 'request_documents'
          ? isAr
            ? 'تم إرسال طلب استكمال مستندات الملكية والسجل التجاري إلى المالك.'
            : 'Requested additional verification documents from owner.'
          : isAr
          ? 'تم تحديث حالة توثيق السجل التجاري للمالك.'
          : 'Owner verification updated.'
      );
      await loadAdminData();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث توثيق المالك');
    }
  }

  async function handleAdminBookingStatus(bookingId: number, status: 'confirmed' | 'cancelled' | 'completed') {
    try {
      await apiFetch(`/api/admin/bookings/${bookingId}/status`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      setBanner(isAr ? 'تم تحديث حالة الحجز وجدول التوفر بنجاح.' : 'Booking status updated.');
      await loadAdminData();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث حالة الحجز');
    }
  }

  async function handleCreateAuthorizedUser(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/admin/users/create', {
        method: 'POST',
        body: JSON.stringify({
          name: newUserName,
          email: newUserEmail,
          phone: newUserPhone,
          password: newUserPassword,
          roleSlug: newUserRole,
          businessName: newBusinessName,
        }),
      });
      setNewUserName('');
      setNewUserEmail('');
      setNewUserPhone('');
      setNewBusinessName('');
      setBanner(isAr ? 'تم إنشاء الحساب المعتمد بنجاح وتسجيله في سجل التدقيق.' : 'Authorized account created.');
      await loadAdminData();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر إنشاء الحساب');
    }
  }

  async function handleVerifyPayment(paymentId: number, status: 'verified' | 'refunded') {
    try {
      await apiFetch(`/api/admin/payments/${paymentId}/verify`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      setBanner(
        isAr
          ? `تم تحديث السجل المالي إلى (${status === 'verified' ? 'مدفوع وموثق' : 'مسترد'}) وإعادة احتساب الإيرادات.`
          : `Payment marked as ${status}.`
      );
      await loadAdminData();
      onMarketplaceRefresh();
    } catch (err: unknown) {
      setBanner(err instanceof Error ? err.message : 'تعذر تحديث السجل المالي');
    }
  }

  async function handleSaveSettings(e: React.FormEvent) {
    e.preventDefault();
    await apiFetch('/api/admin/settings', {
      method: 'POST',
      body: JSON.stringify({ settings: settingsMap }),
    });
    setBanner(isAr ? 'تم حفظ إعدادات المنصة والعمولات بنجاح.' : 'Platform settings saved.');
    await loadAdminData();
    onMarketplaceRefresh();
  }

  async function handleBroadcastNotification(e: React.FormEvent) {
    e.preventDefault();
    const res = (await apiFetch('/api/admin/notifications/broadcast', {
      method: 'POST',
      body: JSON.stringify({
        targetRole: notifRole,
        titleAr: notifTitleAr,
        messageAr: notifMessageAr,
      }),
    })) as { recipientCount: number };
    setNotifTitleAr('');
    setNotifMessageAr('');
    setBanner(
      isAr
        ? `تم إرسال الإشعار التعميمي بنجاح إلى ${res.recipientCount} مستخدم.`
        : `Broadcast sent to ${res.recipientCount} users.`
    );
    await loadAdminData();
  }

  if (loading || !data) {
    return (
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="h-40 animate-pulse rounded-xl bg-[#F3EFEA]" />
      </div>
    );
  }

  const { stats } = data;
  const filteredUsers = data.users.filter((u) => {
    const matchesRole = userRoleFilter === 'all' || u.role_slug === userRoleFilter;
    const q = userSearch.trim().toLowerCase();
    const matchesQuery =
      !q ||
      String(u.name).toLowerCase().includes(q) ||
      String(u.email).toLowerCase().includes(q) ||
      String(u.phone).toLowerCase().includes(q);
    return matchesRole && matchesQuery;
  });

  const permissionsByModule: Record<string, PermissionItem[]> = {};
  for (const p of data.permissionsCatalog || []) {
    if (!permissionsByModule[p.module]) {
      permissionsByModule[p.module] = [];
    }
    permissionsByModule[p.module].push(p);
  }

  const employeeActivityLogs = data.auditLogs.filter(
    (l) => l.actor_role === 'employee' || l.actor_role === 'support_agent' || l.entity_type === 'employees'
  );

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-6 py-8">
      {/* Command Center Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#0B3B2B]/15 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#52635B]">
            <ShieldAlert className="h-4 w-4 text-[#0B3B2B]" />
            <span>
              {isGeneralManager
                ? isAr
                  ? 'لوحة المدير العام والحوكمة الشاملة للمنصة (صلاحيات كاملة + إدارة الموظفين و RBAC)'
                  : 'General Manager Governance & Employee RBAC Center'
                : isAr
                ? `بوابة الموظف التشغيلية — مقيدة حسب الصلاحيات الممنوحة (${data.currentUserPermissions?.length || 0} صلاحية نشطة)`
                : `Permission-Scoped Employee Workspace (${data.currentUserPermissions?.length || 0} active permissions)`}
            </span>
          </div>
          <h1 className="font-display text-3xl font-bold text-[#0B241C]">
            {isGeneralManager
              ? isAr
                ? 'لوحة المدير العام — مناسبتي'
                : 'Munasabati General Manager Dashboard'
              : isAr
              ? 'مساحة عمل الموظف المخول — مناسبتي'
              : 'Authorized Employee Workspace'}
          </h1>
        </div>

        {/* Dynamic Permission-Gated Module Tabs */}
        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-[#F3EFEA] p-1">
          {[
            ...(isGeneralManager
              ? [
                  {
                    id: 'employees_rbac',
                    ar: `الموظفون والصلاحيات (${stats.totalEmployees})`,
                    en: `Employees & RBAC (${stats.totalEmployees})`,
                  },
                ]
              : []),
            ...(hasPerm(['halls.view', 'halls.approve_reject', 'owners.view_applications'])
              ? [
                  {
                    id: 'halls',
                    ar: `القاعات والتوثيق (${stats.pendingHallApprovals} معلقة)`,
                    en: `Venues & Verification (${stats.pendingHallApprovals})`,
                  },
                ]
              : []),
            ...(hasPerm(['customers.view', 'customers.edit', 'customers.suspend_reactivate'])
              ? [
                  {
                    id: 'users',
                    ar: `العملاء والملاك (${stats.totalUsers})`,
                    en: `Customers & Users (${stats.totalUsers})`,
                  },
                ]
              : []),
            ...(hasPerm(['finance.view_payments', 'finance.verify_payments', 'finance.view_commissions'])
              ? [
                  {
                    id: 'financials',
                    ar: 'المالية والمدفوعات',
                    en: 'Financials & Payments',
                  },
                ]
              : []),
            ...(hasPerm(['bookings.view', 'bookings.review', 'bookings.confirm', 'content.moderate_reviews', 'support.view_tickets'])
              ? [
                  {
                    id: 'bookings_reviews',
                    ar: 'الحجوزات والتقييمات والدعم',
                    en: 'Bookings, Reviews & Support',
                  },
                ]
              : []),
            ...(isGeneralManager
              ? [
                  { id: 'settings_plans', ar: 'إعدادات المنصة والباقات', en: 'Platform Settings & Plans' },
                  { id: 'audit_notifications', ar: `سجل التدقيق (${data.auditLogs.length})`, en: `Audit Logs (${data.auditLogs.length})` },
                ]
              : []),
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id as typeof activeTab)}
              className={`rounded-md px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                activeTab === t.id ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B] hover:text-[#0B241C]'
              }`}
            >
              {isAr ? t.ar : t.en}
            </button>
          ))}
        </div>
      </div>

      {/* If logged in as an Employee, show their active Granular Permissions Banner */}
      {!isGeneralManager && (
        <div className="rounded-xl border border-[#0B3B2B]/15 bg-white p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0B3B2B]">
              <Lock className="h-4 w-4 text-[#C5A059]" />
              <span>
                {isAr
                  ? 'الصلاحيات الفردية الممنوحة لحسابك من المدير العام (لا يمكنك منح نفسك صلاحيات إضافية):'
                  : 'Your individual permissions granted by the General Manager:'}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(data.currentUserPermissions || []).map((slug) => (
                <span
                  key={slug}
                  className="rounded border border-[#0B3B2B]/15 bg-[#FAF8F5] px-2 py-0.5 font-mono text-[11px] font-medium text-[#0B241C]"
                >
                  {slug}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {banner && (
        <div className="flex items-center justify-between rounded-lg border border-[#C5A059]/50 bg-white px-4 py-3 text-sm font-medium text-[#0B241C]">
          <span>{banner}</span>
          <button onClick={() => setBanner(null)} className="text-xs font-semibold text-[#8A6829]">
            {isAr ? 'إغلاق' : 'Dismiss'}
          </button>
        </div>
      )}

      {/* Database-Backed Executive Statistics Grid (Protected by dashboard.view_stats) */}
      {hasPerm(['dashboard.view_stats', 'dashboard.view_reports']) && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">{isAr ? 'إجمالي المستخدمين' : 'Total Users'}</div>
            <div className="mt-1 font-mono text-xl font-bold text-[#0B241C] tabular-nums">{stats.totalUsers}</div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {stats.totalCustomers} {isAr ? 'عميل' : 'Cust'} · {stats.totalHallOwners} {isAr ? 'مالك' : 'Owners'} · {stats.totalEmployees} {isAr ? 'موظف' : 'Staff'}
            </div>
          </div>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">{isAr ? 'إجمالي القاعات' : 'Total Halls'}</div>
            <div className="mt-1 font-mono text-xl font-bold text-[#0B241C] tabular-nums">{stats.totalHalls}</div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {stats.activeHalls} {isAr ? 'نشطة' : 'Active'} ·{' '}
              <span className="font-semibold text-amber-800">
                {stats.pendingHallApprovals} {isAr ? 'معلقة' : 'Pending'}
              </span>
            </div>
          </div>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">{isAr ? 'الحجوزات المؤكدة والمكتملة' : 'Confirmed Bookings'}</div>
            <div className="mt-1 font-mono text-xl font-bold text-[#0B3B2B] tabular-nums">
              {stats.confirmedBookings + stats.completedBookings}
            </div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {stats.pendingBookings} {isAr ? 'بانتظار التأكيد' : 'Pending'} · {stats.cancelledBookings} {isAr ? 'ملغاة' : 'Cancelled'}
            </div>
          </div>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">{isAr ? 'المدفوعات الموثقة فعلياً' : 'Verified Paid Revenue'}</div>
            <div className="mt-1 font-mono text-lg font-bold text-emerald-800 tabular-nums">
              {formatMoney(stats.financials.verifiedPaidAmount, currency, locale)}
            </div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {isAr ? 'قيمة العقود:' : 'Gross:'} {formatMoney(stats.financials.grossBookingValue, currency, locale)}
            </div>
          </div>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">
              {isAr ? `عمولة المنصة (${stats.financials.commissionRatePercentage}%)` : `Platform Commission (${stats.financials.commissionRatePercentage}%)`}
            </div>
            <div className="mt-1 font-mono text-lg font-bold text-[#8A6829] tabular-nums">
              {formatMoney(stats.financials.platformCommission, currency, locale)}
            </div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {isAr ? 'صافي الملاك:' : 'Owners Net:'} {formatMoney(stats.financials.hallOwnerNetRevenue, currency, locale)}
            </div>
          </div>

          <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
            <div className="text-[11px] text-[#52635B]">{isAr ? 'مدفوعات قيد التحقق' : 'Pending Verification'}</div>
            <div className="mt-1 font-mono text-lg font-bold text-amber-800 tabular-nums">
              {formatMoney(stats.financials.pendingPaymentsAmount, currency, locale)}
            </div>
            <div className="mt-1 text-[11px] text-[#52635B] tabular-nums">
              {isAr ? 'المرتجعات:' : 'Refunds:'} {formatMoney(stats.financials.refundedAmount, currency, locale)}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODULE TAB 0: GENERAL MANAGER EMPLOYEE MANAGEMENT & GRANULAR RBAC     */}
      {/* ===================================================================== */}
      {activeTab === 'employees_rbac' && isGeneralManager && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Left Column: Create Individual Employee Account */}
            <form
              onSubmit={handleCreateEmployee}
              className="space-y-3.5 rounded-xl border border-[#0B3B2B]/15 bg-white p-5 lg:col-span-5"
            >
              <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
                <UserPlus className="h-4 w-4 text-[#0B3B2B]" />
                <div>
                  <h3 className="font-display text-lg font-bold text-[#0B241C]">
                    {isAr ? 'إنشاء حساب موظف جديد وتخصيص صلاحياته' : 'Create Individual Employee Account'}
                  </h3>
                  <p className="text-[11px] text-[#52635B]">
                    {isAr
                      ? 'يُمنع التسجيل العام للموظفين؛ يُنشأ لكل موظف حساب مستقل بصلاحيات محددة.'
                      : 'Public employee registration is disabled; each employee has an isolated login.'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'الاسم الكامل للموظف *' : 'Employee Full Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={empName}
                    onChange={(e) => setEmpName(e.target.value)}
                    placeholder={isAr ? 'مثال: أمل الحكيمي' : 'Full name'}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'المسمى الوظيفي *' : 'Job Title *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={empJobTitle}
                    onChange={(e) => setEmpJobTitle(e.target.value)}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'البريد الإلكتروني الرسمي (فريد) *' : 'Official Email (Unique) *'}
                  </label>
                  <input
                    type="email"
                    required
                    value={empEmail}
                    onChange={(e) => setEmpEmail(e.target.value)}
                    placeholder="staff.member@munasabati.com"
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'رقم الهاتف *' : 'Phone Number *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={empPhone}
                    onChange={(e) => setEmpPhone(e.target.value)}
                    placeholder="+96777..."
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'القسم / الإدارة' : 'Department'}
                  </label>
                  <input
                    type="text"
                    value={empDepartment}
                    onChange={(e) => setEmpDepartment(e.target.value)}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'الفئة الوظيفية' : 'Role Category'}
                  </label>
                  <select
                    value={empRoleSlug}
                    onChange={(e) => setEmpRoleSlug(e.target.value as 'employee' | 'support_agent')}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold"
                  >
                    <option value="employee">{isAr ? 'موظف إداري وتشغيلي' : 'Operations Employee'}</option>
                    <option value="support_agent">{isAr ? 'أخصائي دعم وشكاوى' : 'Support Agent'}</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'كلمة المرور المبدئية *' : 'Initial Password *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={empPassword}
                    onChange={(e) => setEmpPassword(e.target.value)}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-[#0B241C]">
                  <span>{isAr ? 'الصلاحيات الأولية للموظف الجديد:' : 'Initial Employee Permissions:'}</span>
                  <span className="font-mono text-[#8A6829] tabular-nums">{newEmpPermissions.length}</span>
                </div>
                <div className="max-h-40 space-y-1.5 overflow-y-auto rounded-lg border border-[#0B3B2B]/12 bg-[#FAF8F5] p-2.5 text-xs">
                  {(data.permissionsCatalog || []).map((perm) => {
                    const checked = newEmpPermissions.includes(perm.slug);
                    return (
                      <label key={perm.slug} className="flex cursor-pointer items-center gap-2 py-0.5">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setNewEmpPermissions((prev) =>
                              checked ? prev.filter((s) => s !== perm.slug) : [...prev, perm.slug]
                            )
                          }
                          className="h-3.5 w-3.5 accent-[#0B3B2B]"
                        />
                        <span className="font-medium text-[#0B241C]">{isAr ? perm.name_ar : perm.name_en}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
              >
                {isAr ? 'إنشاء حساب الموظف وتفعيل الصلاحيات' : 'Create Employee Account & Assign Permissions'}
              </button>
            </form>

            {/* Right Column: Employees Directory & Status / Profile / Password Control */}
            <div className="space-y-4 lg:col-span-7">
              <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
                <div className="flex items-center justify-between border-b border-[#0B3B2B]/10 bg-[#FAF8F5] px-5 py-3.5">
                  <h3 className="font-display text-lg font-bold text-[#0B241C]">
                    {isAr ? 'قائمة موظفي المنصة وحالة حساباتهم' : 'Platform Employees Directory & Status'}
                  </h3>
                  <span className="text-xs text-[#52635B]">
                    {isAr ? 'اختر موظفاً لتعديل صلاحياته أو بياناته' : 'Select an employee to configure permissions'}
                  </span>
                </div>
                <table className="w-full text-start text-xs">
                  <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                    <tr>
                      <th className="px-4 py-2.5 text-start">{isAr ? 'الموظف والمسمى الوظيفي' : 'Employee & Job Title'}</th>
                      <th className="px-4 py-2.5 text-start">{isAr ? 'الصلاحيات' : 'Permissions'}</th>
                      <th className="px-4 py-2.5 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                      <th className="px-4 py-2.5 text-start">{isAr ? 'إجراءات سريعة' : 'Quick Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#0B3B2B]/8">
                    {(data.employees || []).map((emp) => {
                      const isSelected = Number(emp.id) === selectedEmpId;
                      return (
                        <tr
                          key={emp.id}
                          onClick={() => handleSelectEmployee(emp)}
                          className={`cursor-pointer transition-colors ${
                            isSelected ? 'bg-[#0B3B2B]/6' : 'hover:bg-[#FAF8F5]'
                          }`}
                        >
                          <td className="px-4 py-3">
                            <div className="font-semibold text-[#0B241C]">{emp.name}</div>
                            <div className="text-[11px] font-medium text-[#0B3B2B]">
                              {emp.job_title} · {emp.department}
                            </div>
                            <div className="font-mono text-[11px] text-[#52635B] tabular-nums">
                              {emp.email} · {emp.phone}
                            </div>
                          </td>
                          <td className="px-4 py-3 font-mono font-semibold text-[#8A6829] tabular-nums">
                            {emp.permissions.length} {isAr ? 'صلاحية' : 'Granted'}
                          </td>
                          <td className="px-4 py-3 font-semibold">
                            {emp.status === 'active' ? (
                              <span className="text-emerald-800">{isAr ? 'نشط' : 'Active'}</span>
                            ) : emp.status === 'inactive' ? (
                              <span className="text-amber-800">{isAr ? 'غير نشط' : 'Inactive'}</span>
                            ) : (
                              <span className="text-red-800">{isAr ? 'موقوف' : 'Suspended'}</span>
                            )}
                          </td>
                          <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                            <div className="flex flex-wrap items-center gap-1.5">
                              {emp.status !== 'active' && (
                                <button
                                  type="button"
                                  onClick={() => handleSetEmployeeStatus(Number(emp.id), 'active')}
                                  className="rounded bg-[#0B3B2B] px-2 py-1 text-[11px] font-semibold text-white"
                                >
                                  {isAr ? 'تفعيل' : 'Activate'}
                                </button>
                              )}
                              {emp.status === 'active' && (
                                <button
                                  type="button"
                                  onClick={() => handleSetEmployeeStatus(Number(emp.id), 'inactive')}
                                  className="rounded border border-amber-800/30 px-2 py-1 text-[11px] font-semibold text-amber-800"
                                >
                                  {isAr ? 'تعطيل مؤقت' : 'Deactivate'}
                                </button>
                              )}
                              {emp.status !== 'suspended' && (
                                <button
                                  type="button"
                                  onClick={() => handleSetEmployeeStatus(Number(emp.id), 'suspended')}
                                  className="rounded border border-red-800/30 px-2 py-1 text-[11px] font-semibold text-red-800"
                                >
                                  {isAr ? 'إيقاف' : 'Suspend'}
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Selected Employee Profile Editor & Password Reset */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <form
                  onSubmit={handleUpdateEmployeeInfo}
                  className="space-y-3 rounded-xl border border-[#0B3B2B]/15 bg-white p-4"
                >
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#0B241C]">
                    <Edit3 className="h-3.5 w-3.5 text-[#0B3B2B]" />
                    <span>{isAr ? 'تعديل بيانات الموظف المحدد' : 'Edit Selected Employee Info'}</span>
                  </div>
                  <input
                    type="text"
                    required
                    value={editEmpName}
                    onChange={(e) => setEditEmpName(e.target.value)}
                    placeholder={isAr ? 'الاسم الكامل' : 'Full Name'}
                    className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 text-xs"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="email"
                      required
                      value={editEmpEmail}
                      onChange={(e) => setEditEmpEmail(e.target.value)}
                      className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 font-mono text-xs"
                    />
                    <input
                      type="text"
                      required
                      value={editEmpPhone}
                      onChange={(e) => setEditEmpPhone(e.target.value)}
                      className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 font-mono text-xs"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={editEmpJobTitle}
                      onChange={(e) => setEditEmpJobTitle(e.target.value)}
                      placeholder={isAr ? 'المسمى الوظيفي' : 'Job Title'}
                      className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 text-xs"
                    />
                    <input
                      type="text"
                      value={editEmpDepartment}
                      onChange={(e) => setEditEmpDepartment(e.target.value)}
                      placeholder={isAr ? 'القسم' : 'Department'}
                      className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1.5 text-xs"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded bg-[#0B3B2B] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                  >
                    {isAr ? 'حفظ تعديلات بيانات الموظف' : 'Save Employee Profile'}
                  </button>
                </form>

                <form
                  onSubmit={handleResetEmployeePassword}
                  className="flex flex-col justify-between space-y-3 rounded-xl border border-[#0B3B2B]/15 bg-white p-4"
                >
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#0B241C]">
                      <KeyRound className="h-3.5 w-3.5 text-[#8A6829]" />
                      <span>{isAr ? 'إعادة تعيين كلمة مرور الموظف بشكل آمن' : 'Secure Employee Password Reset'}</span>
                    </div>
                    <p className="text-[11px] text-[#52635B]">
                      {isAr
                        ? `تعيين كلمة مرور جديدة للموظف (${editEmpName}) مع تشفير Scrypt فوري.`
                        : `Set a new password for (${editEmpName}).`}
                    </p>
                    <input
                      type="text"
                      required
                      minLength={8}
                      value={resetPasswordText}
                      onChange={(e) => setResetPasswordText(e.target.value)}
                      placeholder={isAr ? 'كلمة المرور الجديدة (8 أحرف على الأقل)...' : 'New password (min 8 chars)...'}
                      className="w-full rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded border border-[#0B3B2B] bg-[#FAF8F5] px-3 py-2 text-xs font-semibold text-[#0B3B2B] hover:bg-[#0B3B2B] hover:text-white"
                  >
                    {isAr ? 'تحديث كلمة المرور الآن' : 'Reset Password Securely'}
                  </button>
                </form>
              </div>
            </div>
          </div>

          {/* Granular 8-Category Permission Matrix for Selected Employee */}
          <div className="rounded-xl border border-[#0B3B2B]/15 bg-white p-6">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-4 border-b border-[#0B3B2B]/10 pb-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-[#8A6829]">
                  <UserCog className="h-4 w-4" />
                  <span>{isAr ? 'مصفوفة الصلاحيات التفصيلية (Granular RBAC Matrix)' : 'Granular RBAC Permission Matrix'}</span>
                </div>
                <h3 className="mt-1 font-display text-xl font-bold text-[#0B241C]">
                  {isAr
                    ? `تخصيص صلاحيات الموظف: ${editEmpName} (${editEmpJobTitle})`
                    : `Configure Permissions for: ${editEmpName} (${editEmpJobTitle})`}
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setEditingPermSlugs((data.permissionsCatalog || []).map((p) => p.slug))
                  }
                  className="rounded border border-[#0B3B2B]/20 px-3 py-1.5 text-xs font-semibold text-[#0B3B2B] hover:bg-[#FAF8F5]"
                >
                  {isAr ? 'تحديد الكل' : 'Select All'}
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveEmployeePermissions([])}
                  className="rounded border border-red-800/30 px-3 py-1.5 text-xs font-semibold text-red-800 hover:bg-red-950/5"
                >
                  {isAr ? 'سحب جميع الصلاحيات فوراً' : 'Revoke All Immediately'}
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveEmployeePermissions()}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                >
                  <ShieldCheck className="h-4 w-4 text-[#C5A059]" />
                  <span>{isAr ? 'حفظ وتطبيق الصلاحيات المحددة' : 'Save & Enforce Permissions'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
              {Object.entries(PERMISSION_MODULES).map(([modKey, modLabel]) => {
                const modPerms = permissionsByModule[modKey] || [];
                return (
                  <div key={modKey} className="rounded-lg border border-[#0B3B2B]/12 bg-[#FAF8F5] p-4">
                    <div className="mb-2.5 border-b border-[#0B3B2B]/10 pb-2 text-xs font-bold text-[#0B3B2B]">
                      {isAr ? modLabel.ar : modLabel.en}
                    </div>
                    <div className="space-y-2 text-xs">
                      {modPerms.map((perm) => {
                        const isChecked = editingPermSlugs.includes(perm.slug);
                        return (
                          <label key={perm.slug} className="flex cursor-pointer items-start gap-2">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() =>
                                setEditingPermSlugs((prev) =>
                                  isChecked ? prev.filter((s) => s !== perm.slug) : [...prev, perm.slug]
                                )
                              }
                              className="mt-0.5 h-3.5 w-3.5 accent-[#0B3B2B]"
                            />
                            <div>
                              <div className="font-medium text-[#0B241C]">{isAr ? perm.name_ar : perm.name_en}</div>
                              <div className="font-mono text-[10px] text-[#52635B]">{perm.slug}</div>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Employee Activity Logs */}
          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
            <div className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] px-5 py-3.5">
              <h3 className="font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'سجل نشاطات وإجراءات الموظفين (Employee Activity Logs)' : 'Employee Activity & Permission Audit Logs'}
              </h3>
            </div>
            <div className="max-h-72 overflow-y-auto">
              <table className="w-full text-start text-xs">
                <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                  <tr>
                    <th className="px-4 py-2.5 text-start">#</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'العملية' : 'Action'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'المنفذ' : 'Actor'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'التفاصيل' : 'Details'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'التوقيت' : 'Time'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#0B3B2B]/8">
                  {employeeActivityLogs.map((log) => (
                    <tr key={Number(log.id)} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-2 font-mono tabular-nums">{String(log.id)}</td>
                      <td className="px-4 py-2 font-mono font-semibold text-[#0B3B2B]">{String(log.action)}</td>
                      <td className="px-4 py-2">{String(log.actor_name || 'General Manager')}</td>
                      <td className="max-w-md truncate px-4 py-2 font-mono text-[11px] text-[#52635B]">
                        {String(log.details_json || '')}
                      </td>
                      <td className="px-4 py-2 font-mono text-[11px] text-[#52635B] tabular-nums">
                        {String(log.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODULE TAB 1: Hall Approval, Rejection with Reason & Owner Verification Queue */}
      {activeTab === 'halls' && (
        <div className="space-y-6">
          {/* Owner Commercial Registration & Verification Queue */}
          {hasPerm(['owners.view_applications', 'owners.review_documents', 'owners.approve_reject']) && (
            <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#0B3B2B]/10 bg-[#FAF8F5] px-5 py-3.5">
                <div>
                  <h3 className="font-display text-lg font-bold text-[#0B241C]">
                    {isAr ? 'مراجعة وتوثيق السجلات التجارية ووثائق ملكية الملاك' : 'Hall Owner Verification & Ownership Documents Queue'}
                  </h3>
                  <p className="text-xs text-[#52635B]">
                    {isAr
                      ? 'لا تظهر قاعات المالك في البحث العام إلا بعد توثيق سجله التجاري ووثائق الملكية.'
                      : 'Unverified owner venues remain hidden from public search until verified.'}
                  </p>
                </div>
              </div>
              <div className="divide-y divide-[#0B3B2B]/8 px-5 py-2 text-xs">
                {data.users
                  .filter((u) => u.role_slug === 'hall_owner')
                  .map((owner) => {
                    const uid = Number(owner.id);
                    const isVerified = Boolean(owner.owner_verified);
                    const verStatus = String(owner.verification_status || (isVerified ? 'verified' : 'pending'));
                    return (
                      <div key={uid} className="flex flex-wrap items-center justify-between gap-3 py-3">
                        <div>
                          <span className="font-semibold text-[#0B241C]">{String(owner.name)}</span>
                          <span className="mx-2 text-[#52635B]">·</span>
                          <span className="font-medium text-[#0B3B2B]">
                            {String(owner.business_name || 'مؤسسة مناسبات')}
                          </span>
                          <span className="mx-2 text-[#52635B]">·</span>
                          <span className="font-mono text-[#52635B] tabular-nums">
                            {String(owner.commercial_registration_no || 'CR-PENDING')}
                          </span>
                          {hasPerm(['owners.review_documents']) && Boolean(owner.verification_document_url) && (
                            <>
                              <span className="mx-2 text-[#52635B]">·</span>
                              <span className="font-mono text-[11px] text-[#8A6829]">
                                {String(owner.verification_document_url)}
                              </span>
                            </>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`font-semibold ${
                              isVerified
                                ? 'text-emerald-800'
                                : verStatus === 'additional_documents_requested'
                                ? 'text-[#8A6829]'
                                : 'text-amber-800'
                            }`}
                          >
                            {isVerified
                              ? isAr
                                ? 'سجل تجاري موثق ✓'
                                : 'Verified Owner ✓'
                              : verStatus === 'additional_documents_requested'
                              ? isAr
                                ? 'تم طلب مستندات إضافية'
                                : 'Additional Docs Requested'
                              : isAr
                              ? 'بانتظار مراجعة الوثائق'
                              : 'Pending Verification'}
                          </span>
                          {hasPerm(['owners.request_documents']) && !isVerified && (
                            <button
                              type="button"
                              onClick={() => handleVerifyOwner(uid, false, 'request_documents')}
                              className="rounded border border-[#8A6829]/40 px-2.5 py-1 font-semibold text-[#8A6829] hover:bg-[#FAF8F5]"
                            >
                              {isAr ? 'طلب مستندات إضافية' : 'Request Additional Docs'}
                            </button>
                          )}
                          {hasPerm(['owners.approve_reject']) && (
                            <button
                              type="button"
                              onClick={() => handleVerifyOwner(uid, !isVerified)}
                              className={`rounded px-3 py-1 font-semibold transition-colors ${
                                isVerified
                                  ? 'border border-[#0B3B2B]/20 text-[#52635B] hover:bg-[#FAF8F5]'
                                  : 'bg-[#0B3B2B] text-white hover:bg-[#0F4C3A]'
                              }`}
                            >
                              {isVerified
                                ? isAr
                                  ? 'إلغاء التوثيق'
                                  : 'Revoke'
                                : isAr
                                ? 'اعتماد وتوثيق المالك'
                                : 'Approve Owner'}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-[#0B241C]">
              {isAr ? 'طابور اعتماد ومراقبة القاعات المدرجة' : 'Hall Approval & Moderation Queue'}
            </h2>
            <span className="text-xs text-[#52635B]">
              {isAr
                ? 'القاعات المعتمدة فقط تظهر للجمهور؛ القاعات المعلقة أو المرفوضة أو الموقوفة تظل محجوبة عن البحث العام.'
                : 'Only approved halls appear publicly; pending, rejected, or suspended halls remain hidden.'}
            </span>
          </div>

          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
            <table className="w-full text-start text-sm">
              <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-xs text-[#52635B]">
                <tr>
                  <th className="px-4 py-3 text-start">{isAr ? 'القاعة، التصنيف، والمدينة' : 'Venue, Suitability & City'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'المالك والسجل التجاري' : 'Owner & Verification'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'السعة والمدة' : 'Capacity & Duration'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'الحالة الحالية' : 'Status'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'قرار الاعتماد / الإجراءات المخولة' : 'Moderation Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0B3B2B]/8">
                {data.halls.map((h) => {
                  const id = Number(h.id);
                  const currentSuitability = String(h.suitability_type || 'MIXED') as SuitabilityType;
                  return (
                    <tr key={id} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-[#0B241C]">{String(h.name_ar)}</div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs font-medium text-[#0B3B2B]">
                          <span className="rounded bg-[#0B3B2B]/8 px-1.5 py-0.5 font-semibold text-[#0B3B2B]">
                            {getSuitabilityLabel(currentSuitability, locale)} ({currentSuitability})
                          </span>
                          <span>·</span>
                          <span className="text-[#8A6829]">
                            {getHallTypeLabel(String(h.hall_type || 'wedding'), locale)}
                          </span>
                        </div>
                        <div className="text-xs text-[#52635B]">
                          {getCityLabel(String(h.city), locale)} · {String(h.address)}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-xs">
                        <div className="font-medium text-[#0B241C]">{String(h.owner_name)}</div>
                        <div className="text-[#52635B]">{String(h.business_name || h.owner_email)}</div>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-xs tabular-nums">
                        <div>
                          {String(h.capacity_min)}–{String(h.capacity_max)} {isAr ? 'ضيف' : 'guests'}
                        </div>
                        <div className="text-[11px] text-[#52635B]">
                          {String(h.event_duration_hours || 6)}h (+{String(h.prep_buffer_hours || 2)}h/{String(h.cleanup_buffer_hours || 2)}h)
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-xs">
                        {h.status === 'active' && (
                          <span className="font-semibold text-emerald-800">{isAr ? 'نشطة (عامة)' : 'Active (Public)'}</span>
                        )}
                        {h.status === 'pending' && (
                          <span className="font-semibold text-amber-800">{isAr ? 'بانتظار الاعتماد (مخفية)' : 'Pending Approval'}</span>
                        )}
                        {h.status === 'suspended' && (
                          <span className="font-semibold text-amber-900">{isAr ? 'معلقة إدارياً (مخفية)' : 'Suspended'}</span>
                        )}
                        {h.status === 'rejected' && (
                          <div>
                            <span className="font-semibold text-red-800">{isAr ? 'مرفوضة (مخفية)' : 'Rejected'}</span>
                            {Boolean(h.rejection_reason) && (
                              <div className="text-[11px] text-red-700">{String(h.rejection_reason)}</div>
                            )}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex flex-wrap items-center gap-2">
                          {hasPerm(['halls.edit']) && (
                            <select
                              aria-label="Admin Edit Suitability Type"
                              value={currentSuitability}
                              onChange={(e) => handleModerateHall(id, undefined, undefined, e.target.value as SuitabilityType)}
                              className="rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2 py-1 text-xs font-semibold text-[#0B3B2B]"
                            >
                              {SUITABILITY_TYPES.map((st) => (
                                <option key={st.slug} value={st.slug}>
                                  {isAr ? st.label_ar : st.label_en}
                                </option>
                              ))}
                            </select>
                          )}

                          {hasPerm(['halls.approve_reject', 'halls.suspend_reactivate']) && h.status !== 'active' && (
                            <button
                              type="button"
                              onClick={() => handleModerateHall(id, 'active')}
                              className="inline-flex items-center gap-1 rounded bg-[#0B3B2B] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                            >
                              <CheckCircle2 className="h-3.5 w-3.5 text-[#C5A059]" />
                              <span>{isAr ? 'اعتماد ونشر' : 'Approve'}</span>
                            </button>
                          )}

                          {hasPerm(['halls.approve_reject']) && (
                            <>
                              <input
                                type="text"
                                value={rejectReasons[id] || ''}
                                onChange={(e) => setRejectReasons((prev) => ({ ...prev, [id]: e.target.value }))}
                                placeholder={isAr ? 'سبب الرفض (إلزامي عند الرفض)...' : 'Rejection reason...'}
                                className="w-40 rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1 text-xs"
                              />
                              <button
                                type="button"
                                onClick={() => handleModerateHall(id, 'rejected')}
                                className="inline-flex items-center gap-1 rounded border border-red-800/25 px-2.5 py-1 text-xs font-semibold text-red-800 hover:bg-red-950/5"
                              >
                                <XCircle className="h-3.5 w-3.5" />
                                <span>{isAr ? 'رفض' : 'Reject'}</span>
                              </button>
                            </>
                          )}

                          {hasPerm(['halls.suspend_reactivate']) && h.status === 'active' && (
                            <button
                              type="button"
                              onClick={() => handleModerateHall(id, 'suspended')}
                              className="inline-flex items-center gap-1 rounded border border-amber-800/30 px-2.5 py-1 text-xs font-semibold text-amber-800 hover:bg-amber-950/5"
                            >
                              <PauseCircle className="h-3.5 w-3.5" />
                              <span>{isAr ? 'تعليق' : 'Suspend'}</span>
                            </button>
                          )}

                          {hasPerm(['halls.edit']) && (
                            <button
                              type="button"
                              onClick={() => handleModerateHall(id, undefined, !h.featured)}
                              className={`inline-flex items-center gap-1 rounded border px-2.5 py-1 text-xs font-medium ${
                                h.featured
                                  ? 'border-[#C5A059] bg-[#C5A059]/15 text-[#8A6829]'
                                  : 'border-[#0B3B2B]/15 text-[#52635B]'
                              }`}
                            >
                              <Star className="h-3 w-3" />
                              <span>{h.featured ? (isAr ? 'مميزة' : 'Featured') : isAr ? 'تمييز' : 'Feature'}</span>
                            </button>
                          )}

                          {hasPerm(['halls.delete']) && h.status !== 'active' && (
                            <button
                              type="button"
                              onClick={() => handleDeleteHall(id)}
                              className="inline-flex items-center gap-1 rounded border border-red-800/30 px-2 py-1 text-xs font-semibold text-red-800 hover:bg-red-950/5"
                              title={isAr ? 'حذف القاعة نهائياً' : 'Delete Hall'}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODULE TAB 2: User, Owner, Customer & Staff Management */}
      {activeTab === 'users' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className={isGeneralManager ? 'space-y-4 lg:col-span-8' : 'space-y-4 lg:col-span-12'}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute top-2.5 start-3 h-4 w-4 text-[#52635B]" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder={isAr ? 'بحث بالاسم، البريد الإلكتروني، أو الهاتف...' : 'Search name, email, phone...'}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-white py-2 ps-9 pe-3 text-xs"
                />
              </div>
              <div className="flex items-center gap-1 rounded-lg bg-[#F3EFEA] p-1">
                {[
                  { id: 'all', ar: 'الكل', en: 'All' },
                  { id: 'hall_owner', ar: 'الملاك', en: 'Owners' },
                  { id: 'customer', ar: 'العملاء', en: 'Customers' },
                  { id: 'support_agent', ar: 'الدعم', en: 'Support' },
                  { id: 'employee', ar: 'الموظفون', en: 'Staff' },
                ].map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setUserRoleFilter(r.id)}
                    className={`rounded px-2.5 py-1 text-xs font-semibold ${
                      userRoleFilter === r.id ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                    }`}
                  >
                    {isAr ? r.ar : r.en}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
              <table className="w-full text-start text-xs">
                <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                  <tr>
                    <th className="px-4 py-3 text-start">{isAr ? 'المستخدم' : 'User'}</th>
                    <th className="px-4 py-3 text-start">{isAr ? 'الدور الوظيفي' : 'Role'}</th>
                    <th className="px-4 py-3 text-start">{isAr ? 'الحالة والتوثيق' : 'Status'}</th>
                    <th className="px-4 py-3 text-start">{isAr ? 'إجراءات الإدارة' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#0B3B2B]/8">
                  {filteredUsers.map((u) => {
                    const uid = Number(u.id);
                    return (
                      <tr key={uid} className="hover:bg-[#FAF8F5]">
                        <td className="px-4 py-3">
                          <div className="font-semibold text-[#0B241C]">{String(u.name)}</div>
                          <div className="font-mono text-[11px] text-[#52635B] tabular-nums">
                            {String(u.email)} · {String(u.phone)}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-medium text-[#0B3B2B]">
                          {isAr ? String(u.role_name_ar) : String(u.role_name_en)}
                          {Boolean(u.job_title) && (
                            <div className="text-[11px] text-[#52635B]">{String(u.job_title)}</div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`font-semibold ${
                              u.status === 'active' ? 'text-emerald-800' : 'text-red-800'
                            }`}
                          >
                            {u.status === 'active' ? (isAr ? 'نشط' : 'Active') : isAr ? 'معلق' : 'Suspended'}
                          </span>
                          {u.role_slug === 'hall_owner' && (
                            <div className="text-[11px] text-[#52635B]">
                              {u.owner_verified ? (isAr ? 'سجل تجاري موثق' : 'Verified CR') : isAr ? 'غير موثق' : 'Unverified'}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap items-center gap-2">
                            {u.role_slug !== 'super_admin' &&
                              (isGeneralManager ||
                                (u.role_slug === 'customer' && hasPerm(['customers.suspend_reactivate']))) && (
                                <button
                                  type="button"
                                  onClick={() => handleToggleUserStatus(uid, String(u.status))}
                                  className={`rounded border px-2.5 py-1 text-xs font-semibold ${
                                    u.status === 'active'
                                      ? 'border-red-800/25 text-red-800 hover:bg-red-950/5'
                                      : 'border-emerald-800/25 text-emerald-800 hover:bg-emerald-950/5'
                                  }`}
                                >
                                  {u.status === 'active'
                                    ? isAr
                                      ? 'تعليق الحساب'
                                      : 'Suspend'
                                    : isAr
                                    ? 'إعادة تفعيل'
                                    : 'Reactivate'}
                                </button>
                              )}
                            {u.role_slug === 'hall_owner' && hasPerm(['owners.approve_reject']) && (
                              <button
                                type="button"
                                onClick={() => handleVerifyOwner(uid, !u.owner_verified)}
                                className="rounded border border-[#0B3B2B]/20 px-2.5 py-1 text-xs font-semibold text-[#0B3B2B] hover:bg-[#FAF8F5]"
                              >
                                {u.owner_verified
                                  ? isAr
                                    ? 'إلغاء توثيق السجل'
                                    : 'Revoke CR'
                                  : isAr
                                  ? 'توثيق السجل التجاري'
                                  : 'Verify CR'}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Create Authorized Account Form (General Manager Only) */}
          {isGeneralManager && (
            <form
              onSubmit={handleCreateAuthorizedUser}
              className="space-y-3.5 rounded-xl border border-[#0B3B2B]/15 bg-white p-5 lg:col-span-4"
            >
              <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
                <UserPlus className="h-4 w-4 text-[#0B3B2B]" />
                <h3 className="font-display text-lg font-bold text-[#0B241C]">
                  {isAr ? 'إنشاء حساب مالك قاعة أو موظف سريع' : 'Create Authorized Account'}
                </h3>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'الاسم الكامل *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'البريد الإلكتروني الرسمي *' : 'Official Email *'}
                </label>
                <input
                  type="email"
                  required
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'رقم الهاتف *' : 'Phone Number *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserPhone}
                  onChange={(e) => setNewUserPhone(e.target.value)}
                  placeholder="+96777..."
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs tabular-nums"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'الدور والصلاحية (تحقق خادمي) *' : 'Assigned Role *'}
                </label>
                <select
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold"
                >
                  <option value="hall_owner">{isAr ? 'مالك قاعة موثق' : 'Verified Hall Owner'}</option>
                  <option value="support_agent">{isAr ? 'أخصائي دعم العملاء والشكاوى' : 'Customer Support Agent'}</option>
                  <option value="employee">{isAr ? 'موظف إشراف وتشغيل' : 'Platform Employee'}</option>
                </select>
              </div>

              {newUserRole === 'hall_owner' && (
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'الاسم التجاري للمؤسسة' : 'Business Name'}
                  </label>
                  <input
                    type="text"
                    value={newBusinessName}
                    onChange={(e) => setNewBusinessName(e.target.value)}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
                  />
                </div>
              )}

              <div>
                <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                  {isAr ? 'كلمة المرور المبدئية *' : 'Initial Password *'}
                </label>
                <input
                  type="text"
                  required
                  value={newUserPassword}
                  onChange={(e) => setNewUserPassword(e.target.value)}
                  className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
              >
                {isAr ? 'اعتماد وإنشاء الحساب' : 'Create Authorized Account'}
              </button>
            </form>
          )}
        </div>
      )}

      {/* MODULE TAB 3: Financial Reports, Verified Payments, Commission & Refunds */}
      {activeTab === 'financials' && (
        <div className="space-y-6">
          {hasPerm(['finance.view_commissions', 'dashboard.view_reports']) && (
            <div className="rounded-xl border border-[#0B3B2B]/15 bg-white p-6">
              <div className="mb-4 flex items-center gap-2">
                <Landmark className="h-5 w-5 text-[#0B3B2B]" />
                <h2 className="font-display text-xl font-bold text-[#0B241C]">
                  {isAr
                    ? 'التفصيل المالي الموثق (يُحتسب الدخل فقط من المعاملات المالية المؤكدة)'
                    : 'Verified Financial Ledger & Commission Breakdown'}
                </h2>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 lg:grid-cols-6">
                <div className="border-e border-[#0B3B2B]/10 pe-4">
                  <div className="text-xs text-[#52635B]">{isAr ? 'إجمالي قيمة العقود (Booking Value)' : 'Gross Booking Value'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-[#0B241C] tabular-nums">
                    {formatMoney(stats.financials.grossBookingValue, currency, locale)}
                  </div>
                </div>
                <div className="border-e border-[#0B3B2B]/10 pe-4">
                  <div className="text-xs text-[#52635B]">{isAr ? 'مدفوعات مؤكدة (Confirmed Payments)' : 'Confirmed Payments'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-emerald-800 tabular-nums">
                    {formatMoney(stats.financials.verifiedPaidAmount, currency, locale)}
                  </div>
                </div>
                <div className="border-e border-[#0B3B2B]/10 pe-4">
                  <div className="text-xs text-[#52635B]">{isAr ? 'إيراد الملاك الصافي (Owners Revenue)' : 'Hall Owners Revenue'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-[#0B3B2B] tabular-nums">
                    {formatMoney(stats.financials.hallOwnerNetRevenue, currency, locale)}
                  </div>
                </div>
                <div className="border-e border-[#0B3B2B]/10 pe-4">
                  <div className="text-xs text-[#52635B]">{isAr ? 'صافي عمولة المنصة (Platform Commission)' : 'Platform Commission'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-[#8A6829] tabular-nums">
                    {formatMoney(stats.financials.platformCommission, currency, locale)}
                  </div>
                </div>
                <div className="border-e border-[#0B3B2B]/10 pe-4">
                  <div className="text-xs text-[#52635B]">{isAr ? 'مدفوعات معلقة (Pending Payments)' : 'Pending Verification'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-amber-800 tabular-nums">
                    {formatMoney(stats.financials.pendingPaymentsAmount, currency, locale)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-[#52635B]">{isAr ? 'المبالغ المستردة (Refunds)' : 'Verified Refunds'}</div>
                  <div className="mt-1 font-mono text-base font-bold text-red-800 tabular-nums">
                    {formatMoney(stats.financials.refundedAmount, currency, locale)}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payment Transactions Verification Table */}
          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
            <table className="w-full text-start text-xs">
              <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                <tr>
                  <th className="px-4 py-3 text-start">{isAr ? 'مرجع العملية' : 'Payment Ref'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'الحجز والقاعة' : 'Booking & Venue'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'العميل وطريقة الدفع' : 'Payer & Method'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'المبلغ' : 'Amount'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'حالة التحقق' : 'Verification Status'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'إجراء التدقيق المالي' : 'Audit Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0B3B2B]/8">
                {data.payments.map((p) => (
                  <tr key={p.id} className="hover:bg-[#FAF8F5]">
                    <td className="px-4 py-3 font-mono font-semibold text-[#0B3B2B] tabular-nums">
                      {p.payment_reference}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-mono font-semibold text-[#0B241C] tabular-nums">{p.booking_code || '—'}</div>
                      <div className="text-[#52635B]">{p.hall_name_ar || ''}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-[#0B241C]">{p.payer_name}</div>
                      <div className="font-mono text-[11px] text-[#52635B] tabular-nums">
                        {p.payment_method} · {p.transaction_number}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-[#0B241C] tabular-nums">
                      {formatMoney(p.amount, currency, locale)}
                    </td>
                    <td className="px-4 py-3 font-semibold">
                      {p.status === 'verified' ? (
                        <span className="text-emerald-800">{isAr ? 'مدفوع ومؤكد' : 'Verified Paid'}</span>
                      ) : p.status === 'pending_verification' ? (
                        <span className="text-amber-800">{isAr ? 'بانتظار مطابقة الحوالة' : 'Pending Verification'}</span>
                      ) : (
                        <span className="text-red-800">{isAr ? 'مسترد (Refunded)' : 'Refunded'}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {p.status !== 'verified' && hasPerm(['finance.verify_payments']) && (
                          <button
                            type="button"
                            onClick={() => handleVerifyPayment(p.id, 'verified')}
                            className="rounded bg-[#0B3B2B] px-2.5 py-1 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                          >
                            {isAr ? 'توثيق واعتماد الدفعة' : 'Verify Payment'}
                          </button>
                        )}
                        {p.status === 'verified' && hasPerm(['finance.manage_refunds']) && (
                          <button
                            type="button"
                            onClick={() => handleVerifyPayment(p.id, 'refunded')}
                            className="rounded border border-red-800/25 px-2.5 py-1 text-xs font-semibold text-red-800 hover:bg-red-950/5"
                          >
                            {isAr ? 'تسجيل استرداد' : 'Issue Refund'}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODULE TAB 4: Bookings Oversight, Review Moderation & Support Tickets */}
      {activeTab === 'bookings_reviews' && (
        <div className="space-y-6">
          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
            <div className="border-b border-[#0B3B2B]/10 px-5 py-3.5 font-display text-lg font-bold text-[#0B241C]">
              {isAr ? 'الرقابة المركزية وإدارة الحجوزات والفترات الزمنية' : 'Platform-Wide Booking & Schedule Oversight'}
            </div>
            <table className="w-full text-start text-xs">
              <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                <tr>
                  <th className="px-4 py-3 text-start">{isAr ? 'رقم العقد' : 'Code'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'القاعة والتصنيف والمالك' : 'Venue, Suitability & Owner'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'العميل' : 'Customer'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'تواريخ الحجز وعدد الأيام' : 'Dates & Booked Days'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'القيمة' : 'Total'}</th>
                  <th className="px-4 py-3 text-start">{isAr ? 'الحالة والإجراءات المخولة' : 'Status & Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0B3B2B]/8">
                {data.bookings.map((b) => {
                  const daysCount = Number(b.booked_days || 1);
                  const endDateStr = b.end_date || b.event_date;
                  return (
                    <tr key={b.id} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-3 font-mono font-bold text-[#0B3B2B] tabular-nums">{b.booking_code}</td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#0B241C]">
                          {b.hall_name_ar}{' '}
                          <span className="rounded bg-[#0B3B2B]/8 px-1.5 py-0.5 text-[10px] font-semibold text-[#0B3B2B]">
                            {getSuitabilityLabel(b.suitability_type, locale)} ({b.suitability_type || 'MIXED'})
                          </span>
                        </div>
                        <div className="text-[#52635B]">{b.owner_name}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div>{b.customer_name}</div>
                        <div className="font-mono text-[#52635B] tabular-nums">{b.customer_phone}</div>
                      </td>
                      <td className="px-4 py-3 font-mono tabular-nums">
                        <div className="font-semibold text-[#0B241C]">
                          {daysCount > 1 ? `${b.event_date} → ${endDateStr}` : b.event_date} ({b.shift})
                        </div>
                        <div className="text-[11px] text-[#52635B]">
                          {daysCount} {isAr ? (daysCount > 1 ? 'أيام تقويمية' : 'يوم') : 'day(s)'} ·{' '}
                          {b.start_time || '16:00'}–{b.end_time || '22:00'} ({b.duration_hours || 6}h)
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono font-semibold tabular-nums">
                        <div>{formatMoney(b.total_amount, currency, locale)}</div>
                        <div className="text-[10px] font-normal text-[#52635B]">
                          {isAr ? 'اليوم:' : 'Day:'} {formatMoney(Number(b.price_per_day || b.base_price), currency, locale)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-[#0B3B2B]">
                            {b.status} · {b.payment_status}
                          </span>
                          {b.status === 'pending' && hasPerm(['bookings.confirm']) && (
                            <button
                              type="button"
                              onClick={() => handleAdminBookingStatus(b.id, 'confirmed')}
                              className="rounded bg-[#0B3B2B] px-2 py-1 text-[11px] font-semibold text-white"
                            >
                              {isAr ? 'تأكيد' : 'Confirm'}
                            </button>
                          )}
                          {b.status !== 'cancelled' && hasPerm(['bookings.cancel', 'bookings.reject']) && (
                            <button
                              type="button"
                              onClick={() => handleAdminBookingStatus(b.id, 'cancelled')}
                              className="rounded border border-red-800/30 px-2 py-1 text-[11px] font-semibold text-red-800"
                            >
                              {isAr ? 'إلغاء' : 'Cancel'}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {hasPerm(['content.moderate_reviews']) && (
            <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
              <div className="border-b border-[#0B3B2B]/10 px-5 py-3.5 font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'مراقبة واعتماد تقييمات العملاء' : 'Customer Reviews Moderation'}
              </div>
              <div className="divide-y divide-[#0B3B2B]/8 p-5 text-xs">
                {data.reviews.map((r) => (
                  <div key={Number(r.id)} className="flex items-center justify-between py-3">
                    <div>
                      <div className="font-semibold text-[#0B241C]">
                        {String(r.customer_name)} · <span className="text-[#8A6829]">★ {String(r.rating_overall)}</span> ·{' '}
                        <span className="text-[#52635B]">{String(r.hall_name_ar)}</span>
                      </div>
                      <p className="mt-1 text-[#1E352D]">{String(r.comment)}</p>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const next = r.status === 'approved' ? 'hidden' : 'approved';
                        await apiFetch(`/api/admin/reviews/${r.id}/status`, {
                          method: 'POST',
                          body: JSON.stringify({ status: next }),
                        });
                        await loadAdminData();
                        onMarketplaceRefresh();
                      }}
                      className="rounded border border-[#0B3B2B]/20 px-3 py-1 font-semibold text-[#0B3B2B] hover:bg-[#FAF8F5]"
                    >
                      {r.status === 'approved' ? (isAr ? 'إخفاء التقييم' : 'Hide Review') : isAr ? 'اعتماد التقييم' : 'Approve'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Support Tickets Oversight */}
          {hasPerm(['support.view_tickets']) && (
            <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white">
              <div className="border-b border-[#0B3B2B]/10 px-5 py-3.5 font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'الرقابة على تذاكر الدعم الفني والشكاوى' : 'Support Tickets & Disputes Oversight'}
              </div>
              <div className="divide-y divide-[#0B3B2B]/8 p-5 text-xs">
                {(data.supportTickets || []).map((t) => (
                  <div key={Number(t.id)} className="flex flex-wrap items-center justify-between gap-2 py-3">
                    <div>
                      <span className="font-mono font-bold text-[#0B3B2B] tabular-nums">{String(t.ticket_code)}</span>
                      <span className="mx-2 text-[#52635B]">·</span>
                      <span className="font-semibold text-[#0B241C]">{String(t.subject)}</span>
                      {Boolean(t.booking_code) && (
                        <>
                          <span className="mx-2 text-[#52635B]">·</span>
                          <span className="font-mono text-[#8A6829] tabular-nums">{String(t.booking_code)}</span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-[#52635B]">
                      <span>{String(t.customer_name || '')}</span>
                      <span>·</span>
                      <span className="font-semibold text-[#0B3B2B]">{String(t.status)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODULE TAB 5: Platform Settings, Currency, Commissions & Subscription Plans */}
      {activeTab === 'settings_plans' && isGeneralManager && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={handleSaveSettings}
            className="space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-6 lg:col-span-7"
          >
            <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
              <Settings className="h-5 w-5 text-[#0B3B2B]" />
              <h3 className="font-display text-xl font-bold text-[#0B241C]">
                {isAr
                  ? 'إعدادات المنصة، العملات، العمولات، وقواعد الحجز والإلغاء'
                  : 'Platform, Currency, Commission & Booking Rules Configuration'}
              </h3>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {data.settings.map((item) => (
                <div key={item.setting_key}>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {item.description || item.setting_key}
                  </label>
                  <input
                    type="text"
                    value={settingsMap[item.setting_key] || ''}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        [item.setting_key]: e.target.value,
                      }))
                    }
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-medium text-[#0B241C]"
                  />
                </div>
              ))}
            </div>

            <button
              type="submit"
              className="rounded-lg bg-[#0B3B2B] px-5 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              {isAr ? 'حفظ وتطبيق إعدادات النظام' : 'Save Platform Configuration'}
            </button>
          </form>

          <div className="space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-6 lg:col-span-5">
            <h3 className="font-display text-xl font-bold text-[#0B241C]">
              {isAr ? 'باقات اشتراك ملاك القاعات والعمولات' : 'Hall Owner Subscription Plans'}
            </h3>
            <div className="space-y-3">
              {data.subscriptionPlans.map((plan) => (
                <div key={Number(plan.id)} className="rounded-lg border border-[#0B3B2B]/12 bg-[#FAF8F5] p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-display text-base font-bold text-[#0B241C]">{String(plan.name_ar)}</span>
                    <span className="font-mono text-sm font-bold text-[#0B3B2B] tabular-nums">
                      {formatMoney(Number(plan.price), currency, locale)}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[#52635B]">{String(plan.description)}</p>
                  <div className="mt-2 flex items-center gap-3 font-mono text-[11px] text-[#8A6829] tabular-nums">
                    <span>
                      {isAr ? 'الحد الأقصى للقاعات:' : 'Max Halls:'} {String(plan.max_halls_allowed)}
                    </span>
                    <span>·</span>
                    <span>
                      {isAr ? 'نسبة العمولة:' : 'Commission:'} {String(plan.commission_rate_percentage)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* MODULE TAB 6: Security Audit Logs & Notification Broadcast */}
      {activeTab === 'audit_notifications' && isGeneralManager && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="overflow-hidden rounded-xl border border-[#0B3B2B]/12 bg-white lg:col-span-8">
            <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 px-5 py-3.5">
              <FileText className="h-4 w-4 text-[#0B3B2B]" />
              <h3 className="font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'سجل التدقيق الأمني والإداري الشامل (audit_logs)' : 'Immutable Security Audit Logs'}
              </h3>
            </div>
            <div className="max-h-[480px] overflow-y-auto">
              <table className="w-full text-start text-xs">
                <thead className="border-b border-[#0B3B2B]/10 bg-[#FAF8F5] text-[#52635B]">
                  <tr>
                    <th className="px-4 py-2.5 text-start">#</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'الحدث الأمني / الإداري' : 'Action'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'المنفذ' : 'Actor'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'التفاصيل' : 'Details'}</th>
                    <th className="px-4 py-2.5 text-start">{isAr ? 'التوقيت' : 'Timestamp'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#0B3B2B]/8">
                  {data.auditLogs.map((log) => (
                    <tr key={Number(log.id)} className="hover:bg-[#FAF8F5]">
                      <td className="px-4 py-2.5 font-mono tabular-nums">{String(log.id)}</td>
                      <td className="px-4 py-2.5 font-mono font-semibold text-[#0B3B2B]">{String(log.action)}</td>
                      <td className="px-4 py-2.5">{String(log.actor_name || 'System')}</td>
                      <td className="max-w-xs truncate px-4 py-2.5 font-mono text-[11px] text-[#52635B]">
                        {String(log.details_json || '')}
                      </td>
                      <td className="px-4 py-2.5 font-mono text-[11px] text-[#52635B] tabular-nums">
                        {String(log.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <form
            onSubmit={handleBroadcastNotification}
            className="space-y-4 rounded-xl border border-[#0B3B2B]/15 bg-white p-5 lg:col-span-4"
          >
            <div className="flex items-center gap-2 border-b border-[#0B3B2B]/10 pb-3">
              <Bell className="h-4 w-4 text-[#0B3B2B]" />
              <h3 className="font-display text-lg font-bold text-[#0B241C]">
                {isAr ? 'إرسال إشعار إداري للمستخدمين' : 'Broadcast System Notification'}
              </h3>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'الفئة المستهدفة' : 'Target Audience'}
              </label>
              <select
                value={notifRole}
                onChange={(e) => setNotifRole(e.target.value)}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              >
                <option value="all">{isAr ? 'جميع المستخدمين النشطين' : 'All Active Users'}</option>
                <option value="hall_owner">{isAr ? 'ملاك القاعات فقط' : 'Hall Owners Only'}</option>
                <option value="customer">{isAr ? 'العملاء فقط' : 'Customers Only'}</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'عنوان الإشعار *' : 'Notification Title *'}
              </label>
              <input
                type="text"
                required
                value={notifTitleAr}
                onChange={(e) => setNotifTitleAr(e.target.value)}
                placeholder={isAr ? 'مثال: تحديث مواسم الحجوزات الملكية' : 'e.g., Seasonal Booking Update'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                {isAr ? 'نص الإشعار *' : 'Message *'}
              </label>
              <textarea
                rows={3}
                required
                value={notifMessageAr}
                onChange={(e) => setNotifMessageAr(e.target.value)}
                placeholder={isAr ? 'اكتب نص التعميم أو التنبيه...' : 'Write notification content...'}
                className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-3 text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
            >
              {isAr ? 'إرسال التعميم الآن' : 'Send Broadcast'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
