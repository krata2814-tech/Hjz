import React, { useState, useEffect, useCallback } from 'react';
import { Headphones, MessageSquare, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Locale, SupportTicket, InquiryRecord } from '../types.ts';

interface SupportPortalProps {
  locale: Locale;
  apiFetch: (url: string, options?: RequestInit) => Promise<unknown>;
}

export const SupportPortal: React.FC<SupportPortalProps> = ({ locale, apiFetch }) => {
  const isAr = locale === 'ar';
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [inquiries, setInquiries] = useState<InquiryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyMap, setReplyMap] = useState<Record<number, string>>({});
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const res = (await apiFetch('/api/support/dashboard')) as {
        tickets: SupportTicket[];
        inquiries: InquiryRecord[];
      };
      setTickets(res.tickets);
      setInquiries(res.inquiries);
    } finally {
      setLoading(false);
    }
  }, [apiFetch]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleTicketReply(ticketId: number, newStatus: string) {
    const message = replyMap[ticketId];
    if (!message) return;
    await apiFetch(`/api/support/tickets/${ticketId}/reply`, {
      method: 'POST',
      body: JSON.stringify({ message, newStatus }),
    });
    setReplyMap((prev) => ({ ...prev, [ticketId]: '' }));
    await loadData();
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="h-32 animate-pulse rounded-xl bg-[#F3EFEA]" />
      </div>
    );
  }

  const filteredTickets = tickets.filter((t) => statusFilter === 'all' || t.status === statusFilter);

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-6 py-8">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#0B3B2B]/12 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#52635B]">
            <Headphones className="h-4 w-4 text-[#0B3B2B]" />
            <span>{isAr ? 'مركز إسعاد العملاء ومعالجة الشكاوى والنزاعات' : 'Customer Support & Dispute Resolution Center'}</span>
          </div>
          <h1 className="font-display text-3xl font-bold text-[#0B241C]">
            {isAr ? 'بوابة دعم العملاء ومساندة الحجوزات' : 'Concierge Support Desk'}
          </h1>
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-[#F3EFEA] p-1">
          {[
            { id: 'all', ar: `الكل (${tickets.length})`, en: `All (${tickets.length})` },
            { id: 'open', ar: 'مفتوحة', en: 'Open' },
            { id: 'in_progress', ar: 'قيد المعالجة', en: 'In Progress' },
            { id: 'resolved', ar: 'تم الحل', en: 'Resolved' },
          ].map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setStatusFilter(f.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors ${
                statusFilter === f.id ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B] hover:text-[#0B241C]'
              }`}
            >
              {isAr ? f.ar : f.en}
            </button>
          ))}
        </div>
      </div>

      {/* Tickets List */}
      <div className="space-y-4">
        {filteredTickets.map((t) => (
          <div key={t.id} className="rounded-xl border border-[#0B3B2B]/15 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#0B3B2B]/10 pb-3">
              <div className="flex items-center gap-2 text-xs">
                <span className="font-mono font-bold text-[#0B3B2B] tabular-nums">{t.ticket_code}</span>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-[#0B241C]">{t.subject}</span>
                {t.booking_code && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[#8A6829] tabular-nums">{t.booking_code}</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs">
                {t.priority === 'high' || t.priority === 'urgent' ? (
                  <span className="inline-flex items-center gap-1 font-semibold text-amber-800">
                    <AlertTriangle className="h-3.5 w-3.5" />
                    {isAr ? 'أولوية عالية' : 'High Priority'}
                  </span>
                ) : null}
                <span className="text-[#52635B]">
                  {t.customer_name} ({t.customer_phone})
                </span>
                <span className="font-semibold text-[#0B3B2B]">{t.status}</span>
              </div>
            </div>

            <div className="my-3 space-y-2">
              {t.messages?.map((m) => (
                <div
                  key={m.id}
                  className={`rounded-lg p-3 text-xs ${
                    m.sender_role === 'support_agent' || m.sender_role === 'super_admin'
                      ? 'bg-[#0B3B2B]/8 text-[#0B241C]'
                      : 'bg-[#FAF8F5] text-[#1E352D]'
                  }`}
                >
                  <div className="mb-1 font-semibold text-[#0B3B2B]">
                    {m.sender_name} ({m.sender_role})
                  </div>
                  <p>{m.message}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={replyMap[t.id] || ''}
                onChange={(e) => setReplyMap((prev) => ({ ...prev, [t.id]: e.target.value }))}
                placeholder={isAr ? 'اكتب رد فريق الدعم أو قرار المعالجة...' : 'Write support resolution reply...'}
                className="flex-1 rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs"
              />
              <button
                type="button"
                onClick={() => handleTicketReply(t.id, 'in_progress')}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
              >
                <MessageSquare className="h-3.5 w-3.5 text-[#C5A059]" />
                <span>{isAr ? 'رد ومتابعة' : 'Reply'}</span>
              </button>
              <button
                type="button"
                onClick={() => handleTicketReply(t.id, 'resolved')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-800/30 bg-emerald-950/5 px-4 py-2 text-xs font-semibold text-emerald-900 hover:bg-emerald-950/10"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{isAr ? 'رد وإغلاق التذكرة كمحلولة' : 'Resolve Ticket'}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Platform Inquiries Oversight */}
      <div className="rounded-xl border border-[#0B3B2B]/12 bg-white p-6">
        <h2 className="mb-4 font-display text-xl font-bold text-[#0B241C]">
          {isAr ? 'متابعة استفسارات الزوار المباشرة للقاعات' : 'Platform Venue Inquiries Oversight'}
        </h2>
        <div className="divide-y divide-[#0B3B2B]/8 text-xs">
          {inquiries.map((inq) => (
            <div key={inq.id} className="flex items-center justify-between py-3">
              <div>
                <span className="font-mono font-semibold text-[#8A6829] tabular-nums">{inq.inquiry_code}</span>
                <span className="mx-2 text-[#52635B]">·</span>
                <span className="font-semibold text-[#0B241C]">{inq.subject}</span>
                <span className="mx-2 text-[#52635B]">·</span>
                <span className="text-[#52635B]">{inq.hall_name_ar}</span>
              </div>
              <div className="text-[#52635B]">
                {inq.sender_name} · <span className="font-semibold text-[#0B3B2B]">{inq.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
