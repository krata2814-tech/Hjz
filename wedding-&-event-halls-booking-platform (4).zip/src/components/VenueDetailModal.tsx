import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Calendar,
  Users,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  CreditCard,
  Landmark,
  Banknote,
  Star,
  MessageSquare,
  MapPin,
  Clock,
  FileText,
  Building2,
} from 'lucide-react';
import {
  Hall,
  Locale,
  CurrencyCode,
  UserSession,
  BookingQuote,
  HALL_TYPES,
  formatMoney,
  getCityLabel,
  getShiftLabel,
  getHallTypeLabel,
  getSuitabilityLabel,
  computeConsecutiveDatesClient,
} from '../types.ts';
import { VenueImage } from './VenueImage.tsx';

interface VenueDetailModalProps {
  hall: Hall;
  locale: Locale;
  currency: CurrencyCode;
  user: UserSession | null;
  reviews: Array<Record<string, unknown>>;
  onClose: () => void;
  onRequireLogin: () => void;
  onBookingCreated: () => void;
  apiFetch: (url: string, options?: RequestInit) => Promise<unknown>;
}

export const VenueDetailModal: React.FC<VenueDetailModalProps> = ({
  hall,
  locale,
  currency,
  user,
  reviews,
  onClose,
  onRequireLogin,
  onBookingCreated,
  apiFetch,
}) => {
  const isAr = locale === 'ar';
  const [activeTab, setActiveTab] = useState<'booking' | 'inquiry' | 'reviews'>('booking');
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);

  // Booking Duration Mode: 'package' (Full Shift/Day Package) or 'hourly' (Custom Duration Hours)
  const [durationMode, setDurationMode] = useState<'package' | 'hourly'>('package');
  const [customHours, setCustomHours] = useState<number>(hall.event_duration_hours || 6);
  const [customStartTime, setCustomStartTime] = useState<string>('16:00');
  const [selectedEventType, setSelectedEventType] = useState<string>(String(hall.hall_type || 'wedding'));

  // Multi-day consecutive booking selection
  const [selectedDate, setSelectedDate] = useState<string>('2026-11-18');
  const [bookedDays, setBookedDays] = useState<number>(1);
  const [selectedPricingId, setSelectedPricingId] = useState<number>(hall.pricing[0]?.id || 0);
  const [guestCount, setGuestCount] = useState<number>(Math.min(400, hall.capacity_max));
  const [paymentMethod, setPaymentMethod] = useState<'card_payment' | 'bank_transfer' | 'cash_on_site'>('card_payment');
  const [transactionNumber, setTransactionNumber] = useState<string>('');
  const [customerNotes, setCustomerNotes] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [serverQuote, setServerQuote] = useState<BookingQuote | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Inquiry state
  const [inquirySubject, setInquirySubject] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');

  // Review state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  // Generate 16 dates for interactive availability calendar (including consecutive days around selectedDate)
  const upcomingDates = useMemo(() => {
    const list: string[] = [
      '2026-11-15',
      '2026-11-16',
      '2026-11-17',
      '2026-11-18',
      '2026-11-19',
      '2026-11-20',
      '2026-11-21',
      '2026-11-22',
      '2026-11-23',
      '2026-11-24',
      '2026-11-25',
      '2026-11-28',
    ];
    const selectedRange = computeConsecutiveDatesClient(selectedDate, bookedDays);
    for (const d of selectedRange) {
      if (!list.includes(d)) list.push(d);
    }
    return list.sort().slice(0, 12);
  }, [selectedDate, bookedDays]);

  const selectedPackage = useMemo(() => {
    return hall.pricing.find((p) => p.id === selectedPricingId) || hall.pricing[0];
  }, [hall.pricing, selectedPricingId]);

  const selectedShift = durationMode === 'hourly' ? 'hourly' : selectedPackage?.shift || 'evening';

  // Consecutive calendar dates occupied by this reservation
  const requestedDates = useMemo(() => {
    return computeConsecutiveDatesClient(selectedDate, bookedDays);
  }, [selectedDate, bookedDays]);

  const calculatedEndDate = requestedDates[requestedDates.length - 1] || selectedDate;

  // Fetch authoritative server quote whenever date, days, package, or duration changes
  useEffect(() => {
    let active = true;
    apiFetch('/api/bookings/quote', {
      method: 'POST',
      body: JSON.stringify({
        hallId: hall.id,
        pricingId: durationMode === 'package' ? selectedPackage?.id : null,
        startDate: selectedDate,
        bookedDays,
        shift: selectedShift,
        durationHours: durationMode === 'hourly' ? customHours : hall.event_duration_hours || 6,
      }),
    })
      .then((res) => {
        const data = res as { quote?: BookingQuote };
        if (active && data?.quote) {
          setServerQuote(data.quote);
        }
      })
      .catch(() => {
        // Fallback to local calculation if offline
      });
    return () => {
      active = false;
    };
  }, [apiFetch, hall.id, hall.event_duration_hours, durationMode, selectedPackage?.id, selectedDate, bookedDays, selectedShift, customHours]);

  // Check if any requested day in the multi-day range has a slot conflict
  const conflictingDates = useMemo(() => {
    if (serverQuote && Array.isArray(serverQuote.conflictingDates)) {
      return serverQuote.conflictingDates;
    }
    return requestedDates.filter((dateStr) =>
      hall.unavailableSlots.some(
        (s) =>
          s.date === dateStr &&
          (s.status === 'booked' || s.status === 'blocked' || s.status === 'pending') &&
          (s.shift === selectedShift || s.shift === 'full_day' || selectedShift === 'full_day')
      )
    );
  }, [serverQuote, requestedDates, hall.unavailableSlots, selectedShift]);

  const isHardBlocked = conflictingDates.length > 0;

  const hourlyRate = Number(hall.hourly_rate || 85000);
  const fallbackPricePerDay =
    durationMode === 'hourly'
      ? Math.round(customHours * hourlyRate)
      : selectedPackage
      ? Number(selectedPackage.base_price)
      : hall.starting_price;
  const fallbackSubtotal = fallbackPricePerDay * bookedDays;
  const discountPctPerDay = Number(hall.multi_day_discount_pct ?? 5);
  const fallbackDiscountPct = bookedDays > 1 ? Math.min(25, (bookedDays - 1) * discountPctPerDay) : 0;
  const fallbackDiscountAmount = bookedDays > 1 ? Math.round(fallbackSubtotal * (fallbackDiscountPct / 100)) : 0;
  const fallbackAdditionalFees = bookedDays > 1 ? Number(hall.additional_fees || 0) * bookedDays : 0;
  const fallbackTaxable = fallbackSubtotal - fallbackDiscountAmount + fallbackAdditionalFees;
  const fallbackTax = Math.round(fallbackTaxable * 0.05);
  const fallbackTotal = fallbackTaxable + fallbackTax;
  const fallbackDeposit =
    durationMode === 'hourly' || bookedDays > 1
      ? Math.round(fallbackTotal * 0.3)
      : selectedPackage
      ? Number(selectedPackage.deposit_required)
      : Math.round(fallbackTotal * 0.3);

  const pricePerDay = serverQuote ? serverQuote.pricePerDay : fallbackPricePerDay;
  const subtotalPrice = serverQuote ? serverQuote.subtotalAmount : fallbackSubtotal;
  const discountAmount = serverQuote ? serverQuote.discountAmount : fallbackDiscountAmount;
  const discountPct = serverQuote ? serverQuote.discountPercent : fallbackDiscountPct;
  const additionalFees = serverQuote ? serverQuote.additionalFees : fallbackAdditionalFees;
  const taxAmount = serverQuote ? serverQuote.taxAmount : fallbackTax;
  const totalAmount = serverQuote ? serverQuote.totalAmount : fallbackTotal;
  const depositAmount = serverQuote ? serverQuote.depositRequired : fallbackDeposit;

  const hallReviews = useMemo(
    () => reviews.filter((r) => Number(r.hall_id) === hall.id),
    [reviews, hall.id]
  );

  const gallery = useMemo(() => {
    const base = hall.images && hall.images.length > 0 ? hall.images : [];
    const extras = [
      { id: 901, hall_id: hall.id, image_url: '/api/artwork/taj-royal-palace', is_primary: 0, caption: 'المسرح الملكي والكوشة' },
      { id: 902, hall_id: hall.id, image_url: '/api/artwork/aden-coastal-pearl', is_primary: 0, caption: 'صالة الضيافة والولائم' },
      { id: 903, hall_id: hall.id, image_url: '/api/artwork/princess-ibb-garden', is_primary: 0, caption: 'البهو الملكي واستقبال الضيوف' },
      { id: 904, hall_id: hall.id, image_url: '/api/artwork/andalus-heritage-palace', is_primary: 0, caption: 'جناح العروسين والأقواس الأندلسية' },
    ];
    return [...base, ...extras].slice(0, 4);
  }, [hall.images, hall.id]);

  async function handleConfirmBooking(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      onRequireLogin();
      return;
    }
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = (await apiFetch('/api/bookings', {
        method: 'POST',
        body: JSON.stringify({
          hallId: hall.id,
          pricingId: durationMode === 'package' ? selectedPackage?.id : null,
          eventDate: selectedDate,
          bookedDays,
          shift: durationMode === 'hourly' ? 'hourly' : selectedShift,
          eventType: selectedEventType,
          guestCount,
          durationHours: durationMode === 'hourly' ? customHours : hall.event_duration_hours || 6,
          startTime: durationMode === 'hourly' ? customStartTime : undefined,
          customerNotes,
          paymentMethod,
          transactionNumber,
          payDepositNow: paymentMethod !== 'cash_on_site',
        }),
      })) as {
        booking: {
          bookingCode: string;
          status: string;
          startDate: string;
          endDate: string;
          bookedDays: number;
          totalAmount: number;
        };
      };

      setFeedback({
        type: 'success',
        text: isAr
          ? `تم تسجيل حجزكم بنجاح! رقم العقد: ${res.booking.bookingCode} (${res.booking.startDate} إلى ${res.booking.endDate} — ${res.booking.bookedDays} أيام) — ${
              res.booking.status === 'confirmed' ? 'مؤكد فوراً' : 'بانتظار مراجعة العربون'
            }`
          : `Booking confirmed! Code: ${res.booking.bookingCode} (${res.booking.startDate} to ${res.booking.endDate}, ${res.booking.bookedDays} days)`,
      });
      onBookingCreated();
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'حدث خطأ أثناء إتمام الحجز',
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSendInquiry(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      onRequireLogin();
      return;
    }
    setSubmitting(true);
    setFeedback(null);
    try {
      const res = (await apiFetch('/api/inquiries', {
        method: 'POST',
        body: JSON.stringify({
          hallId: hall.id,
          eventDate: selectedDate,
          guestEstimate: guestCount,
          subject: inquirySubject || `استفسار حول ${hall.name_ar}`,
          message: inquiryMessage,
        }),
      })) as { inquiryCode: string };
      setInquiryMessage('');
      setInquirySubject('');
      setFeedback({
        type: 'success',
        text: isAr
          ? `تم إرسال استفساركم إلى إدارة القاعة بنجاح (رقم المرجع: ${res.inquiryCode})`
          : `Inquiry sent successfully (${res.inquiryCode})`,
      });
      onBookingCreated();
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'تعذر إرسال الاستفسار',
      });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      onRequireLogin();
      return;
    }
    setSubmitting(true);
    setFeedback(null);
    try {
      await apiFetch('/api/reviews', {
        method: 'POST',
        body: JSON.stringify({
          hallId: hall.id,
          ratingOverall: reviewRating,
          comment: reviewComment,
        }),
      });
      setReviewComment('');
      setFeedback({
        type: 'success',
        text: isAr ? 'شكراً لتقييمكم! تم نشر التقييم بنجاح.' : 'Thank you! Your review has been published.',
      });
      onBookingCreated();
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: err instanceof Error ? err.message : 'تعذر إرسال التقييم',
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-2 sm:p-4 backdrop-blur-xs">
      <div className="relative flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-[#0B3B2B]/15 bg-[#FAF8F5] shadow-2xl">
        {/* Top Modal Header */}
        <div className="flex items-center justify-between border-b border-[#0B3B2B]/10 bg-white px-5 py-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#52635B]">
              <span className="font-semibold text-[#0B3B2B]">{getCityLabel(hall.city, locale)}</span>
              <span aria-hidden="true">·</span>
              <span
                data-testid="detail-suitability-badge"
                className="rounded border border-[#0B3B2B]/20 bg-[#0B3B2B]/8 px-2 py-0.5 font-semibold text-[#0B3B2B]"
              >
                {getSuitabilityLabel(hall.suitability_type, locale)} ({hall.suitability_type || 'MIXED'})
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-medium text-[#8A6829]">
                {getHallTypeLabel(String(hall.hall_type || 'wedding'), locale)}
              </span>
              <span aria-hidden="true">·</span>
              {hall.owner_verified ? (
                <>
                  <span className="font-semibold text-emerald-800">
                    {isAr ? 'مالك ومنشأة موثقة ✓' : 'Verified Owner ✓'}
                  </span>
                  <span aria-hidden="true">·</span>
                </>
              ) : null}
              <span className="font-mono tabular-nums">
                {hall.capacity_min}–{hall.capacity_max} {isAr ? 'ضيف' : 'Guests'}
              </span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1 font-mono text-[#8A6829] tabular-nums">
                <Star className="h-3.5 w-3.5 fill-[#C5A059] text-[#C5A059]" />
                {Number(hall.rating).toFixed(2)} ({hall.reviews_count})
              </span>
            </div>
            <h2 className="font-display text-2xl font-bold text-[#0B241C]">
              {isAr ? hall.name_ar : hall.name_en || hall.name_ar}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg border border-[#0B3B2B]/15 p-2 text-[#0B241C] transition-colors hover:bg-[#F3EFEA]"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Contiguous Split Body: Left Media, Amenities, Owner Info & Terms | Right Purchase & Booking Module */}
        <div className="grid flex-1 grid-cols-1 gap-8 overflow-y-auto p-5 sm:p-6 lg:grid-cols-12">
          {/* Left Column: Gallery, Architecture Details, Facilities, Owner Info & Booking Terms (7 cols) */}
          <div className="space-y-6 lg:col-span-7">
            <div className="relative overflow-hidden rounded-xl border border-[#0B3B2B]/10 bg-[#0B2920]">
              <VenueImage
                src={gallery[selectedImageIdx]?.image_url}
                alt={isAr ? hall.name_ar : hall.name_en || hall.name_ar}
                loading="eager"
                className="aspect-[16/10] w-full"
              />
              {gallery[selectedImageIdx]?.caption && (
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent px-4 py-3 text-xs font-medium text-[#FAF8F5]">
                  {gallery[selectedImageIdx]?.caption}
                </div>
              )}
            </div>

            {/* Thumbnail Strip */}
            <div className="grid grid-cols-4 gap-3">
              {gallery.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`overflow-hidden rounded-lg border transition-all ${
                    selectedImageIdx === idx
                      ? 'border-[#C5A059] ring-2 ring-[#C5A059]/40'
                      : 'border-[#0B3B2B]/10 opacity-75 hover:opacity-100'
                  }`}
                >
                  <VenueImage src={img.image_url} alt={img.caption || hall.name_ar} className="aspect-[4/3] w-full" />
                </button>
              ))}
            </div>

            {/* Location & Architectural Description */}
            <div className="space-y-3 border-t border-[#0B3B2B]/10 pt-5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#52635B]">
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-[#0B3B2B]" />
                  <span className="font-medium text-[#0B241C]">
                    {getCityLabel(hall.city, locale)} {hall.district ? `— ${hall.district}` : ''} · {hall.address}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 font-mono tabular-nums">
                  <Clock className="h-3.5 w-3.5 text-[#8A6829]" />
                  <span>
                    {isAr
                      ? `مدة الفعالية: ${hall.event_duration_hours || 6} ساعات (+${hall.prep_buffer_hours || 2}س تجهيز / +${hall.cleanup_buffer_hours || 2}س إخلاء)`
                      : `Duration: ${hall.event_duration_hours || 6}h (+${hall.prep_buffer_hours || 2}h Prep / +${hall.cleanup_buffer_hours || 2}h Cleanup)`}
                  </span>
                </div>
              </div>
              <p className="text-sm leading-relaxed text-[#1E352D]">
                {isAr ? hall.description_ar : hall.description_en || hall.description_ar}
              </p>
            </div>

            {/* Facilities & Amenities Grid */}
            <div className="border-t border-[#0B3B2B]/10 pt-5">
              <h3 className="mb-3.5 font-display text-lg font-bold tracking-normal text-[#0B241C]">
                {isAr ? 'المرافق والتجهيزات المتوفرة في القاعة' : 'Included Royal Amenities & Facilities'}
              </h3>
              <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
                {hall.facilities.map((fac) => (
                  <div
                    key={fac.facility_id}
                    className="flex items-start justify-between gap-3 rounded-xl border border-[#0B3B2B]/12 bg-white p-3.5 shadow-2xs"
                  >
                    <div className="space-y-1">
                      <div className="text-sm font-bold leading-relaxed tracking-normal text-[#0B241C]">
                        {isAr ? fac.name_ar : fac.name_en}
                      </div>
                      {fac.details && (
                        <div className="text-xs leading-relaxed tracking-normal text-[#52635B]">
                          {fac.details}
                        </div>
                      )}
                    </div>
                    <span className="shrink-0 rounded-md border border-[#0B3B2B]/15 bg-[#FAF8F5] px-2.5 py-1 text-xs font-semibold tracking-normal text-[#0B3B2B]">
                      {fac.is_complimentary
                        ? isAr
                          ? 'مشمول مجاناً'
                          : 'Included'
                        : formatMoney(fac.extra_charge || 0, currency, locale)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Verified Hall Owner & Business Information */}
            <div className="border-t border-[#0B3B2B]/10 pt-5">
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#0B3B2B]/12 bg-white p-4">
                <div className="flex items-start gap-3">
                  <Building2 className="mt-0.5 h-5 w-5 shrink-0 text-[#0B3B2B]" />
                  <div>
                    <div className="text-xs font-semibold text-[#8A6829]">
                      {isAr ? 'بيانات المالك والمنشأة الموثقة' : 'Verified Venue Ownership & Management'}
                    </div>
                    <div className="mt-0.5 font-display text-base font-bold text-[#0B241C]">
                      {hall.business_name || hall.owner_name || (isAr ? 'مؤسسة القصور الملكية للمناسبات' : 'Royal Venues Hospitality Group')}
                    </div>
                    <div className="mt-1 text-xs text-[#52635B]">
                      {isAr ? 'المدير المسؤول:' : 'Managed by:'} {hall.owner_name || (isAr ? 'إدارة القصر المعتمدة' : 'Verified Management')} ·{' '}
                      <span className="font-semibold text-emerald-800">
                        {isAr ? 'سجل تجاري ووثائق ملكية معتمدة لدى الإدارة العليا ✓' : 'Commercial Registration Verified ✓'}
                      </span>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('inquiry')}
                  className="rounded-lg border border-[#0B3B2B]/25 px-3.5 py-2 text-xs font-semibold text-[#0B3B2B] transition-colors hover:bg-[#FAF8F5] whitespace-nowrap"
                >
                  {isAr ? 'مراسلة إدارة القاعة' : 'Contact Owner'}
                </button>
              </div>
            </div>

            {/* Booking Terms & Cancellation Policy */}
            <div className="border-t border-[#0B3B2B]/10 pt-5">
              <div className="mb-2 flex items-center gap-2">
                <FileText className="h-4 w-4 text-[#0B3B2B]" />
                <h3 className="font-display text-base font-bold text-[#0B241C]">
                  {isAr ? 'شروط العقد وسياسة العربون والحجز متعدد الأيام' : 'Booking Terms, Deposit & Multi-Day Policy'}
                </h3>
              </div>
              <ul className="space-y-1.5 text-xs leading-relaxed text-[#52635B]">
                <li>
                  •{' '}
                  {isAr
                    ? 'تصنيف القاعة المعتمد: ' + getSuitabilityLabel(hall.suitability_type, locale) + ` (${hall.suitability_type || 'MIXED'}).`
                    : `Suitability Classification: ${getSuitabilityLabel(hall.suitability_type, locale)} (${hall.suitability_type || 'MIXED'}).`}
                </li>
                <li>
                  •{' '}
                  {isAr
                    ? 'الحجوزات متعددة الأيام: يتم قفل كافة الأيام التقويمية المتتالية المختارة حصرياً مع خصم تلقائي للأيام المتعددة.'
                    : 'Multi-Day Reservations: All consecutive calendar days are locked atomically with automatic multi-day discounts.'}
                </li>
                <li>
                  •{' '}
                  {isAr
                    ? `فترات التجهيز والإخلاء: تشمل الباقة ${hall.prep_buffer_hours || 2} ساعات مجانية قبل الفعالية لتنسيق الكوشة والضيافة، و${hall.cleanup_buffer_hours || 2} ساعات للإخلاء بعد انتهاء المناسبة.`
                    : `Preparation & Cleanup: Includes ${hall.prep_buffer_hours || 2}h pre-event setup and ${hall.cleanup_buffer_hours || 2}h post-event breakdown buffer.`}
                </li>
              </ul>
            </div>
          </div>

          {/* Right Column: Contiguous Booking, Inquiry & Review Module (5 cols) */}
          <div className="flex flex-col rounded-xl border border-[#0B3B2B]/15 bg-white p-5 sm:p-6 lg:col-span-5">
            {/* Functional Segmented Switcher */}
            <div className="mb-5 flex items-center gap-1 rounded-lg bg-[#F3EFEA] p-1">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('booking');
                  setFeedback(null);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeTab === 'booking'
                    ? 'bg-[#0B3B2B] text-white shadow-xs'
                    : 'text-[#52635B] hover:text-[#0B241C]'
                }`}
              >
                {isAr ? 'الحجز والتقويم' : 'Live Booking'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('inquiry');
                  setFeedback(null);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeTab === 'inquiry'
                    ? 'bg-[#0B3B2B] text-white shadow-xs'
                    : 'text-[#52635B] hover:text-[#0B241C]'
                }`}
              >
                {isAr ? 'استفسار مباشر' : 'Direct Inquiry'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('reviews');
                  setFeedback(null);
                }}
                className={`flex-1 rounded-md px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeTab === 'reviews'
                    ? 'bg-[#0B3B2B] text-white shadow-xs'
                    : 'text-[#52635B] hover:text-[#0B241C]'
                }`}
              >
                {isAr ? `التقييمات (${hallReviews.length})` : `Reviews (${hallReviews.length})`}
              </button>
            </div>

            {feedback && (
              <div
                className={`mb-4 flex items-start gap-2.5 rounded-lg border p-3.5 text-sm ${
                  feedback.type === 'success'
                    ? 'border-emerald-700/30 bg-emerald-950/5 text-emerald-900'
                    : 'border-red-700/30 bg-red-950/5 text-red-900'
                }`}
              >
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" />
                ) : (
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-700" />
                )}
                <span>{feedback.text}</span>
              </div>
            )}

            {activeTab === 'booking' && (
              <form onSubmit={handleConfirmBooking} className="space-y-4">
                {/* Step 1: Booking Duration Selector (Full Package vs Custom Hourly) */}
                <div>
                  <div className="mb-1.5 flex items-center justify-between">
                    <label className="text-xs font-semibold text-[#52635B]">
                      {isAr ? '1. نظام المدة والباقة' : '1. Booking Duration & Package'}
                    </label>
                    <div className="flex items-center gap-1 rounded-md bg-[#F3EFEA] p-0.5 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setDurationMode('package')}
                        className={`rounded px-2 py-0.5 font-semibold whitespace-nowrap ${
                          durationMode === 'package' ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                        }`}
                      >
                        {isAr ? 'باقة فترة كاملة' : 'Shift Package'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setDurationMode('hourly')}
                        className={`rounded px-2 py-0.5 font-semibold whitespace-nowrap ${
                          durationMode === 'hourly' ? 'bg-[#0B3B2B] text-white' : 'text-[#52635B]'
                        }`}
                      >
                        {isAr ? 'حجز بالساعة' : 'Hourly Rate'}
                      </button>
                    </div>
                  </div>

                  {durationMode === 'hourly' ? (
                    <div className="space-y-2.5 rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-[#0B241C]">
                          {isAr ? 'حدد عدد ساعات الحجز اليومية ووقت البدء:' : 'Select Daily Duration & Start Time:'}
                        </span>
                        <span className="font-mono font-bold text-[#0B3B2B] tabular-nums">
                          {formatMoney(hourlyRate, currency, locale)} / {isAr ? 'ساعة' : 'hr'}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <input
                          type="range"
                          min={hall.min_booking_hours || 3}
                          max={hall.max_booking_hours || 12}
                          value={customHours}
                          onChange={(e) => setCustomHours(Number(e.target.value))}
                          className="w-full accent-[#0B3B2B]"
                        />
                        <span className="w-20 text-end font-mono text-sm font-bold text-[#0B241C] tabular-nums">
                          {customHours} {isAr ? 'ساعات' : 'Hrs'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2 pt-1 text-xs">
                        <span className="text-[#52635B]">{isAr ? 'وقت بداية الفعالية:' : 'Start Time:'}</span>
                        <select
                          value={customStartTime}
                          onChange={(e) => setCustomStartTime(e.target.value)}
                          className="rounded border border-[#0B3B2B]/20 bg-white px-2.5 py-1 font-mono text-xs text-[#0B241C]"
                        >
                          <option value="09:00">09:00 AM</option>
                          <option value="12:00">12:00 PM</option>
                          <option value="15:00">03:00 PM</option>
                          <option value="16:00">04:00 PM</option>
                          <option value="18:00">06:00 PM</option>
                          <option value="19:00">07:00 PM</option>
                        </select>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {hall.pricing.map((pkg) => (
                        <button
                          key={pkg.id}
                          type="button"
                          onClick={() => setSelectedPricingId(pkg.id)}
                          className={`flex w-full items-center justify-between rounded-lg border px-3.5 py-2.5 text-start transition-colors ${
                            selectedPackage?.id === pkg.id
                              ? 'border-[#0B3B2B] bg-[#0B3B2B]/5'
                              : 'border-[#0B3B2B]/15 hover:bg-[#FAF8F5]'
                          }`}
                        >
                          <div>
                            <div className="text-sm font-semibold text-[#0B241C]">
                              {isAr ? pkg.title_ar : pkg.title_en || pkg.title_ar}
                            </div>
                            <div className="text-xs text-[#52635B]">
                              {getShiftLabel(pkg.shift, locale)} · {isAr ? 'سعر اليوم:' : 'Per Day:'}{' '}
                              <span className="tabular-nums">{formatMoney(pkg.base_price, currency, locale)}</span>
                            </div>
                          </div>
                          <div className="font-mono text-sm font-semibold text-[#0B3B2B] tabular-nums">
                            {formatMoney(pkg.base_price, currency, locale)}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Step 2: Multi-Day Start Date, Consecutive Days & Live Availability Calendar */}
                <div className="space-y-2.5 rounded-lg border border-[#0B3B2B]/15 bg-[#FAF8F5] p-3">
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                        {isAr ? 'تاريخ بدء الحجز' : 'Start Date'}
                      </label>
                      <input
                        type="date"
                        data-testid="booking-start-date-input"
                        value={selectedDate}
                        min="2026-10-20"
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full rounded border border-[#0B3B2B]/20 bg-white px-2.5 py-1.5 font-mono text-xs text-[#0B241C] tabular-nums"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                        {isAr ? 'عدد الأيام المتتالية' : 'Consecutive Days'}
                      </label>
                      <select
                        data-testid="booking-days-select"
                        value={bookedDays}
                        onChange={(e) => setBookedDays(Number(e.target.value))}
                        className="w-full rounded border border-[#0B3B2B]/20 bg-white px-2.5 py-1.5 font-mono text-xs font-semibold text-[#0B241C] tabular-nums"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 10, 14].map((d) => (
                          <option key={d} value={d}>
                            {isAr ? `${d} ${d === 1 ? 'يوم واحد' : 'أيام متتالية'}` : `${d} ${d === 1 ? 'Day' : 'Consecutive Days'}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Calculated Start Date, End Date & Booked Calendar Days Banner */}
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded border border-[#0B3B2B]/12 bg-white px-3 py-2 text-xs">
                    <div>
                      <span className="text-[#52635B]">{isAr ? 'من:' : 'From:'} </span>
                      <span data-testid="quote-start-date" className="font-mono font-bold text-[#0B241C] tabular-nums">
                        {selectedDate}
                      </span>
                      <span className="mx-1.5 text-[#52635B]">→</span>
                      <span className="text-[#52635B]">{isAr ? 'إلى:' : 'To:'} </span>
                      <span data-testid="quote-end-date" className="font-mono font-bold text-[#0B241C] tabular-nums">
                        {calculatedEndDate}
                      </span>
                    </div>
                    <span
                      data-testid="quote-booked-days"
                      className="rounded bg-[#0B3B2B]/10 px-2 py-0.5 font-mono text-[11px] font-bold text-[#0B3B2B] tabular-nums"
                    >
                      {isAr ? `${bookedDays} أيام تقويمية` : `${bookedDays} Calendar Day(s)`}
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-1.5 pt-1">
                    {upcomingDates.map((d) => {
                      const slot = hall.unavailableSlots.find(
                        (s) =>
                          s.date === d &&
                          (s.shift === selectedShift || s.shift === 'full_day' || selectedShift === 'full_day')
                      );
                      const status = slot?.status || 'available';
                      const isInSelectedRange = requestedDates.includes(d);
                      return (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setSelectedDate(d)}
                          className={`flex flex-col items-center rounded-md border px-2 py-1.5 font-mono text-xs transition-colors tabular-nums ${
                            isInSelectedRange
                              ? status === 'booked' || status === 'blocked' || status === 'pending'
                                ? 'border-red-700 bg-red-800 text-white'
                                : 'border-[#0B3B2B] bg-[#0B3B2B] text-white'
                              : status === 'booked'
                              ? 'border-red-800/25 bg-red-950/5 text-red-800'
                              : status === 'blocked'
                              ? 'border-stone-400/40 bg-stone-200/50 text-stone-700'
                              : status === 'pending'
                              ? 'border-amber-700/30 bg-amber-950/5 text-amber-800'
                              : 'border-[#0B3B2B]/15 bg-white text-[#0B241C] hover:border-[#0B3B2B]/40'
                          }`}
                        >
                          <span>{d.slice(5)}</span>
                          <span className="text-[10px] font-sans">
                            {status === 'booked'
                              ? isAr
                                ? 'محجوز'
                                : 'Booked'
                              : status === 'blocked'
                              ? isAr
                                ? 'مغلق'
                                : 'Blocked'
                              : status === 'pending'
                              ? isAr
                                ? 'طلب معلق'
                                : 'Pending'
                              : isInSelectedRange
                              ? isAr
                                ? 'مختار ✓'
                                : 'Selected ✓'
                              : isAr
                              ? 'متاح'
                              : 'Open'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  {isHardBlocked && (
                    <p className="mt-1.5 text-xs font-medium text-red-700">
                      {isAr
                        ? `تنبيه: توجد أيام غير متاحة ضمن الفترة المختارة (${conflictingDates.join('، ')}). يرجى اختيار تواريخ متاحة.`
                        : `Notice: Unavailable dates in selected range (${conflictingDates.join(', ')}).`}
                    </p>
                  )}
                </div>

                {/* Step 3: Event Occasion Type, Guest Count & Notes */}
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'نوع المناسبة أو الفعالية' : 'Event Category / Occasion'}
                  </label>
                  <select
                    value={selectedEventType}
                    onChange={(e) => setSelectedEventType(e.target.value)}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-xs font-semibold text-[#0B241C]"
                  >
                    {Object.entries(HALL_TYPES)
                      .filter(([k]) => k !== 'all')
                      .map(([key, label]) => (
                        <option key={key} value={key}>
                          {isAr ? label.ar : label.en}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                      {isAr ? 'عدد الضيوف المتوقع' : 'Expected Guests'}
                    </label>
                    <div className="relative">
                      <Users className="pointer-events-none absolute top-2.5 start-3 h-4 w-4 text-[#52635B]" />
                      <input
                        type="number"
                        min={hall.capacity_min}
                        max={hall.capacity_max}
                        value={guestCount}
                        onChange={(e) => setGuestCount(Number(e.target.value))}
                        className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] py-2 ps-9 pe-3 font-mono text-sm tabular-nums"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                      {isAr ? 'ملاحظات التجهيز / الكوشة' : 'Special Notes'}
                    </label>
                    <input
                      type="text"
                      value={customerNotes}
                      onChange={(e) => setCustomerNotes(e.target.value)}
                      placeholder={isAr ? 'مثال: كوشة ورود بيضاء...' : 'e.g., White floral stage'}
                      className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
                    />
                  </div>
                </div>

                {/* Step 4: Payment Gateway & Deposit Method */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#52635B]">
                    {isAr ? '3. وسيلة سداد العربون وتوثيق العقد' : '3. Deposit Payment Method'}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card_payment')}
                      className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs font-medium transition-colors ${
                        paymentMethod === 'card_payment'
                          ? 'border-[#0B3B2B] bg-[#0B3B2B]/8 text-[#0B3B2B]'
                          : 'border-[#0B3B2B]/15 text-[#52635B]'
                      }`}
                    >
                      <CreditCard className="h-4 w-4" />
                      <span className="whitespace-nowrap">{isAr ? 'بطاقة / مدى' : 'Card / Mada'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bank_transfer')}
                      className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs font-medium transition-colors ${
                        paymentMethod === 'bank_transfer'
                          ? 'border-[#0B3B2B] bg-[#0B3B2B]/8 text-[#0B3B2B]'
                          : 'border-[#0B3B2B]/15 text-[#52635B]'
                      }`}
                    >
                      <Landmark className="h-4 w-4" />
                      <span className="whitespace-nowrap">{isAr ? 'تحويل بنكي' : 'Bank Transfer'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cash_on_site')}
                      className={`flex flex-col items-center gap-1 rounded-lg border p-2.5 text-xs font-medium transition-colors ${
                        paymentMethod === 'cash_on_site'
                          ? 'border-[#0B3B2B] bg-[#0B3B2B]/8 text-[#0B3B2B]'
                          : 'border-[#0B3B2B]/15 text-[#52635B]'
                      }`}
                    >
                      <Banknote className="h-4 w-4" />
                      <span className="whitespace-nowrap">{isAr ? 'نقداً بالقصر' : 'Pay on Site'}</span>
                    </button>
                  </div>

                  {paymentMethod === 'bank_transfer' && (
                    <input
                      type="text"
                      required
                      value={transactionNumber}
                      onChange={(e) => setTransactionNumber(e.target.value)}
                      placeholder={isAr ? 'أدخل رقم الحوالة البنكية / الكريمي للتوثيق...' : 'Enter Bank Transfer Reference Number...'}
                      className="mt-2 w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 font-mono text-xs"
                    />
                  )}
                </div>

                {/* Server-Verified Multi-Day Financial Breakdown */}
                <div className="space-y-1.5 rounded-lg border border-[#0B3B2B]/12 bg-[#FAF8F5] p-3.5 text-xs">
                  <div className="flex justify-between text-[#52635B]">
                    <span>{isAr ? 'فترة الحجز التقويمية' : 'Reservation Dates'}</span>
                    <span className="font-mono font-semibold text-[#0B241C] tabular-nums">
                      {selectedDate} → {calculatedEndDate} ({bookedDays} {isAr ? 'أيام' : 'days'})
                    </span>
                  </div>
                  <div className="flex justify-between text-[#52635B]">
                    <span>{isAr ? 'السعر لليوم الواحد' : 'Price Per Day'}</span>
                    <span data-testid="quote-price-per-day" className="font-mono tabular-nums">
                      {formatMoney(pricePerDay, currency, locale)}
                    </span>
                  </div>
                  <div className="flex justify-between text-[#52635B]">
                    <span>
                      {isAr
                        ? `إجمالي الأيام (${bookedDays} × ${formatMoney(pricePerDay, currency, locale)})`
                        : `Subtotal (${bookedDays} days)`}
                    </span>
                    <span className="font-mono tabular-nums">{formatMoney(subtotalPrice, currency, locale)}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between font-medium text-emerald-800">
                      <span>
                        {isAr ? `خصم الحجز متعدد الأيام (${discountPct}%)` : `Multi-Day Discount (${discountPct}%)`}
                      </span>
                      <span data-testid="quote-discount-amount" className="font-mono tabular-nums">
                        -{formatMoney(discountAmount, currency, locale)}
                      </span>
                    </div>
                  )}
                  {additionalFees > 0 && (
                    <div className="flex justify-between text-[#52635B]">
                      <span>{isAr ? 'رسوم الخدمات والتجهيز الإضافية' : 'Additional Service Fees'}</span>
                      <span data-testid="quote-additional-fees" className="font-mono tabular-nums">
                        {formatMoney(additionalFees, currency, locale)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between text-[#52635B]">
                    <span>{isAr ? 'ضريبة القيمة المضافة والخدمات (5%)' : 'VAT & Hospitality Tax (5%)'}</span>
                    <span className="font-mono tabular-nums">{formatMoney(taxAmount, currency, locale)}</span>
                  </div>
                  <div className="flex justify-between border-t border-[#0B3B2B]/10 pt-1.5 text-sm font-bold text-[#0B241C]">
                    <span>{isAr ? 'الإجمالي الكلي للعقد (محسوب من الخادم)' : 'Total Contract Value (Server Verified)'}</span>
                    <span data-testid="quote-total-amount" className="font-mono tabular-nums">
                      {formatMoney(totalAmount, currency, locale)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs font-semibold text-[#8A6829]">
                    <span>{isAr ? 'العربون المطلوب لتأكيد الحجز الآن' : 'Required Deposit Now'}</span>
                    <span className="font-mono tabular-nums">{formatMoney(depositAmount, currency, locale)}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting || isHardBlocked}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#0B3B2B] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0F4C3A] disabled:opacity-50"
                >
                  <Calendar className="h-4 w-4 text-[#C5A059]" />
                  <span>
                    {submitting
                      ? isAr
                        ? 'جاري توثيق العقد...'
                        : 'Processing Reservation...'
                      : isAr
                      ? 'تأكيد الحجز وإصدار العقد الإلكتروني'
                      : 'Confirm Reservation & Issue Contract'}
                  </span>
                </button>

                <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#52635B]">
                  <ShieldCheck className="h-3.5 w-3.5 text-[#0B3B2B]" />
                  <span>
                    {isAr
                      ? 'حماية كاملة من تضارب المواعيد عبر قفل ذري لقاعدة البيانات لجميع الأيام'
                      : 'Protected by ACID conflict-free reservation lock across all booked days'}
                  </span>
                </div>
              </form>
            )}

            {activeTab === 'inquiry' && (
              <form onSubmit={handleSendInquiry} className="space-y-4">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'عنوان الاستفسار' : 'Subject'}
                  </label>
                  <input
                    type="text"
                    required
                    value={inquirySubject}
                    onChange={(e) => setInquirySubject(e.target.value)}
                    placeholder={isAr ? 'مثال: استفسار عن باقة الضيافة الملكية والتصوير' : 'e.g., Catering and VIP entrance options'}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-[#52635B]">
                    {isAr ? 'رسالتك لإدارة القاعة' : 'Your Message to Venue Management'}
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    placeholder={
                      isAr
                        ? 'اكتب تفاصيل استفسارك حول التجهيزات أو المواعيد المتاحة...'
                        : 'Write your questions regarding packages, stage setup, or custom arrangements...'
                    }
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-3 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#0B3B2B] px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#0F4C3A]"
                >
                  <MessageSquare className="h-4 w-4 text-[#C5A059]" />
                  <span>{isAr ? 'إرسال الاستفسار المباشر' : 'Send Direct Inquiry'}</span>
                </button>
              </form>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-4">
                <div className="max-h-60 space-y-3 overflow-y-auto pe-1">
                  {hallReviews.length === 0 ? (
                    <p className="py-6 text-center text-xs text-[#52635B]">
                      {isAr ? 'لا توجد تقييمات منشورة بعد لهذه القاعة.' : 'No reviews published yet.'}
                    </p>
                  ) : (
                    hallReviews.map((rev, i) => (
                      <div key={i} className="rounded-lg border border-[#0B3B2B]/10 bg-[#FAF8F5] p-3.5 text-xs">
                        <div className="flex items-center justify-between font-semibold text-[#0B241C]">
                          <span>{String(rev.customer_name || 'عميل موثق')}</span>
                          <span className="inline-flex items-center gap-1 text-[#8A6829] tabular-nums">
                            <Star className="h-3.5 w-3.5 fill-[#C5A059] text-[#C5A059]" />
                            {Number(rev.rating_overall || 5).toFixed(1)}
                          </span>
                        </div>
                        <p className="mt-1.5 leading-relaxed text-[#1E352D]">{String(rev.comment)}</p>
                      </div>
                    ))
                  )}
                </div>

                <form onSubmit={handleSubmitReview} className="space-y-3 border-t border-[#0B3B2B]/10 pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[#0B241C]">
                      {isAr ? 'أضف تقييمك للتجربة' : 'Share Your Experience'}
                    </span>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(Number(e.target.value))}
                      className="rounded border border-[#0B3B2B]/20 bg-[#FAF8F5] px-2.5 py-1 text-xs font-semibold"
                    >
                      <option value={5}>★★★★★ (5/5)</option>
                      <option value={4}>★★★★☆ (4/5)</option>
                      <option value={3}>★★★☆☆ (3/5)</option>
                    </select>
                  </div>
                  <textarea
                    rows={2}
                    required
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder={isAr ? 'شارك رأيك حول مستوى النظافة، الضيافة، والتجهيزات...' : 'Write your review...'}
                    className="w-full rounded-lg border border-[#0B3B2B]/20 bg-[#FAF8F5] p-2.5 text-xs"
                  />
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full rounded-lg bg-[#0B3B2B] px-4 py-2 text-xs font-semibold text-white hover:bg-[#0F4C3A]"
                  >
                    {isAr ? 'نشر التقييم' : 'Publish Review'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
