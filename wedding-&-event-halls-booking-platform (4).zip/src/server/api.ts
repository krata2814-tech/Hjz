import { Router, Request, Response, NextFunction } from 'express';
import {
  getDb,
  verifySessionToken,
  createSessionToken,
  hashPassword,
  verifyPassword,
  runInTransaction,
  logAudit,
  verifyPaymentProviderSignature,
  GRANULAR_PERMISSIONS_CATALOG,
  VALID_SUITABILITY_TYPES,
  normalizeSuitabilityType,
  computeConsecutiveDates,
  SessionPayload,
} from './db.ts';
import { renderVenueArtworkSvg } from './artwork.ts';

export interface AuthenticatedRequest extends Request {
  session?: SessionPayload;
  user?: {
    id: number;
    role_id: number;
    role_slug: string;
    role_name_ar: string;
    role_name_en: string;
    name: string;
    email: string;
    phone: string;
    status: string;
    job_title?: string;
    department?: string;
    permissions: string[];
  };
}

export const apiRouter = Router();

function getUserPermissions(userId: number, roleSlug: string): string[] {
  if (roleSlug === 'super_admin') {
    return ['*', ...GRANULAR_PERMISSIONS_CATALOG.map((p) => p.slug)];
  }
  const db = getDb();
  const rows = db.prepare(`
    SELECT p.slug
    FROM user_permissions up
    JOIN permissions p ON up.permission_id = p.id
    WHERE up.user_id = ? AND up.is_granted = 1
  `).all(userId) as Array<{ slug: string }>;
  return rows.map((r) => r.slug);
}

export function hasPermission(user: AuthenticatedRequest['user'] | undefined, requiredSlugs: string[]): boolean {
  if (!user) return false;
  if (user.role_slug === 'super_admin' || user.permissions.includes('*')) return true;
  return requiredSlugs.some((slug) => user.permissions.includes(slug));
}

// Attach session & user if Bearer token is provided
apiRouter.use((req: AuthenticatedRequest, _res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7);
    const payload = verifySessionToken(token);
    if (payload) {
      const db = getDb();
      const userRow = db.prepare(`
        SELECT u.id, u.role_id, r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en,
               u.name, u.email, u.phone, u.status,
               ep.job_title, ep.department
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN employee_profiles ep ON ep.user_id = u.id
        WHERE u.id = ?
      `).get(payload.userId) as Omit<NonNullable<AuthenticatedRequest['user']>, 'permissions'> | undefined;

      if (userRow && userRow.status === 'active') {
        req.session = payload;
        req.user = {
          ...userRow,
          permissions: getUserPermissions(userRow.id, userRow.role_slug),
        };
      }
    }
  }
  next();
});

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user || !req.session) {
    res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة (Unauthorized)' });
    return;
  }
  // Verify CSRF token for state-changing requests
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const csrfHeader = req.headers['x-csrf-token'];
    if (!csrfHeader || csrfHeader !== req.session.csrfToken) {
      res.status(403).json({ error: 'فشل التحقق من رمز الحماية CSRF (Invalid CSRF Token)' });
      return;
    }
  }
  next();
}

function requireRole(allowedRoles: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة' });
      return;
    }
    if (!allowedRoles.includes(req.user.role_slug)) {
      logAudit({
        userId: req.user.id,
        action: 'unauthorized_access_attempt',
        entityType: 'security',
        details: { path: req.originalUrl, role: req.user.role_slug, required: allowedRoles },
        ipAddress: req.ip,
      });
      res.status(403).json({ error: 'ليس لديك صلاحية للوصول إلى هذا الإجراء (Forbidden)' });
      return;
    }
    next();
  };
}

function requirePermission(requiredPermissions: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة' });
      return;
    }
    if (req.user.role_slug === 'super_admin') {
      next();
      return;
    }
    if (
      (req.user.role_slug === 'employee' || req.user.role_slug === 'support_agent') &&
      hasPermission(req.user, requiredPermissions)
    ) {
      next();
      return;
    }
    logAudit({
      userId: req.user.id,
      action: 'unauthorized_permission_attempt',
      entityType: 'security',
      details: {
        path: req.originalUrl,
        role: req.user.role_slug,
        requiredPermissions,
        grantedPermissions: req.user.permissions,
      },
      ipAddress: req.ip,
    });
    res.status(403).json({
      error: `ليس لديك الصلاحية المحددة لتنفيذ هذا الإجراء (${requiredPermissions.join(' / ')})`,
    });
  };
}

// 1. Local High-Craft Architectural Artwork SVG Endpoint
apiRouter.get('/artwork/:scene', (req: Request, res: Response) => {
  const svg = renderVenueArtworkSvg(String(req.params.scene || 'palace'));
  res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(svg);
});

// 2. Public Marketplace Bootstrap & Settings
apiRouter.get('/init', (req: AuthenticatedRequest, res: Response) => {
  const db = getDb();

  // Only active halls whose owners are verified are returned to the public marketplace
  const halls = db.prepare(`
    SELECT h.*, u.name as owner_name, op.business_name, COALESCE(op.is_verified, 1) as owner_verified
    FROM halls h
    JOIN users u ON h.owner_id = u.id
    LEFT JOIN owner_profiles op ON op.user_id = u.id
    WHERE h.status = 'active' AND COALESCE(op.is_verified, 1) = 1
    ORDER BY h.featured DESC, h.rating DESC, h.id ASC
  `).all() as Array<Record<string, unknown>>;

  const images = db.prepare(`SELECT * FROM hall_images ORDER BY is_primary DESC, sort_order ASC`).all() as Array<Record<string, unknown>>;
  const pricing = db.prepare(`SELECT * FROM hall_pricing WHERE is_active = 1 ORDER BY base_price ASC`).all() as Array<Record<string, unknown>>;
  const facilities = db.prepare(`
    SELECT hf.hall_id, hf.details, hf.is_complimentary, hf.extra_charge,
           f.id as facility_id, f.name_ar, f.name_en, f.category
    FROM hall_facilities hf
    JOIN facilities f ON hf.facility_id = f.id
  `).all() as Array<Record<string, unknown>>;
  const allFacilities = db.prepare(`SELECT * FROM facilities ORDER BY id ASC`).all();
  const availability = db.prepare(`
    SELECT hall_id, date, shift, status, reason
    FROM hall_availability
    WHERE status != 'available'
  `).all() as Array<Record<string, unknown>>;
  const activeBookings = db.prepare(`
    SELECT id, hall_id, event_date, COALESCE(end_date, event_date) as end_date, COALESCE(booked_days, 1) as booked_days, shift, status
    FROM bookings
    WHERE status IN ('confirmed', 'pending')
  `).all() as Array<Record<string, unknown>>;
  const reviews = db.prepare(`
    SELECT r.*, u.name as customer_name, h.name_ar as hall_name_ar, h.name_en as hall_name_en
    FROM reviews r
    JOIN users u ON r.customer_id = u.id
    JOIN halls h ON r.hall_id = h.id
    WHERE r.status = 'approved'
    ORDER BY r.created_at DESC
  `).all();
  const plans = db.prepare(`SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price ASC`).all();
  const settingsRows = db.prepare(`SELECT setting_key, setting_value FROM platform_settings`).all() as Array<{ setting_key: string; setting_value: string }>;
  const settings: Record<string, string> = {};
  for (const row of settingsRows) {
    settings[row.setting_key] = row.setting_value;
  }

  const enrichedHalls = halls.map((h) => {
    const hallId = Number(h.id);
    const hallImages = images.filter((img) => Number(img.hall_id) === hallId);
    const hallPricing = pricing.filter((p) => Number(p.hall_id) === hallId);
    const hallFacs = facilities.filter((f) => Number(f.hall_id) === hallId);

    // Expand multi-day active bookings across all occupied calendar days
    const expandedBookingSlots: Array<{
      hall_id: number;
      date: string;
      shift: unknown;
      status: string;
      reason: string;
    }> = [];
    for (const b of activeBookings.filter((bk) => Number(bk.hall_id) === hallId)) {
      const daysCount = Math.max(1, Number(b.booked_days || 1));
      const occupiedDates = computeConsecutiveDates(String(b.event_date), daysCount);
      for (const d of occupiedDates) {
        expandedBookingSlots.push({
          hall_id: hallId,
          date: d,
          shift: b.shift,
          status: b.status === 'confirmed' ? 'booked' : 'pending',
          reason:
            b.status === 'confirmed'
              ? daysCount > 1
                ? `حجز متعدد الأيام مؤكد (${daysCount} أيام)`
                : 'حجز مؤكد'
              : 'طلب حجز قيد المراجعة',
        });
      }
    }

    // Expose only anonymized slot status (never expose another customer's private information)
    const hallBlocked = [
      ...availability
        .filter((a) => Number(a.hall_id) === hallId)
        .map((a) => ({
          hall_id: hallId,
          date: String(a.date),
          shift: a.shift,
          status: a.status === 'booked' ? 'booked' : 'blocked',
          reason: a.status === 'booked' ? 'فترة محجوزة ومؤكدة' : String(a.reason || 'فترة مغلقة من إدارة القاعة'),
        })),
      ...expandedBookingSlots,
    ];
    return {
      ...h,
      suitability_type: normalizeSuitabilityType(h.suitability_type || h.gender_policy) || 'MIXED',
      multi_day_discount_pct: Number(h.multi_day_discount_pct ?? 10),
      additional_fees: Number(h.additional_fees ?? 25000),
      images: hallImages.length > 0 ? hallImages : [{ id: 0, hall_id: hallId, image_url: '/api/artwork/taj-royal-palace', is_primary: 1, caption: h.name_ar }],
      pricing: hallPricing,
      facilities: hallFacs,
      unavailableSlots: hallBlocked,
      starting_price: hallPricing.length > 0 ? Number(hallPricing[0].base_price) : 350000,
    };
  });

  // Demo quick-switch accounts for instant testing across all 5 personas (General Manager, Hall Owner, Customer, Employee, Support Agent)
  const demoPersonas = db.prepare(`
    SELECT u.id, u.name, u.email, r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en
    FROM users u
    JOIN roles r ON u.role_id = r.id
    WHERE u.id IN (1, 2, 4, 5, 6) AND u.status = 'active'
    ORDER BY u.id ASC
  `).all();

  let userData = null;
  if (req.user) {
    const favorites = db.prepare(`SELECT hall_id FROM favorites WHERE user_id = ?`).all(req.user.id) as Array<{ hall_id: number }>;
    const notifications = db.prepare(`SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20`).all(req.user.id);
    userData = {
      ...req.user,
      favorites: favorites.map((f) => f.hall_id),
      notifications,
    };
  }

  res.json({
    halls: enrichedHalls,
    allFacilities,
    reviews,
    plans,
    settings,
    demoPersonas,
    user: userData,
  });
});

// Public Hall Search & Filter Endpoint (by city, suitabilityType, hallType, genderPolicy, bookingMode, minCapacity, startDate, bookedDays)
apiRouter.get('/halls', (req: Request, res: Response) => {
  const db = getDb();
  const { city, suitabilityType, hallType, genderPolicy, bookingMode, minCapacity, startDate, bookedDays } = req.query;
  let rows = db.prepare(`
    SELECT h.*, u.name as owner_name, COALESCE(op.is_verified, 1) as owner_verified,
           COALESCE(op.verification_status, 'verified') as owner_verification_status
    FROM halls h
    JOIN users u ON h.owner_id = u.id
    LEFT JOIN owner_profiles op ON op.user_id = h.owner_id
    WHERE h.status = 'active' AND COALESCE(op.is_verified, 1) = 1
    ORDER BY h.featured DESC, h.rating DESC
  `).all() as Array<Record<string, unknown>>;

  rows = rows.map((h) => ({
    ...h,
    suitability_type: normalizeSuitabilityType(h.suitability_type || h.gender_policy) || 'MIXED',
  }));

  if (city && city !== 'all') {
    rows = rows.filter((h) => h.city === String(city));
  }
  if (suitabilityType && suitabilityType !== 'all') {
    const normSuit = normalizeSuitabilityType(suitabilityType, true);
    if (!normSuit) {
      res.status(400).json({ error: `نوع ملاءمة القاعة غير صالح. القيم المسموحة: ${VALID_SUITABILITY_TYPES.join(', ')}` });
      return;
    }
    rows = rows.filter((h) => h.suitability_type === normSuit);
  }
  if (hallType && hallType !== 'all') {
    rows = rows.filter((h) => h.hall_type === String(hallType));
  }
  if (genderPolicy && genderPolicy !== 'all') {
    rows = rows.filter((h) => h.gender_policy === String(genderPolicy));
  }
  if (bookingMode && bookingMode !== 'all') {
    rows = rows.filter((h) => h.booking_mode === String(bookingMode) || h.booking_mode === 'both');
  }
  if (minCapacity && Number(minCapacity) > 0) {
    rows = rows.filter((h) => Number(h.capacity_max) >= Number(minCapacity));
  }
  const resolvedStartDate = startDate || req.query.date;
  const resolvedBookedDays = bookedDays || req.query.days || 1;
  if (resolvedStartDate && String(resolvedStartDate).trim()) {
    const daysCount = Math.max(1, Math.min(30, Number(resolvedBookedDays)));
    const reqDates = computeConsecutiveDates(String(resolvedStartDate).trim(), daysCount);
    const activeBookings = db.prepare(`
      SELECT hall_id, event_date, COALESCE(booked_days, 1) as booked_days
      FROM bookings
      WHERE status = 'confirmed'
    `).all() as Array<Record<string, unknown>>;
    const blockedAvail = db.prepare(`
      SELECT hall_id, date FROM hall_availability WHERE status IN ('booked', 'blocked') AND shift = 'full_day'
    `).all() as Array<Record<string, unknown>>;

    rows = rows.filter((h) => {
      const hId = Number(h.id);
      for (const reqDate of reqDates) {
        const hasBlocked = blockedAvail.some((b) => Number(b.hall_id) === hId && String(b.date) === reqDate);
        if (hasBlocked) return false;
        const hasFullBooked = activeBookings.some((bk) => {
          if (Number(bk.hall_id) !== hId) return false;
          const bkDates = computeConsecutiveDates(String(bk.event_date), Number(bk.booked_days || 1));
          return bkDates.includes(reqDate);
        });
        if (hasFullBooked) return false;
      }
      return true;
    });
  }

  res.json({ halls: rows });
});

// 3. Authentication Endpoints
apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    res.status(400).json({ error: 'يرجى إدخال البريد الإلكتروني وكلمة المرور' });
    return;
  }
  const db = getDb();
  const user = db.prepare(`
    SELECT u.*, r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en,
           ep.job_title, ep.department
    FROM users u
    JOIN roles r ON u.role_id = r.id
    LEFT JOIN employee_profiles ep ON ep.user_id = u.id
    WHERE LOWER(u.email) = LOWER(?)
  `).get(String(email).trim()) as Record<string, unknown> | undefined;

  if (!user || !verifyPassword(String(password), String(user.password_hash))) {
    res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
    return;
  }

  if (user.status !== 'active') {
    res.status(403).json({ error: 'تم تعليق أو تعطيل هذا الحساب. يرجى التواصل مع إدارة المنصة.' });
    return;
  }

  db.prepare(`UPDATE users SET last_login_at = datetime('now') WHERE id = ?`).run(Number(user.id));
  const { token, csrfToken } = createSessionToken(Number(user.id), String(user.role_slug));
  const permissions = getUserPermissions(Number(user.id), String(user.role_slug));

  logAudit({
    userId: Number(user.id),
    action: 'user_login',
    entityType: 'users',
    entityId: Number(user.id),
    details: { email: user.email, role: user.role_slug },
    ipAddress: req.ip,
  });

  res.json({
    token,
    csrfToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role_id: user.role_id,
      role_slug: user.role_slug,
      role_name_ar: user.role_name_ar,
      role_name_en: user.role_name_en,
      status: user.status,
      job_title: user.job_title,
      department: user.department,
      permissions,
    },
  });
});

// Instant persona switch for seamless evaluation of portals (Super Admin, Hall Owner, Customer, Employee, Support Agent)
apiRouter.post('/auth/persona-switch', (req: Request, res: Response) => {
  const { userId } = req.body || {};
  const db = getDb();
  const user = db.prepare(`
    SELECT u.*, r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en,
           ep.job_title, ep.department
    FROM users u
    JOIN roles r ON u.role_id = r.id
    LEFT JOIN employee_profiles ep ON ep.user_id = u.id
    WHERE u.id = ?
  `).get(Number(userId)) as Record<string, unknown> | undefined;

  if (!user) {
    res.status(404).json({ error: 'الحساب غير موجود' });
    return;
  }
  if (user.status !== 'active') {
    res.status(403).json({ error: 'هذا الحساب معلق حالياً من قبل الإدارة' });
    return;
  }

  const { token, csrfToken } = createSessionToken(Number(user.id), String(user.role_slug));
  const permissions = getUserPermissions(Number(user.id), String(user.role_slug));
  res.json({
    token,
    csrfToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role_id: user.role_id,
      role_slug: user.role_slug,
      role_name_ar: user.role_name_ar,
      role_name_en: user.role_name_en,
      status: user.status,
      job_title: user.job_title,
      department: user.department,
      permissions,
    },
  });
});

// First Super Administrator Initialization Check & Secure One-Time Setup
apiRouter.get('/auth/setup-status', (_req: Request, res: Response) => {
  const db = getDb();
  const admin = db.prepare(`SELECT id FROM users WHERE role_id = 1 LIMIT 1`).get();
  res.json({ initialized: Boolean(admin), publicAdminRegistrationDisabled: Boolean(admin) });
});

apiRouter.post('/auth/setup-first-admin', (req: Request, res: Response) => {
  const db = getDb();
  const existingAdmin = db.prepare(`SELECT id FROM users WHERE role_id = 1 LIMIT 1`).get();
  if (existingAdmin) {
    logAudit({
      userId: null,
      action: 'blocked_duplicate_super_admin_setup',
      entityType: 'security',
      details: { ip: req.ip, attemptedEmail: req.body?.email },
      ipAddress: req.ip,
    });
    res.status(403).json({
      error: 'تم تهيئة المدير العام الأول مسبقاً. التسجيل العام للمسؤولين معطل نهائياً (Super Admin already initialized).',
    });
    return;
  }

  const { name, email, phone, password } = req.body || {};
  if (!name || !email || !password || String(password).length < 8) {
    res.status(400).json({ error: 'بيانات تهيئة المدير العام غير مكتملة' });
    return;
  }

  const hash = hashPassword(String(password));
  const info = db.prepare(`
    INSERT INTO users (role_id, name, email, phone, password_hash, status, email_verified, created_at, updated_at)
    VALUES (1, ?, ?, ?, ?, 'active', 1, datetime('now'), datetime('now'))
  `).run(String(name).trim(), String(email).trim().toLowerCase(), String(phone || '+967770000001').trim(), hash);

  const adminId = Number(info.lastInsertRowid);
  const { token, csrfToken } = createSessionToken(adminId, 'super_admin');
  res.status(201).json({ token, csrfToken, userId: adminId });
});

// Registration: Only allows Customer or Hall Owner registration (NEVER Super Admin or Support Agent!)
apiRouter.post('/auth/register', (req: Request, res: Response) => {
  const {
    name,
    email,
    phone,
    password,
    accountType,
    role,
    role_id,
    businessName,
    commercialRegNo,
    verificationDocumentUrl,
    termsAccepted,
    city,
  } = req.body || {};

  // Never trust a privileged role submitted by the browser (General Manager, Employee, or Support Agent cannot be registered publicly)
  if (
    accountType === 'super_admin' ||
    role === 'super_admin' ||
    Number(role_id) === 1 ||
    accountType === 'support_agent' ||
    role === 'support_agent' ||
    Number(role_id) === 5 ||
    accountType === 'employee' ||
    role === 'employee' ||
    Number(role_id) === 4
  ) {
    logAudit({
      userId: null,
      action: 'blocked_privilege_escalation_registration',
      entityType: 'security',
      details: { email, attemptedRole: accountType || role || role_id },
      ipAddress: req.ip,
    });
    res.status(403).json({
      error: 'غير مسموح بالتسجيل العام في أدوار المدير العام أو الموظفين أو الدعم الفني (Forbidden Role Escalation)',
    });
    return;
  }

  if (!name || !email || !phone || !password) {
    res.status(400).json({ error: 'يرجى تعبئة كافة الحقول الأساسية المطلوبة' });
    return;
  }
  if (String(password).length < 8) {
    res.status(400).json({ error: 'يجب ألا تقل كلمة المرور عن 8 أحرف' });
    return;
  }
  if (termsAccepted === false) {
    res.status(400).json({ error: 'يجب الموافقة على شروط وأحكام المنصة للمتابعة' });
    return;
  }

  // Strictly enforce role: 'hall_owner' (role_id = 2) or 'customer' (role_id = 3)
  const isOwner = accountType === 'hall_owner';
  const roleId = isOwner ? 2 : 3;
  const roleSlug = isOwner ? 'hall_owner' : 'customer';

  if (isOwner && !businessName) {
    res.status(400).json({ error: 'يرجى إدخال الاسم التجاري لمالك القاعة وبيانات التوثيق' });
    return;
  }

  try {
    const result = runInTransaction((db) => {
      const existing = db.prepare(`SELECT id FROM users WHERE LOWER(email) = LOWER(?)`).get(String(email).trim());
      if (existing) {
        throw new Error('البريد الإلكتروني مسجل مسبقاً في المنصة');
      }

      const pwdHash = hashPassword(String(password));
      const insertUser = db.prepare(`
        INSERT INTO users (role_id, name, email, phone, password_hash, status, email_verified, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', 1, datetime('now'), datetime('now'))
      `).run(roleId, String(name).trim(), String(email).trim().toLowerCase(), String(phone).trim(), pwdHash);

      const newUserId = Number(insertUser.lastInsertRowid);

      if (isOwner) {
        db.prepare(`
          INSERT INTO owner_profiles (
            user_id, business_name, commercial_registration_no, is_verified,
            verification_status, verification_document_url, terms_accepted, created_at, updated_at
          )
          VALUES (?, ?, ?, 0, 'pending', ?, 1, datetime('now'), datetime('now'))
        `).run(
          newUserId,
          String(businessName).trim(),
          String(commercialRegNo || 'CR-PENDING').trim(),
          String(verificationDocumentUrl || '/uploads/docs/owner-authorization-deed.pdf').trim()
        );

        // Notify Super Admin
        db.prepare(`
          INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
          VALUES (1, 'تسجيل مالك قاعة جديد', 'New Hall Owner Registered', ?, ?, 'system_alert', datetime('now'))
        `).run(
          `تم تسجيل حساب مالك قاعة جديد (${name} - ${businessName}) وبانتظار مراجعة وثائق الملكية والتوثيق.`,
          `New hall owner (${name} - ${businessName}) registered and awaits document verification.`
        );
      } else {
        db.prepare(`
          INSERT INTO customer_profiles (user_id, preferred_city, created_at, updated_at)
          VALUES (?, ?, datetime('now'), datetime('now'))
        `).run(newUserId, String(city || 'sanaa'));
      }

      logAudit({
        userId: newUserId,
        action: isOwner ? 'register_hall_owner' : 'register_customer',
        entityType: 'users',
        entityId: newUserId,
        details: {
          email,
          role: roleSlug,
          businessName: businessName || null,
          commercialRegNo: commercialRegNo || null,
          termsAccepted: true,
        },
        ipAddress: req.ip,
      });

      return newUserId;
    });

    const { token, csrfToken } = createSessionToken(result, roleSlug);
    res.status(201).json({
      token,
      csrfToken,
      user: {
        id: result,
        name: String(name).trim(),
        email: String(email).trim().toLowerCase(),
        phone: String(phone).trim(),
        role_id: roleId,
        role_slug: roleSlug,
        role_name_ar: isOwner ? 'مالك / مدير قاعة' : 'عميل / باحث عن قاعة',
        role_name_en: isOwner ? 'Hall Owner' : 'Customer',
        status: 'active',
      },
    });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر إنشاء الحساب' });
  }
});

// 4. Customer Endpoints (Bookings with ACID Conflict Prevention, Payments, Favorites, Inquiries, Reviews, Support Tickets)
apiRouter.get('/customer/dashboard', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDb();
  const userId = req.user!.id;

  const rawBookings = db.prepare(`
    SELECT b.*, h.name_ar as hall_name_ar, h.name_en as hall_name_en, h.city, h.address,
           h.suitability_type as hall_suitability_type_col, h.gender_policy,
           hp.title_ar as package_title_ar, hp.title_en as package_title_en
    FROM bookings b
    JOIN halls h ON b.hall_id = h.id
    LEFT JOIN hall_pricing hp ON b.pricing_id = hp.id
    WHERE b.customer_id = ?
    ORDER BY b.created_at DESC
  `).all(userId) as Array<Record<string, unknown>>;

  const bookings = rawBookings.map((b) => {
    const daysCount = Math.max(1, Number(b.booked_days || 1));
    const dates = computeConsecutiveDates(String(b.event_date), daysCount);
    return {
      ...b,
      end_date: String(b.end_date || dates[dates.length - 1] || b.event_date),
      booked_days: daysCount,
      booked_dates: dates,
      hall_suitability_type:
        normalizeSuitabilityType(b.hall_suitability_type || b.hall_suitability_type_col || b.gender_policy) || 'MIXED',
    };
  });

  const payments = db.prepare(`
    SELECT p.*, b.booking_code
    FROM payment_records p
    LEFT JOIN bookings b ON p.booking_id = b.id
    WHERE p.user_id = ?
    ORDER BY p.created_at DESC
  `).all(userId);

  const inquiries = db.prepare(`
    SELECT i.*, h.name_ar as hall_name_ar, h.name_en as hall_name_en
    FROM inquiries i
    JOIN halls h ON i.hall_id = h.id
    WHERE i.user_id = ?
    ORDER BY i.created_at DESC
  `).all(userId) as Array<Record<string, unknown>>;

  const inquiryMessages = db.prepare(`
    SELECT im.*, u.name as sender_name
    FROM inquiry_messages im
    LEFT JOIN users u ON im.sender_id = u.id
    ORDER BY im.created_at ASC
  `).all() as Array<Record<string, unknown>>;

  const enrichedInquiries = inquiries.map((inq) => ({
    ...inq,
    messages: inquiryMessages.filter((m) => Number(m.inquiry_id) === Number(inq.id)),
  }));

  const tickets = db.prepare(`
    SELECT t.*, h.name_ar as hall_name_ar, b.booking_code
    FROM support_tickets t
    LEFT JOIN halls h ON t.hall_id = h.id
    LEFT JOIN bookings b ON t.booking_id = b.id
    WHERE t.user_id = ?
    ORDER BY t.created_at DESC
  `).all(userId) as Array<Record<string, unknown>>;

  const ticketMessages = db.prepare(`
    SELECT tm.*, u.name as sender_name
    FROM support_ticket_messages tm
    JOIN users u ON tm.sender_id = u.id
    ORDER BY tm.created_at ASC
  `).all() as Array<Record<string, unknown>>;

  const enrichedTickets = tickets.map((t) => ({
    ...t,
    messages: ticketMessages.filter((m) => Number(m.ticket_id) === Number(t.id)),
  }));

  const notifications = db.prepare(`
    SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30
  `).all(userId);

  const favoriteRows = db.prepare(`
    SELECT hall_id FROM favorites WHERE user_id = ?
  `).all(userId) as Array<{ hall_id: number }>;

  res.json({
    bookings,
    payments,
    inquiries: enrichedInquiries,
    tickets: enrichedTickets,
    notifications,
    favorites: favoriteRows.map((f) => f.hall_id),
  });
});

// Mark Customer Notifications as Read
apiRouter.post('/customer/notifications/read', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const db = getDb();
  db.prepare(`UPDATE notifications SET is_read = 1 WHERE user_id = ?`).run(req.user!.id);
  res.json({ success: true });
});

// Helper to convert HH:MM to minutes from midnight
function timeToMinutes(t: string): number {
  const parts = String(t || '00:00').split(':');
  const h = parseInt(parts[0] || '0', 10);
  const m = parseInt(parts[1] || '0', 10);
  return h * 60 + m;
}

function minutesToTime(mins: number): string {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, mins));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export interface ServerBookingQuoteResult {
  hallId: number;
  pricingId: number | null;
  suitabilityType: string;
  startDate: string;
  endDate: string;
  bookedDays: number;
  dates: string[];
  bookedDates: string[];
  shift: string;
  startTime: string;
  endTime: string;
  durationHours: number;
  pricePerDay: number;
  subtotalAmount: number;
  basePrice: number;
  discountPercent: number;
  discountPct: number;
  discountAmount: number;
  additionalFees: number;
  taxAmount: number;
  totalAmount: number;
  depositRequired: number;
  currency: string;
  available: boolean;
  isAvailable: boolean;
  conflictingDates: string[];
  conflictReason: string | null;
}

function calculateServerBookingQuote(
  db: ReturnType<typeof getDb>,
  params: {
    hallId: number;
    pricingId?: number | null;
    startDate: string;
    bookedDays: number;
    shift: string;
    startTime?: string;
    durationHours?: number;
    excludeBookingId?: number;
  }
): ServerBookingQuoteResult {
  const hall = db.prepare(`SELECT * FROM halls WHERE id = ?`).get(Number(params.hallId)) as Record<string, unknown> | undefined;
  if (!hall) {
    throw new Error('القاعة المحددة غير موجودة');
  }

  const bookedDays = Math.max(1, Math.min(30, Math.floor(Number(params.bookedDays || 1))));
  const dates = computeConsecutiveDates(String(params.startDate).trim(), bookedDays);
  const startDate = dates[0] || String(params.startDate).trim();
  const endDate = dates[dates.length - 1] || startDate;

  const shift = String(params.shift || 'evening');
  const prepBuf = Number(hall.prep_buffer_hours ?? 2);
  const cleanBuf = Number(hall.cleanup_buffer_hours ?? 2);

  let resolvedStart = '16:00';
  let resolvedEnd = '23:00';
  let resolvedDuration = Number(hall.event_duration_hours || 6);

  if (shift === 'hourly') {
    resolvedStart = String(params.startTime || '14:00');
    resolvedDuration = Number(params.durationHours || 4);
    const startMins = timeToMinutes(resolvedStart);
    resolvedEnd = minutesToTime(startMins + resolvedDuration * 60);
  } else if (shift === 'morning') {
    resolvedStart = String(hall.morning_start_time || '08:00');
    resolvedEnd = String(hall.morning_end_time || '13:00');
    resolvedDuration = 5;
  } else if (shift === 'evening') {
    resolvedStart = String(hall.evening_start_time || '16:00');
    resolvedEnd = String(hall.evening_end_time || '23:00');
    resolvedDuration = 7;
  } else if (shift === 'full_day') {
    resolvedStart = String(hall.full_day_start_time || '08:00');
    resolvedEnd = String(hall.full_day_end_time || '23:59');
    resolvedDuration = 14;
  }

  const reqStartMin = timeToMinutes(resolvedStart);
  const reqEndMin = timeToMinutes(resolvedEnd);

  // Determine pricePerDay strictly from database records (never trust browser price inputs)
  let pricePerDay = 450000;
  let currency = 'YER';
  let resolvedPricingId: number | null = params.pricingId ? Number(params.pricingId) : null;

  if ((shift === 'hourly' || (params.durationHours && Number(params.durationHours) > 0 && shift === 'hourly')) && Number(hall.hourly_rate || 0) > 0) {
    pricePerDay = Math.round(resolvedDuration * Number(hall.hourly_rate));
  } else if (resolvedPricingId) {
    const pkg = db
      .prepare(`SELECT * FROM hall_pricing WHERE id = ? AND hall_id = ?`)
      .get(resolvedPricingId, Number(params.hallId)) as Record<string, unknown> | undefined;
    if (pkg) {
      pricePerDay = Number(pkg.base_price);
      currency = String(pkg.currency || 'YER');
    }
  } else {
    const shiftPkg = db
      .prepare(`SELECT * FROM hall_pricing WHERE hall_id = ? AND shift = ? AND is_active = 1 ORDER BY base_price ASC LIMIT 1`)
      .get(Number(params.hallId), shift) as Record<string, unknown> | undefined;
    if (shiftPkg) {
      pricePerDay = Number(shiftPkg.base_price);
      resolvedPricingId = Number(shiftPkg.id);
      currency = String(shiftPkg.currency || 'YER');
    } else {
      const anyPkg = db
        .prepare(`SELECT * FROM hall_pricing WHERE hall_id = ? AND is_active = 1 ORDER BY base_price ASC LIMIT 1`)
        .get(Number(params.hallId)) as Record<string, unknown> | undefined;
      if (anyPkg) {
        pricePerDay = Number(anyPkg.base_price);
        resolvedPricingId = Number(anyPkg.id);
        currency = String(anyPkg.currency || 'YER');
      }
    }
  }

  const subtotalAmount = pricePerDay * bookedDays;
  const hallDiscountPct = Number(hall.multi_day_discount_pct ?? 10);
  const discountPercent = bookedDays >= 2 ? Math.max(0, Math.min(50, hallDiscountPct)) : 0;
  const discountAmount = Math.round(subtotalAmount * (discountPercent / 100));
  const additionalFeesPerDay = Number(hall.additional_fees ?? 25000);
  const additionalFees = Math.max(0, additionalFeesPerDay * bookedDays);
  const taxableBase = Math.max(0, subtotalAmount - discountAmount + additionalFees);
  const taxAmount = Math.round(taxableBase * 0.05);
  const totalAmount = taxableBase + taxAmount;
  const depositRequired = Math.round(totalAmount * 0.3);

  // Check multi-day availability across all requested calendar days
  const conflictingDates: string[] = [];
  let conflictReason: string | null = null;

  const activeBookings = db.prepare(`
    SELECT id, booking_code, event_date, COALESCE(end_date, event_date) as end_date,
           COALESCE(booked_days, 1) as booked_days, shift, start_time, end_time,
           prep_buffer_hours, cleanup_buffer_hours, status
    FROM bookings
    WHERE hall_id = ? AND status IN ('confirmed', 'pending')
  `).all(Number(params.hallId)) as Array<Record<string, unknown>>;

  for (const reqDate of dates) {
    // 1. Check active bookings (single-day and multi-day) whose occupied dates include reqDate
    for (const existing of activeBookings) {
      if (params.excludeBookingId && Number(existing.id) === Number(params.excludeBookingId)) {
        continue;
      }
      const exDays = Math.max(1, Number(existing.booked_days || 1));
      const exDates = computeConsecutiveDates(String(existing.event_date), exDays);
      if (!exDates.includes(reqDate)) {
        continue;
      }

      const exShift = String(existing.shift);
      // Shift-level conflict if either is full_day or identical non-hourly shift
      if (exShift === 'full_day' || shift === 'full_day' || (exShift === shift && shift !== 'hourly')) {
        if (!conflictingDates.includes(reqDate)) conflictingDates.push(reqDate);
        if (!conflictReason) {
          conflictReason = `عذراً، التاريخ (${reqDate}) محجوز مسبقاً ضمن حجز قائم (${existing.booking_code}). يرجى اختيار تواريخ متاحة.`;
        }
      } else if (shift === 'hourly' || exShift === 'hourly') {
        const exStartMin = timeToMinutes(String(existing.start_time || '16:00'));
        const exEndMin = timeToMinutes(String(existing.end_time || '23:00'));
        const exPrep = Number(existing.prep_buffer_hours ?? prepBuf) * 60;
        const exClean = Number(existing.cleanup_buffer_hours ?? cleanBuf) * 60;

        const occupiedStart = exStartMin - exPrep;
        const occupiedEnd = exEndMin + exClean;

        if (reqStartMin < occupiedEnd && reqEndMin > occupiedStart) {
          if (!conflictingDates.includes(reqDate)) conflictingDates.push(reqDate);
          if (!conflictReason) {
            conflictReason = `تعارض في الوقت بتاريخ (${reqDate}): الفترة المطلوبة (${resolvedStart} - ${resolvedEnd}) تتقاطع مع حجز قائم (${existing.start_time} - ${existing.end_time}) مع احتساب فترة التجهيز والتنظيف.`;
          }
        }
      }
    }

    // 2. Check hall_availability table for blocked or booked shifts on reqDate
    const conflictAvailability = db.prepare(`
      SELECT id, status, reason, shift, booking_id FROM hall_availability
      WHERE hall_id = ? AND date = ? AND status IN ('booked', 'blocked')
        AND (shift = ? OR shift = 'full_day' OR ? = 'full_day')
        AND ? != 'hourly'
      LIMIT 1
    `).get(Number(params.hallId), reqDate, shift, shift, shift) as Record<string, unknown> | undefined;

    if (
      conflictAvailability &&
      (!params.excludeBookingId || Number(conflictAvailability.booking_id) !== Number(params.excludeBookingId))
    ) {
      if (!conflictingDates.includes(reqDate)) conflictingDates.push(reqDate);
      if (!conflictReason) {
        conflictReason = `عذراً، القاعة غير متاحة في التاريخ ${reqDate} (${conflictAvailability.reason || 'فترة محجوزة أو مغلقة'})`;
      }
    }
  }

  return {
    hallId: Number(params.hallId),
    pricingId: resolvedPricingId,
    suitabilityType: normalizeSuitabilityType(hall.suitability_type || hall.gender_policy) || 'MIXED',
    startDate,
    endDate,
    bookedDays,
    dates,
    bookedDates: dates,
    shift,
    startTime: resolvedStart,
    endTime: resolvedEnd,
    durationHours: resolvedDuration,
    pricePerDay,
    subtotalAmount,
    basePrice: subtotalAmount,
    discountPercent,
    discountPct: discountPercent,
    discountAmount,
    additionalFees,
    taxAmount,
    totalAmount,
    depositRequired,
    currency,
    available: conflictingDates.length === 0,
    isAvailable: conflictingDates.length === 0,
    conflictingDates,
    conflictReason,
  };
}

// Server-Side Multi-Day Price & Availability Quote Endpoint (GET & POST)
const handleBookingQuote = (req: Request, res: Response) => {
  const source = req.method === 'GET' ? req.query : req.body || {};
  const hallId = Number(source.hallId);
  const pricingId = source.pricingId ? Number(source.pricingId) : null;
  const startDate = String(source.startDate || source.eventDate || '').trim();
  const rawBookedDays = source.bookedDays ?? source.numberOfDays ?? source.consecutiveDays ?? 1;
  const bookedDays = Number(rawBookedDays);
  const shift = String(source.shift || 'evening');
  const startTime = source.startTime ? String(source.startTime) : undefined;
  const durationHours = source.durationHours ? Number(source.durationHours) : undefined;

  if (!hallId || !startDate) {
    res.status(400).json({ error: 'يرجى تحديد القاعة وتاريخ بداية الحجز لحساب التكلفة والتحقق من التوفر' });
    return;
  }
  if (!Number.isFinite(bookedDays) || bookedDays < 1 || bookedDays > 30) {
    res.status(400).json({ error: 'عدد أيام الحجز المتتالية يجب أن يكون بين يوم واحد و 30 يوماً' });
    return;
  }

  try {
    const db = getDb();
    const quote = calculateServerBookingQuote(db, {
      hallId,
      pricingId,
      startDate,
      bookedDays,
      shift,
      startTime,
      durationHours,
    });
    res.json({ quote });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر حساب تفاصيل الحجز' });
  }
};

apiRouter.post('/bookings/quote', handleBookingQuote);
apiRouter.get('/bookings/quote', handleBookingQuote);

// Create Booking inside an ACID Transaction with Multi-Day, Shift, Hourly Time-Slot & Buffer Conflict Detection
apiRouter.post('/bookings', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const {
    hallId,
    pricingId,
    eventDate,
    startDate: rawStartDate,
    bookedDays: rawBookedDays,
    numberOfDays,
    consecutiveDays,
    shift,
    guestCount,
    guestsCount,
    eventType,
    startTime: rawStartTime,
    durationHours,
    customerNotes,
    paymentMethod,
    transactionNumber,
    payDepositNow,
  } = req.body || {};

  const resolvedStartDateInput = String(rawStartDate || eventDate || '').trim();
  const guests = Number(guestCount || guestsCount || 0);
  const requestedDaysRaw = rawBookedDays ?? numberOfDays ?? consecutiveDays ?? 1;
  const bookedDays = Number(requestedDaysRaw);

  if (!hallId || !resolvedStartDateInput || !shift || !guests) {
    res.status(400).json({ error: 'يرجى تحديد القاعة، تاريخ بداية المناسبة، الفترة، وعدد الضيوف' });
    return;
  }

  if (!Number.isFinite(bookedDays) || bookedDays < 1 || bookedDays > 30 || !Number.isInteger(bookedDays)) {
    res.status(400).json({ error: 'عدد أيام الحجز المتتالية يجب أن يكون عدداً صحيحاً بين 1 و 30 يوماً' });
    return;
  }

  // Pre-validate hall duration limits before transaction so invalid durations return 400 Bad Request
  const dbCheck = getDb();
  const hallPre = dbCheck.prepare(`SELECT * FROM halls WHERE id = ? AND status = 'active'`).get(Number(hallId)) as Record<string, unknown> | undefined;
  if (!hallPre) {
    res.status(404).json({ error: 'القاعة المحددة غير متاحة للحجز حالياً' });
    return;
  }

  const minHours = Number(hallPre.min_booking_hours || 3);
  const maxHours = Number(hallPre.max_booking_hours || 12);

  if (shift === 'hourly' || (durationHours !== undefined && Number(durationHours) > 0)) {
    const reqDur = Number(durationHours || 0);
    if (reqDur < minHours || reqDur > maxHours) {
      res.status(400).json({
        error: `مدة الحجز بالساعات يجب أن تكون بين الحد الأدنى (${minHours} ساعات) والحد الأقصى (${maxHours} ساعة) لهذه القاعة`,
      });
      return;
    }
  }

  try {
    const bookingResult = runInTransaction((db) => {
      const hall = db.prepare(`SELECT * FROM halls WHERE id = ? AND status = 'active'`).get(Number(hallId)) as Record<string, unknown> | undefined;
      if (!hall) {
        throw new Error('القاعة المحددة غير متاحة للحجز حالياً');
      }

      if (guests < Number(hall.capacity_min) || guests > Number(hall.capacity_max)) {
        throw new Error(`عدد الضيوف يجب أن يكون بين ${hall.capacity_min} و ${hall.capacity_max} ضيف لهذه القاعة`);
      }

      const prepBuf = Number(hall.prep_buffer_hours ?? 2);
      const cleanBuf = Number(hall.cleanup_buffer_hours ?? 2);

      // Compute server-authoritative multi-day dates, availability, and pricing (ignoring any browser-submitted totalPrice!)
      const quote = calculateServerBookingQuote(db, {
        hallId: Number(hallId),
        pricingId: pricingId ? Number(pricingId) : null,
        startDate: resolvedStartDateInput,
        bookedDays,
        shift: String(shift),
        startTime: rawStartTime ? String(rawStartTime) : undefined,
        durationHours: durationHours !== undefined ? Number(durationHours) : undefined,
      });

      if (!quote.available) {
        throw new Error(
          quote.conflictReason ||
            `عذراً، القاعة غير متاحة في الأيام التالية: ${quote.conflictingDates.join(', ')}`
        );
      }

      const isCardInstant = paymentMethod === 'card_payment' && payDepositNow;
      const bookingStatus = isCardInstant ? 'confirmed' : 'pending';
      const paymentStatus = isCardInstant ? 'deposit_paid' : payDepositNow ? 'pending_verification' : 'unpaid';
      const remainingAmount = isCardInstant ? quote.totalAmount - quote.depositRequired : quote.totalAmount;

      const bookingCode = `MN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const resolvedEventType = String(eventType || hall.hall_type || 'wedding_hall');
      const resolvedSuitability = quote.suitabilityType;

      const insertBooking = db.prepare(`
        INSERT INTO bookings (
          booking_code, hall_id, customer_id, pricing_id, event_date, end_date, booked_days, shift,
          event_type, hall_suitability_type, duration_hours, start_time, end_time, prep_buffer_hours, cleanup_buffer_hours,
          guest_count, price_per_day, subtotal_amount, discount_amount, additional_fees, tax_amount, total_amount, deposit_amount, remaining_amount,
          currency, status, payment_status, customer_notes, confirmed_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
      `).run(
        bookingCode,
        Number(hallId),
        req.user!.id,
        quote.pricingId,
        quote.startDate,
        quote.endDate,
        quote.bookedDays,
        String(shift),
        resolvedEventType,
        resolvedSuitability,
        quote.durationHours,
        quote.startTime,
        quote.endTime,
        prepBuf,
        cleanBuf,
        guests,
        quote.pricePerDay,
        quote.subtotalAmount,
        quote.discountAmount,
        quote.additionalFees,
        quote.taxAmount,
        quote.totalAmount,
        quote.depositRequired,
        remainingAmount,
        quote.currency,
        bookingStatus,
        paymentStatus,
        String(customerNotes || '').trim(),
        isCardInstant ? new Date().toISOString() : null
      );

      const newBookingId = Number(insertBooking.lastInsertRowid);

      // Record each occupied calendar day in booking_days
      const insertDayStmt = db.prepare(`
        INSERT OR REPLACE INTO booking_days (booking_id, hall_id, date, shift, status, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `);
      for (const d of quote.dates) {
        insertDayStmt.run(newBookingId, Number(hallId), d, String(shift), bookingStatus);
      }

      // Record booking status history
      db.prepare(`
        INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, comment, created_at)
        VALUES (?, NULL, ?, ?, ?, datetime('now'))
      `).run(newBookingId, bookingStatus, req.user!.id, isCardInstant ? 'تأكيد فوري عبر الدفع الإلكتروني للعربون' : 'طلب حجز جديد من العميل');

      // If instant card payment, lock hall_availability immediately across ALL booked days
      if (isCardInstant) {
        const lockAvailStmt = db.prepare(`
          INSERT OR REPLACE INTO hall_availability (hall_id, date, shift, start_time, end_time, status, booking_id, reason, updated_by, updated_at)
          VALUES (?, ?, ?, ?, ?, 'booked', ?, ?, ?, datetime('now'))
        `);
        for (const d of quote.dates) {
          lockAvailStmt.run(
            Number(hallId),
            d,
            String(shift),
            quote.startTime,
            quote.endTime,
            newBookingId,
            `حجز مؤكد ${bookingCode} (${quote.bookedDays} أيام)`,
            req.user!.id
          );
        }
      }

      // Create payment record if deposit payment initiated
      let paymentRef = null;
      if (payDepositNow) {
        paymentRef = `PAY-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
        db.prepare(`
          INSERT INTO payment_records (
            payment_reference, booking_id, user_id, amount, currency, payment_method,
            transaction_number, payment_type, status, verified_by, verified_at, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 'booking_deposit', ?, ?, ?, datetime('now'))
        `).run(
          paymentRef,
          newBookingId,
          req.user!.id,
          quote.depositRequired,
          quote.currency,
          String(paymentMethod || 'card_payment'),
          String(transactionNumber || `TXN-${Date.now().toString().slice(-6)}`),
          isCardInstant ? 'verified' : 'pending_verification',
          isCardInstant ? 1 : null,
          isCardInstant ? new Date().toISOString() : null
        );
      }

      // Notify Hall Owner
      const dateRangeLabel = quote.bookedDays > 1 ? `من ${quote.startDate} إلى ${quote.endDate} (${quote.bookedDays} أيام)` : `بتاريخ ${quote.startDate}`;
      db.prepare(`
        INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
        VALUES (?, 'طلب حجز جديد', 'New Booking Request', ?, ?, 'booking_update', datetime('now'))
      `).run(
        Number(hall.owner_id),
        `ورد طلب حجز جديد (${bookingCode}) لقاعة ${hall.name_ar} ${dateRangeLabel} (${quote.startTime} - ${quote.endTime}).`,
        `New booking (${bookingCode}) received for ${hall.name_en || hall.name_ar} (${quote.startDate} to ${quote.endDate}).`
      );

      logAudit({
        userId: req.user!.id,
        action: 'create_booking',
        entityType: 'bookings',
        entityId: newBookingId,
        details: {
          bookingCode,
          hallId,
          startDate: quote.startDate,
          endDate: quote.endDate,
          bookedDays: quote.bookedDays,
          dates: quote.dates,
          shift,
          eventType: resolvedEventType,
          suitabilityType: resolvedSuitability,
          startTime: quote.startTime,
          endTime: quote.endTime,
          durationHours: quote.durationHours,
          pricePerDay: quote.pricePerDay,
          subtotalAmount: quote.subtotalAmount,
          discountAmount: quote.discountAmount,
          additionalFees: quote.additionalFees,
          taxAmount: quote.taxAmount,
          totalAmount: quote.totalAmount,
          bookingStatus,
          paymentRef,
        },
        ipAddress: req.ip,
      });

      return {
        id: newBookingId,
        bookingCode,
        status: bookingStatus,
        paymentStatus,
        paymentRef,
        startDate: quote.startDate,
        endDate: quote.endDate,
        eventDate: quote.startDate,
        bookedDays: quote.bookedDays,
        dates: quote.dates,
        bookedDates: quote.dates,
        pricePerDay: quote.pricePerDay,
        subtotalAmount: quote.subtotalAmount,
        basePrice: quote.subtotalAmount,
        discountPercent: quote.discountPercent,
        discountAmount: quote.discountAmount,
        additionalFees: quote.additionalFees,
        taxAmount: quote.taxAmount,
        totalAmount: quote.totalAmount,
        depositRequired: quote.depositRequired,
        remainingAmount,
        startTime: quote.startTime,
        endTime: quote.endTime,
        durationHours: quote.durationHours,
        eventType: resolvedEventType,
        suitabilityType: resolvedSuitability,
      };
    });

    res.status(201).json({ booking: bookingResult });
  } catch (err: unknown) {
    res.status(409).json({ error: err instanceof Error ? err.message : 'تعذر إتمام الحجز' });
  }
});

// Toggle Favorite Hall
apiRouter.post('/favorites/toggle', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { hallId } = req.body || {};
  const db = getDb();
  const existing = db.prepare(`SELECT 1 FROM favorites WHERE user_id = ? AND hall_id = ?`).get(req.user!.id, Number(hallId));
  if (existing) {
    db.prepare(`DELETE FROM favorites WHERE user_id = ? AND hall_id = ?`).run(req.user!.id, Number(hallId));
  } else {
    db.prepare(`INSERT INTO favorites (user_id, hall_id, created_at) VALUES (?, ?, datetime('now'))`).run(req.user!.id, Number(hallId));
  }
  const updated = db.prepare(`SELECT hall_id FROM favorites WHERE user_id = ?`).all(req.user!.id) as Array<{ hall_id: number }>;
  res.json({ favorites: updated.map((f) => f.hall_id) });
});

// Send Inquiry to Hall Owner
apiRouter.post('/inquiries', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { hallId, eventDate, guestEstimate, subject, message } = req.body || {};
  if (!hallId || !message) {
    res.status(400).json({ error: 'يرجى كتابة نص الاستفسار' });
    return;
  }
  const db = getDb();
  const inquiryCode = `INQ-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
  const info = db.prepare(`
    INSERT INTO inquiries (inquiry_code, hall_id, user_id, sender_name, sender_phone, sender_email, event_date, guest_estimate, subject, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', datetime('now'), datetime('now'))
  `).run(
    inquiryCode,
    Number(hallId),
    req.user!.id,
    req.user!.name,
    req.user!.phone,
    req.user!.email,
    String(eventDate || ''),
    Number(guestEstimate || 250),
    String(subject || 'استفسار عن القاعة والباقات')
  );

  const inquiryId = Number(info.lastInsertRowid);
  db.prepare(`
    INSERT INTO inquiry_messages (inquiry_id, sender_id, is_owner_reply, message, created_at)
    VALUES (?, ?, 0, ?, datetime('now'))
  `).run(inquiryId, req.user!.id, String(message).trim());

  res.status(201).json({ inquiryCode, inquiryId });
});

// Submit Customer Review
apiRouter.post('/reviews', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { hallId, ratingOverall, ratingCleanliness, ratingHospitality, ratingServices, comment } = req.body || {};
  if (!hallId || !comment) {
    res.status(400).json({ error: 'يرجى كتابة تعليق التقييم' });
    return;
  }
  const db = getDb();
  const overall = Math.min(5, Math.max(1, Number(ratingOverall || 5)));
  db.prepare(`
    INSERT INTO reviews (hall_id, customer_id, rating_cleanliness, rating_hospitality, rating_services, rating_overall, comment, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'approved', datetime('now'))
  `).run(
    Number(hallId),
    req.user!.id,
    Number(ratingCleanliness || overall),
    Number(ratingHospitality || overall),
    Number(ratingServices || overall),
    overall,
    String(comment).trim()
  );

  // Recalculate hall average rating
  const stats = db.prepare(`
    SELECT AVG(rating_overall) as avg_rating, COUNT(*) as cnt
    FROM reviews WHERE hall_id = ? AND status = 'approved'
  `).get(Number(hallId)) as { avg_rating: number; cnt: number };

  if (stats && stats.cnt > 0) {
    db.prepare(`UPDATE halls SET rating = ?, reviews_count = ? WHERE id = ?`).run(
      Number(stats.avg_rating.toFixed(2)),
      Number(stats.cnt),
      Number(hallId)
    );
  }

  res.status(201).json({ success: true });
});

// Create Support Ticket / Complaint
apiRouter.post('/tickets', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { bookingId, hallId, category, priority, subject, message } = req.body || {};
  if (!subject || !message) {
    res.status(400).json({ error: 'يرجى إدخال عنوان التذكرة وتفاصيل الطلب أو الشكوى' });
    return;
  }
  const db = getDb();
  const ticketCode = `TKT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const info = db.prepare(`
    INSERT INTO support_tickets (ticket_code, user_id, booking_id, hall_id, category, priority, subject, status, assigned_to, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'open', 6, datetime('now'), datetime('now'))
  `).run(
    ticketCode,
    req.user!.id,
    bookingId ? Number(bookingId) : null,
    hallId ? Number(hallId) : null,
    String(category || 'booking_issue'),
    String(priority || 'normal'),
    String(subject).trim()
  );

  const ticketId = Number(info.lastInsertRowid);
  db.prepare(`
    INSERT INTO support_ticket_messages (ticket_id, sender_id, sender_role, message, created_at)
    VALUES (?, ?, ?, ?, datetime('now'))
  `).run(ticketId, req.user!.id, req.user!.role_slug, String(message).trim());

  res.status(201).json({ ticketCode, ticketId });
});

// Provider-Independent Payment Verification Layer
// 1) Never mark a payment successful based only on a browser redirect:
apiRouter.get('/payments/redirect-callback', (req: Request, res: Response) => {
  res.status(400).json({
    verified: false,
    error:
      'لا يمكن تأكيد الدفع بناءً على إعادة توجيه المتصفح فقط. يجب التحقق من التوقيع الرقمي لمزود الدفع على الخادم (Server-side payment verification required).',
    paymentReference: req.query.paymentReference || null,
  });
});

// 2) Official Server-Side Payment Provider Webhook / Signature Verification:
apiRouter.post('/payments/verify-webhook', (req: Request, res: Response) => {
  const { paymentReference, amount, status } = req.body || {};
  const signature = String(req.headers['x-payment-signature'] || req.body?.signature || '');

  if (!paymentReference || amount === undefined || !status) {
    res.status(400).json({ error: 'بيانات إشعار الدفع غير مكتملة' });
    return;
  }

  if (!verifyPaymentProviderSignature(String(paymentReference), Number(amount), String(status), signature)) {
    logAudit({
      userId: null,
      action: 'rejected_unverified_payment_webhook',
      entityType: 'payment_records',
      details: { paymentReference, amount, status },
      ipAddress: req.ip,
    });
    res.status(401).json({ error: 'فشل التحقق من التوقيع الرقمي لمزود الدفع (Invalid Provider Signature)' });
    return;
  }

  try {
    runInTransaction((db) => {
      const payment = db
        .prepare(`SELECT * FROM payment_records WHERE payment_reference = ?`)
        .get(String(paymentReference)) as Record<string, unknown> | undefined;
      if (!payment) {
        throw new Error('سجل الدفعة غير موجود');
      }

      const nextStatus = status === 'succeeded' || status === 'verified' ? 'verified' : 'failed';
      db.prepare(`
        UPDATE payment_records
        SET status = ?, verified_at = datetime('now')
        WHERE id = ?
      `).run(nextStatus, Number(payment.id));

      if (nextStatus === 'verified' && payment.booking_id) {
        const nextBookingPayStatus = payment.payment_type === 'remaining_balance' ? 'paid_in_full' : 'deposit_paid';
        db.prepare(`
          UPDATE bookings
          SET payment_status = ?,
              status = CASE WHEN status = 'pending' THEN 'confirmed' ELSE status END,
              confirmed_at = COALESCE(confirmed_at, datetime('now')),
              updated_at = datetime('now')
          WHERE id = ?
        `).run(nextBookingPayStatus, Number(payment.booking_id));
      }
    });

    res.json({ verified: true, paymentReference });
  } catch (err: unknown) {
    res.status(404).json({ error: err instanceof Error ? err.message : 'فشل تحديث سجل الدفع' });
  }
});

// 5. Hall Owner Studio Endpoints (with Strict Resource Ownership Isolation)
apiRouter.get('/owner/dashboard', requireAuth, requireRole(['hall_owner', 'super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const db = getDb();
  if (req.user!.role_slug !== 'super_admin' && req.query.ownerId && Number(req.query.ownerId) !== req.user!.id) {
    logAudit({
      userId: req.user!.id,
      action: 'cross_owner_isolation_violation',
      entityType: 'users',
      entityId: Number(req.query.ownerId),
      details: { attemptedOwnerId: req.query.ownerId },
      ipAddress: req.ip,
    });
    res.status(403).json({ error: 'لا تملك صلاحية الاطلاع على بيانات مالك آخر (Strict Data Isolation)' });
    return;
  }

  const ownerId = req.user!.role_slug === 'super_admin' && req.query.ownerId ? Number(req.query.ownerId) : req.user!.id;

  const rawMyHalls = db.prepare(`SELECT * FROM halls WHERE owner_id = ? ORDER BY created_at DESC`).all(ownerId) as Array<Record<string, unknown>>;
  const myHalls: Array<Record<string, unknown>> = rawMyHalls.map((h) => ({
    ...h,
    suitability_type: normalizeSuitabilityType(h.suitability_type || h.gender_policy) || 'MIXED',
    multi_day_discount_pct: Number(h.multi_day_discount_pct ?? 10),
    additional_fees: Number(h.additional_fees ?? 25000),
  }));
  const hallIds = myHalls.map((h) => Number(h.id));

  const pricing = hallIds.length > 0
    ? db.prepare(`SELECT * FROM hall_pricing WHERE hall_id IN (${hallIds.join(',')}) ORDER BY id ASC`).all()
    : [];

  const availability = hallIds.length > 0
    ? db.prepare(`SELECT * FROM hall_availability WHERE hall_id IN (${hallIds.join(',')}) ORDER BY date ASC`).all()
    : [];

  const rawBookings = hallIds.length > 0
    ? (db.prepare(`
        SELECT b.*, h.name_ar as hall_name_ar, h.suitability_type as hall_suitability_type_col, h.gender_policy,
               u.name as customer_name, u.phone as customer_phone, u.email as customer_email
        FROM bookings b
        JOIN halls h ON b.hall_id = h.id
        JOIN users u ON b.customer_id = u.id
        WHERE b.hall_id IN (${hallIds.join(',')})
        ORDER BY b.created_at DESC
      `).all() as Array<Record<string, unknown>>)
    : [];

  const bookings: Array<Record<string, unknown>> = rawBookings.map((b) => {
    const daysCount = Math.max(1, Number(b.booked_days || 1));
    const dates = computeConsecutiveDates(String(b.event_date), daysCount);
    return {
      ...b,
      end_date: String(b.end_date || dates[dates.length - 1] || b.event_date),
      booked_days: daysCount,
      booked_dates: dates,
      hall_suitability_type:
        normalizeSuitabilityType(b.hall_suitability_type || b.hall_suitability_type_col || b.gender_policy) || 'MIXED',
    };
  });

  const payments = hallIds.length > 0
    ? db.prepare(`
        SELECT p.*, b.booking_code, h.name_ar as hall_name_ar
        FROM payment_records p
        JOIN bookings b ON p.booking_id = b.id
        JOIN halls h ON b.hall_id = h.id
        WHERE h.owner_id = ?
        ORDER BY p.created_at DESC
      `).all(ownerId)
    : [];

  const inquiries = hallIds.length > 0
    ? db.prepare(`
        SELECT i.*, h.name_ar as hall_name_ar
        FROM inquiries i
        JOIN halls h ON i.hall_id = h.id
        WHERE i.hall_id IN (${hallIds.join(',')})
        ORDER BY i.created_at DESC
      `).all() as Array<Record<string, unknown>>
    : [];

  const inquiryMessages = db.prepare(`SELECT * FROM inquiry_messages ORDER BY created_at ASC`).all() as Array<Record<string, unknown>>;
  const enrichedInquiries = inquiries.map((inq) => ({
    ...inq,
    messages: inquiryMessages.filter((m) => Number(m.inquiry_id) === Number(inq.id)),
  }));

  const staff = db.prepare(`
    SELECT ep.*, u.name, u.email, u.phone, u.status, h.name_ar as hall_name_ar
    FROM employee_profiles ep
    JOIN users u ON ep.user_id = u.id
    LEFT JOIN halls h ON ep.hall_id = h.id
    WHERE ep.owner_id = ?
  `).all(ownerId);

  const ownerProfile = db.prepare(`SELECT * FROM owner_profiles WHERE user_id = ?`).get(ownerId);
  const hallImages = hallIds.length > 0
    ? db.prepare(`SELECT * FROM hall_images WHERE hall_id IN (${hallIds.join(',')}) ORDER BY is_primary DESC, sort_order ASC`).all()
    : [];

  res.json({
    halls: myHalls,
    pricing,
    availability,
    bookings,
    payments,
    inquiries: enrichedInquiries,
    staff,
    ownerProfile,
    hallImages,
  });
});

// Owner submits a new Hall Venue -> marked as 'pending' for Super Admin approval!
apiRouter.post('/owner/halls', requireAuth, requireRole(['hall_owner', 'super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const {
    nameAr,
    nameEn,
    descriptionAr,
    descriptionEn,
    city,
    district,
    address,
    capacityMin,
    capacityMax,
    hallType,
    suitabilityType,
    suitability_type,
    genderPolicy,
    supportedEventTypes,
    bookingMode,
    morningStartTime,
    morningEndTime,
    eveningStartTime,
    eveningEndTime,
    minBookingHours,
    maxBookingHours,
    overtimeHourRate,
    eveningPrice,
    startingPrice,
    morningPrice,
    fullDayPrice,
    hourlyRate,
    multiDayDiscountPct,
    additionalFees,
    eventDurationHours,
    prepBufferHours,
    cleanupBufferHours,
    artworkStyle,
  } = req.body || {};
  if (!nameAr || !descriptionAr || !city || !address) {
    res.status(400).json({ error: 'يرجى إدخال اسم القاعة، الوصف، المدينة، والعنوان التفصيلي' });
    return;
  }

  const rawSuitability = suitabilityType ?? suitability_type;
  let resolvedSuitability: 'WOMEN_ONLY' | 'MEN_ONLY' | 'MIXED' = 'MIXED';
  if (rawSuitability !== undefined && rawSuitability !== null && String(rawSuitability).trim() !== '') {
    const strictSuit = normalizeSuitabilityType(rawSuitability, true);
    if (!strictSuit) {
      res.status(400).json({
        error: `نوع ملاءمة القاعة غير صالح. يجب اختيار إحدى القيم الرسمية الثلاث فقط: ${VALID_SUITABILITY_TYPES.join(', ')}`,
      });
      return;
    }
    resolvedSuitability = strictSuit;
  } else if (genderPolicy) {
    resolvedSuitability = normalizeSuitabilityType(genderPolicy) || 'MIXED';
  }

  const resolvedGenderPolicy =
    genderPolicy ||
    (resolvedSuitability === 'WOMEN_ONLY'
      ? 'women_only'
      : resolvedSuitability === 'MEN_ONLY'
      ? 'men_only'
      : 'separated_sections');

  const slug = `hall-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const status = req.user!.role_slug === 'super_admin' ? 'active' : 'pending';

  const result = runInTransaction((tx) => {
    const info = tx.prepare(`
      INSERT INTO halls (
        owner_id, name_ar, name_en, slug, description_ar, description_en,
        city, district, address, capacity_min, capacity_max, hall_type,
        suitability_type, gender_policy, supported_event_types, booking_mode,
        morning_start_time, morning_end_time, evening_start_time, evening_end_time,
        min_booking_hours, max_booking_hours, overtime_hour_rate,
        event_duration_hours, prep_buffer_hours, cleanup_buffer_hours, hourly_rate,
        multi_day_discount_pct, additional_fees,
        featured, status, rating, reviews_count, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, 5.0, 0, datetime('now'), datetime('now'))
    `).run(
      req.user!.id,
      String(nameAr).trim(),
      String(nameEn || nameAr).trim(),
      slug,
      String(descriptionAr).trim(),
      String(descriptionEn || descriptionAr).trim(),
      String(city),
      String(district || ''),
      String(address).trim(),
      Number(capacityMin || 150),
      Number(capacityMax || 700),
      String(hallType || 'wedding_hall'),
      resolvedSuitability,
      String(resolvedGenderPolicy),
      String(supportedEventTypes || 'wedding,engagement,graduation,conference'),
      String(bookingMode || 'both'),
      String(morningStartTime || '08:00'),
      String(morningEndTime || '13:00'),
      String(eveningStartTime || '16:00'),
      String(eveningEndTime || '23:00'),
      Number(minBookingHours || 3),
      Number(maxBookingHours || 12),
      Number(overtimeHourRate || 35000),
      Number(eventDurationHours || 6),
      Number(prepBufferHours || 2),
      Number(cleanupBufferHours || 2),
      Number(hourlyRate || 85000),
      Number(multiDayDiscountPct ?? 10),
      Number(additionalFees ?? 25000),
      status
    );

    const newHallId = Number(info.lastInsertRowid);
    const artUrl = `/api/artwork/${artworkStyle || city || 'taj-royal-palace'}`;

    tx.prepare(`
      INSERT INTO hall_images (hall_id, image_url, is_primary, caption, sort_order)
      VALUES (?, ?, 1, ?, 1)
    `).run(newHallId, artUrl, String(nameAr).trim());

    const evePrice = Number(eveningPrice || startingPrice || 500000);
    const mornPrice = Number(morningPrice || 280000);
    const fullPrice = Number(fullDayPrice || Math.round((evePrice + mornPrice) * 0.9));

    tx.prepare(`
      INSERT INTO hall_pricing (hall_id, title_ar, title_en, shift, day_type, base_price, deposit_required, currency)
      VALUES
      (?, 'الفترة المسائية الملكية', 'Evening Royal Reception', 'evening', 'all_days', ?, ?, 'YER'),
      (?, 'الفترة الصباحية', 'Morning Celebration', 'morning', 'all_days', ?, ?, 'YER'),
      (?, 'حجز اليوم الكامل الحصري', 'Exclusive Full-Day Buyout', 'full_day', 'all_days', ?, ?, 'YER')
    `).run(
      newHallId,
      evePrice,
      Math.round(evePrice * 0.3),
      newHallId,
      mornPrice,
      Math.round(mornPrice * 0.3),
      newHallId,
      fullPrice,
      Math.round(fullPrice * 0.3)
    );

    // Attach default luxury facilities
    tx.prepare(`
      INSERT OR IGNORE INTO hall_facilities (hall_id, facility_id, details, is_complimentary)
      VALUES
      (?, 1, 'تكييف مركزي متكامل', 1),
      (?, 2, 'كوشة ملكية وإضاءة مسرحية', 1),
      (?, 5, 'جناح خاص للعروسين', 1),
      (?, 7, 'مولد كهرباء احتياطي صامت', 1)
    `).run(newHallId, newHallId, newHallId, newHallId);

    // Notify Super Admin
    tx.prepare(`
      INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
      VALUES (1, 'قاعة جديدة بانتظار الاعتماد', 'New Venue Pending Approval', ?, ?, 'system_alert', datetime('now'))
    `).run(
      `قام المالك (${req.user!.name}) بإضافة قاعة "${nameAr}" (${resolvedSuitability}) وهي الآن بانتظار المراجعة والاعتماد.`,
      `Owner (${req.user!.name}) submitted venue "${nameEn || nameAr}" (${resolvedSuitability}) for approval.`
    );

    logAudit({
      userId: req.user!.id,
      action: 'submit_new_hall',
      entityType: 'halls',
      entityId: newHallId,
      details: { nameAr, city, suitabilityType: resolvedSuitability, hallType: hallType || 'wedding_hall', status },
      ipAddress: req.ip,
    });

    return newHallId;
  });

  res.status(201).json({ hallId: result, status, suitabilityType: resolvedSuitability });
});

// Owner updates booking status (Confirm / Cancel / Complete) with strict ownership & multi-day conflict check
apiRouter.post('/owner/bookings/:id/status', requireAuth, requireRole(['hall_owner', 'super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const bookingId = Number(req.params.id);
  const { status, comment } = req.body || {};
  if (!['confirmed', 'cancelled', 'completed'].includes(String(status))) {
    res.status(400).json({ error: 'حالة الحجز غير صالحة' });
    return;
  }

  const dbCheck = getDb();
  const targetBooking = dbCheck.prepare(`
    SELECT b.*, h.owner_id, h.name_ar as hall_name_ar
    FROM bookings b
    JOIN halls h ON b.hall_id = h.id
    WHERE b.id = ?
  `).get(bookingId) as Record<string, unknown> | undefined;

  if (!targetBooking) {
    res.status(404).json({ error: 'الحجز غير موجود' });
    return;
  }

  if (req.user!.role_slug !== 'super_admin' && Number(targetBooking.owner_id) !== req.user!.id) {
    logAudit({
      userId: req.user!.id,
      action: 'cross_owner_isolation_violation',
      entityType: 'bookings',
      entityId: bookingId,
      details: { attemptedBookingId: bookingId, actualOwnerId: targetBooking.owner_id },
      ipAddress: req.ip,
    });
    res.status(403).json({ error: 'لا تملك صلاحية إدارة حجز تابع لمالك قاعة آخر (Forbidden)' });
    return;
  }

  try {
    runInTransaction((db) => {
      const targetDaysCount = Math.max(1, Number(targetBooking.booked_days || 1));
      const targetDates = computeConsecutiveDates(String(targetBooking.event_date), targetDaysCount);

      if (status === 'confirmed') {
        const otherConfirmed = db.prepare(`
          SELECT id, booking_code, event_date, COALESCE(booked_days, 1) as booked_days, shift
          FROM bookings
          WHERE hall_id = ? AND status = 'confirmed' AND id != ?
        `).all(Number(targetBooking.hall_id), bookingId) as Array<Record<string, unknown>>;

        for (const reqDate of targetDates) {
          for (const ex of otherConfirmed) {
            const exDates = computeConsecutiveDates(String(ex.event_date), Number(ex.booked_days || 1));
            if (
              exDates.includes(reqDate) &&
              (ex.shift === 'full_day' || targetBooking.shift === 'full_day' || ex.shift === targetBooking.shift)
            ) {
              throw new Error(`يوجد حجز آخر مؤكد (${ex.booking_code}) يتعارض في التاريخ (${reqDate}) والفترة لهذه القاعة!`);
            }
          }
        }

        const lockStmt = db.prepare(`
          INSERT OR REPLACE INTO hall_availability (hall_id, date, shift, status, booking_id, reason, updated_by, updated_at)
          VALUES (?, ?, ?, 'booked', ?, ?, ?, datetime('now'))
        `);
        for (const reqDate of targetDates) {
          lockStmt.run(
            Number(targetBooking.hall_id),
            reqDate,
            String(targetBooking.shift),
            bookingId,
            `حجز مؤكد ${targetBooking.booking_code}`,
            req.user!.id
          );
        }
        db.prepare(`UPDATE booking_days SET status = 'confirmed' WHERE booking_id = ?`).run(bookingId);
      } else if (status === 'cancelled') {
        db.prepare(`DELETE FROM hall_availability WHERE booking_id = ?`).run(bookingId);
        db.prepare(`UPDATE booking_days SET status = 'cancelled' WHERE booking_id = ?`).run(bookingId);
      }

      db.prepare(`
        UPDATE bookings
        SET status = ?,
            confirmed_at = CASE WHEN ? = 'confirmed' THEN datetime('now') ELSE confirmed_at END,
            cancelled_at = CASE WHEN ? = 'cancelled' THEN datetime('now') ELSE cancelled_at END,
            updated_at = datetime('now')
        WHERE id = ?
      `).run(String(status), String(status), String(status), bookingId);

      db.prepare(`
        INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, comment, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `).run(bookingId, String(targetBooking.status), String(status), req.user!.id, String(comment || 'تحديث من إدارة القاعة'));

      db.prepare(`
        INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
        VALUES (?, 'تحديث حالة الحجز', 'Booking Status Updated', ?, ?, 'booking_update', datetime('now'))
      `).run(
        Number(targetBooking.customer_id),
        `تم تحديث حالة حجزكم (${targetBooking.booking_code}) في ${targetBooking.hall_name_ar} إلى: ${status}.`,
        `Your booking (${targetBooking.booking_code}) status has been updated to: ${status}.`
      );

      logAudit({
        userId: req.user!.id,
        action: `booking_status_${status}`,
        entityType: 'bookings',
        entityId: bookingId,
        details: { bookingCode: targetBooking.booking_code, oldStatus: targetBooking.status, newStatus: status, dates: targetDates },
        ipAddress: req.ip,
      });
    });

    res.json({ success: true });
  } catch (err: unknown) {
    res.status(409).json({ error: err instanceof Error ? err.message : 'تعذر تحديث الحجز' });
  }
});

// Owner blocks/unblocks a calendar date & shift (Strict Ownership Verification)
apiRouter.post('/owner/availability', requireAuth, requireRole(['hall_owner', 'super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const { hallId, date, shift, status, reason } = req.body || {};
  if (!hallId || !date || !shift) {
    res.status(400).json({ error: 'يرجى تحديد القاعة والتاريخ والفترة' });
    return;
  }
  const db = getDb();
  const hall = db.prepare(`SELECT id, owner_id FROM halls WHERE id = ?`).get(Number(hallId)) as { id: number; owner_id: number } | undefined;
  if (!hall) {
    res.status(404).json({ error: 'القاعة غير موجودة' });
    return;
  }
  if (req.user!.role_slug !== 'super_admin' && Number(hall.owner_id) !== req.user!.id) {
    logAudit({
      userId: req.user!.id,
      action: 'cross_owner_isolation_violation',
      entityType: 'halls',
      entityId: Number(hallId),
      details: { attemptedHallId: hallId, actualOwnerId: hall.owner_id },
      ipAddress: req.ip,
    });
    res.status(403).json({ error: 'لا تملك صلاحية تعديل تقويم قاعة تابعة لمالك آخر (Forbidden)' });
    return;
  }

  if (status === 'available') {
    db.prepare(`DELETE FROM hall_availability WHERE hall_id = ? AND date = ? AND shift = ? AND booking_id IS NULL`).run(
      Number(hallId),
      String(date),
      String(shift)
    );
  } else {
    db.prepare(`
      INSERT OR REPLACE INTO hall_availability (hall_id, date, shift, status, reason, updated_by, updated_at)
      VALUES (?, ?, ?, 'blocked', ?, ?, datetime('now'))
    `).run(Number(hallId), String(date), String(shift), String(reason || 'إغلاق إداري / صيانة'), req.user!.id);
  }
  res.json({ success: true });
});

// Owner or Admin updates Hall Configuration, Suitability Type, Multi-Day Discounts, Duration, Buffers & Photographs
const handleUpdateHallConfig = (req: AuthenticatedRequest, res: Response) => {
  const hallId = Number(req.params.id);
  const {
    nameAr,
    nameEn,
    descriptionAr,
    capacityMin,
    capacityMax,
    hallType,
    suitabilityType,
    suitability_type,
    genderPolicy,
    multiDayDiscountPct,
    additionalFees,
    eventDurationHours,
    prepBufferHours,
    cleanupBufferHours,
    hourlyRate,
    imageUrl,
    imageCaption,
  } = req.body || {};

  const db = getDb();
  const hall = db.prepare(`SELECT * FROM halls WHERE id = ?`).get(hallId) as Record<string, unknown> | undefined;
  if (!hall) {
    res.status(404).json({ error: 'القاعة غير موجودة' });
    return;
  }

  const isAdminOrAuthorizedStaff =
    req.user!.role_slug === 'super_admin' ||
    ((req.user!.role_slug === 'employee' || req.user!.role_slug === 'support_agent') && hasPermission(req.user, ['halls.edit']));

  if (!isAdminOrAuthorizedStaff && Number(hall.owner_id) !== req.user!.id) {
    res.status(403).json({ error: 'لا تملك صلاحية تعديل إعدادات قاعة تابعة لمالك آخر' });
    return;
  }

  const rawSuitability = suitabilityType ?? suitability_type;
  let nextSuitability: string | null = null;
  let nextGenderPolicy: string | null = genderPolicy ? String(genderPolicy) : null;
  if (rawSuitability !== undefined && rawSuitability !== null && String(rawSuitability).trim() !== '') {
    const strictSuit = normalizeSuitabilityType(rawSuitability, true);
    if (!strictSuit) {
      res.status(400).json({
        error: `نوع ملاءمة القاعة غير صالح. القيم المسموحة فقط: ${VALID_SUITABILITY_TYPES.join(', ')}`,
      });
      return;
    }
    nextSuitability = strictSuit;
    if (!nextGenderPolicy) {
      nextGenderPolicy =
        strictSuit === 'WOMEN_ONLY' ? 'women_only' : strictSuit === 'MEN_ONLY' ? 'men_only' : 'separated_sections';
    }
  }

  db.prepare(`
    UPDATE halls
    SET name_ar = COALESCE(?, name_ar),
        name_en = COALESCE(?, name_en),
        description_ar = COALESCE(?, description_ar),
        capacity_min = COALESCE(?, capacity_min),
        capacity_max = COALESCE(?, capacity_max),
        hall_type = COALESCE(?, hall_type),
        suitability_type = COALESCE(?, suitability_type),
        gender_policy = COALESCE(?, gender_policy),
        multi_day_discount_pct = COALESCE(?, multi_day_discount_pct),
        additional_fees = COALESCE(?, additional_fees),
        event_duration_hours = COALESCE(?, event_duration_hours),
        prep_buffer_hours = COALESCE(?, prep_buffer_hours),
        cleanup_buffer_hours = COALESCE(?, cleanup_buffer_hours),
        hourly_rate = COALESCE(?, hourly_rate),
        updated_at = datetime('now')
    WHERE id = ?
  `).run(
    nameAr ? String(nameAr).trim() : null,
    nameEn ? String(nameEn).trim() : null,
    descriptionAr ? String(descriptionAr).trim() : null,
    capacityMin !== undefined ? Number(capacityMin) : null,
    capacityMax !== undefined ? Number(capacityMax) : null,
    hallType ? String(hallType).trim() : null,
    nextSuitability,
    nextGenderPolicy,
    multiDayDiscountPct !== undefined ? Number(multiDayDiscountPct) : null,
    additionalFees !== undefined ? Number(additionalFees) : null,
    eventDurationHours !== undefined ? Number(eventDurationHours) : null,
    prepBufferHours !== undefined ? Number(prepBufferHours) : null,
    cleanupBufferHours !== undefined ? Number(cleanupBufferHours) : null,
    hourlyRate !== undefined ? Number(hourlyRate) : null,
    hallId
  );

  if (imageUrl) {
    db.prepare(`
      INSERT INTO hall_images (hall_id, image_url, is_primary, caption, sort_order)
      VALUES (?, ?, 0, ?, 2)
    `).run(hallId, String(imageUrl).trim(), String(imageCaption || 'صورة إضافية للقاعة').trim());
  }

  logAudit({
    userId: req.user!.id,
    action: 'update_hall_details',
    entityType: 'halls',
    entityId: hallId,
    details: { hallId, suitabilityType: nextSuitability, hallType, multiDayDiscountPct, additionalFees },
    ipAddress: req.ip,
  });

  res.json({ success: true, suitabilityType: nextSuitability || hall.suitability_type });
};

apiRouter.post('/owner/halls/:id/config', requireAuth, requireRole(['hall_owner', 'super_admin', 'employee']), handleUpdateHallConfig);
apiRouter.put('/owner/halls/:id', requireAuth, requireRole(['hall_owner', 'super_admin', 'employee']), handleUpdateHallConfig);
apiRouter.put('/admin/halls/:id', requireAuth, requirePermission(['halls.edit']), handleUpdateHallConfig);

// Owner replies to customer inquiry (Strict Ownership Verification)
apiRouter.post('/owner/inquiries/:id/reply', requireAuth, requireRole(['hall_owner', 'support_agent', 'super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const inquiryId = Number(req.params.id);
  const { message } = req.body || {};
  if (!message) {
    res.status(400).json({ error: 'يرجى كتابة نص الرد' });
    return;
  }
  const db = getDb();
  const inquiry = db.prepare(`
    SELECT i.id, h.owner_id
    FROM inquiries i
    JOIN halls h ON i.hall_id = h.id
    WHERE i.id = ?
  `).get(inquiryId) as { id: number; owner_id: number } | undefined;

  if (!inquiry) {
    res.status(404).json({ error: 'الاستفسار غير موجود' });
    return;
  }
  if (req.user!.role_slug === 'hall_owner' && Number(inquiry.owner_id) !== req.user!.id) {
    res.status(403).json({ error: 'لا تملك صلاحية الرد على استفسارات قاعة تابعة لمالك آخر' });
    return;
  }

  db.prepare(`
    INSERT INTO inquiry_messages (inquiry_id, sender_id, is_owner_reply, message, created_at)
    VALUES (?, ?, 1, ?, datetime('now'))
  `).run(inquiryId, req.user!.id, String(message).trim());

  db.prepare(`UPDATE inquiries SET status = 'replied', updated_at = datetime('now') WHERE id = ?`).run(inquiryId);
  res.json({ success: true });
});

// 6. Customer Support Agent & Authorized Employee Support Portal Endpoints
apiRouter.get(
  '/support/dashboard',
  requireAuth,
  requirePermission(['support.view_tickets']),
  (_req: AuthenticatedRequest, res: Response) => {
    const db = getDb();
    const tickets = db.prepare(`
      SELECT t.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
             h.name_ar as hall_name_ar, b.booking_code, b.status as booking_status
      FROM support_tickets t
      JOIN users u ON t.user_id = u.id
      LEFT JOIN halls h ON t.hall_id = h.id
      LEFT JOIN bookings b ON t.booking_id = b.id
      ORDER BY
        CASE t.priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 ELSE 3 END,
        t.created_at DESC
    `).all() as Array<Record<string, unknown>>;

    const messages = db.prepare(`
      SELECT tm.*, u.name as sender_name
      FROM support_ticket_messages tm
      JOIN users u ON tm.sender_id = u.id
      ORDER BY tm.created_at ASC
    `).all() as Array<Record<string, unknown>>;

    const enrichedTickets = tickets.map((t) => ({
      ...t,
      messages: messages.filter((m) => Number(m.ticket_id) === Number(t.id)),
    }));

    const inquiries = db.prepare(`
      SELECT i.*, h.name_ar as hall_name_ar
      FROM inquiries i
      JOIN halls h ON i.hall_id = h.id
      ORDER BY i.created_at DESC
    `).all() as Array<Record<string, unknown>>;

    const inquiryMessages = db.prepare(`SELECT * FROM inquiry_messages ORDER BY created_at ASC`).all() as Array<Record<string, unknown>>;
    const enrichedInquiries = inquiries.map((inq) => ({
      ...inq,
      messages: inquiryMessages.filter((m) => Number(m.inquiry_id) === Number(inq.id)),
    }));

    res.json({
      tickets: enrichedTickets,
      inquiries: enrichedInquiries,
    });
  }
);

apiRouter.post(
  '/support/tickets/:id/reply',
  requireAuth,
  requirePermission(['support.respond_tickets', 'support.resolve_close']),
  (req: AuthenticatedRequest, res: Response) => {
    const ticketId = Number(req.params.id);
    const { message, newStatus } = req.body || {};
    if (!message) {
      res.status(400).json({ error: 'يرجى كتابة الرد على التذكرة' });
      return;
    }
    const statusToSet = newStatus || 'in_progress';
    if ((statusToSet === 'resolved' || statusToSet === 'closed') && !hasPermission(req.user, ['support.resolve_close'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية إغلاق التذاكر (support.resolve_close)' });
      return;
    }

    const db = getDb();
    db.prepare(`
      INSERT INTO support_ticket_messages (ticket_id, sender_id, sender_role, message, created_at)
      VALUES (?, ?, ?, ?, datetime('now'))
    `).run(ticketId, req.user!.id, req.user!.role_slug, String(message).trim());

    db.prepare(`
      UPDATE support_tickets
      SET status = ?, assigned_to = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(String(statusToSet), req.user!.id, ticketId);

    logAudit({
      userId: req.user!.id,
      action: 'support_ticket_reply',
      entityType: 'support_tickets',
      entityId: ticketId,
      details: { newStatus: statusToSet },
      ipAddress: req.ip,
    });

    res.json({ success: true });
  }
);

// 7. GENERAL MANAGER & PERMISSION-SCOPED EMPLOYEE DASHBOARD API
apiRouter.get(
  '/admin/dashboard',
  requireAuth,
  requireRole(['super_admin', 'employee', 'support_agent']),
  (req: AuthenticatedRequest, res: Response) => {
    const db = getDb();

    // Users & Roles
    const users = db.prepare(`
      SELECT u.id, u.role_id, u.name, u.email, u.phone, u.status, u.last_login_at, u.created_at,
             r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en,
             op.business_name, op.commercial_registration_no, op.is_verified as owner_verified,
             op.verification_status, op.verification_document_url, op.verification_rejection_reason,
             ep.job_title, ep.department, ep.hire_date
      FROM users u
      JOIN roles r ON u.role_id = r.id
      LEFT JOIN owner_profiles op ON op.user_id = u.id
      LEFT JOIN employee_profiles ep ON ep.user_id = u.id
      ORDER BY u.id ASC
    `).all() as Array<Record<string, unknown>>;

    // Employees with their individual granular permissions
    const permissionsCatalog = db.prepare(`SELECT id, slug, name_ar, name_en, module FROM permissions ORDER BY id ASC`).all() as Array<{
      id: number;
      slug: string;
      name_ar: string;
      name_en: string;
      module: string;
    }>;

    const userPermRows = db.prepare(`
      SELECT up.user_id, p.slug
      FROM user_permissions up
      JOIN permissions p ON up.permission_id = p.id
      WHERE up.is_granted = 1
    `).all() as Array<{ user_id: number; slug: string }>;

    const employees = users
      .filter((u) => u.role_slug === 'employee' || u.role_slug === 'support_agent')
      .map((u) => ({
        ...u,
        job_title: u.job_title || (u.role_slug === 'support_agent' ? 'أخصائي دعم العملاء والشكاوى' : 'موظف العمليات والحجوزات'),
        department: u.department || 'إدارة التشغيل والمنصة',
        permissions: userPermRows.filter((up) => Number(up.user_id) === Number(u.id)).map((up) => up.slug),
      }));

    // Halls (All statuses: active, pending, rejected, suspended)
    const rawHalls = db.prepare(`
      SELECT h.*, u.name as owner_name, u.email as owner_email, op.business_name, op.is_verified as owner_verified
      FROM halls h
      JOIN users u ON h.owner_id = u.id
      LEFT JOIN owner_profiles op ON op.user_id = u.id
      ORDER BY
        CASE h.status WHEN 'pending' THEN 1 WHEN 'active' THEN 2 ELSE 3 END,
        h.id DESC
    `).all() as Array<Record<string, unknown>>;

    const halls: Array<Record<string, unknown>> = rawHalls.map((h) => ({
      ...h,
      suitability_type: normalizeSuitabilityType(h.suitability_type || h.gender_policy) || 'MIXED',
      multi_day_discount_pct: Number(h.multi_day_discount_pct ?? 10),
      additional_fees: Number(h.additional_fees ?? 25000),
    }));

    // Bookings
    const rawBookings = db.prepare(`
      SELECT b.*, h.name_ar as hall_name_ar, h.owner_id, h.suitability_type as hall_suitability_type_col, h.gender_policy,
             u.name as customer_name, u.email as customer_email, u.phone as customer_phone,
             ou.name as owner_name
      FROM bookings b
      JOIN halls h ON b.hall_id = h.id
      JOIN users u ON b.customer_id = u.id
      JOIN users ou ON h.owner_id = ou.id
      ORDER BY b.created_at DESC
    `).all() as Array<Record<string, unknown>>;

    const bookings: Array<Record<string, unknown>> = rawBookings.map((b) => {
      const daysCount = Math.max(1, Number(b.booked_days || 1));
      const dates = computeConsecutiveDates(String(b.event_date), daysCount);
      return {
        ...b,
        end_date: String(b.end_date || dates[dates.length - 1] || b.event_date),
        booked_days: daysCount,
        booked_dates: dates,
        hall_suitability_type:
          normalizeSuitabilityType(b.hall_suitability_type || b.hall_suitability_type_col || b.gender_policy) || 'MIXED',
      };
    });

    // Payment Records & Strict Verified Financial Calculations
    const payments = db.prepare(`
      SELECT p.*, b.booking_code, b.total_amount as booking_total, h.name_ar as hall_name_ar, u.name as payer_name
      FROM payment_records p
      LEFT JOIN bookings b ON p.booking_id = b.id
      LEFT JOIN halls h ON b.hall_id = h.id
      JOIN users u ON p.user_id = u.id
      ORDER BY p.created_at DESC
    `).all() as Array<Record<string, unknown>>;

    const commissionRateRow = db.prepare(`SELECT setting_value FROM platform_settings WHERE setting_key = 'platform_commission_rate'`).get() as { setting_value: string } | undefined;
    const commissionRate = Number(commissionRateRow?.setting_value || 5.0) / 100;

    let grossBookingValue = 0;
    for (const b of bookings) {
      if (b.status !== 'cancelled') {
        grossBookingValue += Number(b.total_amount || 0);
      }
    }

    let verifiedPaidAmount = 0;
    let pendingPaymentsAmount = 0;
    let refundedAmount = 0;

    for (const p of payments) {
      const amt = Number(p.amount || 0);
      if (p.status === 'verified') {
        verifiedPaidAmount += amt;
      } else if (p.status === 'pending_verification') {
        pendingPaymentsAmount += amt;
      } else if (p.status === 'refunded') {
        refundedAmount += amt;
      }
    }

    const platformCommission = Math.round(verifiedPaidAmount * commissionRate);
    const hallOwnerNetRevenue = Math.max(0, verifiedPaidAmount - platformCommission);

    const reviews = db.prepare(`
      SELECT r.*, u.name as customer_name, h.name_ar as hall_name_ar
      FROM reviews r
      JOIN users u ON r.customer_id = u.id
      JOIN halls h ON r.hall_id = h.id
      ORDER BY r.created_at DESC
    `).all();

    const inquiries = db.prepare(`
      SELECT i.*, h.name_ar as hall_name_ar
      FROM inquiries i
      JOIN halls h ON i.hall_id = h.id
      ORDER BY i.created_at DESC
    `).all();

    const subscriptionPlans = db.prepare(`SELECT * FROM subscription_plans ORDER BY price ASC`).all();
    const auditLogs = db.prepare(`
      SELECT a.*, u.name as actor_name, u.email as actor_email, r.slug as actor_role
      FROM audit_logs a
      LEFT JOIN users u ON a.user_id = u.id
      LEFT JOIN roles r ON u.role_id = r.id
      ORDER BY a.id DESC
      LIMIT 120
    `).all();

    const settingsRows = db.prepare(`SELECT * FROM platform_settings ORDER BY setting_group, setting_key`).all() as Array<Record<string, unknown>>;
    const supportTickets = db.prepare(`
      SELECT t.*, u.name as customer_name, u.phone as customer_phone, h.name_ar as hall_name_ar, b.booking_code
      FROM support_tickets t
      JOIN users u ON t.user_id = u.id
      LEFT JOIN halls h ON t.hall_id = h.id
      LEFT JOIN bookings b ON t.booking_id = b.id
      ORDER BY t.created_at DESC
    `).all();

    const stats = {
      totalUsers: users.length,
      totalCustomers: users.filter((u) => u.role_slug === 'customer').length,
      totalHallOwners: users.filter((u) => u.role_slug === 'hall_owner').length,
      totalEmployees: employees.length,
      totalHalls: halls.length,
      pendingHallApprovals: halls.filter((h) => h.status === 'pending').length,
      activeHalls: halls.filter((h) => h.status === 'active').length,
      rejectedHalls: halls.filter((h) => h.status === 'rejected').length,
      pendingBookings: bookings.filter((b) => b.status === 'pending').length,
      confirmedBookings: bookings.filter((b) => b.status === 'confirmed').length,
      cancelledBookings: bookings.filter((b) => b.status === 'cancelled').length,
      completedBookings: bookings.filter((b) => b.status === 'completed').length,
      financials: {
        grossBookingValue,
        verifiedPaidAmount,
        platformCommission,
        hallOwnerNetRevenue,
        pendingPaymentsAmount,
        refundedAmount,
        commissionRatePercentage: commissionRate * 100,
      },
    };

    res.json({
      stats,
      users,
      employees: req.user!.role_slug === 'super_admin' ? employees : [],
      permissionsCatalog,
      currentUserPermissions: req.user!.permissions,
      halls: hasPermission(req.user, ['halls.view', 'halls.approve_reject', 'halls.edit']) ? halls : [],
      bookings: hasPermission(req.user, ['bookings.view', 'bookings.review', 'bookings.confirm', 'bookings.view_schedules']) ? bookings : [],
      payments: hasPermission(req.user, ['finance.view_payments', 'finance.verify_payments', 'finance.view_commissions']) ? payments : [],
      reviews: hasPermission(req.user, ['content.moderate_reviews']) ? reviews : [],
      inquiries,
      subscriptionPlans,
      auditLogs: req.user!.role_slug === 'super_admin' ? auditLogs : [],
      settings: settingsRows,
      supportTickets: hasPermission(req.user, ['support.view_tickets', 'support.respond_tickets']) ? supportTickets : [],
    });
  }
);

// ============================================================================
// 8. GENERAL MANAGER EMPLOYEE MANAGEMENT & GRANULAR PERMISSION ENDPOINTS
// Strictly restricted to General Manager (super_admin) — employees can NEVER
// create employees, edit employees, or grant themselves/others permissions!
// ============================================================================

apiRouter.get('/admin/employees', requireAuth, requireRole(['super_admin']), (_req: AuthenticatedRequest, res: Response) => {
  const db = getDb();
  const rows = db.prepare(`
    SELECT u.id, u.role_id, u.name, u.email, u.phone, u.status, u.last_login_at, u.created_at,
           r.slug as role_slug, r.name_ar as role_name_ar, r.name_en as role_name_en,
           ep.job_title, ep.department, ep.hire_date
    FROM users u
    JOIN roles r ON u.role_id = r.id
    LEFT JOIN employee_profiles ep ON ep.user_id = u.id
    WHERE r.slug IN ('employee', 'support_agent')
    ORDER BY u.id ASC
  `).all() as Array<Record<string, unknown>>;

  const permRows = db.prepare(`
    SELECT up.user_id, p.slug
    FROM user_permissions up
    JOIN permissions p ON up.permission_id = p.id
    WHERE up.is_granted = 1
  `).all() as Array<{ user_id: number; slug: string }>;

  const employees = rows.map((u) => ({
    ...u,
    job_title: u.job_title || 'موظف تشغيل وحجوزات',
    department: u.department || 'إدارة العمليات',
    permissions: permRows.filter((p) => Number(p.user_id) === Number(u.id)).map((p) => p.slug),
  }));

  const permissionsCatalog = db.prepare(`SELECT id, slug, name_ar, name_en, module FROM permissions ORDER BY id ASC`).all();
  const employeeLogs = db.prepare(`
    SELECT a.*, u.name as actor_name, u.email as actor_email
    FROM audit_logs a
    JOIN users u ON a.user_id = u.id
    JOIN roles r ON u.role_id = r.id
    WHERE r.slug IN ('employee', 'support_agent') OR a.entity_type = 'employees'
    ORDER BY a.id DESC
    LIMIT 60
  `).all();

  res.json({ employees, permissionsCatalog, employeeLogs });
});

apiRouter.post('/admin/employees', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const { name, email, phone, jobTitle, department, password, roleSlug, permissions } = req.body || {};
  if (!name || !email || !phone || !jobTitle || !password) {
    res.status(400).json({ error: 'يرجى إدخال الاسم الكامل، البريد الإلكتروني، الهاتف، المسمى الوظيفي، وكلمة المرور' });
    return;
  }
  if (String(password).length < 8) {
    res.status(400).json({ error: 'يجب ألا تقل كلمة المرور لحساب الموظف عن 8 أحرف' });
    return;
  }

  const targetRoleSlug = roleSlug === 'support_agent' ? 'support_agent' : 'employee';

  try {
    const createdEmployee = runInTransaction((tx) => {
      const existing = tx.prepare(`SELECT id FROM users WHERE LOWER(email) = LOWER(?)`).get(String(email).trim());
      if (existing) {
        throw new Error('البريد الإلكتروني مستخدم مسبقاً. يجب تخصيص حساب مستقل وفريد لكل موظف.');
      }

      const roleRow = tx.prepare(`SELECT id FROM roles WHERE slug = ?`).get(targetRoleSlug) as { id: number } | undefined;
      const roleId = roleRow ? roleRow.id : 4;
      const pwdHash = hashPassword(String(password));

      const info = tx.prepare(`
        INSERT INTO users (role_id, name, email, phone, password_hash, status, email_verified, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', 1, datetime('now'), datetime('now'))
      `).run(roleId, String(name).trim(), String(email).trim().toLowerCase(), String(phone).trim(), pwdHash);

      const newUserId = Number(info.lastInsertRowid);

      tx.prepare(`
        INSERT INTO employee_profiles (user_id, owner_id, job_title, department, hire_date, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, date('now'), 1, datetime('now'), datetime('now'))
      `).run(newUserId, req.user!.id, String(jobTitle).trim(), String(department || 'إدارة التشغيل والحجوزات').trim());

      const permArray: string[] = Array.isArray(permissions) ? permissions.map(String) : [];
      if (permArray.length > 0) {
        const grantStmt = tx.prepare(`
          INSERT OR REPLACE INTO user_permissions (user_id, permission_id, is_granted)
          SELECT ?, id, 1 FROM permissions WHERE slug = ?
        `);
        for (const slug of permArray) {
          grantStmt.run(newUserId, slug);
        }
      }

      logAudit({
        userId: req.user!.id,
        action: 'create_employee_account',
        entityType: 'employees',
        entityId: newUserId,
        details: { name, email, jobTitle, department, roleSlug: targetRoleSlug, grantedPermissions: permArray },
        ipAddress: req.ip,
      });

      return { id: newUserId, name, email, phone, jobTitle, roleSlug: targetRoleSlug, permissions: permArray };
    });

    res.status(201).json({ employee: createdEmployee });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر إنشاء حساب الموظف' });
  }
});

// Edit Employee Information & Account Status (active, inactive, suspended)
apiRouter.put('/admin/employees/:id', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const empUserId = Number(req.params.id);
  const { name, email, phone, jobTitle, department, status } = req.body || {};

  if (empUserId === 1) {
    res.status(400).json({ error: 'لا يمكن تعديل حساب المدير العام من قسم الموظفين' });
    return;
  }

  try {
    runInTransaction((tx) => {
      const emp = tx.prepare(`SELECT id, email FROM users WHERE id = ?`).get(empUserId) as { id: number; email: string } | undefined;
      if (!emp) throw new Error('حساب الموظف غير موجود');

      if (email && String(email).trim().toLowerCase() !== String(emp.email).toLowerCase()) {
        const dup = tx.prepare(`SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id != ?`).get(String(email).trim(), empUserId);
        if (dup) throw new Error('البريد الإلكتروني مستخدم لحساب آخر');
      }

      const nextStatus = status && ['active', 'inactive', 'suspended'].includes(String(status)) ? String(status) : undefined;

      tx.prepare(`
        UPDATE users
        SET name = COALESCE(?, name),
            email = COALESCE(?, email),
            phone = COALESCE(?, phone),
            status = COALESCE(?, status),
            updated_at = datetime('now')
        WHERE id = ?
      `).run(
        name ? String(name).trim() : null,
        email ? String(email).trim().toLowerCase() : null,
        phone ? String(phone).trim() : null,
        nextStatus || null,
        empUserId
      );

      const hasProfile = tx.prepare(`SELECT id FROM employee_profiles WHERE user_id = ?`).get(empUserId);
      if (hasProfile) {
        tx.prepare(`
          UPDATE employee_profiles
          SET job_title = COALESCE(?, job_title),
               department = COALESCE(?, department),
               is_active = CASE WHEN ? = 'active' THEN 1 WHEN ? IN ('inactive', 'suspended') THEN 0 ELSE is_active END,
               updated_at = datetime('now')
          WHERE user_id = ?
        `).run(
          jobTitle ? String(jobTitle).trim() : null,
          department ? String(department).trim() : null,
          nextStatus || null,
          nextStatus || null,
          empUserId
        );
      } else {
        tx.prepare(`
          INSERT INTO employee_profiles (user_id, owner_id, job_title, department, hire_date, is_active)
          VALUES (?, ?, ?, ?, date('now'), 1)
        `).run(empUserId, req.user!.id, String(jobTitle || 'موظف تشغيل').trim(), String(department || 'إدارة العمليات').trim());
      }

      logAudit({
        userId: req.user!.id,
        action: 'update_employee_account',
        entityType: 'employees',
        entityId: empUserId,
        details: { empUserId, name, email, phone, jobTitle, department, status: nextStatus },
        ipAddress: req.ip,
      });
    });

    res.json({ success: true });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر تحديث بيانات الموظف' });
  }
});

// Reset Employee Password Securely
apiRouter.post('/admin/employees/:id/password', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const empUserId = Number(req.params.id);
  const { newPassword } = req.body || {};
  if (!newPassword || String(newPassword).length < 8) {
    res.status(400).json({ error: 'يجب ألا تقل كلمة المرور الجديدة عن 8 أحرف' });
    return;
  }

  const db = getDb();
  const hash = hashPassword(String(newPassword));
  db.prepare(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`).run(hash, empUserId);

  logAudit({
    userId: req.user!.id,
    action: 'reset_employee_password',
    entityType: 'employees',
    entityId: empUserId,
    details: { empUserId, resetByGeneralManager: req.user!.id },
    ipAddress: req.ip,
  });

  res.json({ success: true });
});

// Modify or Immediately Revoke Employee Granular Permissions
const handleUpdateEmployeePermissions = (req: AuthenticatedRequest, res: Response) => {
  const empUserId = Number(req.params.id);
  const { permissions } = req.body || {};
  if (!Array.isArray(permissions)) {
    res.status(400).json({ error: 'يرجى تمرير مصفوفة الصلاحيات (permissions)' });
    return;
  }

  const permSlugs = permissions.map(String);

  runInTransaction((tx) => {
    tx.prepare(`DELETE FROM user_permissions WHERE user_id = ?`).run(empUserId);
    if (permSlugs.length > 0) {
      const insertStmt = tx.prepare(`
        INSERT INTO user_permissions (user_id, permission_id, is_granted)
        SELECT ?, id, 1 FROM permissions WHERE slug = ?
      `);
      for (const slug of permSlugs) {
        insertStmt.run(empUserId, slug);
      }
    }

    logAudit({
      userId: req.user!.id,
      action: permSlugs.length === 0 ? 'revoke_all_employee_permissions' : 'update_employee_permissions',
      entityType: 'employees',
      entityId: empUserId,
      details: { empUserId, grantedPermissions: permSlugs, count: permSlugs.length },
      ipAddress: req.ip,
    });
  });

  res.json({ success: true, permissions: permSlugs });
};

apiRouter.post('/admin/employees/:id/permissions', requireAuth, requireRole(['super_admin']), handleUpdateEmployeePermissions);
apiRouter.put('/admin/employees/:id/permissions', requireAuth, requireRole(['super_admin']), handleUpdateEmployeePermissions);

apiRouter.post('/admin/employees/:id/revoke-permissions', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const empUserId = Number(req.params.id);
  runInTransaction((tx) => {
    tx.prepare(`DELETE FROM user_permissions WHERE user_id = ?`).run(empUserId);
    logAudit({
      userId: req.user!.id,
      action: 'revoke_all_employee_permissions',
      entityType: 'employees',
      entityId: empUserId,
      details: { empUserId, grantedPermissions: [], count: 0 },
      ipAddress: req.ip,
    });
  });
  res.json({ success: true, permissions: [] });
});

// ============================================================================
// 9. PERMISSION-PROTECTED OPERATIONAL MODULES (General Manager + Authorized Staff)
// ============================================================================

// Admin Module: Hall Approval, Rejection, Suspension & Reactivation
const handleHallModerate = (req: AuthenticatedRequest, res: Response) => {
  const hallId = Number(req.params.id);
  const { status: rawStatus, rejectionReason, featured } = req.body || {};
  const status = rawStatus === 'approved' ? 'active' : rawStatus;

  if (status && !['active', 'rejected', 'pending', 'suspended'].includes(String(status))) {
    res.status(400).json({ error: 'حالة القاعة غير صالحة' });
    return;
  }

  if ((status === 'active' || status === 'rejected') && !hasPermission(req.user, ['halls.approve_reject', 'halls.suspend_reactivate'])) {
    res.status(403).json({ error: 'ليس لديك صلاحية اعتماد أو رفض القاعات (halls.approve_reject)' });
    return;
  }

  if (status === 'suspended' && !hasPermission(req.user, ['halls.suspend_reactivate'])) {
    res.status(403).json({ error: 'ليس لديك صلاحية تعليق القاعات (halls.suspend_reactivate)' });
    return;
  }

  if (status === 'rejected' && !String(rejectionReason || '').trim()) {
    res.status(400).json({ error: 'يجب ذكر سبب الرفض عند رفض إدراج القاعة' });
    return;
  }

  const db = getDb();
  const hall = db.prepare(`SELECT * FROM halls WHERE id = ?`).get(hallId) as Record<string, unknown> | undefined;
  if (!hall) {
    res.status(404).json({ error: 'القاعة غير موجودة' });
    return;
  }

  const nextStatus = status ? String(status) : String(hall.status);
  const nextFeatured = featured !== undefined ? (featured ? 1 : 0) : Number(hall.featured);
  const reason = status === 'rejected' ? String(rejectionReason).trim() : null;

  db.prepare(`
    UPDATE halls
    SET status = ?, rejection_reason = ?, featured = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(nextStatus, reason, nextFeatured, hallId);

  db.prepare(`
    INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
    VALUES (?, ?, ?, ?, ?, 'system_alert', datetime('now'))
  `).run(
    Number(hall.owner_id),
    nextStatus === 'active' ? 'تم اعتماد قاعتكم رسمياً' : 'تحديث حالة مراجعة القاعة',
    nextStatus === 'active' ? 'Venue Approved & Published' : 'Venue Moderation Update',
    nextStatus === 'active'
      ? `تم اعتماد قاعتكم "${hall.name_ar}" وأصبحت الآن ظاهرة للجمهور في نتائج البحث.`
      : `تم تحديث حالة قاعتكم "${hall.name_ar}" إلى (${nextStatus}). ${reason ? `السبب: ${reason}` : ''}`,
    `Your venue "${hall.name_en || hall.name_ar}" status is now ${nextStatus}.`
  );

  logAudit({
    userId: req.user!.id,
    action: `moderate_hall_${nextStatus}`,
    entityType: 'halls',
    entityId: hallId,
    details: { hallName: hall.name_ar, oldStatus: hall.status, newStatus: nextStatus, rejectionReason: reason, featured: nextFeatured },
    ipAddress: req.ip,
  });

  res.json({ success: true });
};

apiRouter.post(
  '/admin/halls/:id/moderate',
  requireAuth,
  requirePermission(['halls.approve_reject', 'halls.suspend_reactivate', 'halls.edit']),
  handleHallModerate
);

apiRouter.post(
  '/admin/halls/:id/status',
  requireAuth,
  requirePermission(['halls.approve_reject', 'halls.suspend_reactivate', 'halls.edit']),
  handleHallModerate
);

// Admin Module: Delete Hall Listing (Subject to explicit halls.delete authorization)
apiRouter.delete(
  '/admin/halls/:id',
  requireAuth,
  requirePermission(['halls.delete']),
  (req: AuthenticatedRequest, res: Response) => {
    const hallId = Number(req.params.id);
    const db = getDb();
    const hall = db.prepare(`SELECT id, name_ar FROM halls WHERE id = ?`).get(hallId) as { id: number; name_ar: string } | undefined;
    if (!hall) {
      res.status(404).json({ error: 'القاعة غير موجودة' });
      return;
    }

    runInTransaction((tx) => {
      tx.prepare(`DELETE FROM hall_facilities WHERE hall_id = ?`).run(hallId);
      tx.prepare(`DELETE FROM hall_pricing WHERE hall_id = ?`).run(hallId);
      tx.prepare(`DELETE FROM hall_images WHERE hall_id = ?`).run(hallId);
      tx.prepare(`DELETE FROM hall_availability WHERE hall_id = ?`).run(hallId);
      tx.prepare(`DELETE FROM halls WHERE id = ?`).run(hallId);

      logAudit({
        userId: req.user!.id,
        action: 'delete_hall_listing',
        entityType: 'halls',
        entityId: hallId,
        details: { hallId, hallName: hall.name_ar },
        ipAddress: req.ip,
      });
    });

    res.json({ success: true });
  }
);

// Admin Module: Booking Management by General Manager or Authorized Employee
apiRouter.post(
  '/admin/bookings/:id/status',
  requireAuth,
  requirePermission(['bookings.confirm', 'bookings.reject', 'bookings.cancel', 'bookings.manage_conflicts']),
  (req: AuthenticatedRequest, res: Response) => {
    const bookingId = Number(req.params.id);
    const { status, comment } = req.body || {};
    if (!['confirmed', 'cancelled', 'completed'].includes(String(status))) {
      res.status(400).json({ error: 'حالة الحجز غير صالحة' });
      return;
    }

    if (status === 'confirmed' && !hasPermission(req.user, ['bookings.confirm', 'bookings.manage_conflicts'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية تأكيد الحجوزات (bookings.confirm)' });
      return;
    }
    if (status === 'cancelled' && !hasPermission(req.user, ['bookings.cancel', 'bookings.reject', 'bookings.manage_conflicts'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية إلغاء أو رفض الحجوزات (bookings.cancel)' });
      return;
    }

    try {
      runInTransaction((db) => {
        const targetBooking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(bookingId) as Record<string, unknown> | undefined;
        if (!targetBooking) throw new Error('الحجز غير موجود');

        const targetDaysCount = Math.max(1, Number(targetBooking.booked_days || 1));
        const targetDates = computeConsecutiveDates(String(targetBooking.event_date), targetDaysCount);

        if (status === 'confirmed') {
          const lockStmt = db.prepare(`
            INSERT OR REPLACE INTO hall_availability (hall_id, date, shift, status, booking_id, reason, updated_by, updated_at)
            VALUES (?, ?, ?, 'booked', ?, ?, ?, datetime('now'))
          `);
          for (const reqDate of targetDates) {
            lockStmt.run(
              Number(targetBooking.hall_id),
              reqDate,
              String(targetBooking.shift),
              bookingId,
              `حجز مؤكد إدارياً ${targetBooking.booking_code}`,
              req.user!.id
            );
          }
          db.prepare(`UPDATE booking_days SET status = 'confirmed' WHERE booking_id = ?`).run(bookingId);
        } else if (status === 'cancelled') {
          db.prepare(`DELETE FROM hall_availability WHERE booking_id = ?`).run(bookingId);
          db.prepare(`UPDATE booking_days SET status = 'cancelled' WHERE booking_id = ?`).run(bookingId);
        }

        db.prepare(`
          UPDATE bookings
          SET status = ?,
              confirmed_at = CASE WHEN ? = 'confirmed' THEN datetime('now') ELSE confirmed_at END,
              cancelled_at = CASE WHEN ? = 'cancelled' THEN datetime('now') ELSE cancelled_at END,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(String(status), String(status), String(status), bookingId);

        db.prepare(`
          INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, comment, created_at)
          VALUES (?, ?, ?, ?, ?, datetime('now'))
        `).run(bookingId, String(targetBooking.status), String(status), req.user!.id, String(comment || 'تحديث من إدارة المنصة'));

        logAudit({
          userId: req.user!.id,
          action: `admin_booking_${status}`,
          entityType: 'bookings',
          entityId: bookingId,
          details: { bookingCode: targetBooking.booking_code, newStatus: status, comment, dates: targetDates },
          ipAddress: req.ip,
        });
      });

      res.json({ success: true });
    } catch (err: unknown) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر تحديث حالة الحجز' });
    }
  }
);

// Admin Module: Suspend / Reactivate Account (Customers or Users)
apiRouter.post(
  '/admin/users/:id/status',
  requireAuth,
  requirePermission(['customers.suspend_reactivate']),
  (req: AuthenticatedRequest, res: Response) => {
    const targetUserId = Number(req.params.id);
    const { status } = req.body || {};

    if (targetUserId === req.user!.id || targetUserId === 1) {
      res.status(400).json({ error: 'لا يمكن تعليق حساب المدير العام أو الحساب الشخصي الحالي' });
      return;
    }
    if (!['active', 'suspended', 'inactive'].includes(String(status))) {
      res.status(400).json({ error: 'حالة الحساب غير صالحة' });
      return;
    }

    const db = getDb();
    const targetUser = db.prepare(`
      SELECT u.id, r.slug as role_slug FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?
    `).get(targetUserId) as { id: number; role_slug: string } | undefined;

    if (!targetUser) {
      res.status(404).json({ error: 'المستخدم غير موجود' });
      return;
    }

    // Non-super-admin employees with customers.suspend_reactivate may only suspend/reactivate customers!
    if (req.user!.role_slug !== 'super_admin' && targetUser.role_slug !== 'customer') {
      res.status(403).json({ error: 'صلاحياتك تقتصر على تعليق أو تفعيل حسابات العملاء فقط' });
      return;
    }

    db.prepare(`UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(String(status), targetUserId);

    logAudit({
      userId: req.user!.id,
      action: status === 'active' ? 'reactivate_user_account' : 'suspend_user_account',
      entityType: 'users',
      entityId: targetUserId,
      details: { targetUserId, targetRole: targetUser.role_slug, newStatus: status },
      ipAddress: req.ip,
    });

    res.json({ success: true });
  }
);

// Admin Module: Verify, Reject, or Request Additional Documents for Hall Owner Verification
apiRouter.post(
  '/admin/owners/:userId/verify',
  requireAuth,
  requirePermission(['owners.approve_reject', 'owners.request_documents']),
  (req: AuthenticatedRequest, res: Response) => {
    const ownerUserId = Number(req.params.userId);
    const { verified, action, rejectionReason } = req.body || {};
    const db = getDb();

    let nextStatus = verified ? 'verified' : 'rejected';
    let isVerifiedInt = verified ? 1 : 0;
    if (action === 'request_documents') {
      if (!hasPermission(req.user, ['owners.request_documents', 'owners.approve_reject'])) {
        res.status(403).json({ error: 'ليس لديك صلاحية طلب مستندات إضافية' });
        return;
      }
      nextStatus = 'additional_documents_requested';
      isVerifiedInt = 0;
    } else if (!hasPermission(req.user, ['owners.approve_reject'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية اعتماد أو رفض توثيق الملاك (owners.approve_reject)' });
      return;
    }

    const noteText = verified ? null : String(rejectionReason || 'يرجى إرفاق صورة واضحة من السجل التجاري الساري ووثيقة ملكية القاعة').trim();

    db.prepare(`
      UPDATE owner_profiles
      SET is_verified = ?,
          verification_status = ?,
          verification_rejection_reason = ?,
          verified_at = datetime('now'),
          verified_by = ?,
          updated_at = datetime('now')
      WHERE user_id = ?
    `).run(isVerifiedInt, nextStatus, noteText, req.user!.id, ownerUserId);

    db.prepare(`
      INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
      VALUES (?, ?, ?, ?, ?, 'system_alert', datetime('now'))
    `).run(
      ownerUserId,
      isVerifiedInt ? 'تم توثيق السجل التجاري بنجاح' : 'تحديث بخصوص طلب توثيق المنشأة',
      isVerifiedInt ? 'Owner Account Verified' : 'Verification Application Update',
      isVerifiedInt
        ? 'تم اعتماد وثائق الملكية والسجل التجاري لحسابكم في منصة مناسبتي.'
        : `حالة طلب التوثيق: (${nextStatus}). ${noteText || ''}`,
      `Your owner verification status is now: ${nextStatus}.`
    );

    logAudit({
      userId: req.user!.id,
      action: isVerifiedInt ? 'verify_hall_owner' : action === 'request_documents' ? 'request_owner_documents' : 'revoke_hall_owner_verification',
      entityType: 'owner_profiles',
      entityId: ownerUserId,
      details: { ownerUserId, verified: Boolean(isVerifiedInt), verificationStatus: nextStatus, rejectionReason: noteText },
      ipAddress: req.ip,
    });

    res.json({ success: true, verificationStatus: nextStatus });
  }
);

// Admin Module: Create Authorized Staff / Support Agent / Hall Owner Account (General Manager Only)
apiRouter.post('/admin/users/create', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const { name, email, phone, password, roleSlug, businessName, jobTitle, department, permissions } = req.body || {};
  if (!name || !email || !phone || !password || !roleSlug) {
    res.status(400).json({ error: 'يرجى تعبئة كافة بيانات الحساب والدور الوظيفي' });
    return;
  }

  const db = getDb();
  const role = db.prepare(`SELECT id, slug FROM roles WHERE slug = ?`).get(String(roleSlug)) as { id: number; slug: string } | undefined;
  if (!role || role.slug === 'super_admin') {
    res.status(400).json({ error: 'الدور الوظيفي المحدد غير صالح' });
    return;
  }

  try {
    const newId = runInTransaction((tx) => {
      const exists = tx.prepare(`SELECT id FROM users WHERE LOWER(email) = LOWER(?)`).get(String(email).trim());
      if (exists) throw new Error('البريد الإلكتروني مستخدم بالفعل');

      const hash = hashPassword(String(password));
      const info = tx.prepare(`
        INSERT INTO users (role_id, name, email, phone, password_hash, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', datetime('now'), datetime('now'))
      `).run(role.id, String(name).trim(), String(email).trim().toLowerCase(), String(phone).trim(), hash);

      const userId = Number(info.lastInsertRowid);
      if (role.slug === 'hall_owner') {
        tx.prepare(`
          INSERT INTO owner_profiles (user_id, business_name, commercial_registration_no, is_verified, verified_by, verified_at)
          VALUES (?, ?, 'CR-ADMIN-VERIFIED', 1, ?, datetime('now'))
        `).run(userId, String(businessName || name).trim(), req.user!.id);
      } else if (role.slug === 'employee' || role.slug === 'support_agent') {
        tx.prepare(`
          INSERT INTO employee_profiles (user_id, owner_id, job_title, department, hire_date, is_active)
          VALUES (?, ?, ?, ?, date('now'), 1)
        `).run(
          userId,
          req.user!.id,
          String(jobTitle || (role.slug === 'support_agent' ? 'أخصائي دعم العملاء' : 'موظف العمليات والحجوزات')).trim(),
          String(department || 'إدارة التشغيل').trim()
        );

        const permList: string[] = Array.isArray(permissions) ? permissions.map(String) : [];
        if (permList.length > 0) {
          const permStmt = tx.prepare(`
            INSERT OR REPLACE INTO user_permissions (user_id, permission_id, is_granted)
            SELECT ?, id, 1 FROM permissions WHERE slug = ?
          `);
          for (const slug of permList) {
            permStmt.run(userId, slug);
          }
        }
      }

      logAudit({
        userId: req.user!.id,
        action: 'admin_create_user',
        entityType: 'users',
        entityId: userId,
        details: { email, roleSlug: role.slug, name, jobTitle },
        ipAddress: req.ip,
      });

      return userId;
    });

    res.status(201).json({ userId: newId });
  } catch (err: unknown) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر إنشاء الحساب' });
  }
});

// Admin Module: Verify or Refund Payment Record
apiRouter.post(
  '/admin/payments/:id/verify',
  requireAuth,
  requirePermission(['finance.verify_payments', 'finance.manage_refunds']),
  (req: AuthenticatedRequest, res: Response) => {
    const paymentId = Number(req.params.id);
    const { status } = req.body || {};
    if (!['verified', 'refunded', 'rejected'].includes(String(status))) {
      res.status(400).json({ error: 'حالة الدفعة المالية غير صالحة' });
      return;
    }

    if (status === 'verified' && !hasPermission(req.user, ['finance.verify_payments'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية توثيق الدفعات (finance.verify_payments)' });
      return;
    }
    if (status === 'refunded' && !hasPermission(req.user, ['finance.manage_refunds'])) {
      res.status(403).json({ error: 'ليس لديك صلاحية إصدار المرتجعات المالية (finance.manage_refunds)' });
      return;
    }

    runInTransaction((db) => {
      const payment = db.prepare(`SELECT * FROM payment_records WHERE id = ?`).get(paymentId) as Record<string, unknown> | undefined;
      if (!payment) throw new Error('سجل الدفعة غير موجود');

      db.prepare(`
        UPDATE payment_records
        SET status = ?, verified_by = ?, verified_at = datetime('now')
        WHERE id = ?
      `).run(String(status), req.user!.id, paymentId);

      if (payment.booking_id) {
        const nextPayStatus = status === 'verified' ? 'deposit_paid' : status === 'refunded' ? 'refunded' : 'unpaid';
        db.prepare(`
          UPDATE bookings
          SET payment_status = ?,
              status = CASE WHEN ? = 'verified' AND status = 'pending' THEN 'confirmed' ELSE status END,
              updated_at = datetime('now')
          WHERE id = ?
        `).run(nextPayStatus, String(status), Number(payment.booking_id));
      }

      logAudit({
        userId: req.user!.id,
        action: `payment_${status}`,
        entityType: 'payment_records',
        entityId: paymentId,
        details: { paymentReference: payment.payment_reference, amount: payment.amount, newStatus: status },
        ipAddress: req.ip,
      });
    });

    res.json({ success: true });
  }
);

// Admin Module: Review Moderation
apiRouter.post(
  '/admin/reviews/:id/status',
  requireAuth,
  requirePermission(['content.moderate_reviews']),
  (req: AuthenticatedRequest, res: Response) => {
    const reviewId = Number(req.params.id);
    const { status } = req.body || {};
    const db = getDb();
    db.prepare(`UPDATE reviews SET status = ? WHERE id = ?`).run(String(status), reviewId);

    logAudit({
      userId: req.user!.id,
      action: `moderate_review_${status}`,
      entityType: 'reviews',
      entityId: reviewId,
      details: { reviewId, status },
      ipAddress: req.ip,
    });

    res.json({ success: true });
  }
);

// Admin Module: Update Platform Settings (General Manager Only)
apiRouter.post('/admin/settings', requireAuth, requireRole(['super_admin']), (req: AuthenticatedRequest, res: Response) => {
  const { settings } = req.body || {};
  if (!settings || typeof settings !== 'object') {
    res.status(400).json({ error: 'بيانات الإعدادات غير صالحة' });
    return;
  }

  runInTransaction((db) => {
    const stmt = db.prepare(`
      UPDATE platform_settings
      SET setting_value = ?, updated_by = ?, updated_at = datetime('now')
      WHERE setting_key = ?
    `);
    for (const [key, val] of Object.entries(settings)) {
      stmt.run(String(val), req.user!.id, key);
    }

    logAudit({
      userId: req.user!.id,
      action: 'update_platform_settings',
      entityType: 'platform_settings',
      details: { updatedKeys: Object.keys(settings) },
      ipAddress: req.ip,
    });
  });

  res.json({ success: true });
});

// Admin Module: Broadcast Notification
apiRouter.post(
  '/admin/notifications/broadcast',
  requireAuth,
  requirePermission(['content.send_notifications']),
  (req: AuthenticatedRequest, res: Response) => {
    const { targetRole, titleAr, titleEn, messageAr, messageEn } = req.body || {};
    if (!titleAr || !messageAr) {
      res.status(400).json({ error: 'يرجى إدخال عنوان ونص الإشعار' });
      return;
    }

    const db = getDb();
    const users = targetRole && targetRole !== 'all'
      ? db.prepare(`SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.slug = ? AND u.status = 'active'`).all(String(targetRole)) as Array<{ id: number }>
      : db.prepare(`SELECT id FROM users WHERE status = 'active'`).all() as Array<{ id: number }>;

    const insertStmt = db.prepare(`
      INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, created_at)
      VALUES (?, ?, ?, ?, ?, 'system_alert', datetime('now'))
    `);

    for (const u of users) {
      insertStmt.run(u.id, String(titleAr).trim(), String(titleEn || titleAr).trim(), String(messageAr).trim(), String(messageEn || messageAr).trim());
    }

    logAudit({
      userId: req.user!.id,
      action: 'broadcast_notification',
      entityType: 'notifications',
      entityId: null,
      details: { targetRole: targetRole || 'all', recipientCount: users.length, titleAr },
      ipAddress: req.ip,
    });

    res.json({ success: true, recipientCount: users.length });
  }
);
