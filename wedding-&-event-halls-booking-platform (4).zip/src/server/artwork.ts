/**
 * High-Craft Architectural SVG Scene Renderer for Munasabati Venues
 * Guarantees 100% self-contained, zero-broken-image luxury hospitality visuals
 */

export function renderVenueArtworkSvg(scene: string): string {
  const key = scene.toLowerCase();

  if (key.includes('aden') || key.includes('coastal') || key.includes('sea')) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" width="1200" height="900">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#071B24"/>
          <stop offset="55%" stop-color="#0E3846"/>
          <stop offset="100%" stop-color="#C5A059"/>
        </linearGradient>
        <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#0A2E38"/>
          <stop offset="100%" stop-color="#04151B"/>
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#F3E5AB"/>
          <stop offset="50%" stop-color="#C5A059"/>
          <stop offset="100%" stop-color="#8A6B2F"/>
        </linearGradient>
        <radialGradient id="glow" cx="50%" cy="30%" r="45%">
          <stop offset="0%" stop-color="#FFE8B3" stop-opacity="0.55"/>
          <stop offset="100%" stop-color="#071B24" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <rect width="1200" height="900" fill="url(#sky)"/>
      <circle cx="600" cy="270" r="420" fill="url(#glow)"/>
      <!-- Ocean Horizon -->
      <rect x="0" y="470" width="1200" height="200" fill="url(#sea)"/>
      <!-- Shimmering sea reflections -->
      <g opacity="0.45" fill="#F3E5AB">
        <rect x="480" y="485" width="240" height="3" rx="1.5"/>
        <rect x="510" y="500" width="180" height="2.5" rx="1.2"/>
        <rect x="460" y="518" width="280" height="2" rx="1"/>
        <rect x="530" y="536" width="140" height="2" rx="1"/>
      </g>
      <!-- Panoramic Coastal Ballroom Arches -->
      <path d="M0,0 L1200,0 L1200,900 L0,900 Z" fill="none"/>
      <path d="M0,640 L1200,640 L1200,900 L0,900 Z" fill="#13231E"/>
      <path d="M80,640 L1120,640 L1200,900 L0,900 Z" fill="#FAF8F5" opacity="0.07"/>
      <!-- Architectural Columns & Arches -->
      <g stroke="url(#gold)" stroke-width="4" fill="#081C16" fill-opacity="0.82">
        <path d="M0,0 L1200,0 L1200,130 L0,130 Z"/>
        <rect x="70" y="120" width="44" height="520"/>
        <rect x="380" y="120" width="36" height="520"/>
        <rect x="784" y="120" width="36" height="520"/>
        <rect x="1086" y="120" width="44" height="520"/>
        <path d="M114,260 Q247,110 380,260 L380,120 L114,120 Z"/>
        <path d="M416,240 Q600,70 784,240 L784,120 L416,120 Z"/>
        <path d="M820,260 Q953,110 1086,260 L1086,120 L820,120 Z"/>
      </g>
      <!-- Grand Pearl Chandelier -->
      <g transform="translate(600, 125)">
        <line x1="0" y1="0" x2="0" y2="55" stroke="url(#gold)" stroke-width="3"/>
        <ellipse cx="0" cy="65" rx="95" ry="18" fill="none" stroke="url(#gold)" stroke-width="3"/>
        <ellipse cx="0" cy="92" rx="68" ry="13" fill="none" stroke="url(#gold)" stroke-width="2.5"/>
        <ellipse cx="0" cy="116" rx="40" ry="9" fill="none" stroke="url(#gold)" stroke-width="2"/>
        <circle cx="-75" cy="65" r="5" fill="#FFF7D6"/>
        <circle cx="-35" cy="75" r="5" fill="#FFF7D6"/>
        <circle cx="0" cy="78" r="6" fill="#FFF7D6"/>
        <circle cx="35" cy="75" r="5" fill="#FFF7D6"/>
        <circle cx="75" cy="65" r="5" fill="#FFF7D6"/>
        <circle cx="0" cy="132" r="8" fill="#FFF7D6"/>
      </g>
      <!-- Luxury Banquet Tables -->
      <g transform="translate(0, 20)">
        <ellipse cx="260" cy="735" rx="125" ry="42" fill="#F4EFEA" stroke="url(#gold)" stroke-width="3"/>
        <ellipse cx="600" cy="760" rx="155" ry="50" fill="#FAF8F5" stroke="url(#gold)" stroke-width="4"/>
        <ellipse cx="940" cy="735" rx="125" ry="42" fill="#F4EFEA" stroke="url(#gold)" stroke-width="3"/>
        <circle cx="600" cy="742" r="24" fill="#0B3B2B" stroke="url(#gold)" stroke-width="2"/>
        <circle cx="600" cy="736" r="14" fill="#FAF8F5"/>
      </g>
    </svg>`;
  }

  if (key.includes('ibb') || key.includes('princess') || key.includes('garden')) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" width="1200" height="900">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#072218"/>
          <stop offset="60%" stop-color="#0F3D2C"/>
          <stop offset="100%" stop-color="#192821"/>
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#F6E8B8"/>
          <stop offset="50%" stop-color="#C5A059"/>
          <stop offset="100%" stop-color="#8B6928"/>
        </linearGradient>
        <radialGradient id="sun" cx="50%" cy="35%" r="50%">
          <stop offset="0%" stop-color="#FFF2CC" stop-opacity="0.48"/>
          <stop offset="100%" stop-color="#072218" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <rect width="1200" height="900" fill="url(#bg)"/>
      <circle cx="600" cy="320" r="460" fill="url(#sun)"/>
      <!-- Highland Terraces -->
      <path d="M0,520 Q320,430 640,500 T1200,460 L1200,660 L0,660 Z" fill="#0A2E20" opacity="0.8"/>
      <path d="M0,580 Q400,510 820,570 T1200,530 L1200,680 L0,680 Z" fill="#061D14"/>
      <!-- Botanical Glasshouse Pavilion Structure -->
      <g stroke="url(#gold)" stroke-width="3.5" fill="none">
        <path d="M140,650 L140,250 L600,90 L1060,250 L1060,650"/>
        <line x1="600" y1="90" x2="600" y2="650"/>
        <line x1="370" y1="170" x2="370" y2="650"/>
        <line x1="830" y1="170" x2="830" y2="650"/>
        <path d="M140,250 L1060,250"/>
      </g>
      <!-- Travertine Courtyard Floor -->
      <polygon points="0,900 1200,900 1060,650 140,650" fill="#EAE2D6"/>
      <polygon points="430,900 770,900 690,650 510,650" fill="#FAF8F5" stroke="url(#gold)" stroke-width="3"/>
      <!-- Floral Bridal Gazebo -->
      <g transform="translate(600, 490)">
        <path d="M-130,160 L-130,-40 Q0,-150 130,-40 L130,160" fill="#FAF8F5" fill-opacity="0.14" stroke="url(#gold)" stroke-width="5"/>
        <!-- White Orchid & Jasmine Garland -->
        <g fill="#FAF8F5">
          <circle cx="-110" cy="-35" r="18"/>
          <circle cx="-80" cy="-65" r="22"/>
          <circle cx="-40" cy="-88" r="24"/>
          <circle cx="0" cy="-96" r="26"/>
          <circle cx="40" cy="-88" r="24"/>
          <circle cx="80" cy="-65" r="22"/>
          <circle cx="110" cy="-35" r="18"/>
        </g>
        <!-- Royal Sofa -->
        <rect x="-75" y="95" width="150" height="45" rx="14" fill="#FAF8F5" stroke="url(#gold)" stroke-width="3"/>
        <rect x="-90" y="120" width="180" height="28" rx="6" fill="#C5A059"/>
      </g>
    </svg>`;
  }

  if (key.includes('narjis') || key.includes('taiz') || key.includes('conference')) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" width="1200" height="900">
      <defs>
        <linearGradient id="wall" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#0D1F1A"/>
          <stop offset="100%" stop-color="#1A332B"/>
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#F7E9BE"/>
          <stop offset="50%" stop-color="#C5A059"/>
          <stop offset="100%" stop-color="#876627"/>
        </linearGradient>
      </defs>
      <rect width="1200" height="900" fill="url(#wall)"/>
      <!-- Coffered Ceiling Grid -->
      <polygon points="0,0 1200,0 980,220 220,220" fill="#071410" stroke="url(#gold)" stroke-width="2"/>
      <!-- Geometric Brass Wall Panels -->
      <g stroke="url(#gold)" stroke-width="2" fill="#0B2920" opacity="0.9">
        <rect x="240" y="240" width="160" height="360" rx="8"/>
        <rect x="420" y="240" width="360" height="360" rx="8"/>
        <rect x="800" y="240" width="160" height="360" rx="8"/>
      </g>
      <!-- Crystal Ring Chandeliers -->
      <g stroke="url(#gold)" stroke-width="4" fill="none">
        <ellipse cx="600" cy="145" rx="170" ry="28"/>
        <ellipse cx="600" cy="180" rx="115" ry="20"/>
        <ellipse cx="600" cy="208" rx="60" ry="11"/>
      </g>
      <!-- Marble Floor -->
      <polygon points="0,900 1200,900 980,620 220,620" fill="#F2ECE1"/>
      <polygon points="360,900 840,900 730,620 470,620" fill="#0B3B2B" stroke="url(#gold)" stroke-width="3"/>
      <!-- Stage Platform -->
      <rect x="390" y="535" width="420" height="85" rx="8" fill="#FAF8F5" stroke="url(#gold)" stroke-width="4"/>
      <path d="M470,535 Q600,320 730,535 Z" fill="#FAF8F5" fill-opacity="0.15" stroke="url(#gold)" stroke-width="3"/>
      <rect x="515" y="475" width="170" height="58" rx="12" fill="#FAF8F5" stroke="url(#gold)" stroke-width="3"/>
    </svg>`;
  }

  if (key.includes('andalus') || key.includes('heritage') || key.includes('bridal') || key.includes('suite')) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" width="1200" height="900">
      <defs>
        <linearGradient id="andalusBg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#142921"/>
          <stop offset="60%" stop-color="#0B3B2B"/>
          <stop offset="100%" stop-color="#071D15"/>
        </linearGradient>
        <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#F9ECC3"/>
          <stop offset="50%" stop-color="#C5A059"/>
          <stop offset="100%" stop-color="#8A6829"/>
        </linearGradient>
        <radialGradient id="warmGlow" cx="50%" cy="40%" r="45%">
          <stop offset="0%" stop-color="#FFF0C2" stop-opacity="0.52"/>
          <stop offset="100%" stop-color="#071D15" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <rect width="1200" height="900" fill="url(#andalusBg)"/>
      <circle cx="600" cy="360" r="480" fill="url(#warmGlow)"/>
      <!-- Travertine & Gold Inlay Floor -->
      <polygon points="0,900 1200,900 1020,620 180,620" fill="#F5F0E6"/>
      <polygon points="450,900 750,900 680,620 520,620" fill="#FAF8F5" stroke="url(#gold)" stroke-width="3.5"/>
      <!-- Carved Stucco Arches & Qamariya Stained Glass -->
      <g stroke="url(#gold)" stroke-width="3.5" fill="#FAF8F5" fill-opacity="0.09">
        <path d="M180,620 L180,290 A120,120 0 0,1 420,290 L420,620 Z"/>
        <path d="M440,620 L440,250 A160,160 0 0,1 760,250 L760,620 Z"/>
        <path d="M780,620 L780,290 A120,120 0 0,1 1020,290 L1020,620 Z"/>
      </g>
      <circle cx="300" cy="270" r="55" fill="#C5A059" fill-opacity="0.22" stroke="url(#gold)" stroke-width="3"/>
      <circle cx="600" cy="230" r="75" fill="#C5A059" fill-opacity="0.28" stroke="url(#gold)" stroke-width="3.5"/>
      <circle cx="900" cy="270" r="55" fill="#C5A059" fill-opacity="0.22" stroke="url(#gold)" stroke-width="3"/>
      <!-- Royal Bridal Lounge & Moroccan Brass Lanterns -->
      <line x1="300" y1="0" x2="300" y2="130" stroke="url(#gold)" stroke-width="2.5"/>
      <polygon points="282,130 318,130 310,175 290,175" fill="#FFF3C4" stroke="url(#gold)" stroke-width="2"/>
      <line x1="900" y1="0" x2="900" y2="130" stroke="url(#gold)" stroke-width="2.5"/>
      <polygon points="882,130 918,130 910,175 890,175" fill="#FFF3C4" stroke="url(#gold)" stroke-width="2"/>
      <rect x="460" y="545" width="280" height="75" rx="14" fill="#FAF8F5" stroke="url(#gold)" stroke-width="4"/>
      <rect x="440" y="595" width="320" height="32" rx="6" fill="url(#gold)"/>
    </svg>`;
  }

  // Default: Grand Royal Andalusian Palace (Taj Sana'a / Hero Munasabati Palace)
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900" width="1200" height="900">
    <defs>
      <linearGradient id="emeraldBg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#061913"/>
        <stop offset="55%" stop-color="#0B3B2B"/>
        <stop offset="100%" stop-color="#082219"/>
      </linearGradient>
      <linearGradient id="ivoryFloor" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#EAE3D5"/>
        <stop offset="100%" stop-color="#FAF8F5"/>
      </linearGradient>
      <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#F7E9B7"/>
        <stop offset="50%" stop-color="#C5A059"/>
        <stop offset="100%" stop-color="#8A6829"/>
      </linearGradient>
      <radialGradient id="stageGlow" cx="50%" cy="42%" r="48%">
        <stop offset="0%" stop-color="#FFE7AE" stop-opacity="0.5"/>
        <stop offset="100%" stop-color="#061913" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="1200" height="900" fill="url(#emeraldBg)"/>
    <circle cx="600" cy="380" r="520" fill="url(#stageGlow)"/>

    <!-- Polished Ivory & Gold Marble Floor -->
    <polygon points="0,900 1200,900 1000,630 200,630" fill="url(#ivoryFloor)"/>
    <polygon points="390,900 810,900 710,630 490,630" fill="#0B3B2B" stroke="url(#gold)" stroke-width="4"/>

    <!-- Andalusian Horseshoe Arches -->
    <g stroke="url(#gold)" stroke-width="3.5" fill="#FAF8F5" fill-opacity="0.06">
      <path d="M120,630 L120,310 A110,110 0 1,1 340,310 L340,630 Z"/>
      <path d="M860,630 L860,310 A110,110 0 1,1 1080,310 L1080,630 Z"/>
    </g>
    <path d="M370,630 L370,280 A230,220 0 1,1 830,280 L830,630 Z" fill="#FAF8F5" fill-opacity="0.11" stroke="url(#gold)" stroke-width="5"/>

    <!-- Grand Royal Kosha (Bridal Stage) -->
    <rect x="330" y="565" width="540" height="68" rx="8" fill="#FAF8F5" stroke="url(#gold)" stroke-width="4"/>
    <rect x="365" y="590" width="470" height="43" rx="4" fill="#EFE7D8" stroke="url(#gold)" stroke-width="2"/>

    <!-- White Rose Floral Arch & Royal Divan -->
    <g transform="translate(600, 465)">
      <path d="M-150,100 L-150,-30 A150,140 0 0,1 150,-30 L150,100" fill="none" stroke="#FAF8F5" stroke-width="26" stroke-linecap="round" opacity="0.92"/>
      <path d="M-150,100 L-150,-30 A150,140 0 0,1 150,-30 L150,100" fill="none" stroke="url(#gold)" stroke-width="4" stroke-dasharray="10 8"/>
      <rect x="-95" y="25" width="190" height="56" rx="18" fill="#FAF8F5" stroke="url(#gold)" stroke-width="3.5"/>
      <rect x="-110" y="65" width="220" height="32" rx="6" fill="url(#gold)"/>
    </g>

    <!-- Imperial Crystal Chandelier -->
    <g transform="translate(600, 0)">
      <line x1="0" y1="0" x2="0" y2="70" stroke="url(#gold)" stroke-width="4"/>
      <ellipse cx="0" cy="85" rx="130" ry="22" fill="none" stroke="url(#gold)" stroke-width="4"/>
      <ellipse cx="0" cy="118" rx="92" ry="16" fill="none" stroke="url(#gold)" stroke-width="3"/>
      <ellipse cx="0" cy="146" rx="54" ry="10" fill="none" stroke="url(#gold)" stroke-width="2.5"/>
      <g fill="#FFF9E2">
        <circle cx="-110" cy="85" r="6"/>
        <circle cx="-65" cy="98" r="6"/>
        <circle cx="0" cy="102" r="7"/>
        <circle cx="65" cy="98" r="6"/>
        <circle cx="110" cy="85" r="6"/>
        <circle cx="-70" cy="122" r="5"/>
        <circle cx="0" cy="130" r="6"/>
        <circle cx="70" cy="122" r="5"/>
        <circle cx="0" cy="168" r="9"/>
      </g>
    </g>
  </svg>`;
}
