<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Reset Password Execution
 */

$page_title = 'تعيين كلمة المرور الجديدة';
require_once __DIR__ . '/includes/auth.php';

if (Auth::check()) {
    redirect(Auth::isSuperAdmin() ? (BASE_URL . '/admin/index.php') : (BASE_URL . '/dashboard.php'));
}

$token = sanitize(get('token', post('token', '')));
$errorMessage = null;
$validReset = null;

if (empty($token)) {
    $errorMessage = Lang::isRtl() ? 'رمز استعادة كلمة المرور مفقود أو غير صالح.' : 'Password reset token is missing or invalid.';
} else {
    // Verify token
    try {
        $validReset = Database::fetchOne("
            SELECT * FROM password_resets 
            WHERE token = ? AND used = 0 AND expires_at >= CURRENT_TIMESTAMP 
            LIMIT 1
        ", [$token]);

        if (!$validReset) {
            $errorMessage = Lang::isRtl() 
                ? 'رابط الاستعادة منتهي الصلاحية أو تم استخدامه سابقاً. يرجى طلب رابط جديد.' 
                : 'Reset link has expired or has already been used. Please request a new one.';
        }
    } catch (Exception $e) {
        $errorMessage = Lang::isRtl() ? 'حدث خطأ أثناء التحقق من الرمز.' : 'Error verifying reset token.';
    }
}

if (isPost() && $validReset) {
    CSRF::verifyOrDie();
    $password = post('password', '');
    $passwordConfirm = post('password_confirm', '');

    if (empty($password) || empty($passwordConfirm)) {
        $errorMessage = Lang::isRtl() ? 'يرجى إدخال كلمة المرور وتأكيدها.' : 'Please enter and confirm your new password.';
    } elseif (strlen($password) < 8) {
        $errorMessage = Lang::isRtl() ? 'يجب ألا تقل كلمة المرور عن 8 أحرف وأرقام لضمان الأمان.' : 'Password must be at least 8 characters.';
    } elseif ($password !== $passwordConfirm) {
        $errorMessage = Lang::isRtl() ? 'كلمتا المرور غير متطابقتين.' : 'Passwords do not match.';
    } else {
        try {
            $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            // Update user password
            Database::query("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE email = ?", [
                $passwordHash,
                $validReset['email']
            ]);

            // Invalidate token
            Database::query("UPDATE password_resets SET used = 1 WHERE id = ?", [$validReset['id']]);

            setFlash('success', Lang::isRtl() ? 'تم تحديث كلمة المرور بنجاح! يمكنك الآن تسجيل الدخول بكلمة مرورك الجديدة.' : 'Password updated successfully! You can now log in.');
            redirect(BASE_URL . '/login.php');
        } catch (Exception $e) {
            $errorMessage = Lang::isRtl() ? 'حدث خطأ أثناء تحديث كلمة المرور: ' . $e->getMessage() : 'Error updating password.';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white">
                
                <div class="text-center mb-4">
                    <div class="brand-icon-wrapper mx-auto mb-3" style="width: 56px; height: 56px; font-size: 1.6rem;">
                        <i class="bi bi-shield-lock-fill text-gold"></i>
                    </div>
                    <h2 class="h4 fw-bold text-dark-green"><?= Lang::isRtl() ? 'تعيين كلمة المرور الجديدة' : 'Set New Password' ?></h2>
                    <?php if ($validReset): ?>
                        <p class="text-muted small">
                            <?= Lang::isRtl() ? 'لحساب البريد الإلكتروني:' : 'For account:' ?> 
                            <strong class="text-dark-green"><?= e($validReset['email']) ?></strong>
                        </p>
                    <?php endif; ?>
                </div>

                <?php if ($errorMessage): ?>
                    <div class="alert alert-danger py-2 small shadow-sm rounded-3 mb-4">
                        <i class="bi bi-exclamation-triangle-fill me-1 ms-1"></i> <?= e($errorMessage) ?>
                    </div>
                <?php endif; ?>

                <?php if ($validReset): ?>
                    <form action="<?= BASE_URL ?>/reset-password.php" method="POST" class="needs-validation">
                        <?= CSRF::getFormField() ?>
                        <input type="hidden" name="token" value="<?= e($token) ?>">

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'كلمة المرور الجديدة' : 'New Password' ?></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-lock"></i></span>
                                <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" required minlength="8">
                            </div>
                            <div class="form-text small text-muted">
                                <?= Lang::isRtl() ? '8 أحرف على الأقل، تتضمن حروفاً وأرقاماً.' : 'At least 8 characters with letters and numbers.' ?>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'تأكيد كلمة المرور الجديدة' : 'Confirm Password' ?></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-lock-fill"></i></span>
                                <input type="password" name="password_confirm" id="password_confirm" class="form-control" placeholder="••••••••" required minlength="8">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-gold w-100 py-2 fw-bold d-flex align-items-center justify-content-center gap-2">
                            <i class="bi bi-check-circle-fill"></i>
                            <span><?= Lang::isRtl() ? 'حفظ وتأكيد كلمة المرور' : 'Save & Confirm Password' ?></span>
                        </button>
                    </form>
                <?php else: ?>
                    <div class="text-center py-3">
                        <a href="<?= BASE_URL ?>/forgot-password.php" class="btn btn-outline-dark-green">
                            <i class="bi bi-arrow-repeat me-1 ms-1"></i> <?= Lang::isRtl() ? 'طلب رابط استعادة جديد' : 'Request New Reset Link' ?>
                        </a>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
