<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Venue Details, Photo Gallery, Packages, Booking Request & Inquiries
 */

require_once __DIR__ . '/includes/auth.php';

$hallId = (int) get('id', 0);

if ($hallId <= 0) {
    setFlash('danger', 'قاعة غير صالحة.');
    redirect(BASE_URL . '/halls.php');
}

// Fetch Hall Details
$hall = Database::fetchOne("
    SELECT h.*, u.name as owner_name, u.phone as owner_phone, u.email as owner_email
    FROM halls h
    JOIN users u ON h.owner_id = u.id
    WHERE h.id = ? AND h.status = 'active'
    LIMIT 1
", [$hallId]);

if (!$hall) {
    setFlash('warning', 'القاعة المطلوبة غير موجودة أو قيد المراجعة.');
    redirect(BASE_URL . '/halls.php');
}

// Fetch Gallery Images
$images = Database::fetchAll("SELECT * FROM hall_images WHERE hall_id = ? ORDER BY is_primary DESC, sort_order ASC", [$hallId]);

// Fetch Facilities & Amenities
try {
    $amenities = Database::fetchAll("
        SELECT f.*, hf.details, hf.is_complimentary, hf.extra_charge 
        FROM facilities f
        JOIN hall_facilities hf ON f.id = hf.facility_id
        WHERE hf.hall_id = ?
        ORDER BY f.category ASC
    ", [$hallId]);
} catch (Exception $e) {
    $amenities = [];
}

// Fetch Pricing Packages
try {
    $packages = Database::fetchAll("
        SELECT id, title_ar, title_en, shift, day_type, base_price as price, deposit_required, currency, season 
        FROM hall_pricing 
        WHERE hall_id = ? AND is_active = 1
        ORDER BY base_price ASC
    ", [$hallId]);
} catch (Exception $e) {
    $packages = [];
}

// Fetch Approved Reviews
$reviews = Database::fetchAll("
    SELECT r.*, u.name as reviewer_name 
    FROM reviews r
    JOIN users u ON r.customer_id = u.id
    WHERE r.hall_id = ? AND r.status = 'approved'
    ORDER BY r.created_at DESC
", [$hallId]);

// Handle POST: Submit Inquiry or Booking
$formError = null;
$formSuccess = null;

if (isPost()) {
    CSRF::verifyOrDie();
    $actionType = post('action_type', '');

    if ($actionType === 'inquiry') {
        $senderName = sanitize(post('sender_name'));
        $senderPhone = sanitize(post('sender_phone'));
        $senderEmail = sanitize(post('sender_email'));
        $eventType = sanitize(post('event_type', 'wedding'));
        $eventDate = sanitize(post('event_date'));
        $guestEstimate = (int) post('guest_estimate', 0);
        $message = sanitize(post('message'));

        if (empty($senderName) || empty($senderPhone) || empty($message)) {
            $formError = 'يرجى ملء الاسم ورقم الهاتف ونص الاستفسار بشكل صحيح.';
        } else {
            try {
                $userId = Auth::id() ?: null;
                Database::insert("
                    INSERT INTO inquiries (hall_id, user_id, sender_name, sender_phone, sender_email, event_type, event_date, guest_estimate, message, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
                ", [
                    $hallId, $userId, $senderName, $senderPhone, $senderEmail, $eventType, 
                    !empty($eventDate) ? $eventDate : null, 
                    $guestEstimate > 0 ? $guestEstimate : null, 
                    $message
                ]);
                setFlash('success', __('inquiry_sent'));
                redirect(BASE_URL . '/hall-details.php?id=' . $hallId);
            } catch (Exception $e) {
                $formError = 'حدث خطأ أثناء حفظ الاستفسار: ' . $e->getMessage();
            }
        }
    } elseif ($actionType === 'booking') {
        if (!Auth::check()) {
            setFlash('warning', 'يرجى تسجيل الدخول أولاً لإرسال طلب حجز القاعة.');
            redirect(BASE_URL . '/login.php');
        }

        $eventDate = sanitize(post('event_date'));
        $shift = sanitize(post('shift', 'evening'));
        $packageId = (int) post('package_id', 0);
        $guestCount = (int) post('guest_count', 300);
        $notes = sanitize(post('notes'));

        if (empty($eventDate)) {
            $formError = 'يرجى تحديد تاريخ المناسبة.';
        } else {
            try {
                $totalAmount = ($shift === 'morning') ? $hall['price_morning'] : (($shift === 'full_day') ? $hall['price_full_day'] : $hall['price_evening']);
                if ($packageId > 0) {
                    $pkg = Database::fetchOne("SELECT base_price as price FROM hall_pricing WHERE id = ? AND hall_id = ?", [$packageId, $hallId]);
                    if ($pkg) {
                        $totalAmount = $pkg['price'];
                    }
                }

                $bookingCode = 'BK-' . date('Y') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

                Database::insert("
                    INSERT INTO bookings (booking_code, hall_id, customer_id, package_id, event_date, shift, guest_count, total_amount, deposit_amount, currency, status, payment_status, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0.00, ?, 'pending', 'unpaid', ?)
                ", [
                    $bookingCode, $hallId, Auth::id(), 
                    $packageId > 0 ? $packageId : null, 
                    $eventDate, $shift, $guestCount, $totalAmount, $hall['currency'], $notes
                ]);

                setFlash('success', 'تم إرسال طلب الحجز برقم ' . $bookingCode . ' وسيقوم مالك القاعة بتأكيده والتواصل معك.');
                redirect(BASE_URL . '/hall-details.php?id=' . $hallId);
            } catch (Exception $e) {
                $formError = 'تعذر تسجيل الحجز: ' . $e->getMessage();
            }
        }
    }
}

$page_title = $hall['name_ar'];
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/index.php" class="text-muted"><?= e(__('home')) ?></a></li>
            <li class="breadcrumb-item"><a href="<?= BASE_URL ?>/halls.php" class="text-muted"><?= e(__('halls')) ?></a></li>
            <li class="breadcrumb-item active text-dark-green fw-bold" aria-current="page"><?= e($hall['name_ar']) ?></li>
        </ol>
    </nav>

    <?php if ($formError): ?>
        <div class="alert alert-danger shadow-sm rounded-3"><?= e($formError) ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Main Content -->
        <div class="col-lg-8 col-12">
            <!-- Header Titles -->
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-2 mb-3">
                <div>
                    <h1 class="h2 fw-bold text-dark-green mb-1"><?= e($hall['name_ar']) ?></h1>
                    <div class="text-muted d-flex flex-wrap align-items-center gap-3 small">
                        <span><i class="bi bi-pin-map-fill text-danger"></i> <?= e($hall['address']) ?></span>
                        <span><i class="bi bi-star-fill text-gold"></i> <?= number_format($hall['rating'], 1) ?> (<?= $hall['reviews_count'] ?> تقييم)</span>
                    </div>
                </div>
                <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold">
                    <?= e(getOccasionTypeName($hall['hall_type'])) ?>
                </span>
            </div>

            <!-- Gallery Carousel -->
            <div class="card border rounded-3 overflow-hidden shadow-sm mb-4">
                <?php if (!empty($images)): ?>
                    <div id="hallCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner" style="max-height: 420px;">
                            <?php foreach ($images as $index => $img): ?>
                                <div class="carousel-item <?= ($index === 0) ? 'active' : '' ?>">
                                    <img src="<?= e($img['image_url']) ?>" class="d-block w-100 object-fit-cover" style="height: 420px;" alt="<?= e($img['caption']) ?>">
                                    <?php if (!empty($img['caption'])): ?>
                                        <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-75 rounded-3 p-2">
                                            <p class="mb-0 small text-white"><?= e($img['caption']) ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if (count($images) > 1): ?>
                            <button class="carousel-control-prev" type="button" data-bs-target="#hallCarousel" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">السابق</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#hallCarousel" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">التالي</span>
                            </button>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <img src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80" class="w-100" style="height: 380px; object-fit: cover;" alt="<?= e($hall['name_ar']) ?>">
                <?php endif; ?>
            </div>

            <!-- About Venue Description -->
            <div class="card border rounded-3 p-4 shadow-sm mb-4 bg-white">
                <h4 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                    <i class="bi bi-info-circle-fill text-gold"></i> <?= Lang::isRtl() ? 'نبذة عن القاعة والخدمات' : 'About Venue' ?>
                </h4>
                <p class="text-secondary leading-relaxed mb-0">
                    <?= nl2br(e($hall['description_ar'])) ?>
                </p>
            </div>

            <!-- Pricing Grid -->
            <div class="card border rounded-3 p-4 shadow-sm mb-4 bg-white">
                <h4 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                    <i class="bi bi-tag-fill text-gold"></i> <?= Lang::isRtl() ? 'جدول أسعار الفترات الرسمية' : 'Standard Pricing' ?>
                </h4>
                <div class="row g-3 text-center">
                    <div class="col-md-4 col-12">
                        <div class="p-3 bg-light rounded-3 border">
                            <div class="text-muted small mb-1"><?= e(__('morning_shift')) ?></div>
                            <div class="fs-4 fw-bold text-dark-green font-heading"><?= formatMoney($hall['price_morning'], $hall['currency']) ?></div>
                            <small class="text-secondary">من 9:00 ص إلى 2:00 م</small>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="p-3 bg-light rounded-3 border border-gold">
                            <div class="text-gold fw-bold small mb-1"><?= e(__('evening_shift')) ?> (العرس الكبير)</div>
                            <div class="fs-4 fw-bold text-dark-green font-heading"><?= formatMoney($hall['price_evening'], $hall['currency']) ?></div>
                            <small class="text-secondary">من 4:00 ع إلى 11:30 ل</small>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="p-3 bg-light rounded-3 border">
                            <div class="text-muted small mb-1"><?= e(__('full_day')) ?></div>
                            <div class="fs-4 fw-bold text-dark-green font-heading"><?= formatMoney($hall['price_full_day'], $hall['currency']) ?></div>
                            <small class="text-secondary">يوم كامل (صباحي + مسائي)</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Amenities -->
            <?php if (!empty($amenities)): ?>
                <div class="card border rounded-3 p-4 shadow-sm mb-4 bg-white">
                    <h4 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-stars text-gold"></i> <?= Lang::isRtl() ? 'المرافق والتجهيزات المتوفرة' : 'Amenities & Facilities' ?>
                    </h4>
                    <div class="row g-3">
                        <?php foreach ($amenities as $am): ?>
                            <div class="col-md-6 col-12">
                                <div class="facility-card">
                                    <div class="facility-icon-box">
                                        <i class="bi <?= e($am['icon']) ?>"></i>
                                    </div>
                                    <div>
                                        <div class="facility-card-title"><?= e(Lang::isRtl() ? $am['name_ar'] : ($am['name_en'] ?? $am['name_ar'])) ?></div>
                                        <?php if (!empty($am['details'])): ?>
                                            <div class="facility-card-details"><?= e($am['details']) ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Bundled Packages -->
            <?php if (!empty($packages)): ?>
                <div class="card border rounded-3 p-4 shadow-sm mb-4 bg-white">
                    <h4 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                        <i class="bi bi-gift-fill text-gold"></i> <?= Lang::isRtl() ? 'باقات وعروض القاعة المتكاملة' : 'Special Packages' ?>
                    </h4>
                    <div class="row g-3">
                        <?php foreach ($packages as $pkg): ?>
                            <div class="col-md-6 col-12">
                                <div class="border rounded-3 p-3 h-100 bg-white shadow-sm">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <h5 class="fw-bold text-dark-green mb-0 fs-6"><?= e($pkg['title_ar']) ?></h5>
                                        <span class="badge bg-gold small"><?= formatMoney($pkg['price'], $pkg['currency']) ?></span>
                                    </div>
                                    <p class="text-muted small mb-2"><?= e($pkg['description_ar']) ?></p>
                                    <?php if (!empty($pkg['included_services'])): ?>
                                        <div class="small text-secondary bg-light p-2 rounded-2">
                                            <i class="bi bi-check2-circle text-success me-1 ms-1"></i> <?= e($pkg['included_services']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Customer Reviews -->
            <div class="card border rounded-3 p-4 shadow-sm mb-4 bg-white">
                <h4 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                    <i class="bi bi-chat-quote-fill text-gold"></i> <?= Lang::isRtl() ? 'تقييمات وآراء العملاء' : 'Guest Reviews' ?>
                </h4>
                <?php if (!empty($reviews)): ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($reviews as $rev): ?>
                            <div class="p-3 bg-light rounded-3 border">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="fw-bold text-dark-green"><?= e($rev['reviewer_name']) ?></span>
                                    <span class="text-gold small">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="bi <?= ($i <= $rev['rating']) ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                        <?php endfor; ?>
                                    </span>
                                </div>
                                <p class="text-secondary small mb-1"><?= e($rev['comment']) ?></p>
                                <small class="text-muted" style="font-size: 0.75rem;"><?= date('Y-m-d', strtotime($rev['created_at'])) ?></small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'لا توجد تقييمات مكتوبة حتى الآن.' : 'No reviews yet.' ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar: Action Box -->
        <div class="col-lg-4 col-12">
            <div class="card border rounded-3 p-4 shadow-sm bg-white sticky-top" style="top: 85px;">
                <!-- Nav Tabs for Action -->
                <ul class="nav nav-pills nav-fill mb-3 bg-light p-1 rounded-3" id="bookingTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active rounded-3 small fw-bold" id="book-tab" data-bs-toggle="pill" data-bs-target="#tab-book" type="button" role="tab">
                            <i class="bi bi-calendar-check me-1 ms-1"></i> <?= e(__('book_now')) ?>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link rounded-3 small fw-bold" id="inquire-tab" data-bs-toggle="pill" data-bs-target="#tab-inquire" type="button" role="tab">
                            <i class="bi bi-chat-dots me-1 ms-1"></i> <?= e(__('inquire_now')) ?>
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="bookingTabContent">
                    <!-- Tab 1: Request Booking -->
                    <div class="tab-pane fade show active" id="tab-book" role="tabpanel">
                        <?php if (Auth::check()): ?>
                            <form action="<?= BASE_URL ?>/hall-details.php?id=<?= $hallId ?>" method="POST" class="needs-validation" novalidate>
                                <?= CSRF::getFormField() ?>
                                <input type="hidden" name="action_type" value="booking">

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'تاريخ الحفل المطلوب' : 'Event Date' ?> *</label>
                                    <input type="date" name="event_date" class="form-control min-today" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'الفترة المطلوبة' : 'Shift' ?></label>
                                    <select name="shift" class="form-select">
                                        <option value="evening"><?= e(__('evening_shift')) ?> (<?= formatMoney($hall['price_evening'], $hall['currency']) ?>)</option>
                                        <option value="morning"><?= e(__('morning_shift')) ?> (<?= formatMoney($hall['price_morning'], $hall['currency']) ?>)</option>
                                        <option value="full_day"><?= e(__('full_day')) ?> (<?= formatMoney($hall['price_full_day'], $hall['currency']) ?>)</option>
                                    </select>
                                </div>

                                <?php if (!empty($packages)): ?>
                                    <div class="mb-3">
                                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'اختيار باقة خدمات (اختياري)' : 'Package' ?></label>
                                        <select name="package_id" class="form-select">
                                            <option value="0"><?= Lang::isRtl() ? 'بدون باقة (سعر القاعة الأساسي فقط)' : 'Base Hall Only' ?></option>
                                            <?php foreach ($packages as $pkg): ?>
                                                <option value="<?= $pkg['id'] ?>"><?= e($pkg['title_ar']) ?> (<?= formatMoney($pkg['price'], $pkg['currency']) ?>)</option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endif; ?>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'العدد التقديري للضيوف' : 'Guest Count' ?></label>
                                    <input type="number" name="guest_count" class="form-control" value="300" min="<?= $hall['capacity_min'] ?>" max="<?= $hall['capacity_max'] ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'ملاحظات أو طلبات إضافية' : 'Notes' ?></label>
                                    <textarea name="notes" class="form-control" rows="2" placeholder="تجهيزات الكوشة، الورود، مواعيد الحضور..."></textarea>
                                </div>

                                <button type="submit" class="btn btn-gold w-100 py-2 fw-bold">
                                    <i class="bi bi-send-check me-1 ms-1"></i> <?= Lang::isRtl() ? 'إرسال طلب الحجز المبدئي' : 'Submit Booking Request' ?>
                                </button>
                                <small class="text-muted d-block text-center mt-2" style="font-size: 0.75rem;">
                                    <?= Lang::isRtl() ? 'طلب الحجز يتيح للقاعة تثبيت التاريخ والتواصل معك.' : 'No immediate charges. Hall manager will confirm.' ?>
                                </small>
                            </form>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="bi bi-lock-fill text-gold fs-1 mb-2 d-block"></i>
                                <h6 class="fw-bold text-dark-green"><?= Lang::isRtl() ? 'تسجيل الدخول مطلوب للحجز' : 'Login Required to Book' ?></h6>
                                <p class="text-muted small mb-3"><?= Lang::isRtl() ? 'سجل دخولك لتتمكن من حجز هذه القاعة ومتابعة حالة حجزك.' : 'Please login to submit booking requests.' ?></p>
                                <a href="<?= BASE_URL ?>/login.php" class="btn btn-gold w-100 mb-2"><?= e(__('login')) ?></a>
                                <a href="<?= BASE_URL ?>/register.php" class="btn btn-outline-dark-green w-100"><?= e(__('register')) ?></a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Tab 2: Send Inquiry -->
                    <div class="tab-pane fade" id="tab-inquire" role="tabpanel">
                        <form action="<?= BASE_URL ?>/hall-details.php?id=<?= $hallId ?>" method="POST" class="needs-validation" novalidate>
                            <?= CSRF::getFormField() ?>
                            <input type="hidden" name="action_type" value="inquiry">

                            <div class="mb-2">
                                <label class="form-label small fw-bold text-dark-green"><?= e(__('full_name')) ?> *</label>
                                <input type="text" name="sender_name" class="form-control" value="<?= e($currentUser['name'] ?? '') ?>" required>
                            </div>

                            <div class="mb-2">
                                <label class="form-label small fw-bold text-dark-green"><?= e(__('phone')) ?> (واتساب) *</label>
                                <input type="tel" name="sender_phone" class="form-control" placeholder="+967 77..." value="<?= e($currentUser['phone'] ?? '') ?>" required>
                            </div>

                            <div class="mb-2">
                                <label class="form-label small fw-bold text-dark-green"><?= e(__('email')) ?></label>
                                <input type="email" name="sender_email" class="form-control" value="<?= e($currentUser['email'] ?? '') ?>">
                            </div>

                            <div class="row g-2 mb-2">
                                <div class="col-6">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'المناسبة' : 'Event' ?></label>
                                    <select name="event_type" class="form-select form-select-sm">
                                        <option value="wedding"><?= e(__('type_wedding')) ?></option>
                                        <option value="engagement"><?= e(__('type_engagement')) ?></option>
                                        <option value="graduation"><?= e(__('type_graduation')) ?></option>
                                        <option value="conference"><?= e(__('type_conference')) ?></option>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'التاريخ التقديري' : 'Date' ?></label>
                                    <input type="date" name="event_date" class="form-control form-control-sm min-today">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'نص الاستفسار' : 'Message' ?> *</label>
                                <textarea name="message" class="form-control" rows="3" placeholder="<?= Lang::isRtl() ? 'استفسر عن الأسعار، الشاشات، أجهزة الصوت، أو المواعيد الشاغرة...' : 'Ask about packages, availability, or amenities...' ?>" required></textarea>
                            </div>

                            <button type="submit" class="btn btn-dark-green w-100 py-2 fw-bold">
                                <i class="bi bi-chat-left-dots me-1 ms-1"></i> <?= e(__('inquire_now')) ?>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Direct WhatsApp / Phone Contact -->
                <hr class="my-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <small class="text-muted d-block"><?= Lang::isRtl() ? 'هاتف إدارة القاعة:' : 'Hall Phone:' ?></small>
                        <span class="fw-bold text-dark-green"><?= e($hall['owner_phone']) ?></span>
                    </div>
                    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $hall['owner_phone']) ?>" target="_blank" class="btn btn-success btn-sm d-flex align-items-center gap-1">
                        <i class="bi bi-whatsapp"></i> واتساب
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
