<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Reusable Helper Functions
 */

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/language.php';
require_once __DIR__ . '/upload.php';

/**
 * Escapes HTML output securely against XSS
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitize clean string input
 */
function sanitize(?string $string): string {
    return trim(strip_tags($string ?? ''));
}

/**
 * Check if the request method is POST
 */
function isPost(): bool {
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

/**
 * Get sanitized POST variable
 */
function post(string $key, $default = null) {
    if (!isset($_POST[$key])) return $default;
    return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
}

/**
 * Get sanitized GET variable
 */
function get(string $key, $default = null) {
    if (!isset($_GET[$key])) return $default;
    return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
}

/**
 * Set flash session notification message
 */
function setFlash(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Retrieve and clear flash notification message
 */
function getFlash(): ?array {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Check if a flash notification exists
 */
function hasFlash(): bool {
    return isset($_SESSION['flash']);
}

/**
 * Format money with active currency
 */
function formatMoney(?float $amount, ?string $currency = DEFAULT_CURRENCY): string {
    $cur = !empty($currency) ? $currency : DEFAULT_CURRENCY;
    if ($amount === null || $amount <= 0) {
        return Lang::isRtl() ? 'حسب الاتفاق' : 'Upon Request';
    }
    $formatted = number_format($amount, 0, '.', ',');
    $symbol = ($cur === 'YER') ? (Lang::isRtl() ? 'ر.ي' : 'YER') : $cur;
    return Lang::isRtl() ? ($formatted . ' ' . $symbol) : ($symbol . ' ' . $formatted);
}

/**
 * Return all 22 Yemeni Governorates (جميع محافظات الجمهورية اليمنية)
 */
function getYemenGovernorates(): array {
    $isRtl = Lang::isRtl();
    return [
        'sanaa'      => $isRtl ? 'أمانة العاصمة صنعاء' : "Sana'a Capital",
        'sanaa_gov'  => $isRtl ? 'محافظة صنعاء' : "Sana'a Governorate",
        'aden'       => $isRtl ? 'عدن' : 'Aden',
        'taiz'       => $isRtl ? 'تعز' : 'Taiz',
        'ibb'        => $isRtl ? 'إب' : 'Ibb',
        'hadhramaut' => $isRtl ? 'حضرموت (المكلا / سيئون)' : 'Hadhramaut (Mukalla / Seiyun)',
        'hodeidah'   => $isRtl ? 'الحديدة' : 'Al Hodeidah',
        'dhamar'     => $isRtl ? 'ذمار' : 'Dhamar',
        'marib'      => $isRtl ? 'مأرب' : 'Marib',
        'amran'      => $isRtl ? 'عمران' : 'Amran',
        'hajjah'     => $isRtl ? 'حجة' : 'Hajjah',
        'sadah'      => $isRtl ? 'صعدة' : "Sa'dah",
        'albayda'    => $isRtl ? 'البيضاء' : 'Al Bayda',
        'aldhale'    => $isRtl ? 'الضالع' : "Al Dhale'e",
        'lahj'       => $isRtl ? 'لحج' : 'Lahj',
        'abyan'      => $isRtl ? 'أبين' : 'Abyan',
        'shabwah'    => $isRtl ? 'شبوة' : 'Shabwah',
        'almahrah'   => $isRtl ? 'المهرة' : 'Al Mahrah',
        'aljawf'     => $isRtl ? 'الجوف' : 'Al Jawf',
        'raymah'     => $isRtl ? 'ريمة' : 'Raymah',
        'almahwit'   => $isRtl ? 'المحويت' : 'Al Mahwit',
        'socotra'    => $isRtl ? 'أرخبيل سقطرى' : 'Socotra',
    ];
}

/**
 * Translate city/governorate code to human name
 */
function getCityName(string $cityCode): string {
    $cities = getYemenGovernorates();
    $cities['mukalla'] = Lang::isRtl() ? 'حضرموت (المكلا)' : 'Hadhramaut (Mukalla)';
    $cities['hadramout'] = Lang::isRtl() ? 'حضرموت' : 'Hadhramaut';
    return $cities[$cityCode] ?? $cityCode;
}

/**
 * Translate occasion type to human name
 */
function getOccasionTypeName(string $typeCode): string {
    $types = [
        'wedding' => Lang::isRtl() ? 'أعراس وحفلات زفاف' : 'Weddings & Receptions',
        'engagement' => Lang::isRtl() ? 'حفلات خطوبة وعقد قران' : 'Engagement Parties',
        'graduation' => Lang::isRtl() ? 'حفلات تخرج وتكريم' : 'Graduations',
        'conference' => Lang::isRtl() ? 'مؤتمرات وندوات' : 'Conferences',
        'family' => Lang::isRtl() ? 'مناسبات عائلية خاصة' : 'Family Gatherings',
        'multi_purpose' => Lang::isRtl() ? 'متعددة الأغراض' : 'Multi-purpose',
    ];
    return $types[$typeCode] ?? $typeCode;
}

/**
 * Safe redirect helper
 */
function redirect(string $url): void {
    if (!headers_sent()) {
        header("Location: " . $url);
        exit;
    }
    $safeUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
    echo '<script>window.location.replace(' . json_encode($url) . ');</script>';
    echo '<noscript><meta http-equiv="refresh" content="0;url=' . $safeUrl . '"></noscript>';
    exit;
}
