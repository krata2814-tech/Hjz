<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Secure Image Upload & Media Handling Utility
 */

require_once __DIR__ . '/../config/app.php';

class ImageUploader {
    public const ALLOWED_MIME_TYPES = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    public const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
    public const MAX_WIDTH = 4000;
    public const MAX_HEIGHT = 4000;

    /**
     * Upload and validate image securely
     */
    public static function upload(array $fileArray, string $subfolder = 'halls'): array {
        // 1. Basic error checking
        if (!isset($fileArray['error']) || is_array($fileArray['error'])) {
            return ['success' => false, 'error' => 'معاملات ملف غير صالحة.'];
        }

        switch ($fileArray['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return ['success' => false, 'error' => 'حجم الملف يتجاوز الحد الأقصى المسموح به (5 ميجابايت).'];
            case UPLOAD_ERR_NO_FILE:
                return ['success' => false, 'error' => 'لم يتم إرسال أي ملف.'];
            default:
                return ['success' => false, 'error' => 'حدث خطأ أثناء رفع الملف (كود: ' . $fileArray['error'] . ').'];
        }

        // 2. Check size
        if ($fileArray['size'] > self::MAX_FILE_SIZE) {
            return ['success' => false, 'error' => 'حجم الصورة كبير جداً، الحد الأقصى هو 5 ميجابايت.'];
        }

        // 3. Inspect MIME type using fileinfo
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($fileArray['tmp_name']);

        if (!array_key_exists($mimeType, self::ALLOWED_MIME_TYPES)) {
            return ['success' => false, 'error' => 'نوع الملف غير مدعوم. الأنواع المسموحة هي: JPG, PNG, WEBP فقط.'];
        }

        $extension = self::ALLOWED_MIME_TYPES[$mimeType];

        // 4. Verify that it is indeed a valid image via getimagesize
        $imageInfo = @getimagesize($fileArray['tmp_name']);
        if ($imageInfo === false) {
            return ['success' => false, 'error' => 'الملف المرفوع ليس ملف صورة حقيقي أو تالف.'];
        }

        [$width, $height] = $imageInfo;
        if ($width > self::MAX_WIDTH || $height > self::MAX_HEIGHT) {
            return ['success' => false, 'error' => 'أبعاد الصورة تتجاوز الحد الأقصى المسموح (4000x4000 بكسل).'];
        }

        // 5. Generate secure random filename
        $targetDir = ROOT_PATH . '/uploads/' . trim($subfolder, '/');
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0755, true);
        }

        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        $destination = $targetDir . '/' . $filename;

        // 6. Move uploaded file
        if (!move_uploaded_file($fileArray['tmp_name'], $destination)) {
            return ['success' => false, 'error' => 'فشل حفظ الملف على القرص، يرجى التحقق من أذونات المجلد.'];
        }

        $publicUrl = BASE_URL . '/uploads/' . trim($subfolder, '/') . '/' . $filename;

        return [
            'success' => true,
            'filename' => $filename,
            'url' => $publicUrl,
            'path' => $destination,
            'width' => $width,
            'height' => $height,
            'size' => $fileArray['size'],
            'mime' => $mimeType
        ];
    }

    /**
     * Get image URL with safe local SVG fallback
     */
    public static function getImageUrl(?string $url, string $title = 'صورة القاعة'): string {
        if (!empty($url)) {
            return $url;
        }

        // Return a clean inline SVG placeholder if image is missing
        $titleEscaped = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        return "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='500' viewBox='0 0 800 500'><rect width='100%' height='100%' fill='%23143D30'/><text x='50%' y='50%' font-family='sans-serif' font-size='26' font-weight='bold' fill='%23C5A059' text-anchor='middle' dominant-baseline='middle'>{$titleEscaped}</text></svg>";
    }
}

/**
 * Global helper function to get image URL with safe fallback
 */
function hallImage(?string $url, string $title = 'قاعة أفراح'): string {
    return ImageUploader::getImageUrl($url, $title);
}
