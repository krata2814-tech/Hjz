<?php
/**
 * Wedding & Event Halls Booking Platform
 * Reusable Footer Component
 */

$assetBase = rtrim(BASE_PATH, '/');
?>
<footer class="footer-luxury mt-5">
    <div class="container">
        <div class="row g-4">
            <!-- Col 1: About Platform -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-wrapper" style="width: 42px; height: 42px; font-size: 1.25rem;">
                        <i class="bi bi-building"></i>
                    </div>
                    <span class="fs-5 fw-bold text-white"><?= e(__('app_name')) ?></span>
                </div>
                <p class="text-white-50 small leading-relaxed mb-3">
                    <?= Lang::isRtl()
                        ? 'المنصة الأولى الموثوقة لحجز قاعات الأفراح والمناسبات الرسمية والعائلية في اليمن. نربط بين الباحثين عن ليلة عمر استثنائية وأفضل ملاك القاعات والقصور بأسعار شفافة وباقات متكاملة.'
                        : 'The premier trusted platform for booking wedding and event halls across Yemen. Connecting event hosts with premier venues and palaces.'
                    ?>
                </p>
                <div class="d-flex gap-2">
                    <span class="badge bg-success bg-opacity-25 text-success-emphasis border border-success border-opacity-25 px-2 py-1 small">
                        <i class="bi bi-patch-check-fill me-1 ms-1"></i> قاعات معتمدة ومرخصة
                    </span>
                    <span class="badge bg-warning bg-opacity-25 text-warning-emphasis border border-warning border-opacity-25 px-2 py-1 small">
                        <i class="bi bi-shield-fill-check me-1 ms-1"></i> ضمان الحجز الرسمي
                    </span>
                </div>
            </div>

            <!-- Col 2: Quick Links -->
            <div class="col-lg-2 col-md-6 col-6">
                <h5><?= Lang::isRtl() ? 'استكشاف القاعات' : 'Venues' ?></h5>
                <ul class="footer-links">
                    <li><a href="<?= BASE_URL ?>/index.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= e(__('home')) ?></a></li>
                    <li><a href="<?= BASE_URL ?>/halls.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= e(__('halls')) ?></a></li>
                    <li><a href="<?= BASE_URL ?>/search.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= Lang::isRtl() ? 'البحث المتقدم' : 'Search' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/inquiry.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= Lang::isRtl() ? 'طلب استشارة وحجز' : 'Booking Inquiry' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/about.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= Lang::isRtl() ? 'عن المنصة' : 'About Us' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/contact.php"><i class="bi bi-chevron-left me-1 ms-1"></i> <?= Lang::isRtl() ? 'اتصل بنا' : 'Contact Us' ?></a></li>
                </ul>
            </div>

            <!-- Col 3: Policies & Support -->
            <div class="col-lg-3 col-md-6 col-6">
                <h5><?= Lang::isRtl() ? 'المساعدة والسياسات' : 'Help & Policies' ?></h5>
                <ul class="footer-links">
                    <li><a href="<?= BASE_URL ?>/faq.php"><i class="bi bi-patch-question me-1 ms-1 text-gold"></i> <?= Lang::isRtl() ? 'الأسئلة الشائعة' : 'FAQs' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/terms.php"><i class="bi bi-file-earmark-text me-1 ms-1 text-gold"></i> <?= Lang::isRtl() ? 'الشروط والأحكام' : 'Terms' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/privacy.php"><i class="bi bi-shield-check me-1 ms-1 text-gold"></i> <?= Lang::isRtl() ? 'سياسة الخصوصية' : 'Privacy' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/register.php?role=hall_owner"><i class="bi bi-building-add me-1 ms-1 text-gold"></i> <?= Lang::isRtl() ? 'تسجيل مالك قاعة' : 'Venue Owners' ?></a></li>
                    <li><a href="<?= BASE_URL ?>/install.php"><i class="bi bi-gear me-1 ms-1 text-gold"></i> <?= Lang::isRtl() ? 'فحص النظام والتثبيت' : 'Installation' ?></a></li>
                </ul>
            </div>

            <!-- Col 4: Contact & Platform Standards -->
            <div class="col-lg-3 col-md-6 col-12">
                <h5><?= Lang::isRtl() ? 'خدمة العملاء والضمان' : 'Support & Security' ?></h5>
                <p class="small text-white-50 mb-3">
                    <i class="bi bi-telephone-fill text-gold me-1 ms-1"></i> <span dir="ltr">+967-1-445566</span> | <span dir="ltr">+967 770 000 001</span>
                </p>
                <div class="p-3 rounded-3 bg-white bg-opacity-10 border border-white border-opacity-10 small text-white">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-white-50"><?= Lang::isRtl() ? 'المنطقة الزمنية:' : 'Timezone:' ?></span>
                        <span class="fw-bold">Asia/Aden (GMT+3)</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-white-50"><?= Lang::isRtl() ? 'العملة المعتمدة:' : 'Currency:' ?></span>
                        <span class="fw-bold text-gold"><?= DEFAULT_CURRENCY ?> (<?= CURRENCY_SYMBOL_AR ?>)</span>
                    </div>
                </div>
            </div>
        </div>

        <hr class="border-secondary border-opacity-25 my-4">

        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                <p class="mb-0 small text-white-50">
                    &copy; <?= date('Y') ?> <?= e(__('app_name')) ?>. <?= Lang::isRtl() ? 'جميع الحقوق محفوظة.' : 'All Rights Reserved.' ?>
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <span class="badge bg-white bg-opacity-10 text-white px-3 py-2 rounded-pill small">
                    <i class="bi bi-code-slash me-1 ms-1"></i> PHP 8.2+ &bull; MySQL &bull; PDO &bull; Bootstrap 5 RTL
                </span>
            </div>
        </div>
    </div>
</footer>

<!-- Local Bootstrap 5.3.3 Bundle with Popper -->
<script src="<?= $assetBase ?>/assets/js/bootstrap.bundle.min.js"></script>

<!-- Fallback CDN in case script was directly embedded -->
<script>
if (typeof bootstrap === 'undefined') {
    document.write('<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"><\/script>');
}
</script>

<!-- Custom App Logic -->
<script src="<?= $assetBase ?>/assets/js/app.js?v=<?= APP_VERSION ?>"></script>
</body>
</html>
