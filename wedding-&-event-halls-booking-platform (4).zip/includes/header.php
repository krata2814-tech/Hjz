<?php
/**
 * Wedding & Event Halls Booking Platform
 * Reusable HTML Header Component
 */

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/security.php';
require_once __DIR__ . '/language.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$isRtl = Lang::isRtl();
$direction = Lang::getDirection();
$currentLocale = Lang::getLocale();
$pageTitle = isset($page_title) ? ($page_title . ' | ' . __('app_name')) : __('app_name');

// Clean asset URL helper: uses root-relative path (e.g. /assets/css/style.css or /wedding_halls/assets/css/style.css)
$assetBase = rtrim(BASE_PATH, '/');
?>
<!DOCTYPE html>
<html lang="<?= e($currentLocale) ?>" dir="<?= e($direction) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e(__('app_tagline')) ?>">

    <!-- Arabic Typography: Cairo & Tajawal via Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">

    <!-- Primary CSS: Local Bootstrap 5.3.3 RTL (Guaranteed to load offline & on mobile) -->
    <link rel="stylesheet" href="<?= $assetBase ?>/assets/css/bootstrap.rtl.min.css">

    <!-- CDN Backup for Bootstrap in case hosted environments require it -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" integrity="sha384-dpuaG1suU0eT09tx5plTaGMLBsfDLzUUC6A7955NW5Qbrbfxb+44DZSZOChaozn5" crossorigin="anonymous">

    <!-- Bootstrap Icons (Local font bundle) -->
    <link rel="stylesheet" href="<?= $assetBase ?>/assets/css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Master Custom Luxury Theme CSS (Dark Green, Ivory, Subtle Gold) -->
    <link rel="stylesheet" href="<?= $assetBase ?>/assets/css/style.css?v=<?= APP_VERSION ?>">
</head>
<body class="<?= $isRtl ? 'rtl-mode' : 'ltr-mode' ?>">
