<?php
/**
 * Wedding & Event Halls Booking Platform
 * Reusable Navigation Component
 */

$isLoggedIn = Auth::check();
$currentUser = $isLoggedIn ? Auth::user() : null;
$userRole = Auth::role();
$currentScript = basename($_SERVER['PHP_SELF'] ?? '');
?>

<!-- Top Announcement & Quick Contact Bar -->
<div class="top-bar d-none d-lg-block">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-4">
            <span class="d-flex align-items-center gap-1"><i class="bi bi-telephone-fill text-gold"></i> <span dir="ltr">+967-1-445566</span></span>
            <span class="d-flex align-items-center gap-1"><i class="bi bi-whatsapp text-success"></i> <span dir="ltr">+967 770 000 001</span></span>
            <span class="d-flex align-items-center gap-1 text-white-50"><i class="bi bi-geo-alt-fill text-danger"></i> صنعاء &bull; عدن &bull; تعز &bull; إب &bull; حضرموت</span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <!-- Language Switcher -->
            <?php if (Lang::getLocale() === 'ar'): ?>
                <a href="?lang=en" class="d-flex align-items-center gap-1 text-gold text-decoration-none">
                    <i class="bi bi-globe2"></i> English
                </a>
            <?php else: ?>
                <a href="?lang=ar" class="d-flex align-items-center gap-1 text-gold text-decoration-none">
                    <i class="bi bi-globe2"></i> العربية
                </a>
            <?php endif; ?>

            <?php if ($isLoggedIn): ?>
                <span class="text-white-50">|</span>
                <span class="text-white small"><i class="bi bi-person-fill text-gold"></i> <?= e($currentUser['name'] ?? '') ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Main Luxury Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-luxury sticky-top shadow-sm">
    <div class="container">
        <!-- Brand Logo -->
        <a class="navbar-brand d-flex align-items-center gap-2 text-decoration-none" href="<?= BASE_URL ?>/index.php">
            <div class="brand-icon-wrapper">
                <i class="bi bi-building"></i>
            </div>
            <div class="brand-text">
                <span class="brand-name"><?= e(__('app_name')) ?></span>
                <span class="brand-sub"><?= Lang::isRtl() ? 'حجز قاعات الأفراح والمناسبات الفاخرة' : 'Luxury Wedding & Event Halls' ?></span>
            </div>
        </a>

        <!-- Mobile Toggle Button (Touch Friendly) -->
        <button class="navbar-toggler border-0 p-2 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="bi bi-list fs-2 text-dark"></i>
        </button>

        <!-- Navbar Links & Dropdowns -->
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav mx-auto mb-3 mb-lg-0 py-2 py-lg-0 gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>/index.php">
                        <i class="bi bi-house-door me-1 ms-1"></i> <?= e(__('home')) ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($currentScript === 'halls.php' && !isset($_GET['city'])) ? 'active' : '' ?>" href="<?= BASE_URL ?>/halls.php">
                        <i class="bi bi-grid-fill me-1 ms-1"></i> <?= e(__('halls')) ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (isset($_GET['city']) && $_GET['city'] === 'sanaa') ? 'active' : '' ?>" href="<?= BASE_URL ?>/halls.php?city=sanaa">
                        <?= e(__('city_sanaa')) ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (isset($_GET['city']) && $_GET['city'] === 'aden') ? 'active' : '' ?>" href="<?= BASE_URL ?>/halls.php?city=aden">
                        <?= e(__('city_aden')) ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($currentScript === 'inquiry.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>/inquiry.php">
                        <i class="bi bi-calendar2-heart text-gold me-1 ms-1"></i> <?= Lang::isRtl() ? 'طلب حجز / استشارة' : 'Book / Inquire' ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($currentScript === 'about.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>/about.php">
                        <?= Lang::isRtl() ? 'عن المنصة' : 'About' ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($currentScript === 'contact.php') ? 'active' : '' ?>" href="<?= BASE_URL ?>/contact.php">
                        <?= Lang::isRtl() ? 'اتصل بنا' : 'Contact' ?>
                    </a>
                </li>
            </ul>

            <!-- Auth Buttons & User Menu -->
            <div class="d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center gap-2 pt-2 pt-lg-0 border-top border-lg-0">
                <?php if ($isLoggedIn): ?>
                    <div class="dropdown">
                        <button class="btn btn-dark-green dropdown-toggle w-100 d-flex align-items-center justify-content-between justify-content-lg-start gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="d-flex align-items-center gap-2">
                                <i class="bi bi-person-circle text-gold"></i>
                                <span><?= e($currentUser['name'] ?? 'حسابي') ?></span>
                            </span>
                            <span class="badge bg-gold text-dark fs-8">
                                <?php
                                    switch ($userRole) {
                                        case 'super_admin':
                                        case 'admin': echo 'المدير العام'; break;
                                        case 'hall_owner': echo 'مالك قاعة'; break;
                                        case 'employee': echo 'طاقم عمل'; break;
                                        default: echo 'عميل'; break;
                                    }
                                ?>
                            </span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                            <li><h6 class="dropdown-header text-muted"><?= e($currentUser['email'] ?? '') ?></h6></li>
                            <li>
                                <a class="dropdown-item py-2" href="<?= BASE_URL ?>/dashboard.php">
                                    <i class="bi bi-speedometer2 me-2 ms-2 text-dark-green"></i> <?= e(__('dashboard')) ?>
                                </a>
                            </li>
                            <?php if (Auth::isSuperAdmin()): ?>
                                <li>
                                    <a class="dropdown-item py-2 fw-bold text-dark-green" href="<?= BASE_URL ?>/admin/index.php">
                                        <i class="bi bi-shield-lock-fill text-gold me-2 ms-2"></i> لوحة الإدارة العليا (Super Admin)
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider my-1"></li>
                            <li>
                                <a class="dropdown-item py-2 text-danger" href="<?= BASE_URL ?>/logout.php">
                                    <i class="bi bi-box-arrow-right me-2 ms-2"></i> <?= e(__('logout')) ?>
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline-dark-green text-center">
                        <i class="bi bi-box-arrow-in-left me-1 ms-1"></i> <?= e(__('login')) ?>
                    </a>
                    <a href="<?= BASE_URL ?>/register.php?role=hall_owner" class="btn btn-gold text-center">
                        <i class="bi bi-plus-circle-fill me-1 ms-1"></i> <?= Lang::isRtl() ? 'أضف قاعتك معنا' : 'List Venue' ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- System Flash Messages Container -->
<?php if (hasFlash()): $flash = getFlash(); ?>
    <div class="container mt-3">
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm d-flex align-items-center rounded-3 border-0" role="alert">
            <i class="bi <?= ($flash['type'] === 'success') ? 'bi-check-circle-fill text-success' : 'bi-exclamation-triangle-fill text-warning' ?> me-2 ms-2 fs-5"></i>
            <div class="fw-medium"><?= e($flash['message']) ?></div>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>
