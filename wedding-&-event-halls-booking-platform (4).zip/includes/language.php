<?php
/**
 * Wedding & Event Halls Booking Platform
 * Language and Localization Helper
 */

class Lang {
    private static array $translations = [];
    private static string $currentLocale = 'ar';

    public static function init(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Check if user requested language change via query param ?lang=ar or ?lang=en
        if (isset($_GET['lang']) && in_array($_GET['lang'], ['ar', 'en'])) {
            $_SESSION['lang'] = $_GET['lang'];
        }

        self::$currentLocale = $_SESSION['lang'] ?? 'ar';

        $file = dirname(__DIR__) . '/lang/' . self::$currentLocale . '.php';
        if (file_exists($file)) {
            self::$translations = require $file;
        } else {
            self::$translations = require dirname(__DIR__) . '/lang/ar.php';
        }
    }

    public static function getLocale(): string {
        return self::$currentLocale;
    }

    public static function isRtl(): bool {
        return self::$currentLocale === 'ar';
    }

    public static function getDirection(): string {
        return self::isRtl() ? 'rtl' : 'ltr';
    }

    public static function trans(string $key, array $replace = []): string {
        $text = self::$translations[$key] ?? $key;
        foreach ($replace as $placeholder => $value) {
            $text = str_replace(':' . $placeholder, $value, $text);
        }
        return $text;
    }
}

// Global translation shortcut function
function __(string $key, array $replace = []): string {
    return Lang::trans($key, $replace);
}

// Initialize localization immediately
Lang::init();
