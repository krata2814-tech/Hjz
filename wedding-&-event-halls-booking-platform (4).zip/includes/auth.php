<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Authentication & Role-Based Access Control (RBAC)
 */

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

class Auth {
    /**
     * Ensure the primary Super Administrator account (krata2814@gmail.com / 781802671)
     * is present and updated in the active database (MySQL or SQLite).
     */
    private static function ensureSuperAdminAccount(): void {
        try {
            $adminEmail = 'krata2814@gmail.com';
            $adminPass  = '781802671';
            $existingAdmin = Database::fetchOne("SELECT id, email, password_hash FROM users WHERE role_id = 1 ORDER BY id ASC LIMIT 1");

            if (!$existingAdmin) {
                $hash = password_hash($adminPass, PASSWORD_BCRYPT);
                Database::query("
                    INSERT INTO users (id, role_id, name, email, phone, password_hash, status, created_at, updated_at)
                    VALUES (1, 1, 'المدير العام للنظام (Super Admin)', ?, '+967781802671', ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ", [$adminEmail, $hash]);
            } else {
                $needsEmailUpdate = strtolower(trim($existingAdmin['email'])) !== $adminEmail;
                $needsPassUpdate  = !password_verify($adminPass, (string)$existingAdmin['password_hash']);
                if ($needsEmailUpdate || $needsPassUpdate) {
                    $hash = $needsPassUpdate ? password_hash($adminPass, PASSWORD_BCRYPT) : $existingAdmin['password_hash'];
                    Database::query("
                        UPDATE users
                        SET email = ?, password_hash = ?, status = 'active', updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ", [$adminEmail, $hash, $existingAdmin['id']]);
                }
            }
        } catch (Exception $e) {
            // Ignore if table not yet initialized
        }
    }

    /**
     * Authenticate user with email and password
     */
    public static function attempt(string $email, string $password): bool {
        self::ensureSuperAdminAccount();

        $email = trim(strtolower($email));

        // Fetch user joined with role slug
        $user = Database::fetchOne("
            SELECT u.*, r.slug as role_slug, r.name_ar as role_name_ar
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE LOWER(u.email) = ? AND u.status = 'active'
            LIMIT 1
        ", [$email]);

        if (!$user) {
            return false;
        }

        if (password_verify($password, $user['password_hash'])) {
            self::establishSession($user);

            // Update last login timestamp
            try {
                Database::query("UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?", [$user['id']]);
            } catch (Exception $e) {
                // Non-critical
            }

            return true;
        }

        return false;
    }

    /**
     * Establish a secure session for an authenticated user
     */
    public static function establishSession(array $user): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Prevent session fixation safely
        if (!headers_sent()) {
            session_regenerate_id(true);
        }

        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role_slug'] ?? $user['role'] ?? 'customer';
        $_SESSION['role_id'] = (int)($user['role_id'] ?? 3);
        $_SESSION['logged_in_time'] = time();

        // Load permissions into session for fast authorization
        $_SESSION['user_permissions'] = self::fetchUserPermissions((int)$user['id'], (int)($_SESSION['role_id']));
    }

    /**
     * Fetch user permissions combining role permissions and individual overrides
     */
    public static function fetchUserPermissions(int $userId, int $roleId): array {
        try {
            // Get role permissions
            $rolePerms = Database::fetchAll("
                SELECT p.slug
                FROM role_permissions rp
                JOIN permissions p ON rp.permission_id = p.id
                WHERE rp.role_id = ?
            ", [$roleId]);
            $perms = array_column($rolePerms, 'slug');

            // Apply user specific overrides (grant or deny)
            $overrides = Database::fetchAll("
                SELECT p.slug, up.is_granted
                FROM user_permissions up
                JOIN permissions p ON up.permission_id = p.id
                WHERE up.user_id = ?
            ", [$userId]);

            foreach ($overrides as $o) {
                if ($o['is_granted'] && !in_array($o['slug'], $perms)) {
                    $perms[] = $o['slug'];
                } elseif (!$o['is_granted']) {
                    $perms = array_diff($perms, [$o['slug']]);
                }
            }

            return array_values($perms);
        } catch (Exception $e) {
            return [];
        }
    }

    /**
     * Check if a user is currently logged in
     */
    public static function check(): bool {
        return !empty($_SESSION['user_id']);
    }

    /**
     * Get the authenticated user ID
     */
    public static function id(): ?int {
        return $_SESSION['user_id'] ?? null;
    }

    /**
     * Get the authenticated user role slug
     */
    public static function role(): ?string {
        return $_SESSION['user_role'] ?? null;
    }

    /**
     * Get the authenticated user full name
     */
    public static function name(): ?string {
        return $_SESSION['user_name'] ?? null;
    }

    /**
     * Get the authenticated user email
     */
    public static function email(): ?string {
        return $_SESSION['user_email'] ?? null;
    }

    /**
     * Helper checks for specific roles
     */
    public static function isSuperAdmin(): bool {
        return self::role() === 'super_admin' || self::role() === 'admin';
    }

    public static function isOwner(): bool {
        return self::role() === 'hall_owner';
    }

    public static function isCustomer(): bool {
        return self::role() === 'customer';
    }

    public static function isEmployee(): bool {
        return self::role() === 'employee';
    }

    /**
     * Check if user has a specific permission
     */
    public static function hasPermission(string $permissionSlug): bool {
        if (!self::check()) return false;
        if (self::isSuperAdmin()) return true; // Super admin possesses all permissions

        $perms = $_SESSION['user_permissions'] ?? [];
        return in_array($permissionSlug, $perms);
    }

    /**
     * Get full user data from database with profile
     */
    public static function user(): ?array {
        if (!self::check()) return null;
        return Database::fetchOne("
            SELECT u.*, r.slug as role_slug, r.name_ar as role_name_ar
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ", [self::id()]);
    }

    /**
     * Log the current user out
     */
    public static function logout(): void {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION = [];
        if (ini_get("session.use_cookies") && !headers_sent()) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    /**
     * Require that user is logged in
     */
    public static function requireLogin(): void {
        if (!self::check()) {
            setFlash('warning', __('login_to_continue') ?: 'يرجى تسجيل الدخول أولاً للوصول إلى هذه الصفحة.');
            redirect(BASE_URL . '/login.php');
        }
    }

    /**
     * Require one or more specific roles
     */
    public static function requireRole($allowedRoles): void {
        self::requireLogin();
        $roles = is_array($allowedRoles) ? $allowedRoles : [$allowedRoles];
        
        // Match both 'admin' and 'super_admin' for backwards compatibility
        if (in_array('admin', $roles) && self::isSuperAdmin()) {
            return;
        }

        if (!in_array(self::role(), $roles)) {
            setFlash('danger', __('access_denied') ?: 'عذراً، لا تمتلك الصلاحية الكافية لدخول هذه الصفحة.');
            redirect(BASE_URL . '/index.php');
        }
    }

    /**
     * Require a specific permission slug
     */
    public static function requirePermission(string $permissionSlug): void {
        self::requireLogin();
        if (!self::hasPermission($permissionSlug)) {
            setFlash('danger', 'عذراً، حسابك لا يمتلك الصلاحية: ' . $permissionSlug);
            redirect(BASE_URL . '/dashboard.php');
        }
    }
}
