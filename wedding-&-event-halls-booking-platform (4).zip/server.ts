import express from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { getDb } from './src/server/db.ts';
import { apiRouter } from './src/server/api.ts';

export async function createAppServer() {
  // Initialize SQLite database & non-destructive schema evolution
  getDb();

  const app = express();
  app.use(express.json({ limit: '5mb' }));
  app.use('/uploads', express.static(path.resolve(process.cwd(), 'uploads')));

  // Mount REST API
  app.use('/api', apiRouter);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  return app;
}

const PORT = Number(process.env.PORT) || 3000;

if (process.env.NODE_ENV !== 'test') {
  createAppServer().then((app) => {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`Munasabati Marketplace Server listening on http://0.0.0.0:${PORT}`);
    });
  });
}
