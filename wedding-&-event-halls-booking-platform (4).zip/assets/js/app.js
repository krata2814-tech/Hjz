/**
 * Wedding & Event Halls Booking Platform
 * JavaScript Application Logic
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Initialize Bootstrap Tooltips
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // 2. Mobile Navbar: Auto-close collapsed menu when clicking a nav link
    const navLinks = document.querySelectorAll('.navbar-collapse .nav-link');
    const navCollapse = document.getElementById('mainNav');
    if (navCollapse && typeof bootstrap !== 'undefined') {
        navLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                if (window.innerWidth < 992 && navCollapse.classList.contains('show')) {
                    const bsCollapse = bootstrap.Collapse.getInstance(navCollapse) || new bootstrap.Collapse(navCollapse);
                    bsCollapse.hide();
                }
            });
        });
    }

    // 3. Auto-dismiss alert messages after 5 seconds
    const flashAlerts = document.querySelectorAll('.alert-dismissible');
    flashAlerts.forEach(function (alert) {
        setTimeout(function () {
            if (typeof bootstrap !== 'undefined') {
                const bsAlert = bootstrap.Alert.getInstance(alert);
                if (bsAlert) bsAlert.close();
            } else {
                alert.style.opacity = '0';
                setTimeout(function () { alert.style.display = 'none'; }, 300);
            }
        }, 5000);
    });

    // 4. Client-side Form Validation Feedback
    const forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // 5. Date picker: constrain minimum event date to today
    const dateInputs = document.querySelectorAll('input[type="date"].min-today');
    if (dateInputs.length > 0) {
        const today = new Date().toISOString().split('T')[0];
        dateInputs.forEach(function (input) {
            input.setAttribute('min', today);
        });
    }
});
