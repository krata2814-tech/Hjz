<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Public Booking Inquiry & Venue Consultation Page
 */

$page_title = 'طلب استفسار وحجز قاعة | استشارة مجانية';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

$preselectedHallId = (int) get('hall_id', 0);

// Fetch Active Halls for Dropdown
try {
    $hallsList = Database::fetchAll("
        SELECT id, name_ar, city, capacity_min, capacity_max, price_evening, currency 
        FROM halls 
        WHERE status = 'active' 
        ORDER BY city ASC, featured DESC, name_ar ASC
    ");
} catch (Exception $e) {
    $hallsList = [];
}

$errorMessage = null;
$successData = null;

if (isPost()) {
    CSRF::verifyOrDie();
    $hallId = (int) post('hall_id', 0);
    $senderName = sanitize(post('sender_name'));
    $senderPhone = sanitize(post('sender_phone'));
    $senderEmail = sanitize(post('sender_email'));
    $eventType = sanitize(post('event_type', 'wedding'));
    $eventDate = sanitize(post('event_date'));
    $shift = sanitize(post('shift', 'evening'));
    $guestEstimate = (int) post('guest_estimate', 0);
    $budgetRange = sanitize(post('budget_range'));
    $message = sanitize(post('message'));

    if (empty($senderName) || empty($senderPhone)) {
        $errorMessage = Lang::isRtl() ? 'يرجى إدخال اسمك الكريم ورقم هاتفك للتواصل.' : 'Please enter your name and phone number.';
    } elseif (!empty($senderEmail) && !filter_var($senderEmail, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = Lang::isRtl() ? 'يرجى إدخال عنوان بريد إلكتروني صحيح.' : 'Please enter a valid email address.';
    } else {
        try {
            $userId = Auth::id() ?: null;
            $targetHallId = ($hallId > 0) ? $hallId : ($hallsList[0]['id'] ?? 1);

            $inquiryText = "طلب استفسار وحجز (" . getOccasionTypeName($eventType) . ")\n" .
                           "الفترة: " . ($shift === 'morning' ? 'صباحية' : ($shift === 'full_day' ? 'يوم كامل' : 'مسائية')) . "\n" .
                           ($budgetRange ? ("الميزانية المتوقعة: " . $budgetRange . "\n") : "") .
                           "ملاحظات العميل: " . ($message ?: 'طلب حجز واستفسار عام');

            Database::insert("
                INSERT INTO inquiries (hall_id, user_id, sender_name, sender_phone, sender_email, event_type, event_date, guest_estimate, message, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', CURRENT_TIMESTAMP)
            ", [
                $targetHallId,
                $userId,
                $senderName,
                $senderPhone,
                $senderEmail ?: null,
                $eventType,
                !empty($eventDate) ? $eventDate : null,
                $guestEstimate > 0 ? $guestEstimate : null,
                $inquiryText
            ]);

            // Selected hall details for summary
            $selectedHall = null;
            foreach ($hallsList as $h) {
                if ($h['id'] == $targetHallId) {
                    $selectedHall = $h;
                    break;
                }
            }

            $successData = [
                'ref' => 'INQ-' . strtoupper(substr(md5(uniqid()), 0, 8)),
                'name' => $senderName,
                'phone' => $senderPhone,
                'hall' => $selectedHall ? $selectedHall['name_ar'] : 'استشارة عامة لترشيح قاعة',
                'event_type' => getOccasionTypeName($eventType),
                'date' => $eventDate ?: 'غير محدد بدقة بعد',
            ];
        } catch (Exception $e) {
            $errorMessage = Lang::isRtl() ? 'حدث خطأ أثناء حفظ طلبك: ' . $e->getMessage() : 'Error submitting inquiry.';
        }
    }
}
?>

<!-- Hero Header -->
<section class="py-5 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
    <div class="container text-center py-3">
        <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i class="bi bi-calendar2-heart me-1 ms-1"></i> <?= Lang::isRtl() ? 'خدمة استشارية وتنسيق مجاني' : 'Free Consultation' ?>
        </span>
        <h1 class="display-6 fw-bold text-white mb-2"><?= Lang::isRtl() ? 'طلب استفسار وحجز قاعة مناسبات' : 'Venue Inquiry & Booking Request' ?></h1>
        <p class="text-white-50 mx-auto small fs-6" style="max-width: 650px;">
            <?= Lang::isRtl() 
                ? 'أرسل تفاصيل مناسبتك، وسيقوم فريق التنسيق وإدارة القاعة بالتواصل الفوري معك لتأكيد المواعيد الشاغرة وتقديم أفضل الباقات الحصرية.' 
                : 'Submit your event requirements and venue management will get in touch with available dates and packages.' ?>
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-12">
            
            <?php if ($successData): ?>
                <!-- Success Receipt Card -->
                <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white text-center">
                    <div class="rounded-circle bg-success bg-opacity-10 text-success d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 70px; height: 70px; font-size: 2.2rem;">
                        <i class="bi bi-check2-circle"></i>
                    </div>
                    <span class="badge bg-gold text-dark px-3 py-1 rounded-pill fw-bold mb-2"><?= e($successData['ref']) ?></span>
                    <h2 class="h4 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'تم استلام طلب الاستفسار بنجاح!' : 'Inquiry Received Successfully!' ?></h2>
                    <p class="text-muted small mb-4">
                        <?= Lang::isRtl() 
                            ? 'شكراً لك أستاذ ' . e($successData['name']) . '، تم توجيه طلبك مباشرة إلى إدارة ' . e($successData['hall']) . ' وسيتم الاتصال بك على الرقم (' . e($successData['phone']) . ').'
                            : 'Thank you! Your inquiry has been forwarded to hall coordinators.' ?>
                    </p>

                    <div class="p-3 rounded-3 bg-light border text-start mb-4 small">
                        <div class="row g-2">
                            <div class="col-sm-6"><strong><?= Lang::isRtl() ? 'القاعة المستهدفة:' : 'Selected Venue:' ?></strong> <?= e($successData['hall']) ?></div>
                            <div class="col-sm-6"><strong><?= Lang::isRtl() ? 'نوع المناسبة:' : 'Event Type:' ?></strong> <?= e($successData['event_type']) ?></div>
                            <div class="col-sm-6"><strong><?= Lang::isRtl() ? 'التاريخ المقترح:' : 'Target Date:' ?></strong> <?= e($successData['date']) ?></div>
                            <div class="col-sm-6"><strong><?= Lang::isRtl() ? 'حالة الطلب:' : 'Status:' ?></strong> <span class="badge bg-primary">جديد قيد المتابعة</span></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center gap-2 flex-wrap">
                        <a href="https://wa.me/967770000001?text=<?= urlencode('مرحباً، أرسلت طلب استفسار برقم مرجعي: ' . $successData['ref'] . ' بخصوص قاعة ' . $successData['hall']) ?>" target="_blank" class="btn btn-success d-flex align-items-center gap-2">
                            <i class="bi bi-whatsapp"></i>
                            <span><?= Lang::isRtl() ? 'متابعة سريعة عبر الواتساب' : 'Follow up via WhatsApp' ?></span>
                        </a>
                        <a href="<?= BASE_URL ?>/halls.php" class="btn btn-outline-dark-green">
                            <?= Lang::isRtl() ? 'استكشاف قاعات أخرى' : 'Explore Other Venues' ?>
                        </a>
                    </div>
                </div>
            <?php else: ?>

                <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white">
                    <div class="mb-4">
                        <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'استمارة الحجز والتنسيق المباشر' : 'Booking & Inquiry Form' ?></span>
                        <h2 class="h4 fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'أدخل تفاصيل مناسبتك السعيدة' : 'Fill in your celebration details' ?></h2>
                        <p class="text-muted small"><?= Lang::isRtl() ? 'الحقول المميزة بـ (*) مطلوبة لتنسيق الموعد وتزويدك بالأسعار الرسمية.' : 'Fields marked with (*) are required.' ?></p>
                    </div>

                    <?php if ($errorMessage): ?>
                        <div class="alert alert-danger py-2 small shadow-sm rounded-3 mb-4">
                            <i class="bi bi-exclamation-triangle-fill me-1 ms-1"></i> <?= e($errorMessage) ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/inquiry.php" method="POST" class="needs-validation">
                        <?= CSRF::getFormField() ?>

                        <!-- Row 1: Hall Selection & Occasion Type -->
                        <div class="row g-3 mb-3">
                            <div class="col-md-7 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-building text-gold"></i> <?= Lang::isRtl() ? 'القاعة أو القصر المطلوب' : 'Select Venue' ?> <span class="text-danger">*</span>
                                </label>
                                <select name="hall_id" class="form-select" required>
                                    <option value="0"><?= Lang::isRtl() ? '--- ترشيح أفضل قاعة مناسبة (استشارة عامة) ---' : 'General consultation' ?></option>
                                    <?php foreach ($hallsList as $h): ?>
                                        <option value="<?= $h['id'] ?>" <?= ($preselectedHallId == $h['id']) ? 'selected' : '' ?>>
                                            <?= e($h['name_ar']) ?> (<?= e(getCityName($h['city'])) ?> - سعة <?= $h['capacity_max'] ?> ضيف)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-5 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-calendar2-heart text-gold"></i> <?= Lang::isRtl() ? 'نوع المناسبة' : 'Event Type' ?> <span class="text-danger">*</span>
                                </label>
                                <select name="event_type" class="form-select" required>
                                    <option value="wedding"><?= e(__('type_wedding')) ?></option>
                                    <option value="engagement"><?= e(__('type_engagement')) ?></option>
                                    <option value="graduation"><?= e(__('type_graduation')) ?></option>
                                    <option value="conference"><?= e(__('type_conference')) ?></option>
                                    <option value="family"><?= e(__('type_family')) ?></option>
                                </select>
                            </div>
                        </div>

                        <!-- Row 2: Date, Shift, Guests -->
                        <div class="row g-3 mb-3">
                            <div class="col-md-4 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-calendar-event text-gold"></i> <?= Lang::isRtl() ? 'تاريخ المناسبة التقريبي' : 'Approximate Date' ?>
                                </label>
                                <input type="date" name="event_date" class="form-control min-today" value="<?= e(post('event_date', get('date', ''))) ?>">
                            </div>

                            <div class="col-md-4 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-clock text-gold"></i> <?= Lang::isRtl() ? 'الفترة المطلوبة' : 'Preferred Shift' ?>
                                </label>
                                <select name="shift" class="form-select">
                                    <option value="evening"><?= Lang::isRtl() ? 'مسائية (عرس / زفاف)' : 'Evening (Wedding)' ?></option>
                                    <option value="morning"><?= Lang::isRtl() ? 'صباحية (تخرج / ندوة)' : 'Morning' ?></option>
                                    <option value="full_day"><?= Lang::isRtl() ? 'يوم كامل' : 'Full Day' ?></option>
                                </select>
                            </div>

                            <div class="col-md-4 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-people text-gold"></i> <?= Lang::isRtl() ? 'عدد الضيوف المتوقع' : 'Estimated Guests' ?>
                                </label>
                                <input type="number" name="guest_estimate" class="form-control" placeholder="<?= Lang::isRtl() ? 'مثال: 350' : '350' ?>" min="50" max="2500" value="<?= e(post('guest_estimate', get('capacity', ''))) ?>">
                            </div>
                        </div>

                        <!-- Row 3: Name & Phone -->
                        <div class="row g-3 mb-3">
                            <div class="col-md-6 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-person text-gold"></i> <?= Lang::isRtl() ? 'الاسم الكريم' : 'Your Name' ?> <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="sender_name" class="form-control" placeholder="<?= Lang::isRtl() ? 'مثال: أحمد عبد الله' : 'e.g. Ahmed' ?>" value="<?= e(post('sender_name', Auth::name() ?? '')) ?>" required>
                            </div>

                            <div class="col-md-6 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-telephone text-gold"></i> <?= Lang::isRtl() ? 'رقم الهاتف / الواتساب' : 'Phone / WhatsApp' ?> <span class="text-danger">*</span>
                                </label>
                                <input type="tel" name="sender_phone" class="form-control" placeholder="<?= Lang::isRtl() ? '770000000' : 'Phone number' ?>" value="<?= e(post('sender_phone', Auth::user()['phone'] ?? '')) ?>" required>
                            </div>
                        </div>

                        <!-- Row 4: Email & Budget -->
                        <div class="row g-3 mb-3">
                            <div class="col-md-6 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-envelope text-gold"></i> <?= Lang::isRtl() ? 'البريد الإلكتروني (اختياري)' : 'Email (Optional)' ?>
                                </label>
                                <input type="email" name="sender_email" class="form-control" placeholder="user@example.com" value="<?= e(post('sender_email', Auth::user()['email'] ?? '')) ?>">
                            </div>

                            <div class="col-md-6 col-12">
                                <label class="form-label small fw-bold text-dark-green">
                                    <i class="bi bi-cash-stack text-gold"></i> <?= Lang::isRtl() ? 'الميزانية التقريبية' : 'Budget Estimate' ?>
                                </label>
                                <select name="budget_range" class="form-select">
                                    <option value=""><?= Lang::isRtl() ? 'غير محدد' : 'Not specified' ?></option>
                                    <option value="economy"><?= Lang::isRtl() ? 'اقتصادية (أقل من 400,000 ريال)' : 'Economy (< 400,000 YER)' ?></option>
                                    <option value="medium"><?= Lang::isRtl() ? 'متوسطة (400,000 - 800,000 ريال)' : 'Medium (400k - 800k YER)' ?></option>
                                    <option value="vip"><?= Lang::isRtl() ? 'ملكية فاخرة VIP (أكثر من 800,000 ريال)' : 'Luxury VIP (> 800k YER)' ?></option>
                                </select>
                            </div>
                        </div>

                        <!-- Notes & Requirements -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-dark-green">
                                <i class="bi bi-chat-left-text text-gold"></i> <?= Lang::isRtl() ? 'طلبات خاصة أو استفسارات إضافية' : 'Special Requirements' ?>
                            </label>
                            <textarea name="message" rows="4" class="form-control" placeholder="<?= Lang::isRtl() ? 'هل تحتاج إلى خدمات إضافية مثل: بوفيه مفتوح، كوشة خاصة، تصوير وفيديو، زفة، أو إمكانية التفاوض في الأسعار؟' : 'Any special requests regarding catering, sound, Kosha...' ?>"><?= e(post('message')) ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-gold w-100 py-3 fw-bold d-flex align-items-center justify-content-center gap-2">
                            <i class="bi bi-calendar-check-fill fs-5"></i>
                            <span><?= Lang::isRtl() ? 'إرسال طلب الاستفسار والتنسيق الآن' : 'Submit Booking Inquiry' ?></span>
                        </button>
                    </form>

                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
