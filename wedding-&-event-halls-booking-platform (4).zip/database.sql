-- ============================================================================
-- Wedding & Event Halls Booking Platform
-- منصة حجز قاعات الأفراح والمناسبات
-- Complete Production Relational Database Schema
-- File: database.sql
-- Engine: MySQL 8.0+ / MariaDB 10.5+
-- Storage Engine: InnoDB | Character Set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `wedding_halls_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `wedding_halls_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------------------
-- Drop existing tables in reverse dependency order
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS `platform_settings`;
DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `favorites`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `inquiry_messages`;
DROP TABLE IF EXISTS `inquiries`;
DROP TABLE IF EXISTS `payment_records`;
DROP TABLE IF EXISTS `booking_status_history`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `owner_subscriptions`;
DROP TABLE IF EXISTS `subscription_plans`;
DROP TABLE IF EXISTS `hall_availability`;
DROP TABLE IF EXISTS `hall_pricing`;
DROP TABLE IF EXISTS `hall_facilities`;
DROP TABLE IF EXISTS `facilities`;
DROP TABLE IF EXISTS `hall_images`;
DROP TABLE IF EXISTS `halls`;
DROP TABLE IF EXISTS `employee_profiles`;
DROP TABLE IF EXISTS `customer_profiles`;
DROP TABLE IF EXISTS `owner_profiles`;
DROP TABLE IF EXISTS `user_permissions`;
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- 1. ROLES & PERMISSIONS SYSTEM
-- ============================================================================

-- 1.1 Roles Master Table
CREATE TABLE `roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(100) NOT NULL,
    `name_en` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(50) NOT NULL UNIQUE,
    `description` VARCHAR(255) NULL,
    `is_system` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_roles_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.2 Permissions Master Table
CREATE TABLE `permissions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(150) NOT NULL,
    `name_en` VARCHAR(150) NOT NULL,
    `slug` VARCHAR(100) NOT NULL UNIQUE,
    `module` VARCHAR(50) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_perm_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1.3 Role Permissions Pivot Table
CREATE TABLE `role_permissions` (
    `role_id` INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    PRIMARY KEY (`role_id`, `permission_id`),
    CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 2. USERS & PROFILES MODULE
-- ============================================================================

-- 2.1 Users Core Table
CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL UNIQUE,
    `phone` VARCHAR(30) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `status` ENUM('active', 'pending_approval', 'suspended', 'banned') NOT NULL DEFAULT 'active',
    `avatar` VARCHAR(255) NULL,
    `last_login_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_role_id` (`role_id`),
    INDEX `idx_users_status` (`status`),
    INDEX `idx_users_email` (`email`),
    CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.2 Granular User Permissions Override Table
CREATE TABLE `user_permissions` (
    `user_id` INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    `is_granted` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`user_id`, `permission_id`),
    CONSTRAINT `fk_up_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_up_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.3 Hall Owner Profile Table
CREATE TABLE `owner_profiles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL UNIQUE,
    `business_name` VARCHAR(191) NOT NULL,
    `commercial_registration_no` VARCHAR(100) NULL,
    `tax_number` VARCHAR(100) NULL,
    `national_id_number` VARCHAR(100) NULL,
    `id_document_path` VARCHAR(255) NULL,
    `bank_name` VARCHAR(100) NULL,
    `bank_account_number` VARCHAR(100) NULL,
    `bank_iban` VARCHAR(100) NULL,
    `is_verified` TINYINT(1) NOT NULL DEFAULT 0,
    `verified_at` DATETIME NULL,
    `verified_by` INT UNSIGNED NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_op_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_op_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.4 Customer Profile Table
CREATE TABLE `customer_profiles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL UNIQUE,
    `preferred_city` VARCHAR(50) NULL,
    `wedding_date_estimate` DATE NULL,
    `emergency_phone` VARCHAR(30) NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_cp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 3. HALLS, GALLERIES, & FACILITIES MODULE
-- ============================================================================

-- 3.1 Venues & Halls Master Table
CREATE TABLE `halls` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `owner_id` INT UNSIGNED NOT NULL,
    `name_ar` VARCHAR(191) NOT NULL,
    `name_en` VARCHAR(191) NULL,
    `slug` VARCHAR(191) NOT NULL UNIQUE,
    `description_ar` TEXT NOT NULL,
    `description_en` TEXT NULL,
    `city` VARCHAR(50) NOT NULL,
    `district` VARCHAR(100) NULL,
    `address` VARCHAR(255) NOT NULL,
    `map_lat` DECIMAL(10, 8) NULL,
    `map_lng` DECIMAL(11, 8) NULL,
    `capacity_min` INT UNSIGNED NOT NULL DEFAULT 100,
    `capacity_max` INT UNSIGNED NOT NULL DEFAULT 800,
    `hall_type` ENUM('wedding', 'engagement', 'graduation', 'conference', 'family', 'multi_purpose') NOT NULL DEFAULT 'wedding',
    `featured` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('active', 'pending_approval', 'rejected', 'maintenance') NOT NULL DEFAULT 'pending_approval',
    `rejection_reason` TEXT NULL,
    `rating` DECIMAL(3, 2) NOT NULL DEFAULT 5.00,
    `reviews_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_halls_city` (`city`),
    INDEX `idx_halls_type` (`hall_type`),
    INDEX `idx_halls_status` (`status`),
    INDEX `idx_halls_featured` (`featured`),
    INDEX `idx_halls_owner` (`owner_id`),
    CONSTRAINT `fk_halls_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2.5 Employee Profile Table (Linked to both Users and Halls)
CREATE TABLE `employee_profiles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL UNIQUE,
    `owner_id` INT UNSIGNED NOT NULL,
    `hall_id` INT UNSIGNED NULL,
    `job_title` VARCHAR(100) NOT NULL,
    `department` VARCHAR(100) NULL,
    `hire_date` DATE NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ep_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ep_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ep_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.2 Hall Images Gallery
CREATE TABLE `hall_images` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `image_url` VARCHAR(255) NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `caption` VARCHAR(150) NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_images_hall` (`hall_id`),
    CONSTRAINT `fk_images_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.3 Facilities Master Table
CREATE TABLE `facilities` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(100) NOT NULL,
    `name_en` VARCHAR(100) NOT NULL,
    `icon` VARCHAR(50) NOT NULL DEFAULT 'bi-stars',
    `category` ENUM('comfort', 'decor', 'lighting', 'audio', 'hospitality', 'parking', 'utility', 'multimedia', 'security') NOT NULL DEFAULT 'comfort',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_facilities_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3.4 Hall Facilities Mapping Table
CREATE TABLE `hall_facilities` (
    `hall_id` INT UNSIGNED NOT NULL,
    `facility_id` INT UNSIGNED NOT NULL,
    `details` VARCHAR(255) NULL,
    `is_complimentary` TINYINT(1) NOT NULL DEFAULT 1,
    `extra_charge` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    PRIMARY KEY (`hall_id`, `facility_id`),
    CONSTRAINT `fk_hf_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_hf_facility` FOREIGN KEY (`facility_id`) REFERENCES `facilities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 4. PRICING & CALENDAR AVAILABILITY MODULE
-- ============================================================================

-- 4.1 Granular Hall Pricing Schedules
CREATE TABLE `hall_pricing` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `title_ar` VARCHAR(150) NOT NULL,
    `title_en` VARCHAR(150) NULL,
    `shift` ENUM('morning', 'evening', 'full_day') NOT NULL DEFAULT 'evening',
    `day_type` ENUM('all_days', 'weekdays', 'weekend', 'thursday_friday') NOT NULL DEFAULT 'all_days',
    `base_price` DECIMAL(12, 2) NOT NULL,
    `deposit_required` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `season` ENUM('regular', 'high_season_summer', 'eid_holidays', 'custom') NOT NULL DEFAULT 'regular',
    `valid_from` DATE NULL,
    `valid_to` DATE NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_pricing_hall` (`hall_id`),
    INDEX `idx_pricing_shift` (`shift`),
    CONSTRAINT `fk_pricing_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4.2 Hall Availability Calendar Matrix
CREATE TABLE `hall_availability` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `date` DATE NOT NULL,
    `shift` ENUM('morning', 'evening', 'full_day') NOT NULL DEFAULT 'evening',
    `status` ENUM('available', 'reserved_pending', 'booked_confirmed', 'blocked_maintenance') NOT NULL DEFAULT 'available',
    `booking_id` INT UNSIGNED NULL,
    `reason` VARCHAR(255) NULL,
    `updated_by` INT UNSIGNED NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_hall_date_shift` (`hall_id`, `date`, `shift`),
    INDEX `idx_avail_date` (`date`),
    INDEX `idx_avail_status` (`status`),
    CONSTRAINT `fk_avail_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_avail_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 5. SUBSCRIPTION PLANS FOR HALL OWNERS
-- ============================================================================

-- 5.1 Platform Subscription Plans Table
CREATE TABLE `subscription_plans` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(100) NOT NULL,
    `name_en` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(50) NOT NULL UNIQUE,
    `description` TEXT NULL,
    `price` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `billing_period_months` INT UNSIGNED NOT NULL DEFAULT 1,
    `max_halls_allowed` INT UNSIGNED NOT NULL DEFAULT 1,
    `featured_halls_quota` INT UNSIGNED NOT NULL DEFAULT 0,
    `commission_rate_percentage` DECIMAL(5, 2) NOT NULL DEFAULT 0.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5.2 Hall Owner Active Subscriptions
CREATE TABLE `owner_subscriptions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `owner_id` INT UNSIGNED NOT NULL,
    `plan_id` INT UNSIGNED NOT NULL,
    `starts_at` DATETIME NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `amount_paid` DECIMAL(12, 2) NOT NULL,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `payment_status` ENUM('paid', 'pending', 'expired') NOT NULL DEFAULT 'pending',
    `auto_renew` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sub_owner` (`owner_id`),
    INDEX `idx_sub_expires` (`expires_at`),
    CONSTRAINT `fk_sub_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_sub_plan` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 6. BOOKINGS & STATUS HISTORY MODULE
-- ============================================================================

-- 6.1 Bookings Master Table
CREATE TABLE `bookings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `booking_code` VARCHAR(30) NOT NULL UNIQUE,
    `hall_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED NOT NULL,
    `pricing_id` INT UNSIGNED NULL,
    `event_date` DATE NOT NULL,
    `shift` ENUM('morning', 'evening', 'full_day') NOT NULL DEFAULT 'evening',
    `guest_count` INT UNSIGNED NOT NULL DEFAULT 200,
    `subtotal_amount` DECIMAL(12, 2) NOT NULL,
    `discount_amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(12, 2) NOT NULL,
    `deposit_amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `remaining_amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `status` ENUM('pending', 'confirmed', 'rejected', 'cancelled', 'completed') NOT NULL DEFAULT 'pending',
    `payment_status` ENUM('unpaid', 'deposit_paid', 'partially_paid', 'fully_paid', 'refunded') NOT NULL DEFAULT 'unpaid',
    `customer_notes` TEXT NULL,
    `admin_notes` TEXT NULL,
    `confirmed_at` DATETIME NULL,
    `cancelled_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_bookings_date` (`event_date`),
    INDEX `idx_bookings_status` (`status`),
    INDEX `idx_bookings_shift` (`shift`),
    INDEX `idx_bookings_hall` (`hall_id`),
    INDEX `idx_bookings_customer` (`customer_id`),
    CONSTRAINT `fk_bookings_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_bookings_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_bookings_pricing` FOREIGN KEY (`pricing_id`) REFERENCES `hall_pricing` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add circular foreign key from hall_availability to bookings
ALTER TABLE `hall_availability`
ADD CONSTRAINT `fk_avail_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL;

-- 6.2 Booking Status Audit History Table
CREATE TABLE `booking_status_history` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `booking_id` INT UNSIGNED NOT NULL,
    `old_status` VARCHAR(50) NULL,
    `new_status` VARCHAR(50) NOT NULL,
    `changed_by` INT UNSIGNED NOT NULL,
    `comment` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_bsh_booking` (`booking_id`),
    CONSTRAINT `fk_bsh_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bsh_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 7. FINANCIAL TRANSACTIONS & PAYMENT RECORDS
-- ============================================================================

-- 7.1 Payment Records Table
CREATE TABLE `payment_records` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `payment_reference` VARCHAR(50) NOT NULL UNIQUE,
    `booking_id` INT UNSIGNED NULL,
    `subscription_id` INT UNSIGNED NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `amount` DECIMAL(12, 2) NOT NULL,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `payment_method` ENUM('cash_on_site', 'kuraimi', 'jawali', 'onecash', 'floosak', 'bank_transfer', 'credit_card') NOT NULL DEFAULT 'cash_on_site',
    `transaction_number` VARCHAR(100) NULL,
    `proof_document_path` VARCHAR(255) NULL,
    `payment_type` ENUM('booking_deposit', 'booking_balance', 'subscription_fee', 'refund') NOT NULL DEFAULT 'booking_deposit',
    `status` ENUM('pending_verification', 'verified_paid', 'rejected', 'refunded') NOT NULL DEFAULT 'pending_verification',
    `verified_by` INT UNSIGNED NULL,
    `verified_at` DATETIME NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_pay_booking` (`booking_id`),
    INDEX `idx_pay_user` (`user_id`),
    INDEX `idx_pay_status` (`status`),
    CONSTRAINT `fk_pay_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_pay_subscription` FOREIGN KEY (`subscription_id`) REFERENCES `owner_subscriptions` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_pay_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_pay_verified_by` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 8. INQUIRIES & MESSAGING MODULE
-- ============================================================================

-- 8.1 Inquiries Master Table
CREATE TABLE `inquiries` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `inquiry_code` VARCHAR(30) NOT NULL UNIQUE,
    `hall_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NULL,
    `sender_name` VARCHAR(150) NOT NULL,
    `sender_phone` VARCHAR(30) NOT NULL,
    `sender_email` VARCHAR(191) NULL,
    `event_type` VARCHAR(50) NOT NULL DEFAULT 'wedding',
    `event_date` DATE NULL,
    `shift` ENUM('morning', 'evening', 'full_day') NULL,
    `guest_estimate` INT UNSIGNED NULL,
    `subject` VARCHAR(191) NULL,
    `status` ENUM('new', 'in_progress', 'replied', 'closed') NOT NULL DEFAULT 'new',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_inquiries_hall` (`hall_id`),
    INDEX `idx_inquiries_user` (`user_id`),
    INDEX `idx_inquiries_status` (`status`),
    CONSTRAINT `fk_inquiries_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_inquiries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8.2 Inquiry Messages (Conversation Thread) Table
CREATE TABLE `inquiry_messages` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `inquiry_id` INT UNSIGNED NOT NULL,
    `sender_id` INT UNSIGNED NULL,
    `is_owner_reply` TINYINT(1) NOT NULL DEFAULT 0,
    `message` TEXT NOT NULL,
    `attachment_path` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_im_inquiry` (`inquiry_id`),
    CONSTRAINT `fk_im_inquiry` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiries` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_im_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 9. REVIEWS, FAVORITES, & NOTIFICATIONS
-- ============================================================================

-- 9.1 Multi-Criteria Reviews Table
CREATE TABLE `reviews` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED NOT NULL,
    `booking_id` INT UNSIGNED NULL,
    `rating_cleanliness` TINYINT UNSIGNED NOT NULL DEFAULT 5,
    `rating_hospitality` TINYINT UNSIGNED NOT NULL DEFAULT 5,
    `rating_services` TINYINT UNSIGNED NOT NULL DEFAULT 5,
    `rating_overall` TINYINT UNSIGNED NOT NULL CHECK (`rating_overall` BETWEEN 1 AND 5),
    `comment` TEXT NOT NULL,
    `owner_response` TEXT NULL,
    `owner_responded_at` DATETIME NULL,
    `status` ENUM('approved', 'pending_moderation', 'rejected') NOT NULL DEFAULT 'approved',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_reviews_hall` (`hall_id`),
    INDEX `idx_reviews_status` (`status`),
    CONSTRAINT `fk_reviews_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_reviews_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_reviews_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9.2 Customer Favorites / Wishlist Table
CREATE TABLE `favorites` (
    `user_id` INT UNSIGNED NOT NULL,
    `hall_id` INT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `hall_id`),
    CONSTRAINT `fk_fav_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_fav_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9.3 In-App System Notifications Table
CREATE TABLE `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `title_ar` VARCHAR(150) NOT NULL,
    `title_en` VARCHAR(150) NULL,
    `message_ar` TEXT NOT NULL,
    `message_en` TEXT NULL,
    `type` ENUM('booking_update', 'inquiry_reply', 'payment_update', 'system_announcement', 'hall_approved') NOT NULL DEFAULT 'booking_update',
    `link_url` VARCHAR(255) NULL,
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_notif_user` (`user_id`),
    INDEX `idx_notif_read` (`is_read`),
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 10. AUDIT LOGGING & PLATFORM SETTINGS
-- ============================================================================

-- 10.1 Security Audit Logs Table
CREATE TABLE `audit_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(50) NULL,
    `entity_id` INT UNSIGNED NULL,
    `details_json` TEXT NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_user` (`user_id`),
    INDEX `idx_audit_action` (`action`),
    INDEX `idx_audit_created` (`created_at`),
    CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10.2 Global Key-Value Platform Settings Table
CREATE TABLE `platform_settings` (
    `setting_key` VARCHAR(100) PRIMARY KEY,
    `setting_value` TEXT NOT NULL,
    `setting_group` ENUM('general', 'booking', 'financial', 'localization', 'security') NOT NULL DEFAULT 'general',
    `description` VARCHAR(255) NULL,
    `updated_by` INT UNSIGNED NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_settings_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- 11. INITIAL MASTER SEED DATA (System Roles, Permissions, Facilities, Settings)
-- NOTE: No Super Admin user is pre-created here to fulfill the critical requirement
-- that the first Super Admin is registered through the secure first-run installer.
-- ============================================================================

-- 11.1 System Roles
INSERT INTO `roles` (`id`, `name_ar`, `name_en`, `slug`, `description`, `is_system`) VALUES
(1, 'المدير العام للنظام', 'Super Administrator', 'super_admin', 'صلاحيات كاملة وغير مقيدة لإدارة المنصة، المستخدمين، القاعات، التقارير والتدقيق الأمني', 1),
(2, 'مالك / مدير قاعة', 'Hall Owner', 'hall_owner', 'إدارة القاعات الخاصة، الموظفين، الأسعار، تقويم المواعيد، الحجوزات واستفسارات الزوار', 1),
(3, 'عميل / باحث عن قاعة', 'Customer', 'customer', 'استكشاف القاعات وحجز المواعيد وإرسال الاستفسارات وكتابة التقييمات', 1),
(4, 'موظف قاعة', 'Hall Employee', 'employee', 'الوصول للوحدات المحددة من قبل مالك القاعة (استقبال، جداول، إدخال زوار)', 1);

-- 11.2 Master Permissions
INSERT INTO `permissions` (`id`, `name_ar`, `name_en`, `slug`, `module`) VALUES
(1, 'إدارة جميع المستخدمين', 'Manage Users', 'manage_users', 'users'),
(2, 'اعتماد وتعليق ملاك القاعات', 'Verify Owners', 'verify_owners', 'users'),
(3, 'إدارة إعدادات النظام', 'Manage System Settings', 'manage_settings', 'system'),
(4, 'الاطلاع على سجلات التدقيق', 'View Audit Logs', 'view_audit_logs', 'security'),
(5, 'إدارة باقات اشتراك الملاك', 'Manage Subscription Plans', 'manage_subscriptions', 'billing'),
(6, 'اعتماد وتعديل القاعات العامة', 'Moderate Halls', 'moderate_halls', 'halls'),
(7, 'إضافة وتعديل قاعاتي الخاصة', 'Manage Own Halls', 'manage_own_halls', 'halls'),
(8, 'إدارة أسعار وباقات القاعة', 'Manage Hall Pricing', 'manage_hall_pricing', 'pricing'),
(9, 'إدارة تقويم مواعيد القاعة', 'Manage Availability', 'manage_availability', 'calendar'),
(10, 'قبول وتأكيد حجوزات القاعة', 'Manage Hall Bookings', 'manage_hall_bookings', 'bookings'),
(11, 'الرد على استفسارات الزوار', 'Respond Inquiries', 'respond_inquiries', 'inquiries'),
(12, 'إدارة طاقم عمل القاعة', 'Manage Hall Staff', 'manage_hall_staff', 'staff'),
(13, 'حجز قاعات واستعراض العقود', 'Create Bookings', 'create_bookings', 'customer'),
(14, 'إرسال استفسارات لملاك القاعات', 'Send Inquiries', 'send_inquiries', 'customer'),
(15, 'تقييم القاعات المحجوزة', 'Review Halls', 'review_halls', 'customer');

-- 11.3 Assign Permissions to System Roles
-- Super Admin gets all permissions (1-15)
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, id FROM `permissions`;

-- Hall Owner permissions
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(2, 7), (2, 8), (2, 9), (2, 10), (2, 11), (2, 12);

-- Customer permissions
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(3, 13), (3, 14), (3, 15);

-- Employee default permissions (reception & calendar)
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(4, 9), (4, 10), (4, 11);

-- 11.4 Master Facilities Master List
INSERT INTO `facilities` (`id`, `name_ar`, `name_en`, `icon`, `category`) VALUES
(1, 'تكييف مركزي متطور', 'Central AC & Climate Control', 'bi-snow', 'comfort'),
(2, 'كوشة عصرية وتصميم ديكور فاخر', 'Modern Kosha & Luxury Decor', 'bi-gem', 'decor'),
(3, 'إضاءة مسرحية وليزر ومؤثرات ضوئية', 'Stage Lighting & Fog FX', 'bi-stars', 'lighting'),
(4, 'نظام صوتيات دي جي احترافي ومكروفونات لاسلكية', 'Pro Sound System & DJ', 'bi-soundwave', 'audio'),
(5, 'جناح ملكي خاص للعروس مع حمام مستقل', 'Private Bridal Suite', 'bi-heart-fill', 'comfort'),
(6, 'مواقف سيارات محروسة ومظللة', 'Spacious Secure Parking', 'bi-p-circle', 'parking'),
(7, 'مولدات كهرباء ديزل متواصلة (صفر انقطاع)', 'Backup Diesel Generators', 'bi-lightning-charge-fill', 'utility'),
(8, 'ضيافة قهوة عربية ومشروبات وبوفيه مفتوح', 'Hospitality & Open Buffet', 'bi-cup-hot-fill', 'hospitality'),
(9, 'طاقم أمني مدرب ومشرفات صالة نسائية', 'Security & Hostess Staff', 'bi-shield-check', 'security'),
(10, 'شاشات عرض عملاقة LED وتصوير احترافي', 'Giant LED Screens & Pro Video', 'bi-tv', 'multimedia');

-- 11.5 Default Subscription Plans for Venue Owners
INSERT INTO `subscription_plans` (`id`, `name_ar`, `name_en`, `slug`, `description`, `price`, `billing_period_months`, `max_halls_allowed`, `featured_halls_quota`, `commission_rate_percentage`, `is_active`) VALUES
(1, 'الباقة المجانية الأساسية', 'Basic Free Plan', 'free_starter', 'تمكّن مالك القاعة من إدراج قاعة واحدة واستقبال الحجوزات مع عمولة منصة 5%', 0.00, 12, 1, 0, 5.00, 1),
(2, 'الباقة الذهبية المميزة', 'Golden Venue Plan', 'golden_owner', 'إدراج حتى 3 صالات + قاعة مميزة في الصفحة الرئيسية + أولوية الظهور في نتائج البحث', 75000.00, 6, 3, 1, 2.50, 1),
(3, 'الباقة الماسية للقصور الكبرى', 'Diamond Grand Plan', 'diamond_vip', 'إدراج غير محدود للصالات + دعم فني مخصص + بدون أي عمولة إضافية على الحجوزات', 140000.00, 12, 10, 3, 0.00, 1);

-- 11.6 Platform Global Settings
INSERT INTO `platform_settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('site_name_ar', 'منصة إيوان لحجز قاعات الأفراح والمناسبات', 'general', 'الاسم الرسمي للمنصة باللغة العربية'),
('site_name_en', 'Iwan Halls & Wedding Venues Platform', 'general', 'Official platform name in English'),
('default_currency', 'YER', 'financial', 'العملة الأساسية المعتمدة لعرض الأسعار والحجوزات'),
('supported_currencies', 'YER,SAR,USD', 'financial', 'العملات الإضافية المدعومة للتحويل والعرض'),
('platform_timezone', 'Asia/Aden', 'localization', 'المنطقة الزمنية الرسمية للجمهورية اليمنية (توقيت مكة واليمن GMT+3)'),
('admin_email', 'krata2814@gmail.com', 'general', 'البريد الإلكتروني المعتمد لتلقي إشعارات الإدارة العامة'),
('contact_phone', '+967-1-445566', 'general', 'رقم الهاتف الرسمي لخدمة العملاء'),
('whatsapp_support', '+967770000001', 'general', 'رقم خدمة الدعم الفني المباشر عبر واتساب'),
('require_owner_verification', '1', 'security', 'اشتراط فحص السجل التجاري واعتماد مالك القاعة قبل نشر الصالات'),
('min_password_length', '8', 'security', 'الحد الأدنى لطول كلمات المرور لجميع المستخدمين');

-- 11.7 Initial Super Administrator Account (krata2814@gmail.com / 781802671)
INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `phone`, `password_hash`, `status`) VALUES
(1, 1, 'المدير العام للنظام (Super Admin)', 'krata2814@gmail.com', '+967781802671', '$2y$10$MunasabatiAdminSalt22u63Dcv.8lR4R9rD0zJ22fqvtzAZQswsG', 'active')
ON DUPLICATE KEY UPDATE
    `email` = 'krata2814@gmail.com',
    `password_hash` = '$2y$10$MunasabatiAdminSalt22u63Dcv.8lR4R9rD0zJ22fqvtzAZQswsG',
    `status` = 'active';

-- ============================================================================
-- 12. CONTACT & PASSWORD RESETS MODULE
-- ============================================================================

CREATE TABLE IF NOT EXISTS `contact_messages` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `subject` VARCHAR(191) NOT NULL,
    `message` TEXT NOT NULL,
    `status` ENUM('new', 'read', 'replied', 'archived') NOT NULL DEFAULT 'new',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_contact_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_resets` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `email` VARCHAR(191) NOT NULL,
    `token` VARCHAR(100) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_resets_email` (`email`),
    INDEX `idx_resets_token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
