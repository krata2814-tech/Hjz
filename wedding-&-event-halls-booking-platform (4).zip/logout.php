<?php
/**
 * Wedding & Event Halls Booking Platform
 * User Logout
 */

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/includes/auth.php';

Auth::logout();
setFlash('info', 'تم تسجيل الخروج بنجاح.');
redirect(BASE_URL . '/index.php');
