<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Multi-Role Dashboard (Super Admin, Hall Owner, Customer, Employee)
 */

$page_title = 'لوحة التحكم';
require_once __DIR__ . '/includes/auth.php';

Auth::requireLogin();

$user = Auth::user();
$role = Auth::role();
$userId = Auth::id();
$isSuperAdmin = Auth::isSuperAdmin();

$stats = [];
$recentBookings = [];
$recentInquiries = [];
$recentAuditLogs = [];
$pendingHalls = [];
$myHalls = [];

// Handle Admin Quick Actions (Approve/Reject Venue)
if (isPost() && $isSuperAdmin) {
    CSRF::verifyOrDie();
    $action = post('admin_action');
    $targetHallId = (int)post('target_hall_id');

    if ($targetHallId > 0 && in_array($action, ['approve_hall', 'reject_hall'])) {
        $newStatus = ($action === 'approve_hall') ? 'active' : 'rejected';
        try {
            Database::query("UPDATE halls SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $targetHallId]);
            
            // Record audit log
            Database::insert("
                INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent)
                VALUES (?, ?, 'halls', ?, ?, ?, ?)
            ", [
                $userId, $action, $targetHallId, 
                json_encode(['status' => $newStatus, 'hall_id' => $targetHallId]),
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
            ]);

            setFlash('success', ($action === 'approve_hall') ? 'تم اعتماد ونشر القاعة بنجاح!' : 'تم رفض إدراج القاعة.');
            redirect(BASE_URL . '/dashboard.php');
        } catch (Exception $e) {
            setFlash('danger', 'خطأ أثناء تنفيذ الإجراء: ' . $e->getMessage());
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

try {
    if ($isSuperAdmin) {
        $stats['total_users'] = Database::fetchOne("SELECT COUNT(*) as c FROM users")['c'] ?? 0;
        $stats['total_halls'] = Database::fetchOne("SELECT COUNT(*) as c FROM halls")['c'] ?? 0;
        $stats['total_bookings'] = Database::fetchOne("SELECT COUNT(*) as c FROM bookings")['c'] ?? 0;
        $stats['total_inquiries'] = Database::fetchOne("SELECT COUNT(*) as c FROM inquiries")['c'] ?? 0;

        $recentBookings = Database::fetchAll("
            SELECT b.*, h.name_ar as hall_name, u.name as customer_name, u.phone as customer_phone
            FROM bookings b
            JOIN halls h ON b.hall_id = h.id
            JOIN users u ON b.customer_id = u.id
            ORDER BY b.created_at DESC LIMIT 6
        ");

        $recentInquiries = Database::fetchAll("
            SELECT i.*, h.name_ar as hall_name
            FROM inquiries i
            JOIN halls h ON i.hall_id = h.id
            ORDER BY i.created_at DESC LIMIT 5
        ");

        $recentAuditLogs = Database::fetchAll("
            SELECT a.*, u.name as user_name, u.email as user_email
            FROM audit_logs a
            LEFT JOIN users u ON a.user_id = u.id
            ORDER BY a.created_at DESC LIMIT 6
        ");

        $pendingHalls = Database::fetchAll("
            SELECT h.*, u.name as owner_name, u.phone as owner_phone
            FROM halls h
            JOIN users u ON h.owner_id = u.id
            WHERE h.status = 'pending_approval'
            ORDER BY h.created_at DESC LIMIT 5
        ");
    } elseif ($role === 'hall_owner') {
        $myHalls = Database::fetchAll("SELECT * FROM halls WHERE owner_id = ?", [$userId]);
        $hallIds = array_column($myHalls, 'id');

        if (!empty($hallIds)) {
            $inClause = implode(',', array_map('intval', $hallIds));
            $stats['my_halls_count'] = count($myHalls);
            $stats['total_bookings'] = Database::fetchOne("SELECT COUNT(*) as c FROM bookings WHERE hall_id IN ($inClause)")['c'] ?? 0;
            $stats['pending_bookings'] = Database::fetchOne("SELECT COUNT(*) as c FROM bookings WHERE hall_id IN ($inClause) AND status = 'pending'")['c'] ?? 0;
            $stats['total_inquiries'] = Database::fetchOne("SELECT COUNT(*) as c FROM inquiries WHERE hall_id IN ($inClause)")['c'] ?? 0;

            $recentBookings = Database::fetchAll("
                SELECT b.*, h.name_ar as hall_name, u.name as customer_name, u.phone as customer_phone
                FROM bookings b
                JOIN halls h ON b.hall_id = h.id
                JOIN users u ON b.customer_id = u.id
                WHERE b.hall_id IN ($inClause)
                ORDER BY b.created_at DESC LIMIT 6
            ");

            $recentInquiries = Database::fetchAll("
                SELECT i.*, h.name_ar as hall_name
                FROM inquiries i
                JOIN halls h ON i.hall_id = h.id
                WHERE i.hall_id IN ($inClause)
                ORDER BY i.created_at DESC LIMIT 5
            ");
        } else {
            $stats['my_halls_count'] = 0;
            $stats['total_bookings'] = 0;
            $stats['pending_bookings'] = 0;
            $stats['total_inquiries'] = 0;
        }
    } else {
        // Customer View
        $stats['my_bookings_count'] = Database::fetchOne("SELECT COUNT(*) as c FROM bookings WHERE customer_id = ?", [$userId])['c'] ?? 0;
        $stats['my_inquiries_count'] = Database::fetchOne("SELECT COUNT(*) as c FROM inquiries WHERE user_id = ?", [$userId])['c'] ?? 0;

        $recentBookings = Database::fetchAll("
            SELECT b.*, h.name_ar as hall_name, h.city as hall_city, h.address as hall_address
            FROM bookings b
            JOIN halls h ON b.hall_id = h.id
            WHERE b.customer_id = ?
            ORDER BY b.created_at DESC LIMIT 10
        ", [$userId]);

        $recentInquiries = Database::fetchAll("
            SELECT i.*, h.name_ar as hall_name
            FROM inquiries i
            JOIN halls h ON i.hall_id = h.id
            WHERE i.user_id = ?
            ORDER BY i.created_at DESC LIMIT 5
        ", [$userId]);
    }
} catch (Exception $e) {
    // Graceful error handling
}
?>

<div class="container py-4">
    <!-- Header Banner -->
    <div class="card border rounded-3 shadow-sm p-4 mb-4 bg-white">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3">
            <div class="d-flex align-items-center gap-3">
                <div class="brand-icon-wrapper" style="width: 54px; height: 54px; font-size: 1.5rem;">
                    <i class="bi bi-person-circle"></i>
                </div>
                <div>
                    <h1 class="h4 fw-bold text-dark-green mb-1">
                        <?= Lang::isRtl() ? 'أهلاً وسهلاً، ' : 'Welcome, ' ?> <?= e($user['name']) ?>
                    </h1>
                    <div class="d-flex flex-wrap align-items-center gap-2 small text-muted">
                        <span class="badge bg-gold text-white">
                            <?php
                                switch ($role) {
                                    case 'super_admin':
                                    case 'admin': echo 'المدير العام للنظام (Super Admin)'; break;
                                    case 'hall_owner': echo e(__('role_hall_owner')); break;
                                    case 'employee': echo e(__('role_employee')); break;
                                    default: echo e(__('role_customer')); break;
                                }
                            ?>
                        </span>
                        <span>&bull;</span>
                        <span><i class="bi bi-envelope"></i> <?= e($user['email']) ?></span>
                        <span>&bull;</span>
                        <span><i class="bi bi-telephone"></i> <?= e($user['phone']) ?></span>
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2 w-100 w-sm-auto flex-wrap">
                <?php if ($isSuperAdmin): ?>
                    <a href="<?= BASE_URL ?>/admin/index.php" class="btn btn-gold btn-sm fw-bold shadow-sm d-flex align-items-center gap-1">
                        <i class="bi bi-shield-lock-fill"></i> لوحة الإدارة العليا (Super Admin Console)
                    </a>
                    <a href="<?= BASE_URL ?>/admin/halls.php" class="btn btn-outline-dark-green btn-sm fw-bold">
                        <i class="bi bi-building me-1 ms-1"></i> اعتماد القاعات
                    </a>
                <?php elseif ($role === 'hall_owner'): ?>
                    <a href="<?= BASE_URL ?>/halls.php" class="btn btn-outline-dark-green btn-sm w-100 w-sm-auto">
                        <i class="bi bi-eye me-1 ms-1"></i> استعراض القاعات
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Stats Cards Row -->
    <div class="row g-3 mb-4">
        <?php if ($isSuperAdmin): ?>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1">إجمالي المستخدمين</div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_users'] ?></div>
                    <small class="text-success"><i class="bi bi-people-fill"></i> جميع الأدوار</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1">إجمالي القاعات المسجلة</div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_halls'] ?></div>
                    <small class="text-gold"><i class="bi bi-building"></i> صالات وقصور</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1">إجمالي الحجوزات</div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_bookings'] ?></div>
                    <small class="text-primary"><i class="bi bi-calendar-check-fill"></i> جميع المناسبات</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1">استفسارات الزوار</div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_inquiries'] ?></div>
                    <small class="text-info"><i class="bi bi-chat-dots-fill"></i> استفسارات نشطة</small>
                </div>
            </div>
        <?php elseif ($role === 'hall_owner'): ?>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= e(__('my_halls')) ?></div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['my_halls_count'] ?></div>
                    <small class="text-gold"><i class="bi bi-building"></i> قاعات نشطة</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= e(__('total_bookings')) ?></div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_bookings'] ?></div>
                    <small class="text-success"><i class="bi bi-calendar-check"></i> مناسبات مسجلة</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= e(__('pending_bookings')) ?></div>
                    <div class="fs-3 fw-bold text-gold font-heading"><?= $stats['pending_bookings'] ?></div>
                    <small class="text-danger"><i class="bi bi-hourglass-split"></i> بحاجة لمراجعة</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= e(__('inquiries')) ?></div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['total_inquiries'] ?></div>
                    <small class="text-info"><i class="bi bi-chat-left-text"></i> استفسارات واردة</small>
                </div>
            </div>
        <?php else: ?>
            <div class="col-md-6 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= Lang::isRtl() ? 'حجوزاتي المؤكدة والمطلوبة' : 'My Bookings' ?></div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['my_bookings_count'] ?></div>
                    <small class="text-primary"><i class="bi bi-calendar2-heart-fill"></i> مناسبات سعيدة</small>
                </div>
            </div>
            <div class="col-md-6 col-6">
                <div class="card border rounded-3 p-3 bg-white shadow-sm h-100">
                    <div class="text-muted small mb-1"><?= Lang::isRtl() ? 'استفساراتي المرسلة' : 'Sent Inquiries' ?></div>
                    <div class="fs-3 fw-bold text-dark-green font-heading"><?= $stats['my_inquiries_count'] ?></div>
                    <small class="text-info"><i class="bi bi-chat-quote-fill"></i> تواصل مع إدارات القاعات</small>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Super Admin Specific: Security Audit Logs & Venue Moderation Queue -->
    <?php if ($isSuperAdmin && !empty($recentAuditLogs)): ?>
        <div class="card border rounded-3 p-4 mb-4 bg-white shadow-sm">
            <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                <i class="bi bi-shield-shaded text-gold"></i> سجلات التدقيق الأمني للمنظومة (Security Audit Logs)
            </h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th>المعرف</th>
                            <th>المستخدم</th>
                            <th>الحدث الأمني (Action)</th>
                            <th>الكيان (Entity)</th>
                            <th>عنوان IP</th>
                            <th>التاريخ والتوقيت</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentAuditLogs as $log): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $log['id'] ?></td>
                                <td>
                                    <strong><?= e($log['user_name'] ?: 'النظام / زائر') ?></strong>
                                    <?php if (!empty($log['user_email'])): ?>
                                        <div class="text-muted" style="font-size: 0.75rem;"><?= e($log['user_email']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark-green border">
                                        <?= e($log['action']) ?>
                                    </span>
                                </td>
                                <td><?= e($log['entity_type'] ?? '-') ?></td>
                                <td class="font-monospace text-muted"><?= e($log['ip_address'] ?? '127.0.0.1') ?></td>
                                <td><?= date('Y-m-d H:i:s', strtotime($log['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <!-- Bookings Table Section -->
    <div class="card border rounded-3 p-4 mb-4 bg-white shadow-sm">
        <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-calendar-range text-gold"></i> 
            <?= ($role === 'customer') ? (Lang::isRtl() ? 'جدول حجوزاتي' : 'My Bookings') : (Lang::isRtl() ? 'أحدث الحجوزات والمناسبات' : 'Recent Bookings') ?>
        </h5>

        <?php if (!empty($recentBookings)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small">
                        <tr>
                            <th>رقم الحجز</th>
                            <th>اسم القاعة</th>
                            <?php if ($role !== 'customer'): ?>
                                <th>اسم العميل</th>
                                <th>الهاتف</th>
                            <?php endif; ?>
                            <th>تاريخ المناسبة</th>
                            <th>الفترة</th>
                            <th>المبلغ الإجمالي</th>
                            <th>حالة الحجز</th>
                            <th>حالة الدفع</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php foreach ($recentBookings as $b): ?>
                            <tr>
                                <td class="fw-bold font-monospace text-dark-green"><?= e($b['booking_code']) ?></td>
                                <td>
                                    <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $b['hall_id'] ?>" class="text-dark-green fw-bold">
                                        <?= e($b['hall_name']) ?>
                                    </a>
                                </td>
                                <?php if ($role !== 'customer'): ?>
                                    <td><?= e($b['customer_name']) ?></td>
                                    <td><a href="tel:<?= e($b['customer_phone']) ?>" class="text-muted"><?= e($b['customer_phone']) ?></a></td>
                                <?php endif; ?>
                                <td class="fw-bold text-primary"><?= e($b['event_date']) ?></td>
                                <td>
                                    <?php
                                        switch ($b['shift']) {
                                            case 'morning': echo '<span class="badge bg-light text-dark-green border">صباحية</span>'; break;
                                            case 'full_day': echo '<span class="badge bg-dark-green">يوم كامل</span>'; break;
                                            default: echo '<span class="badge bg-gold text-white">مسائية (عرس)</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="fw-bold"><?= formatMoney($b['total_amount'], $b['currency']) ?></td>
                                <td>
                                    <?php
                                        switch ($b['status']) {
                                            case 'confirmed': echo '<span class="badge bg-success">مؤكد</span>'; break;
                                            case 'cancelled': echo '<span class="badge bg-danger">ملغي</span>'; break;
                                            case 'completed': echo '<span class="badge bg-info text-dark">مكتمل</span>'; break;
                                            default: echo '<span class="badge bg-warning text-dark">قيد الانتظار</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        switch ($b['payment_status']) {
                                            case 'fully_paid': echo '<span class="text-success fw-bold"><i class="bi bi-check-circle"></i> مدفوع بالكامل</span>'; break;
                                            case 'deposit_paid': echo '<span class="text-primary fw-bold"><i class="bi bi-clock"></i> مدفوع العربون</span>'; break;
                                            default: echo '<span class="text-muted"><i class="bi bi-dash-circle"></i> غير مسدد</span>'; break;
                                        }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-4 text-muted">
                <i class="bi bi-calendar-x fs-2 d-block mb-2 text-gold"></i>
                <p class="small mb-2"><?= Lang::isRtl() ? 'لا توجد حجوزات مسجلة حتى الآن.' : 'No bookings recorded yet.' ?></p>
                <?php if ($role === 'customer'): ?>
                    <a href="<?= BASE_URL ?>/halls.php" class="btn btn-gold btn-sm"><?= Lang::isRtl() ? 'استكشف القاعات واحجز موعدك' : 'Browse Halls' ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Inquiries Section -->
    <div class="card border rounded-3 p-4 bg-white shadow-sm">
        <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-chat-left-dots text-gold"></i>
            <?= ($role === 'customer') ? (Lang::isRtl() ? 'استفساراتي المرسلة للقاعات' : 'My Sent Inquiries') : (Lang::isRtl() ? 'استفسارات العملاء الواردة' : 'Customer Inquiries') ?>
        </h5>

        <?php if (!empty($recentInquiries)): ?>
            <div class="row g-3">
                <?php foreach ($recentInquiries as $inq): ?>
                    <div class="col-md-6 col-12">
                        <div class="p-3 bg-light rounded-3 border">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <div class="fw-bold text-dark-green"><?= e($inq['hall_name']) ?></div>
                                    <small class="text-muted"><?= e($inq['sender_name']) ?> &bull; <?= e($inq['sender_phone']) ?></small>
                                </div>
                                <span class="badge <?= ($inq['status'] === 'new') ? 'bg-danger' : 'bg-success' ?> small">
                                    <?= ($inq['status'] === 'new') ? 'جديد' : 'تم الرد' ?>
                                </span>
                            </div>
                            <p class="small text-secondary mb-2 bg-white p-2 rounded-2 border border-light">
                                "<?= e($inq['message']) ?>"
                            </p>
                            <div class="d-flex justify-content-between align-items-center text-muted" style="font-size: 0.75rem;">
                                <span><i class="bi bi-calendar-event"></i> المناسبة: <?= e(getOccasionTypeName($inq['event_type'])) ?></span>
                                <span><?= date('Y-m-d H:i', strtotime($inq['created_at'])) ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'لا توجد استفسارات حالية.' : 'No inquiries found.' ?></p>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
