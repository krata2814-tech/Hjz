<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Password Recovery Interface (Forgot Password)
 */

$page_title = 'استعادة كلمة المرور';
require_once __DIR__ . '/includes/auth.php';

if (Auth::check()) {
    redirect(Auth::isSuperAdmin() ? (BASE_URL . '/admin/index.php') : (BASE_URL . '/dashboard.php'));
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

$errorMessage = null;
$resetSuccess = false;
$resetLink = null;
$submittedEmail = '';

if (isPost()) {
    CSRF::verifyOrDie();
    $email = strtolower(sanitize(post('email')));
    $submittedEmail = $email;

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = Lang::isRtl() ? 'يرجى إدخال عنوان بريد إلكتروني صالح.' : 'Please enter a valid email address.';
    } else {
        try {
            $user = Database::fetchOne("SELECT id, name, email FROM users WHERE email = ? AND status = 'active' LIMIT 1", [$email]);

            if ($user) {
                // Generate secure token
                $token = bin2hex(random_bytes(32));
                $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 hour validity

                // Invalidate any existing unused tokens for this email
                Database::query("UPDATE password_resets SET used = 1 WHERE email = ?", [$email]);

                // Insert new reset token
                Database::insert("
                    INSERT INTO password_resets (email, token, expires_at, used, created_at)
                    VALUES (?, ?, ?, 0, CURRENT_TIMESTAMP)
                ", [$email, $token, $expiresAt]);

                $resetSuccess = true;
                $resetLink = BASE_URL . '/reset-password.php?token=' . urlencode($token);
            } else {
                // Show generic friendly message or notice
                $errorMessage = Lang::isRtl() 
                    ? 'لم نتمكن من العثور على حساب نشط مرتبط بهذا البريد الإلكتروني. يرجى التأكد من البريد أو إنشاء حساب جديد.' 
                    : 'No active account found with this email address.';
            }
        } catch (Exception $e) {
            $errorMessage = Lang::isRtl() ? 'حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.' : 'An error occurred. Please try again later.';
        }
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white">
                
                <div class="text-center mb-4">
                    <div class="brand-icon-wrapper mx-auto mb-3" style="width: 56px; height: 56px; font-size: 1.6rem;">
                        <i class="bi bi-key-fill text-gold"></i>
                    </div>
                    <h2 class="h4 fw-bold text-dark-green"><?= Lang::isRtl() ? 'استعادة كلمة المرور' : 'Reset Password' ?></h2>
                    <p class="text-muted small">
                        <?= Lang::isRtl() 
                            ? 'أدخل بريدك الإلكتروني المسجل وسنزودك برابط آمن لتعيين كلمة مرور جديدة لحسابك.' 
                            : 'Enter your registered email address to receive a secure password reset link.' ?>
                    </p>
                </div>

                <?php if ($resetSuccess): ?>
                    <div class="alert alert-success py-3 px-3 rounded-3 shadow-sm mb-4">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="bi bi-check-circle-fill fs-4 text-success"></i>
                            <strong class="text-dark-green"><?= Lang::isRtl() ? 'تم إنشاء رابط استعادة كلمة المرور!' : 'Password reset link ready!' ?></strong>
                        </div>
                        <p class="small text-secondary mb-3">
                            <?= Lang::isRtl() 
                                ? 'في بيئة الاستضافة يتم إرسال الرابط إلى بريدك (' . e($submittedEmail) . '). في هذه النسخة التجريبية يمكنك المتابعة مباشرة عبر الزر أدناه:' 
                                : 'In production, an email is dispatched. For testing, click the direct button below:' ?>
                        </p>
                        <a href="<?= $resetLink ?>" class="btn btn-gold w-100 py-2 fw-bold text-center d-flex align-items-center justify-content-center gap-2">
                            <i class="bi bi-arrow-right-circle-fill"></i>
                            <span><?= Lang::isRtl() ? 'متابعة تعيين كلمة المرور الجديدة' : 'Proceed to Set New Password' ?></span>
                        </a>
                    </div>
                <?php else: ?>

                    <?php if ($errorMessage): ?>
                        <div class="alert alert-danger py-2 small shadow-sm rounded-3 mb-3">
                            <i class="bi bi-exclamation-triangle-fill me-1 ms-1"></i> <?= e($errorMessage) ?>
                        </div>
                    <?php endif; ?>

                    <form action="<?= BASE_URL ?>/forgot-password.php" method="POST" class="needs-validation">
                        <?= CSRF::getFormField() ?>

                        <div class="mb-4">
                            <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'البريد الإلكتروني المسجل' : 'Registered Email' ?></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control" placeholder="user@example.com" value="<?= e($submittedEmail) ?>" required autofocus>
                            </div>
                            <div class="form-text small text-muted">
                                <?= Lang::isRtl() ? 'تأكد من كتابة البريد الذي استخدمته عند إنشاء حسابك.' : 'Use the email address associated with your account.' ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-gold w-100 py-2 fw-bold d-flex align-items-center justify-content-center gap-2">
                            <i class="bi bi-send-check-fill"></i>
                            <span><?= Lang::isRtl() ? 'إرسال رابط الاستعادة' : 'Send Recovery Link' ?></span>
                        </button>
                    </form>

                <?php endif; ?>

                <div class="mt-4 pt-3 border-top text-center">
                    <span class="text-muted small"><?= Lang::isRtl() ? 'تذكرت كلمة المرور؟' : 'Remembered your password?' ?></span>
                    <a href="<?= BASE_URL ?>/login.php" class="text-gold fw-bold small text-decoration-none me-1 ms-1">
                        <?= Lang::isRtl() ? 'العودة لتسجيل الدخول' : 'Back to Login' ?>
                    </a>
                </div>

            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
