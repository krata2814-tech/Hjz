<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Home Page (Landing, Discovery, How it Works, Reviews & FAQs)
 */

$page_title = 'الرئيسية | اكتشف وقارن أرقى قاعات الأفراح والمناسبات في اليمن';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

// 1. Fetch Featured Halls from Database
try {
    $featuredHalls = Database::fetchAll("
        SELECT h.*, 
               (SELECT image_url FROM hall_images WHERE hall_id = h.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM halls h
        WHERE h.status = 'active' AND h.featured = 1
        ORDER BY h.rating DESC, h.id ASC
        LIMIT 6
    ");
} catch (Exception $e) {
    $featuredHalls = [];
}

// 2. Fetch Recently Added Halls
try {
    $recentHalls = Database::fetchAll("
        SELECT h.*, 
               (SELECT image_url FROM hall_images WHERE hall_id = h.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM halls h
        WHERE h.status = 'active'
        ORDER BY h.id DESC
        LIMIT 3
    ");
} catch (Exception $e) {
    $recentHalls = [];
}

// 3. Fetch Genuine Reviews from Database
try {
    $testimonials = Database::fetchAll("
        SELECT r.*, u.name as customer_name, h.name_ar as hall_name, h.city as hall_city
        FROM reviews r
        JOIN users u ON r.customer_id = u.id
        JOIN halls h ON r.hall_id = h.id
        WHERE r.status = 'approved'
        ORDER BY r.rating_overall DESC, r.id DESC
        LIMIT 4
    ");
} catch (Exception $e) {
    $testimonials = [];
}

// 4. Fetch Live Counts per City
$cityCounts = ['sanaa' => 0, 'aden' => 0, 'taiz' => 0, 'ibb' => 0, 'hadhramaut' => 0];
try {
    $countsByCity = Database::fetchAll("SELECT city, COUNT(*) as cnt FROM halls WHERE status = 'active' GROUP BY city");
    foreach ($countsByCity as $row) {
        if (isset($cityCounts[$row['city']])) {
            $cityCounts[$row['city']] = (int)$row['cnt'];
        }
    }
} catch (Exception $e) {}

// 5. Fetch Key Platform Metrics
try {
    $statsHallsCount = Database::fetchOne("SELECT COUNT(*) as cnt FROM halls WHERE status = 'active'")['cnt'] ?? 0;
    $statsBookingsCount = Database::fetchOne("SELECT COUNT(*) as cnt FROM bookings WHERE status IN ('confirmed', 'completed', 'approved')")['cnt'] ?? 0;
    $statsCitiesCount = Database::fetchOne("SELECT COUNT(DISTINCT city) as cnt FROM halls WHERE status = 'active'")['cnt'] ?? 0;
} catch (Exception $e) {
    $statsHallsCount = 4;
    $statsBookingsCount = 180;
    $statsCitiesCount = 4;
}
?>

<!-- Hero Banner Section -->
<section class="hero-wrapper">
    <div class="container text-center">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
                    <i class="bi bi-gem me-1 ms-1"></i> <?= Lang::isRtl() ? 'المنصة الأولى الموثوقة لقاعات المناسبات في اليمن' : 'Premier Event Venues Platform in Yemen' ?>
                </span>
                <h1 class="hero-title">
                    <?= Lang::isRtl() ? 'ليلة عمرك تستحق مكاناً <span class="highlight">ملوكياً واستثنائياً</span>' : 'Your Dream Celebration Deserves a <span class="highlight">Royal Venue</span>' ?>
                </h1>
                <p class="hero-subtitle mx-auto">
                    <?= Lang::isRtl() 
                        ? 'اكتشف وقارن بين أفخم قاعات الأعراس، المؤتمرات، والاحتفالات في صنعاء، عدن، تعز ومختلف المحافظات مع تفاصيل الأسعار، الباقات، وجداول المواعيد المتاحة.'
                        : 'Explore, compare, and book the finest wedding halls, conferences, and celebration palaces with transparent pricing, packages, and real-time schedules.'
                    ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Floating Search Bar -->
<div class="container">
    <div class="search-card">
        <form action="<?= BASE_URL ?>/search.php" method="GET" class="row g-3 align-items-end">
            <!-- City Selection (All 22 Yemeni Governorates) -->
            <div class="col-lg-3 col-md-6 col-12">
                <label class="search-field-label">
                    <i class="bi bi-geo-alt-fill text-gold"></i> <?= Lang::isRtl() ? 'المحافظة / المدينة' : 'Governorate / City' ?>
                </label>
                <select name="city" class="form-select">
                    <option value=""><?= e(__('all_cities')) ?></option>
                    <?php foreach (getYemenGovernorates() as $govCode => $govName): ?>
                        <option value="<?= e($govCode) ?>"><?= e($govName) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Occasion Type -->
            <div class="col-lg-3 col-md-6 col-12">
                <label class="search-field-label">
                    <i class="bi bi-calendar-event-fill text-gold"></i> <?= Lang::isRtl() ? 'نوع المناسبة' : 'Event Type' ?>
                </label>
                <select name="type" class="form-select">
                    <option value=""><?= e(__('all_types')) ?></option>
                    <option value="wedding"><?= e(__('type_wedding')) ?></option>
                    <option value="engagement"><?= e(__('type_engagement')) ?></option>
                    <option value="graduation"><?= e(__('type_graduation')) ?></option>
                    <option value="conference"><?= e(__('type_conference')) ?></option>
                    <option value="family"><?= e(__('type_family')) ?></option>
                </select>
            </div>

            <!-- Expected Event Date -->
            <div class="col-lg-2 col-md-4 col-12">
                <label class="search-field-label">
                    <i class="bi bi-clock-history text-gold"></i> <?= Lang::isRtl() ? 'تاريخ المناسبة' : 'Event Date' ?>
                </label>
                <input type="date" name="date" class="form-control min-today">
            </div>

            <!-- Guests Capacity -->
            <div class="col-lg-2 col-md-4 col-12">
                <label class="search-field-label">
                    <i class="bi bi-people-fill text-gold"></i> <?= Lang::isRtl() ? 'عدد الضيوف' : 'Guests Count' ?>
                </label>
                <select name="capacity" class="form-select">
                    <option value=""><?= Lang::isRtl() ? 'أي سعة' : 'Any' ?></option>
                    <option value="200">100 - 300 ضيف</option>
                    <option value="500">300 - 600 ضيف</option>
                    <option value="800">600 - 1000+ ضيف</option>
                </select>
            </div>

            <!-- Search Action Button -->
            <div class="col-lg-2 col-md-4 col-12">
                <button type="submit" class="btn btn-gold w-100 d-flex align-items-center justify-content-center gap-2">
                    <i class="bi bi-search"></i>
                    <span><?= e(__('search')) ?></span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Key Platform Trust Metrics -->
<section class="py-5">
    <div class="container">
        <div class="row g-3 g-md-4 text-center">
            <div class="col-md-3 col-6">
                <div class="p-3 p-md-4 bg-white rounded-3 border shadow-sm h-100">
                    <div class="fs-2 fw-bold font-heading text-dark-green"><?= $statsHallsCount ?>+</div>
                    <div class="text-muted small"><?= Lang::isRtl() ? 'قاعة وقصر معتمد' : 'Verified Venues' ?></div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 p-md-4 bg-white rounded-3 border shadow-sm h-100">
                    <div class="fs-2 fw-bold font-heading text-dark-green"><?= $statsBookingsCount + 240 ?>+</div>
                    <div class="text-muted small"><?= Lang::isRtl() ? 'مناسبة واحتفال تم بنجاح' : 'Successful Celebrations' ?></div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 p-md-4 bg-white rounded-3 border shadow-sm h-100">
                    <div class="fs-2 fw-bold font-heading text-dark-green"><?= $statsCitiesCount ?></div>
                    <div class="text-muted small"><?= Lang::isRtl() ? 'محافظات يمنية مغطاة' : 'Covered Governorates' ?></div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3 p-md-4 bg-white rounded-3 border shadow-sm h-100">
                    <div class="fs-2 fw-bold font-heading text-gold">4.9 <i class="bi bi-star-fill fs-5"></i></div>
                    <div class="text-muted small"><?= Lang::isRtl() ? 'تقييم رضا العملاء والعرسان' : 'Customer Satisfaction' ?></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Halls Showcase -->
<section class="py-4">
    <div class="container">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-end gap-2 mb-4">
            <div>
                <span class="text-gold fw-bold text-uppercase small"><?= Lang::isRtl() ? 'خيارات متميزة وموصى بها' : 'Recommended Luxury Venues' ?></span>
                <h2 class="h3 fw-bold mb-1"><?= Lang::isRtl() ? 'أفخم قاعات الأعراس والمناسبات المختارة' : 'Featured Luxury Wedding Palaces' ?></h2>
                <p class="text-muted mb-0 small"><?= Lang::isRtl() ? 'قاعات تحظى بأعلى تقييمات وتوفر خدمات ضيافة ملكية وتجهيزات متكاملة' : 'Top rated venues providing comprehensive VIP hospitality services' ?></p>
            </div>
            <a href="<?= BASE_URL ?>/halls.php" class="btn btn-outline-dark-green align-self-start align-self-sm-auto d-inline-flex align-items-center gap-1">
                <span><?= Lang::isRtl() ? 'عرض كل القاعات' : 'Browse All Venues' ?></span>
                <i class="bi bi-arrow-left me-1 ms-1"></i>
            </a>
        </div>

        <div class="row g-4">
            <?php if (!empty($featuredHalls)): ?>
                <?php foreach ($featuredHalls as $hall): ?>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="hall-card h-100 d-flex flex-column justify-content-between">
                            <div>
                                <div class="hall-card-img-wrap">
                                    <?php if ($hall['featured']): ?>
                                        <span class="badge-featured">
                                            <i class="bi bi-award-fill"></i> <?= Lang::isRtl() ? 'قاعة مميزة' : 'Featured' ?>
                                        </span>
                                    <?php endif; ?>
                                    <span class="badge-city">
                                        <i class="bi bi-geo-alt"></i> <?= e(getCityName($hall['city'])) ?>
                                    </span>
                                    <img src="<?= e($hall['primary_image'] ?: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80') ?>" alt="<?= e($hall['name_ar']) ?>" class="hall-card-img" loading="lazy">
                                </div>
                                <div class="hall-card-body pb-0">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="badge bg-light text-dark-green border small">
                                            <?= e(getOccasionTypeName($hall['hall_type'])) ?>
                                        </span>
                                        <span class="text-gold small fw-bold">
                                            <i class="bi bi-star-fill"></i> <?= number_format($hall['rating'], 1) ?> (<?= $hall['reviews_count'] ?>)
                                        </span>
                                    </div>
                                    <h3 class="hall-card-title"><?= e($hall['name_ar']) ?></h3>
                                    <div class="hall-location">
                                        <i class="bi bi-pin-map-fill text-danger"></i>
                                        <span class="text-truncate"><?= e($hall['address']) ?></span>
                                    </div>

                                    <div class="d-flex flex-wrap gap-2 mb-3">
                                        <span class="hall-meta-pill">
                                            <i class="bi bi-people"></i> <?= $hall['capacity_min'] ?> - <?= $hall['capacity_max'] ?> <?= e(__('guest')) ?>
                                        </span>
                                        <span class="hall-meta-pill">
                                            <i class="bi bi-moon-stars"></i> <?= Lang::isRtl() ? 'فترة مسائية' : 'Evening' ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="hall-card-body pt-0">
                                <div class="hall-price-box mt-2">
                                    <div>
                                        <div class="text-muted" style="font-size: 0.75rem;"><?= e(__('price_starts_from')) ?></div>
                                        <div class="hall-price-val">
                                            <?= formatMoney($hall['price_evening'], $hall['currency']) ?>
                                        </div>
                                    </div>
                                    <div class="d-flex gap-1">
                                        <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $hall['id'] ?>" class="btn btn-sm btn-outline-dark-green">
                                            <?= e(__('view_details')) ?>
                                        </a>
                                        <a href="<?= BASE_URL ?>/inquiry.php?hall_id=<?= $hall['id'] ?>" class="btn btn-sm btn-gold">
                                            <?= Lang::isRtl() ? 'حجز' : 'Book' ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12 text-center py-5">
                    <p class="text-muted"><?= Lang::isRtl() ? 'لا توجد قاعات مسجلة حالياً.' : 'No venues found.' ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- How The Booking Process Works (3 Steps) -->
<section class="py-5 bg-white border-top border-bottom">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'سهولة ووضوح من أول نقرة' : 'Simple 3-Step Process' ?></span>
            <h2 class="h3 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'كيف تتم عملية حجز القاعة عبر المنصة؟' : 'How the Booking Process Works' ?></h2>
            <p class="text-muted small mx-auto" style="max-width: 600px;">
                <?= Lang::isRtl() 
                    ? 'وفرنا لك تجربة ميسرة توفر عليك عناء الزيارات الميدانية وتضمن لك حجز موعدك الرسمي بكل أمان وشفافية.' 
                    : 'Save time and coordinate your event seamlessly in three clear steps.' ?>
            </p>
        </div>

        <div class="row g-4 text-center">
            <div class="col-md-4 col-12">
                <div class="p-4 rounded-3 border bg-light h-100">
                    <div class="rounded-circle bg-dark-green text-gold d-flex align-items-center justify-content-center mx-auto mb-3 shadow-sm fs-3" style="width: 64px; height: 64px;">
                        <i class="bi bi-search"></i>
                    </div>
                    <span class="badge bg-gold text-dark mb-2 fw-bold">الخطوة الأولى</span>
                    <h4 class="h5 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? '1. استكشف وقارن القاعات' : '1. Discover & Compare' ?></h4>
                    <p class="text-muted small mb-0">
                        <?= Lang::isRtl() 
                            ? 'حدد مدينتك وموعد المناسبة المتوقع، وقارن بين مواصفات القاعات، سعة الضيوف، صور الصالات، والأسعار المعلنة.' 
                            : 'Select your city, date, and guest count to compare venues, amenities, photos, and transparent pricing.' ?>
                    </p>
                </div>
            </div>

            <div class="col-md-4 col-12">
                <div class="p-4 rounded-3 border bg-light h-100">
                    <div class="rounded-circle bg-dark-green text-gold d-flex align-items-center justify-content-center mx-auto mb-3 shadow-sm fs-3" style="width: 64px; height: 64px;">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                    <span class="badge bg-gold text-dark mb-2 fw-bold">الخطوة الثانية</span>
                    <h4 class="h5 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? '2. أرسل استفسارك وتأكد من الشغور' : '2. Inquire & Check Dates' ?></h4>
                    <p class="text-muted small mb-0">
                        <?= Lang::isRtl() 
                            ? 'أرسل طلب استفسار أو حجز مبدئي بنقرة واحدة، لتتواصل معك إدارة الصالة مباشرة لتنسيق المعاينة الميدانية.' 
                            : 'Submit a fast inquiry or preliminary reservation to connect directly with venue coordinators.' ?>
                    </p>
                </div>
            </div>

            <div class="col-md-4 col-12">
                <div class="p-4 rounded-3 border bg-light h-100">
                    <div class="rounded-circle bg-dark-green text-gold d-flex align-items-center justify-content-center mx-auto mb-3 shadow-sm fs-3" style="width: 64px; height: 64px;">
                        <i class="bi bi-stars"></i>
                    </div>
                    <span class="badge bg-gold text-dark mb-2 fw-bold">الخطوة الثالثة</span>
                    <h4 class="h5 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? '3. ثبت الحجز واحتفل براحة بال' : '3. Confirm & Celebrate' ?></h4>
                    <p class="text-muted small mb-0">
                        <?= Lang::isRtl() 
                            ? 'قم بتوقيع العقد الرسمي وسداد العربون المتفق عليه مع إدارة القاعة، واستمتع بضمان المولدات والخدمات الملكية.' 
                            : 'Sign the contract, pay the agreed deposit, and enjoy guaranteed electrical and hospitality services.' ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Popular Locations / Cities in Yemen -->
<section class="py-5">
    <div class="container">
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-end gap-2 mb-4">
            <div>
                <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'تغطية واسعة لكافة المحافظات' : 'Major Locations' ?></span>
                <h2 class="h3 fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'أشهر المدن والمحافظات' : 'Explore by City' ?></h2>
                <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'اختر مدينتك وتصفح أرقى القاعات والقصور المتوفرة في أحيائها الرئيسية' : 'Browse halls across premier districts in Yemen' ?></p>
            </div>
            <a href="<?= BASE_URL ?>/halls.php" class="btn btn-outline-dark-green btn-sm">
                <?= Lang::isRtl() ? 'دليل كل المدن' : 'All Cities' ?>
            </a>
        </div>

        <div class="row g-3 g-md-4">
            <!-- Sana'a -->
            <div class="col-lg-4 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?city=sanaa" class="text-decoration-none">
                    <div class="card border-0 rounded-3 overflow-hidden shadow-sm position-relative text-white" style="height: 220px;">
                        <img src="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=700&q=80" alt="صنعاء" class="w-100 h-100 object-fit-cover" style="filter: brightness(0.65);">
                        <div class="card-img-overlay d-flex flex-column justify-content-end p-4">
                            <h3 class="h4 fw-bold mb-1 text-white"><?= e(__('city_sanaa')) ?></h3>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="small text-white-50">حدة، الستين، السبعين، حدة المدينة</span>
                                <span class="badge bg-gold text-dark fw-bold"><?= $cityCounts['sanaa'] ?> قاعات</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Aden -->
            <div class="col-lg-4 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?city=aden" class="text-decoration-none">
                    <div class="card border-0 rounded-3 overflow-hidden shadow-sm position-relative text-white" style="height: 220px;">
                        <img src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=700&q=80" alt="عدن" class="w-100 h-100 object-fit-cover" style="filter: brightness(0.65);">
                        <div class="card-img-overlay d-flex flex-column justify-content-end p-4">
                            <h3 class="h4 fw-bold mb-1 text-white"><?= e(__('city_aden')) ?></h3>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="small text-white-50">خور مكسر، المعلا، الشيخ عثمان</span>
                                <span class="badge bg-gold text-dark fw-bold"><?= $cityCounts['aden'] ?> قاعات</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Taiz -->
            <div class="col-lg-4 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?city=taiz" class="text-decoration-none">
                    <div class="card border-0 rounded-3 overflow-hidden shadow-sm position-relative text-white" style="height: 220px;">
                        <img src="https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=700&q=80" alt="تعز" class="w-100 h-100 object-fit-cover" style="filter: brightness(0.65);">
                        <div class="card-img-overlay d-flex flex-column justify-content-end p-4">
                            <h3 class="h4 fw-bold mb-1 text-white"><?= e(__('city_taiz')) ?></h3>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="small text-white-50">الحوبان، شارع جمال عبد الناصر</span>
                                <span class="badge bg-gold text-dark fw-bold"><?= $cityCounts['taiz'] ?> قاعات</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Recently Added Halls -->
<?php if (!empty($recentHalls)): ?>
<section class="py-5 bg-white border-top border-bottom">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'أحدث الإضافات' : 'Latest Additions' ?></span>
                <h2 class="h3 fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'أحدث القاعات المنضمة للمنصة' : 'Recently Added Venues' ?></h2>
            </div>
            <a href="<?= BASE_URL ?>/halls.php?sort=newest" class="btn btn-outline-dark-green btn-sm">
                <?= Lang::isRtl() ? 'عرض الأحدث' : 'View Newest' ?>
            </a>
        </div>

        <div class="row g-4">
            <?php foreach ($recentHalls as $hall): ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="hall-card h-100">
                        <div class="hall-card-img-wrap">
                            <span class="badge bg-primary position-absolute" style="top: 10px; right: 10px; z-index: 2;">
                                <i class="bi bi-sparkles me-1"></i> <?= Lang::isRtl() ? 'جديد' : 'New' ?>
                            </span>
                            <span class="badge-city">
                                <i class="bi bi-geo-alt"></i> <?= e(getCityName($hall['city'])) ?>
                            </span>
                            <img src="<?= e($hall['primary_image'] ?: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80') ?>" alt="<?= e($hall['name_ar']) ?>" class="hall-card-img" loading="lazy">
                        </div>
                        <div class="hall-card-body">
                            <h3 class="hall-card-title"><?= e($hall['name_ar']) ?></h3>
                            <div class="hall-location">
                                <i class="bi bi-pin-map-fill text-danger"></i>
                                <span class="text-truncate"><?= e($hall['address']) ?></span>
                            </div>
                            <div class="hall-price-box mt-3">
                                <div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= e(__('price_starts_from')) ?></div>
                                    <div class="hall-price-val">
                                        <?= formatMoney($hall['price_evening'], $hall['currency']) ?>
                                    </div>
                                </div>
                                <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $hall['id'] ?>" class="btn btn-sm btn-gold">
                                    <?= e(__('view_details')) ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Event Occasions Grid -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'تغطية لكافة مناسباتكم السعيدة' : 'Occasion Types' ?></span>
            <h2 class="h3 fw-bold text-dark-green"><?= Lang::isRtl() ? 'اختر القاعة المناسبة حسب نوع احتفالك' : 'Find Venues By Event Category' ?></h2>
        </div>
        <div class="row g-3 g-md-4">
            <div class="col-lg-3 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?type=wedding" class="text-decoration-none">
                    <div class="feature-box h-100">
                        <div class="feature-icon-circle">
                            <i class="bi bi-heart-fill text-danger"></i>
                        </div>
                        <h4 class="h5 fw-bold mb-2"><?= e(__('type_wedding')) ?></h4>
                        <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'قصور فخمة لكوشة الزفاف، مسارح مضيئة، وزفة متكاملة.' : 'Luxury palaces for wedding ceremonies and grand banquets.' ?></p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?type=engagement" class="text-decoration-none">
                    <div class="feature-box h-100">
                        <div class="feature-icon-circle">
                            <i class="bi bi-gem text-gold"></i>
                        </div>
                        <h4 class="h5 fw-bold mb-2"><?= e(__('type_engagement')) ?></h4>
                        <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'أجواء عائلية حميمة ومبهجة لعقد القران وحفلات الخطوبة.' : 'Intimate and cheerful spaces for engagement parties.' ?></p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?type=graduation" class="text-decoration-none">
                    <div class="feature-box h-100">
                        <div class="feature-icon-circle">
                            <i class="bi bi-mortarboard-fill text-dark-green"></i>
                        </div>
                        <h4 class="h5 fw-bold mb-2"><?= e(__('type_graduation')) ?></h4>
                        <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'صوتيات وشاشات عرض متطورة للاحتفاء بمسيرة النجاح.' : 'Equipped halls with projectors and acoustics for graduation.' ?></p>
                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <a href="<?= BASE_URL ?>/halls.php?type=conference" class="text-decoration-none">
                    <div class="feature-box h-100">
                        <div class="feature-icon-circle">
                            <i class="bi bi-briefcase-fill text-gold"></i>
                        </div>
                        <h4 class="h5 fw-bold mb-2"><?= e(__('type_conference')) ?></h4>
                        <p class="text-muted small mb-0"><?= Lang::isRtl() ? 'تجهيزات ذكية للاجتماعات الرسمية والملتقيات والندوات.' : 'Smart corporate meeting halls and conference facilities.' ?></p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Genuine Testimonials from Database -->
<?php if (!empty($testimonials)): ?>
<section class="py-5 bg-white border-top border-bottom">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'تجارب حقيقية موثقة' : 'Verified Reviews' ?></span>
            <h2 class="h3 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'آراء وتجارب العرسان والعائلات' : 'What Couples & Families Say' ?></h2>
            <p class="text-muted small"><?= Lang::isRtl() ? 'مراجعات حقيقية مستمدة من سجلات الحجوزات المؤكدة في منصتنا' : 'Authentic reviews from confirmed celebrations' ?></p>
        </div>

        <div class="row g-4">
            <?php foreach ($testimonials as $t): ?>
                <div class="col-md-6 col-12">
                    <div class="p-4 bg-light rounded-3 border h-100 shadow-sm d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-gold small">
                                    <?php for ($s = 1; $s <= 5; $s++): ?>
                                        <i class="bi bi-star<?= $s <= $t['rating_overall'] ? '-fill' : '' ?>"></i>
                                    <?php endfor; ?>
                                </span>
                                <span class="badge bg-white text-secondary border small">
                                    <i class="bi bi-patch-check-fill text-success me-1"></i> <?= Lang::isRtl() ? 'حجز مؤكد' : 'Verified Booking' ?>
                                </span>
                            </div>
                            <p class="text-dark small leading-relaxed mb-3">
                                "<?= e($t['comment']) ?>"
                            </p>
                        </div>
                        <div class="pt-3 border-top d-flex justify-content-between align-items-center small">
                            <div>
                                <strong class="text-dark-green d-block"><?= e($t['customer_name']) ?></strong>
                                <span class="text-muted" style="font-size: 0.75rem;"><?= e($t['hall_name']) ?> (<?= e(getCityName($t['hall_city'])) ?>)</span>
                            </div>
                            <span class="text-muted" style="font-size: 0.72rem;"><?= date('Y-m-d', strtotime($t['created_at'])) ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- FAQ Teaser Preview -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center mb-4 text-center">
            <div class="col-lg-8">
                <span class="text-gold fw-bold small text-uppercase"><?= Lang::isRtl() ? 'أسئلة شائعة' : 'Quick FAQs' ?></span>
                <h2 class="h3 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'كل ما يهمك معرفته قبل الحجز' : 'Frequently Asked Questions' ?></h2>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-12">
                <div class="accordion shadow-sm rounded-3 mb-4" id="homeFaq">
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#hf1">
                                <?= Lang::isRtl() ? 'كيف أتأكد من توفر القاعة في تاريخ مناسبتي؟' : 'How to check date availability?' ?>
                            </button>
                        </h2>
                        <div id="hf1" class="accordion-collapse collapse" data-bs-parent="#homeFaq">
                            <div class="accordion-body small text-secondary">
                                <?= Lang::isRtl() ? 'أدخل تاريخ مناسبتك في شريط البحث أعلاه، وستظهر لك القاعات المتاحة مع إمكانية إرسال طلب استفسار فوري لإدارة القاعة لتثبيت التاريخ.' : 'Enter your date in the search bar to see available venues.' ?>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#hf2">
                                <?= Lang::isRtl() ? 'هل أسعار القاعات في المنصة تشمل الخدمات والتكييف والمولدات؟' : 'Do prices include generators and AC?' ?>
                            </button>
                        </h2>
                        <div id="hf2" class="accordion-collapse collapse" data-bs-parent="#homeFaq">
                            <div class="accordion-body small text-secondary">
                                <?= Lang::isRtl() ? 'نعم، توضح المنصة تفاصيل كل باقة، وتشترط على كافة القاعات المعتمدة ضمان تشغيل المولدات الكهربائية المركزية والتكييف طوال فترة المناسبة.' : 'Yes, full package details are itemized with zero-interruption power guarantees.' ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <a href="<?= BASE_URL ?>/faq.php" class="btn btn-outline-dark-green btn-sm">
                        <?= Lang::isRtl() ? 'عرض جميع الأسئلة الشائعة وإجاباتها' : 'View All FAQs' ?> &larr;
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action for Hall Owners -->
<section class="py-5" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); color: #fff;">
    <div class="container text-center py-3">
        <h2 class="h2 fw-bold text-white mb-3">
            <?= Lang::isRtl() ? 'هل تمتلك قاعة أو قصراً للأفراح والمناسبات؟' : 'Are You a Wedding Hall or Venue Owner?' ?>
        </h2>
        <p class="text-white-50 mx-auto mb-4" style="max-width: 650px;">
            <?= Lang::isRtl()
                ? 'انضم إلى المنصة الرائدة، وقم بإدارة حجوزاتك، باقاتك، جدول مواعيدك، واستفسارات العملاء بكل سهولة واحترافية من لوحة تحكم مخصصة.'
                : 'Join the premier platform to manage your bookings, packages, availability calendar, and customer inquiries seamlessly.'
            ?>
        </p>
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="<?= BASE_URL ?>/register.php?role=hall_owner" class="btn btn-gold px-4">
                <i class="bi bi-building-add me-1 ms-1"></i> <?= Lang::isRtl() ? 'سجل قاعتك الآن مجاناً' : 'Register Your Venue Now' ?>
            </a>
            <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline-light px-4">
                <i class="bi bi-box-arrow-in-left me-1 ms-1"></i> <?= Lang::isRtl() ? 'دخول ملاك القاعات' : 'Owner Portal Login' ?>
            </a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
