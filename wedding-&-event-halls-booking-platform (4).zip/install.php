<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Secure First-Run Setup & Super Administrator Registration
 * File: install.php
 */

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/security.php';
require_once __DIR__ . '/database/init_db.php';
require_once __DIR__ . '/includes/auth.php';

$lockFile = __DIR__ . '/config/installed.lock';
$adminAlreadyExists = hasSuperAdmin() || file_exists($lockFile);

// If Super Administrator already exists, permanently lock the installer
if ($adminAlreadyExists) {
    if (isPost()) {
        http_response_code(403);
        die('خطأ أمني: تم تثبيت النظام وإنشاء المدير العام مسبقاً. معالج التثبيت مقفل بشكل دائم.');
    }
}

$error = null;
$success = null;

// Diagnostics
$phpVersionOk = version_compare(PHP_VERSION, '8.2.0', '>=');
$pdoLoaded = extension_loaded('pdo');
$pdoMysqlLoaded = extension_loaded('pdo_mysql');
$pdoSqliteLoaded = extension_loaded('pdo_sqlite');
$mbstringLoaded = extension_loaded('mbstring');
$sessionLoaded = extension_loaded('session');
$dbDirWritable = is_writable(__DIR__ . '/database') || is_writable(__DIR__);

// Handle First Super Admin Registration
if (isPost() && !$adminAlreadyExists) {
    CSRF::verifyOrDie();

    $name = sanitize(post('admin_name'));
    $email = strtolower(sanitize(post('admin_email')));
    $phone = sanitize(post('admin_phone'));
    $password = post('admin_password', '');
    $passwordConfirm = post('admin_password_confirm', '');
    $siteName = sanitize(post('site_name', APP_NAME_AR));

    // Server-side strict validation
    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'يرجى إدخال جميع الحقول المطلوبة للمدير العام.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'صيغة البريد الإلكتروني غير صحيحة.';
    } elseif (strlen($password) < 8) {
        $error = 'كلمة المرور يجب ألا تقل عن 8 خانات وتحتوي على أحرف وأرقام.';
    } elseif ($password !== $passwordConfirm) {
        $error = 'كلمتا المرور غير متطابقتين.';
    } else {
        // First, ensure all tables are prepared
        initializeDatabase();

        // Create Super Admin via atomic transaction with race-condition prevention
        $createRes = createFirstSuperAdmin([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'password' => $password,
            'password_confirm' => $passwordConfirm
        ]);

        if ($createRes['success']) {
            // Also seed demo venue data for immediate interactive exploration
            seedDemoData();

            // Auto-login the newly created Super Admin
            Auth::attempt($email, $password);

            setFlash('success', 'تهانينا! تم إنشاء حساب المدير العام وتأمين النظام بنجاح. أهلاً بك في لوحة الإدارة.');
            redirect(BASE_URL . '/dashboard.php');
        } else {
            $error = $createRes['error'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>معالج التثبيت وإنشاء المدير العام | System Installation</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Local Bootstrap RTL -->
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-ivory py-4 py-md-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10 col-12">
                <div class="card border rounded-3 shadow-sm overflow-hidden bg-white">
                    <!-- Top Branding Header -->
                    <div class="p-4 d-flex align-items-center gap-3 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
                        <div class="brand-icon-wrapper" style="width: 52px; height: 52px; font-size: 1.5rem;">
                            <i class="bi bi-shield-lock-fill"></i>
                        </div>
                        <div>
                            <h1 class="h4 fw-bold mb-0">معالج التثبيت وإنشاء المدير العام الأول (Super Admin)</h1>
                            <small class="text-white-50">Wedding & Event Halls Booking Platform - First-Run Setup</small>
                        </div>
                    </div>

                    <div class="p-4 p-md-5">
                        <?php if ($adminAlreadyExists): ?>
                            <!-- Locked State -->
                            <div class="text-center py-4">
                                <div class="text-gold fs-1 mb-3"><i class="bi bi-shield-fill-check"></i></div>
                                <h3 class="h4 fw-bold text-dark-green mb-2">النظام مثبت ومؤمن بالفعل</h3>
                                <p class="text-muted small mb-4" style="max-width: 540px; margin: 0 auto;">
                                    تم تسجيل حساب المدير العام للنظام بنجاح، وتم إغلاق معالج التثبيت لمنع أي تعديل أو إعادة كتابة غير مصرح بها.
                                </p>
                                
                                <div class="alert alert-info border-0 rounded-3 small p-3 text-start mb-4 bg-light">
                                    <div class="fw-bold mb-1 text-dark-green"><i class="bi bi-info-circle me-1 ms-1"></i> نصيحة أمنية للنشر على بيئة الإنتاج:</div>
                                    <p class="mb-0 text-secondary">
                                        يمكنك حذف أو إعادة تسمية ملف <code>install.php</code> أو تقييد الوصول إليه عبر ملف <code>.htaccess</code> لمزيد من التحصين.
                                    </p>
                                </div>

                                <div class="d-flex justify-content-center gap-2">
                                    <a href="login.php" class="btn btn-gold px-4">
                                        <i class="bi bi-box-arrow-in-left me-1 ms-1"></i> تسجيل الدخول كمدير عام
                                    </a>
                                    <a href="index.php" class="btn btn-outline-dark-green px-4">
                                        <i class="bi bi-house me-1 ms-1"></i> تصفح المنصة الرئيسية
                                    </a>
                                </div>
                            </div>

                        <?php else: ?>
                            <!-- Active First-Run Setup Form -->
                            <?php if ($error): ?>
                                <div class="alert alert-danger py-2 small shadow-sm rounded-3 mb-4 d-flex align-items-center gap-2">
                                    <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                                    <div><?= e($error) ?></div>
                                </div>
                            <?php endif; ?>

                            <!-- System Pre-flight Diagnostics -->
                            <div class="mb-4">
                                <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                                    <i class="bi bi-cpu-fill text-gold"></i> 1. فحص توافق بيئة التشغيل والخادم:
                                </h5>
                                <div class="row g-2 small">
                                    <div class="col-md-6 col-12">
                                        <div class="p-2 border rounded-2 bg-light d-flex justify-content-between align-items-center">
                                            <span>إصدار PHP (8.2+ مطلوب):</span>
                                            <span class="badge <?= $phpVersionOk ? 'bg-success' : 'bg-danger' ?>">PHP <?= PHP_VERSION ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="p-2 border rounded-2 bg-light d-flex justify-content-between align-items-center">
                                            <span>دعم PDO وقواعد البيانات:</span>
                                            <span class="badge <?= $pdoLoaded ? 'bg-success' : 'bg-danger' ?>"><?= $pdoLoaded ? 'مفعل وجاهز' : 'غير متوفر' ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="p-2 border rounded-2 bg-light d-flex justify-content-between align-items-center">
                                            <span>مكتبة النصوص العربية (mbstring):</span>
                                            <span class="badge <?= $mbstringLoaded ? 'bg-success' : 'bg-danger' ?>"><?= $mbstringLoaded ? 'مفعل' : 'غير متوفر' ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="p-2 border rounded-2 bg-light d-flex justify-content-between align-items-center">
                                            <span>أذونات مجلد التثبيت والقواعد:</span>
                                            <span class="badge <?= $dbDirWritable ? 'bg-success' : 'bg-danger' ?>"><?= $dbDirWritable ? 'قابل للكتابة' : 'غير متاح' ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <!-- Super Admin Creation Form -->
                            <form action="install.php" method="POST" class="needs-validation" novalidate>
                                <?= CSRF::getFormField() ?>

                                <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
                                    <i class="bi bi-person-badge-fill text-gold"></i> 2. بيانات المدير العام الأول (Super Administrator):
                                </h5>
                                <p class="small text-muted mb-3">
                                    سيتم منح هذا الحساب دور <code>super_admin</code> بصلاحيات كاملة وغير مقيدة لإدارة المنصة، المستخدمين، واعتماد القاعات.
                                </p>

                                <div class="row g-3 mb-3">
                                    <div class="col-md-6 col-12">
                                        <label class="form-label small fw-bold text-dark-green">الاسم الكامل للمدير العام *</label>
                                        <input type="text" name="admin_name" class="form-control" placeholder="مثال: المهندس مازن العزي" value="<?= e(post('admin_name', 'المهندس مازن العزي')) ?>" required>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <label class="form-label small fw-bold text-dark-green">رقم الهاتف / واتساب *</label>
                                        <input type="tel" name="admin_phone" class="form-control" placeholder="+967 77..." value="<?= e(post('admin_phone', '+967770000001')) ?>" required>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-dark-green">البريد الإلكتروني الرسمي *</label>
                                    <input type="email" name="admin_email" class="form-control" placeholder="admin@wedding.ye" value="<?= e(post('admin_email', 'admin@wedding.ye')) ?>" required>
                                    <small class="text-muted" style="font-size: 0.75rem;">سيكون هذا البريد هو اسم المستخدم لتسجيل الدخول بلوحة الإدارة.</small>
                                </div>

                                <div class="row g-3 mb-4">
                                    <div class="col-md-6 col-12">
                                        <label class="form-label small fw-bold text-dark-green">كلمة المرور المشفرة * (8 خانات كحد أدنى)</label>
                                        <input type="password" name="admin_password" class="form-control" placeholder="••••••••" required minlength="8" value="<?= e(post('admin_password', 'admin123456')) ?>">
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <label class="form-label small fw-bold text-dark-green">تأكيد كلمة المرور *</label>
                                        <input type="password" name="admin_password_confirm" class="form-control" placeholder="••••••••" required minlength="8" value="<?= e(post('admin_password_confirm', 'admin123456')) ?>">
                                    </div>
                                </div>

                                <div class="p-3 bg-light rounded-3 border mb-4 small text-secondary">
                                    <div class="fw-bold text-dark-green mb-1"><i class="bi bi-shield-check text-gold"></i> معايير الأمان المطبقة فور الإرسال:</div>
                                    <ul class="mb-0 ps-3">
                                        <li>تشفير كلمة المرور عبر <code>password_hash(BCRYPT, cost 12)</code>.</li>
                                        <li>تثبيت الدور عبر خادم قاعدة البيانات حصرياً (Server Authoritative Role).</li>
                                        <li>تسجيل حركة الإنشاء في جدول سجلات التدقيق الأمني <code>audit_logs</code>.</li>
                                        <li>إنشاء ملف القفل <code>config/installed.lock</code> لمنع أي محاولة تسجيل أخرى.</li>
                                    </ul>
                                </div>

                                <button type="submit" class="btn btn-gold w-100 py-3 fw-bold fs-6">
                                    <i class="bi bi-check-circle-fill me-1 ms-1"></i> إنشاء المدير العام وتثبيت المنظومة بالكامل
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
