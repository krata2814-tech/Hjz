import assert from 'node:assert/strict';
import http from 'node:http';
import express from 'express';
import { getDb, signPaymentProviderPayload } from '../src/server/db.ts';
import { apiRouter } from '../src/server/api.ts';

async function runTests() {
  console.log('=== Munasabati Marketplace Comprehensive Automated Test Suite ===');

  const db = getDb();
  const app = express();
  app.use(express.json());
  app.use('/api', apiRouter);

  const server = http.createServer(app);
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const addr = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  async function req(path: string, options: RequestInit = {}) {
    const res = await fetch(`${baseUrl}${path}`, options);
    const body = await res.json().catch(() => ({}));
    return { status: res.status, body };
  }

  try {
    // 1. Authentication Tests
    const invalidLogin = await req('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'krata2814@gmail.com', password: 'WrongPassword!' }),
    });
    assert.equal(invalidLogin.status, 401, 'Invalid password must return 401');

    const validLogin = await req('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'krata2814@gmail.com', password: '781802671' }),
    });
    assert.equal(validLogin.status, 200, 'Valid Super Admin login must succeed');
    assert.ok(validLogin.body.token && validLogin.body.csrfToken, 'Session token & CSRF token must be returned');
    const adminToken = validLogin.body.token;
    const adminCsrf = validLogin.body.csrfToken;
    console.log('[PASS] 1. Authentication & session token issuance verified.');

    // 2. Duplicate Email Prevention
    const dupEmailRes = await req('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Duplicate User',
        email: 'krata2814@gmail.com',
        phone: '+967771234567',
        password: 'password123',
        accountType: 'customer',
      }),
    });
    assert.equal(dupEmailRes.status, 400, 'Registering with an existing email must fail with 400');
    console.log('[PASS] 2. Duplicate email prevention verified.');

    // 3. First Super Administrator Initialization & Privilege Escalation Prevention
    const setupStatus = await req('/api/auth/setup-status');
    assert.equal(setupStatus.body.initialized, true);
    assert.equal(setupStatus.body.publicAdminRegistrationDisabled, true);

    const secondAdminSetup = await req('/api/auth/setup-first-admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Attacker Admin',
        email: 'attacker@munasabati.com',
        password: 'password1234',
      }),
    });
    assert.equal(secondAdminSetup.status, 403, 'Second Super Admin initialization must be blocked with 403');

    const roleEscalationAttempt = await req('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Escalation User',
        email: 'escalate@munasabati.com',
        phone: '+967779999999',
        password: 'password1234',
        accountType: 'super_admin',
        role: 'super_admin',
        role_id: 1,
      }),
    });
    assert.equal(roleEscalationAttempt.status, 403, 'Browser role escalation to super_admin must be blocked with 403');

    // Database-level unique constraint check for single Super Admin
    assert.throws(() => {
      db.prepare(`
        INSERT INTO users (role_id, name, email, phone, password_hash, status)
        VALUES (1, 'DB Bypass Admin', 'db-bypass@munasabati.com', '+967770000999', 'hash', 'active')
      `).run();
    }, 'Database unique index idx_single_super_admin must prevent inserting a second Super Admin');
    console.log('[PASS] 3. First Super Administrator lock & browser privilege escalation prevention verified.');

    // 4. Owner Registration, Verification & Unverified Venue Hiding
    const testOwnerEmail = `owner-test-${Date.now()}@munasabati.com`;
    const ownerReg = await req('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'الشيخ طارق العولقي',
        email: testOwnerEmail,
        phone: '+967773334455',
        password: 'password1234',
        accountType: 'hall_owner',
        businessName: 'مجموعة قصور العولقي الملكية',
        commercialRegNo: 'CR-2026-9988',
        verificationDocumentUrl: '/uploads/docs/awlaki-deed.pdf',
        termsAccepted: true,
      }),
    });
    assert.equal(ownerReg.status, 201, 'Hall Owner registration with required business & document fields must succeed');
    const newOwnerId = ownerReg.body.user.id;
    const newOwnerToken = ownerReg.body.token;
    const newOwnerCsrf = ownerReg.body.csrfToken;

    // Submit a venue as this unverified owner
    const submitHall = await req('/api/owner/halls', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${newOwnerToken}`,
        'X-CSRF-Token': newOwnerCsrf,
      },
      body: JSON.stringify({
        nameAr: 'قاعة الاختبار المؤقتة',
        city: 'sanaa',
        address: 'صنعاء - شارع حدة',
        descriptionAr: 'قاعة اختبار للتحقق من عدم ظهور القاعات غير الموثقة',
      }),
    });
    assert.equal(submitHall.status, 201);
    const createdHallId = submitHall.body.hallId;
    assert.equal(submitHall.body.status, 'pending', 'New owner venue must start as pending');

    // Public marketplace must NOT list this hall while pending or while owner is unverified
    const publicBeforeVerify = await req('/api/init');
    assert.equal(
      publicBeforeVerify.body.halls.some((h: { id: number }) => h.id === createdHallId),
      false,
      'Unverified/pending venue must not appear in public search'
    );

    // Super Admin verifies the owner and approves the hall
    const verifyOwnerRes = await req(`/api/admin/owners/${newOwnerId}/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({ verified: true }),
    });
    assert.equal(verifyOwnerRes.status, 200);

    // Clean up test owner & hall
    db.prepare(`DELETE FROM hall_facilities WHERE hall_id = ?`).run(createdHallId);
    db.prepare(`DELETE FROM hall_pricing WHERE hall_id = ?`).run(createdHallId);
    db.prepare(`DELETE FROM hall_images WHERE hall_id = ?`).run(createdHallId);
    db.prepare(`DELETE FROM halls WHERE id = ?`).run(createdHallId);
    db.prepare(`DELETE FROM owner_profiles WHERE user_id = ?`).run(newOwnerId);
    db.prepare(`DELETE FROM users WHERE id = ?`).run(newOwnerId);
    console.log('[PASS] 4. Hall Owner registration, document verification & unverified venue hiding verified.');

    // 5. Authorization (RBAC & CSRF Enforcement)
    const custSwitch = await req('/api/auth/persona-switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: 4 }), // Customer
    });
    const custToken = custSwitch.body.token;
    const custCsrf = custSwitch.body.csrfToken;

    const forbiddenAdmin = await req('/api/admin/dashboard', {
      headers: { Authorization: `Bearer ${custToken}` },
    });
    assert.equal(forbiddenAdmin.status, 403, 'Customer must be forbidden from Super Admin endpoints');

    const missingCsrf = await req('/api/favorites/toggle', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
      },
      body: JSON.stringify({ hallId: 1 }),
    });
    assert.equal(missingCsrf.status, 403, 'State-changing request without CSRF token must be rejected with 403');
    console.log('[PASS] 5. Server-side RBAC & CSRF protection verified.');

    // 6 & 7. Booking Availability, Privacy Protection & Concurrent Booking Requests
    const initData = await req('/api/init');
    const hall1 = initData.body.halls.find((h: { id: number }) => h.id === 1);
    assert.ok(hall1, 'Hall 1 should be publicly available');
    for (const slot of hall1.unavailableSlots) {
      assert.equal('customer_name' in slot, false, 'Public availability calendar must never expose customer PII');
      assert.equal('customer_phone' in slot, false, 'Public availability calendar must never expose customer phone');
    }

    const testDate = '2027-06-15';
    const [concurrentA, concurrentB] = await Promise.all([
      req('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${custToken}`,
          'X-CSRF-Token': custCsrf,
        },
        body: JSON.stringify({
          hallId: 1,
          pricingId: 2,
          eventDate: testDate,
          shift: 'evening',
          guestCount: 450,
          paymentMethod: 'card_payment',
          payDepositNow: true,
        }),
      }),
      req('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${custToken}`,
          'X-CSRF-Token': custCsrf,
        },
        body: JSON.stringify({
          hallId: 1,
          pricingId: 2,
          eventDate: testDate,
          shift: 'evening',
          guestCount: 420,
          paymentMethod: 'card_payment',
          payDepositNow: true,
        }),
      }),
    ]);

    const statuses = [concurrentA.status, concurrentB.status].sort();
    assert.deepEqual(statuses, [201, 409], 'Concurrent booking requests for the same slot must result in one 201 and one 409 Conflict');
    const createdBooking = concurrentA.status === 201 ? concurrentA.body.booking : concurrentB.body.booking;
    console.log('[PASS] 6 & 7. Booking calendar privacy & concurrent double-booking prevention verified.');

    // 8 & 9. Provider-Independent Payment Verification & Refund Handling
    // Browser redirect alone must NOT mark a payment verified
    const redirectAttempt = await req(`/api/payments/redirect-callback?paymentReference=${createdBooking.paymentRef}&status=success`);
    assert.equal(redirectAttempt.status, 400, 'Browser redirect alone must be rejected for payment verification');

    // Unsigned webhook must be rejected with 401
    const unsignedWebhook = await req('/api/payments/verify-webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Payment-Signature': 'invalid_forged_signature',
      },
      body: JSON.stringify({
        paymentReference: createdBooking.paymentRef,
        amount: createdBooking.depositRequired,
        status: 'verified',
      }),
    });
    assert.equal(unsignedWebhook.status, 401, 'Forged payment webhook signature must be rejected with 401');

    // Valid HMAC-signed provider webhook must succeed
    const validSig = signPaymentProviderPayload(createdBooking.paymentRef, createdBooking.depositRequired, 'verified');
    const signedWebhook = await req('/api/payments/verify-webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Payment-Signature': validSig,
      },
      body: JSON.stringify({
        paymentReference: createdBooking.paymentRef,
        amount: createdBooking.depositRequired,
        status: 'verified',
      }),
    });
    assert.equal(signedWebhook.status, 200, 'Cryptographically signed payment provider webhook must succeed');

    // Test Refund Handling via Super Admin
    const paymentRow = db.prepare(`SELECT id FROM payment_records WHERE payment_reference = ?`).get(createdBooking.paymentRef) as { id: number };
    const refundRes = await req(`/api/admin/payments/${paymentRow.id}/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({ status: 'refunded' }),
    });
    assert.equal(refundRes.status, 200, 'Payment refund handling must succeed');
    const bookingAfterRefund = db.prepare(`SELECT payment_status FROM bookings WHERE id = ?`).get(createdBooking.id) as { payment_status: string };
    assert.equal(bookingAfterRefund.payment_status, 'refunded', 'Booking payment_status must update to refunded');

    // Clean up test booking
    db.prepare(`DELETE FROM payment_records WHERE booking_id = ?`).run(createdBooking.id);
    db.prepare(`DELETE FROM booking_days WHERE booking_id = ?`).run(createdBooking.id);
    db.prepare(`DELETE FROM booking_status_history WHERE booking_id = ?`).run(createdBooking.id);
    db.prepare(`DELETE FROM hall_availability WHERE booking_id = ?`).run(createdBooking.id);
    db.prepare(`DELETE FROM bookings WHERE id = ?`).run(createdBooking.id);
    console.log('[PASS] 8 & 9. Server-side payment signature verification & refund handling verified.');

    // 10. Strict Cross-Owner Data Isolation
    // Log in as Hall Owner 1 (userId = 2, owns Halls 1, 3, 5) and attempt to modify Hall 2 (owned by Owner 2, userId = 3)
    const owner1Switch = await req('/api/auth/persona-switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: 2 }),
    });
    const owner1Token = owner1Switch.body.token;
    const owner1Csrf = owner1Switch.body.csrfToken;

    const crossOwnerDashboard = await req('/api/owner/dashboard?ownerId=3', {
      headers: { Authorization: `Bearer ${owner1Token}` },
    });
    assert.equal(crossOwnerDashboard.status, 403, 'Owner 1 must be forbidden from viewing Owner 2 dashboard');

    const crossOwnerCalendar = await req('/api/owner/availability', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${owner1Token}`,
        'X-CSRF-Token': owner1Csrf,
      },
      body: JSON.stringify({
        hallId: 2, // Owned by userId 3!
        date: '2026-12-01',
        shift: 'evening',
        status: 'blocked',
        reason: 'Cross-owner tamper attempt',
      }),
    });
    assert.equal(crossOwnerCalendar.status, 403, 'Owner 1 must be forbidden from modifying Owner 2 hall availability');
    console.log('[PASS] 10. Strict cross-owner data isolation verified.');

    // =========================================================================
    // PART 4 AUTOMATED TEST SUITES:
    // 11. Employee Creation by General Manager & Public Registration Block
    // 12. Granular RBAC Permission Assignment, Enforcement & Immediate Revocation
    // 13. Unauthorized Employee Access Blocking & Privilege Escalation Prevention
    // 14. Hall Types & Gender Policy Creation and Filtering
    // 15. Booking Duration Validation & Hourly Time-Slot + Buffer Conflict Prevention
    // =========================================================================

    // 11. Public visitors must NOT be able to register as Employee or General Manager
    const publicEmployeeReg = await req('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Rogue Employee',
        email: `rogue.emp.${Date.now()}@munasabati.ye`,
        phone: '+967 770 111 999',
        password: 'Password123!',
        accountType: 'employee',
        termsAccepted: true,
      }),
    });
    assert.equal(publicEmployeeReg.status, 403, 'Public visitor registration as employee must be rejected with 403');

    // General Manager creates a new employee with specific initial permissions (only halls.view and halls.approve_reject)
    const empEmail = `staff.rbac.${Date.now()}@munasabati.ye`;
    const createEmpRes = await req('/api/admin/employees', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({
        name: 'أمل الشامي (مراجعة القاعات)',
        email: empEmail,
        phone: '+967 771 888 777',
        jobTitle: 'أخصائية تدقيق القاعات',
        department: 'إدارة القاعات',
        password: 'EmpPassword2026!',
        permissions: ['dashboard.view_stats', 'halls.view', 'halls.approve_reject'],
      }),
    });
    assert.ok([200, 201].includes(createEmpRes.status), 'General Manager must be able to create an employee account');
    const createdEmpId = (createEmpRes.body.employee?.id || createEmpRes.body.employeeId || createEmpRes.body.id) as number;
    assert.ok(createdEmpId > 0, 'Created employee must have a valid ID');
    console.log('[PASS] 11. General Manager employee creation & public employee registration block verified.');

    // 12 & 13. Authenticate as the newly created Employee and test strict Granular RBAC
    const empLogin = await req('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: empEmail, password: 'EmpPassword2026!' }),
    });
    assert.equal(empLogin.status, 200, 'Created employee must be able to log in');
    const empToken = empLogin.body.token as string;
    const empCsrf = empLogin.body.csrfToken as string;
    assert.equal(empLogin.body.user.role_slug, 'employee');

    // Employee MUST NOT be able to create other employees or grant themselves permissions
    const empSelfEscalate = await req(`/api/admin/employees/${createdEmpId}/permissions`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${empToken}`,
        'X-CSRF-Token': empCsrf,
      },
      body: JSON.stringify({ permissions: ['bookings.confirm', 'finance.verify_payments'] }),
    });
    assert.equal(empSelfEscalate.status, 403, 'Employee must be blocked from granting themselves additional permissions');

    // Employee without 'bookings.confirm' permission MUST be blocked from confirming bookings
    const empUnauthorizedBookingConfirm = await req('/api/admin/bookings/1/status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${empToken}`,
        'X-CSRF-Token': empCsrf,
      },
      body: JSON.stringify({ status: 'confirmed' }),
    });
    assert.equal(
      empUnauthorizedBookingConfirm.status,
      403,
      'Employee without bookings.confirm permission must be blocked with 403'
    );

    // General Manager dynamically assigns 'bookings.view' and 'bookings.confirm' to the employee
    const grantPermRes = await req(`/api/admin/employees/${createdEmpId}/permissions`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({
        permissions: ['dashboard.view_stats', 'halls.view', 'bookings.view', 'bookings.confirm'],
      }),
    });
    assert.equal(grantPermRes.status, 200, 'General Manager must be able to update employee permissions');

    // Now the Employee CAN confirm a booking
    const empAuthorizedBookingConfirm = await req('/api/admin/bookings/1/status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${empToken}`,
        'X-CSRF-Token': empCsrf,
      },
      body: JSON.stringify({ status: 'confirmed' }),
    });
    assert.equal(
      empAuthorizedBookingConfirm.status,
      200,
      'Employee with bookings.confirm permission must be allowed to confirm bookings'
    );

    // General Manager immediately revokes all permissions from the employee
    const revokeRes = await req(`/api/admin/employees/${createdEmpId}/revoke-permissions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
    });
    assert.equal(revokeRes.status, 200, 'General Manager must be able to revoke all employee permissions immediately');

    // Employee is immediately blocked from confirming bookings again
    const empAfterRevoke = await req('/api/admin/bookings/1/status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${empToken}`,
        'X-CSRF-Token': empCsrf,
      },
      body: JSON.stringify({ status: 'confirmed' }),
    });
    assert.equal(empAfterRevoke.status, 403, 'Employee must be immediately blocked after permission revocation');

    // Clean up test employee
    db.prepare(`DELETE FROM booking_status_history WHERE changed_by = ?`).run(createdEmpId);
    db.prepare(`DELETE FROM hall_availability WHERE updated_by = ?`).run(createdEmpId);
    db.prepare(`DELETE FROM audit_logs WHERE user_id = ?`).run(createdEmpId);
    db.prepare(`DELETE FROM employee_profiles WHERE user_id = ?`).run(createdEmpId);
    db.prepare(`DELETE FROM user_permissions WHERE user_id = ?`).run(createdEmpId);
    db.prepare(`DELETE FROM users WHERE id = ?`).run(createdEmpId);
    console.log('[PASS] 12 & 13. Granular RBAC assignment, enforcement, privilege-escalation block & immediate revocation verified.');

    // 14. Hall Types, Gender Policies & Hourly Duration Limits
    const createMensHallRes = await req('/api/owner/halls', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${owner1Token}`,
        'X-CSRF-Token': owner1Csrf,
      },
      body: JSON.stringify({
        nameAr: 'ديوان الأصالة الملكي للرجال',
        nameEn: 'Al-Asalah Royal Mens Diwan',
        city: 'sanaa',
        address: 'شارع الزبيري — صنعاء',
        hallType: 'mens_hall',
        suitabilityType: 'MEN_ONLY',
        genderPolicy: 'men_only',
        bookingMode: 'both',
        minBookingHours: 3,
        maxBookingHours: 10,
        capacityMin: 150,
        capacityMax: 600,
        startingPrice: 280000,
        hourlyRate: 45000,
        prepBufferHours: 1,
        cleanupBufferHours: 1,
        multiDayDiscountPct: 5,
        additionalFees: 20000,
        descriptionAr: 'قاعة وديوان ملكي مخصص لمناسبات الرجال والمؤتمرات',
        imageUrl: '/api/artwork/al-asalah-diwan',
      }),
    });
    assert.ok([200, 201].includes(createMensHallRes.status), 'Owner must be able to create a hall with Hall Type, SuitabilityType, and Hourly Mode');
    assert.equal(createMensHallRes.body.suitabilityType, 'MEN_ONLY');
    const mensHallId = createMensHallRes.body.hallId as number;

    // Approve the newly created hall via General Manager so it appears in public /api/halls filter
    await req(`/api/admin/halls/${mensHallId}/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({ status: 'approved' }),
    });

    // Filter halls via API by hallType=mens_hall and suitabilityType=MEN_ONLY
    const filterByTypeRes = await req('/api/halls?hallType=mens_hall&suitabilityType=MEN_ONLY');
    assert.equal(filterByTypeRes.status, 200);
    assert.ok(
      filterByTypeRes.body.halls.some(
        (h: { id: number; hall_type: string; suitability_type: string }) =>
          h.id === mensHallId && h.hall_type === 'mens_hall' && h.suitability_type === 'MEN_ONLY'
      ),
      'API hall filter must return the newly created mens_hall with suitability_type MEN_ONLY'
    );
    console.log('[PASS] 14. Hall Types & Suitability Classification creation and filtering verified.');

    // 15. Booking Duration Validation & Hourly Time-Slot + Buffer Conflict Prevention
    const hourlyTestDate = '2026-12-20';
    db.prepare(`DELETE FROM hall_availability WHERE hall_id = ? AND date = ?`).run(mensHallId, hourlyTestDate);
    db.prepare(`DELETE FROM booking_days WHERE hall_id = ? AND date = ?`).run(mensHallId, hourlyTestDate);
    db.prepare(`DELETE FROM bookings WHERE hall_id = ? AND event_date = ?`).run(mensHallId, hourlyTestDate);

    // 15a. Attempt hourly booking with duration below min_booking_hours (2 hours < min 3 hours) -> 400
    const tooShortBooking = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: hourlyTestDate,
        shift: 'hourly',
        startTime: '14:00',
        durationHours: 2, // Below minBookingHours (3)
        eventType: 'mens_hall',
        guestsCount: 250,
        customerName: 'عميل اختبار الساعات',
        customerPhone: '+967 770 123 456',
      }),
    });
    assert.equal(tooShortBooking.status, 400, 'Booking shorter than min_booking_hours must be rejected with 400');

    // 15b. Valid 4-hour custom booking from 14:00 to 18:00 (with 1h prep + 1h cleanup buffer => occupies 13:00 to 19:00)
    const validHourlyBooking = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: hourlyTestDate,
        shift: 'hourly',
        startTime: '14:00',
        durationHours: 4,
        eventType: 'mens_hall',
        guestsCount: 250,
        customerName: 'عميل اختبار الساعات',
        customerPhone: '+967 770 123 456',
      }),
    });
    assert.ok([200, 201].includes(validHourlyBooking.status), 'Valid 4-hour custom slot booking must succeed');
    assert.equal(validHourlyBooking.body.booking.startTime, '14:00');
    assert.equal(validHourlyBooking.body.booking.endTime, '18:00');

    // 15c. Overlapping hourly booking on the same date (16:00 for 4 hours -> 16:00-20:00 overlaps 14:00-18:00 + buffers) -> 409 Conflict
    const overlappingHourlyBooking = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: hourlyTestDate,
        shift: 'hourly',
        startTime: '16:00',
        durationHours: 4,
        eventType: 'mens_hall',
        guestsCount: 200,
        customerName: 'عميل متضارب',
        customerPhone: '+967 770 999 888',
      }),
    });
    assert.equal(
      overlappingHourlyBooking.status,
      409,
      'Overlapping hourly time-slot booking on the same date must be rejected with 409 Conflict'
    );

    // 15d. Non-overlapping hourly booking on the same date (08:00 for 3 hours -> 08:00-11:00, with 1h cleanup ends at 12:00, before 13:00 prep of afternoon booking) -> 200/201 OK
    const nonOverlappingMorningHourly = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: hourlyTestDate,
        shift: 'hourly',
        startTime: '08:00',
        durationHours: 3,
        eventType: 'conference_hall',
        guestsCount: 200,
        customerName: 'عميل فترة صباحية بالساعة',
        customerPhone: '+967 770 555 444',
      }),
    });
    assert.ok(
      [200, 201].includes(nonOverlappingMorningHourly.status),
      'Non-overlapping hourly time-slot on the same date must succeed'
    );
    console.log('[PASS] 15. Booking duration limits & hourly time-slot + buffer conflict prevention verified.');

    // =========================================================================
    // PART 5 AUTOMATED TEST SUITES:
    // 16. Exact Hall Suitability Classification (WOMEN_ONLY, MEN_ONLY, MIXED)
    // 17. True Multi-Day Bookings & Server-Side Quote Calculation
    // 18. Multi-Day Booking Conflict Prevention (ACID Date-Range Lock)
    // 19. Multi-Day Booking Cancellation & Availability Release
    // =========================================================================

    // 16a. Invalid suitabilityType value must be rejected with 400
    const invalidSuitabilityRes = await req('/api/owner/halls', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${owner1Token}`,
        'X-CSRF-Token': owner1Csrf,
      },
      body: JSON.stringify({
        nameAr: 'قاعة تصنيف غير صالح',
        city: 'sanaa',
        address: 'شارع حدة',
        suitabilityType: 'VIP_ONLY_INVALID',
      }),
    });
    assert.equal(invalidSuitabilityRes.status, 400, 'Invalid suitabilityType must be rejected with 400');

    // 16b. Update suitabilityType via Owner PUT /api/owner/halls/:id and verify WOMEN_ONLY, MEN_ONLY, MIXED filtering
    const updateToWomenRes = await req(`/api/owner/halls/${mensHallId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${owner1Token}`,
        'X-CSRF-Token': owner1Csrf,
      },
      body: JSON.stringify({ suitabilityType: 'WOMEN_ONLY' }),
    });
    assert.equal(updateToWomenRes.status, 200, 'Owner must be able to update suitabilityType to WOMEN_ONLY');
    assert.equal(updateToWomenRes.body.suitabilityType, 'WOMEN_ONLY');

    const womenFilterRes = await req('/api/halls?suitabilityType=WOMEN_ONLY');
    assert.equal(womenFilterRes.status, 200);
    assert.ok(
      womenFilterRes.body.halls.every((h: { suitability_type: string }) => h.suitability_type === 'WOMEN_ONLY'),
      'All halls returned for suitabilityType=WOMEN_ONLY must have suitability_type === WOMEN_ONLY'
    );
    assert.ok(
      womenFilterRes.body.halls.some((h: { id: number }) => h.id === mensHallId),
      'Updated hall must appear in WOMEN_ONLY filter'
    );

    // Restore to MEN_ONLY via Admin PUT /api/admin/halls/:id
    const adminRestoreMenRes = await req(`/api/admin/halls/${mensHallId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
        'X-CSRF-Token': adminCsrf,
      },
      body: JSON.stringify({ suitabilityType: 'MEN_ONLY' }),
    });
    assert.equal(adminRestoreMenRes.status, 200);
    assert.equal(adminRestoreMenRes.body.suitabilityType, 'MEN_ONLY');
    console.log('[PASS] 16. Exact Hall Suitability Classification (WOMEN_ONLY, MEN_ONLY, MIXED) validation, editing & filtering verified.');

    // 17. True Multi-Day Bookings & Server-Side Price Quote Calculation
    // Test example from specification: booking starting October 20 for 3 calendar days occupies October 20, 21, and 22
    const multiDayStart = '2026-10-20';
    db.prepare(`DELETE FROM hall_availability WHERE hall_id = ? AND date IN ('2026-10-20', '2026-10-21', '2026-10-22', '2026-10-23')`).run(mensHallId);
    db.prepare(`DELETE FROM booking_days WHERE hall_id = ? AND date IN ('2026-10-20', '2026-10-21', '2026-10-22', '2026-10-23')`).run(mensHallId);

    const quoteRes = await req('/api/bookings/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hallId: mensHallId,
        startDate: multiDayStart,
        bookedDays: 3,
        shift: 'evening',
      }),
    });
    assert.equal(quoteRes.status, 200, 'Server quote endpoint must succeed');
    const quote = quoteRes.body.quote;
    assert.equal(quote.startDate, '2026-10-20', 'Start date must be 2026-10-20');
    assert.equal(quote.endDate, '2026-10-22', 'End date for 3 days starting Oct 20 must be 2026-10-22');
    assert.equal(quote.bookedDays, 3, 'Booked calendar days must be 3');
    assert.deepEqual(quote.bookedDates, ['2026-10-20', '2026-10-21', '2026-10-22']);
    assert.equal(quote.pricePerDay, 280000, 'Price per day must match hall evening package');
    assert.equal(quote.basePrice, 840000, '3 days base price must be 3 * 280000 = 840000');
    assert.ok(quote.discountAmount > 0, 'Multi-day booking must receive multi-day discount');
    assert.ok(quote.additionalFees > 0, 'Multi-day booking must include additional fees');
    assert.equal(quote.isAvailable, true, 'All 3 days must be available before booking');

    // Create the 3-day booking and pass a forged totalPrice: 100 to verify the server ignores browser price
    const multiDayBookingRes = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: multiDayStart,
        bookedDays: 3,
        shift: 'evening',
        guestCount: 300,
        paymentMethod: 'card_payment',
        payDepositNow: true,
        totalPrice: 100, // Forged browser price — server MUST ignore this!
      }),
    });
    assert.equal(multiDayBookingRes.status, 201, 'Multi-day booking for 3 available days must succeed');
    const mb = multiDayBookingRes.body.booking;
    assert.equal(mb.startDate, '2026-10-20');
    assert.equal(mb.endDate, '2026-10-22');
    assert.equal(mb.bookedDays, 3);
    assert.deepEqual(mb.bookedDates, ['2026-10-20', '2026-10-21', '2026-10-22']);
    assert.equal(mb.totalAmount, quote.totalAmount, 'Server must enforce its own calculated totalAmount and ignore browser totalPrice');
    assert.notEqual(mb.totalAmount, 100);
    console.log('[PASS] 17. True multi-day booking (Oct 20..22 = 3 days) & server-side price calculation verified.');

    // 18. Multi-Day Booking Conflict Prevention
    // 18a. Attempt a single-day booking on the middle day (2026-10-21) -> must fail with 409 Conflict
    const overlapMiddleDay = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: '2026-10-21',
        bookedDays: 1,
        shift: 'evening',
        guestCount: 250,
      }),
    });
    assert.equal(overlapMiddleDay.status, 409, 'Booking on middle day (2026-10-21) of an active 3-day booking must fail with 409 Conflict');

    // 18b. Attempt a 2-day booking starting 2026-10-22 (occupies Oct 22 & Oct 23, overlapping Oct 22) -> must fail with 409 Conflict
    const overlapLastDay = await req('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${custToken}`,
        'X-CSRF-Token': custCsrf,
      },
      body: JSON.stringify({
        hallId: mensHallId,
        eventDate: '2026-10-22',
        bookedDays: 2,
        shift: 'evening',
        guestCount: 250,
      }),
    });
    assert.equal(overlapLastDay.status, 409, 'Multi-day booking overlapping the last day (2026-10-22) must fail with 409 Conflict');

    // 18c. Public search /api/halls?date=2026-10-21&days=2 must exclude the booked hall
    const searchConflictRange = await req('/api/halls?date=2026-10-21&days=2');
    assert.equal(
      searchConflictRange.body.halls.some((h: { id: number }) => h.id === mensHallId),
      false,
      'Public search for overlapping multi-day range must exclude the booked hall'
    );
    console.log('[PASS] 18. Multi-day booking overlap prevention & multi-day search availability filter verified.');

    // 19. Multi-Day Booking Cancellation Releases All Occupied Days
    const cancelMultiRes = await req(`/api/owner/bookings/${mb.id}/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${owner1Token}`,
        'X-CSRF-Token': owner1Csrf,
      },
      body: JSON.stringify({ status: 'cancelled' }),
    });
    assert.equal(cancelMultiRes.status, 200, 'Cancelling multi-day booking must succeed');

    const quoteAfterCancel = await req('/api/bookings/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hallId: mensHallId,
        startDate: '2026-10-21',
        bookedDays: 1,
        shift: 'evening',
      }),
    });
    assert.equal(quoteAfterCancel.body.quote.isAvailable, true, 'Cancelled multi-day booking dates must become available again');
    console.log('[PASS] 19. Multi-day booking cancellation & atomic release of all booked calendar days verified.');

    // Clean up test hall & bookings
    db.prepare(`DELETE FROM payment_records WHERE booking_id IN (SELECT id FROM bookings WHERE hall_id = ?)`).run(mensHallId);
    db.prepare(`DELETE FROM booking_days WHERE hall_id = ?`).run(mensHallId);
    db.prepare(`DELETE FROM booking_status_history WHERE booking_id IN (SELECT id FROM bookings WHERE hall_id = ?)`).run(mensHallId);
    db.prepare(`DELETE FROM hall_availability WHERE hall_id = ?`).run(mensHallId);
    db.prepare(`DELETE FROM bookings WHERE hall_id = ?`).run(mensHallId);
    db.prepare(`DELETE FROM hall_pricing WHERE hall_id = ?`).run(mensHallId);
    db.prepare(`DELETE FROM hall_images WHERE hall_id = ?`).run(mensHallId);
    db.prepare(`DELETE FROM halls WHERE id = ?`).run(mensHallId);

    console.log('=== ALL 19 AUTOMATED TEST SUITES PASSED SUCCESSFULLY ===');
  } finally {
    server.close();
  }
}

runTests().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
