<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Inquiry Moderation & Communications Oversight
 * File: admin/inquiries.php
 */

$page_title = 'رقابة وإدارة استفسارات الزوار';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $inquiryId = (int)post('inquiry_id');

    if ($inquiryId > 0) {
        if ($action === 'reply_inquiry') {
            $replyMessage = trim(post('reply_message', ''));
            if (!empty($replyMessage)) {
                try {
                    // Update inquiry status
                    Database::query("UPDATE inquiries SET status = 'replied', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$inquiryId]);

                    // Insert inquiry message
                    Database::query("
                        INSERT INTO inquiry_messages (inquiry_id, sender_id, is_owner_reply, message, created_at)
                        VALUES (?, ?, 1, ?, CURRENT_TIMESTAMP)
                    ", [$inquiryId, $adminId, "رد الإدارة العامة: " . $replyMessage]);

                    setFlash('success', 'تم إرسال رد الإدارة على الاستفسار بنجاح.');
                    redirect(BASE_URL . '/admin/inquiries.php');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ: ' . $e->getMessage());
                }
            }
        } elseif ($action === 'close_inquiry') {
            try {
                Database::query("UPDATE inquiries SET status = 'closed', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$inquiryId]);
                setFlash('success', 'تم إغلاق الاستفسار.');
                redirect(BASE_URL . '/admin/inquiries.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    }
}

// Fetch all inquiries
$inquiries = [];
try {
    $inquiries = Database::fetchAll("
        SELECT i.*, h.name_ar as hall_name, h.city as hall_city,
               u.name as registered_user_name,
               (SELECT COUNT(*) FROM inquiry_messages WHERE inquiry_id = i.id) as messages_count
        FROM inquiries i
        JOIN halls h ON i.hall_id = h.id
        LEFT JOIN users u ON i.user_id = u.id
        ORDER BY (CASE WHEN i.status = 'new' THEN 0 ELSE 1 END), i.created_at DESC
    ");
} catch (Exception $e) {
    $inquiries = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-chat-quote-fill text-gold me-2 ms-2"></i> رقابة الاستفسارات وطلبات التواصل (Inquiry Moderation)
                </h4>
                <p class="text-muted small mb-0">متابعة رسائل العملاء الواردة لإدارات القاعات، والتدخل عند الحاجة للرد أو الرقابة.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($inquiries) ?> استفسار
            </span>
        </div>
    </div>

    <!-- Inquiries List -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>كود الاستفسار</th>
                        <th>القاعة المطلوبة</th>
                        <th>المرسل</th>
                        <th>المناسبة والتاريخ</th>
                        <th>عدد الضيوف</th>
                        <th>الموضوع والرسائل</th>
                        <th>الحالة</th>
                        <th class="text-center">الإجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($inquiries)): ?>
                        <?php foreach ($inquiries as $inq): ?>
                            <tr class="<?= ($inq['status'] === 'new') ? 'table-warning' : '' ?>">
                                <td class="font-monospace fw-bold text-dark-green">
                                    <?= e($inq['inquiry_code']) ?>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= date('Y-m-d', strtotime($inq['created_at'])) ?></div>
                                </td>
                                <td>
                                    <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $inq['hall_id'] ?>" target="_blank" class="fw-bold text-dark-green text-decoration-none">
                                        <?= e($inq['hall_name']) ?>
                                    </a>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= e(getCityName($inq['hall_city'])) ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= e($inq['sender_name']) ?></div>
                                    <a href="tel:<?= e($inq['sender_phone']) ?>" class="text-muted" style="font-size: 0.72rem;"><?= e($inq['sender_phone']) ?></a>
                                    <?php if (!empty($inq['sender_email'])): ?>
                                        <div class="text-muted" style="font-size: 0.72rem;"><?= e($inq['sender_email']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= e(getOccasionTypeName($inq['event_type'])) ?></span>
                                    <?php if (!empty($inq['event_date'])): ?>
                                        <div class="text-primary mt-1" style="font-size: 0.75rem;"><?= e($inq['event_date']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><?= $inq['guest_estimate'] ? (number_format($inq['guest_estimate']) . ' ضيف') : '-' ?></td>
                                <td>
                                    <div class="fw-medium text-dark-green"><?= e($inq['subject'] ?: 'طلب استفسار') ?></div>
                                    <span class="badge bg-secondary-subtle text-secondary" style="font-size: 0.72rem;"><?= $inq['messages_count'] ?> رسائل</span>
                                </td>
                                <td>
                                    <?php
                                        switch ($inq['status']) {
                                            case 'new': echo '<span class="badge bg-danger">جديد</span>'; break;
                                            case 'replied': echo '<span class="badge bg-success">تم الرد</span>'; break;
                                            default: echo '<span class="badge bg-secondary">مغلق</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-outline-dark-green btn-sm py-1 px-2" data-bs-toggle="modal" data-bs-target="#inqModal<?= $inq['id'] ?>">
                                        <i class="bi bi-chat-dots"></i> عرض والرد
                                    </button>

                                    <!-- Inquiry Modal with thread & reply -->
                                    <div class="modal fade" id="inqModal<?= $inq['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                            <div class="modal-content text-start text-rtl">
                                                <div class="modal-header bg-dark-green text-white">
                                                    <h5 class="modal-title fs-6 fw-bold">استفسار: <?= e($inq['inquiry_code']) ?> - <?= e($inq['hall_name']) ?></h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                </div>

                                                <div class="modal-body p-4">
                                                    <!-- Fetch thread messages -->
                                                    <?php
                                                        $msgs = Database::fetchAll("SELECT * FROM inquiry_messages WHERE inquiry_id = ? ORDER BY created_at ASC", [$inq['id']]);
                                                    ?>
                                                    <div class="mb-4">
                                                        <h6 class="fw-bold text-dark-green mb-3 border-bottom pb-2">محادثة الاستفسار</h6>
                                                        <?php if (!empty($msgs)): ?>
                                                            <?php foreach ($msgs as $m): ?>
                                                                <div class="p-3 mb-2 rounded <?= $m['is_owner_reply'] ? 'bg-light border-start border-4 border-gold' : 'bg-success-subtle border-start border-4 border-success' ?>">
                                                                    <div class="d-flex justify-content-between small text-muted mb-1">
                                                                        <span class="fw-bold <?= $m['is_owner_reply'] ? 'text-dark-green' : 'text-success' ?>">
                                                                            <?= $m['is_owner_reply'] ? 'إدارة القاعة / المنصة' : e($inq['sender_name']) ?>
                                                                        </span>
                                                                        <span><?= date('Y-m-d H:i', strtotime($m['created_at'])) ?></span>
                                                                    </div>
                                                                    <p class="mb-0 text-dark"><?= nl2br(e($m['message'])) ?></p>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        <?php else: ?>
                                                            <p class="text-muted small">لا توجد رسائل تفصيلية مسجلة.</p>
                                                        <?php endif; ?>
                                                    </div>

                                                    <!-- Reply Form -->
                                                    <form method="POST" action="<?= BASE_URL ?>/admin/inquiries.php">
                                                        <?= CSRF::field() ?>
                                                        <input type="hidden" name="action" value="reply_inquiry">
                                                        <input type="hidden" name="inquiry_id" value="<?= $inq['id'] ?>">

                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">إرسال رد بصفتك مشرف الإدارة العليا</label>
                                                            <textarea name="reply_message" class="form-control form-control-sm" rows="3" required placeholder="أدخل ردك أو توجيهك للعميل ومالك القاعة..."></textarea>
                                                        </div>

                                                        <div class="d-flex justify-content-between">
                                                            <button type="submit" class="btn btn-dark-green btn-sm fw-bold">إرسال الرد</button>
                                                        </div>
                                                    </form>
                                                </div>

                                                <div class="modal-footer d-flex justify-content-between">
                                                    <form method="POST" action="<?= BASE_URL ?>/admin/inquiries.php" class="d-inline">
                                                        <?= CSRF::field() ?>
                                                        <input type="hidden" name="action" value="close_inquiry">
                                                        <input type="hidden" name="inquiry_id" value="<?= $inq['id'] ?>">
                                                        <button type="submit" class="btn btn-outline-secondary btn-sm" onclick="return confirm('إغلاق هذا الاستفسار؟');">
                                                            <i class="bi bi-archive"></i> إغلاق الاستفسار
                                                        </button>
                                                    </form>
                                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إغلاق النافذة</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا توجد استفسارات مسجلة حتى الآن.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
