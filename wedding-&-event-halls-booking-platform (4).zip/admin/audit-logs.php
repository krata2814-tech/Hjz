<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Security Audit Logs & Compliance Ledger
 * File: admin/audit-logs.php
 */

$page_title = 'سجلات التدقيق الأمني والرقابة';
require_once __DIR__ . '/includes/admin_header.php';

// Filters
$actionFilter = trim($_GET['action_type'] ?? '');
$search = trim($_GET['search'] ?? '');

$sql = "
    SELECT a.*, u.name as user_name, u.email as user_email
    FROM audit_logs a
    LEFT JOIN users u ON a.user_id = u.id
    WHERE 1=1
";
$params = [];

if (!empty($actionFilter)) {
    $sql .= " AND a.action = ?";
    $params[] = $actionFilter;
}

if (!empty($search)) {
    $sql .= " AND (a.action LIKE ? OR a.entity_type LIKE ? OR a.details_json LIKE ? OR u.name LIKE ? OR a.ip_address LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY a.created_at DESC LIMIT 100";

$logs = [];
try {
    $logs = Database::fetchAll($sql, $params);
} catch (Exception $e) {
    $logs = [];
}

// Fetch distinct actions for filter dropdown
$distinctActions = [];
try {
    $distinctActions = Database::fetchAll("SELECT DISTINCT action FROM audit_logs ORDER BY action ASC");
} catch (Exception $e) {
    $distinctActions = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-shield-shaded text-gold me-2 ms-2"></i> سجلات التدقيق الأمني والعمليات الإدارية (Audit Logs)
                </h4>
                <p class="text-muted small mb-0">توثيق شامل ومقاوم للتلاعب لجميع العمليات الحساسة، التعديلات الإدارية، وعناوين IP والتوقيتات.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($logs) ?> سجل معروض
            </span>
        </div>
    </div>

    <!-- Filters Toolbar -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <form method="GET" action="<?= BASE_URL ?>/admin/audit-logs.php" class="row g-2 align-items-center">
            <div class="col-md-6 col-12">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="بحث بالعملية، الكيان، المستخدم، عنوان IP، أو التفاصيل..." value="<?= e($search) ?>">
                </div>
            </div>

            <div class="col-md-4 col-8">
                <select name="action_type" class="form-select form-select-sm">
                    <option value="">جميع أنواع العمليات (All Actions)</option>
                    <?php foreach ($distinctActions as $act): ?>
                        <option value="<?= e($act['action']) ?>" <?= ($actionFilter === $act['action']) ? 'selected' : '' ?>>
                            <?= e($act['action']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2 col-4 d-flex gap-1">
                <button type="submit" class="btn btn-dark-green btn-sm w-100">تصفية</button>
                <a href="<?= BASE_URL ?>/admin/audit-logs.php" class="btn btn-outline-secondary btn-sm" title="إعادة ضبط"><i class="bi bi-arrow-counterclockwise"></i></a>
            </div>
        </form>
    </div>

    <!-- Logs Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th># المعرف</th>
                        <th>المسؤول / المستخدم</th>
                        <th>العملية (Action)</th>
                        <th>الكيان (Entity)</th>
                        <th>تفاصيل الحدث (JSON Payload)</th>
                        <th>عنوان IP</th>
                        <th>المتصفح</th>
                        <th>التاريخ والتوقيت</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($logs)): ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $log['id'] ?></td>
                                <td>
                                    <strong><?= e($log['user_name'] ?: 'النظام / تلقائي') ?></strong>
                                    <?php if (!empty($log['user_email'])): ?>
                                        <div class="text-muted" style="font-size: 0.72rem;"><?= e($log['user_email']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark-green border font-monospace">
                                        <?= e($log['action']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?= e($log['entity_type'] ?? '-') ?>
                                    <?php if (!empty($log['entity_id'])): ?>
                                        <span class="font-monospace text-muted">#<?= $log['entity_id'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="max-width: 320px;">
                                    <?php
                                        $details = json_decode($log['details_json'] ?? '', true);
                                        if (is_array($details)):
                                    ?>
                                        <div class="bg-light p-1 rounded font-monospace small" style="font-size: 0.72rem; max-height: 80px; overflow-y: auto;">
                                            <?php foreach ($details as $k => $v): ?>
                                                <div><strong><?= e($k) ?>:</strong> <?= is_array($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : e((string)$v) ?></div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted"><?= e($log['details_json'] ?? '-') ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="font-monospace text-muted"><?= e($log['ip_address'] ?? '127.0.0.1') ?></td>
                                <td class="text-truncate text-muted" style="max-width: 140px;" title="<?= e($log['user_agent'] ?? '') ?>">
                                    <?= e($log['user_agent'] ?? '-') ?>
                                </td>
                                <td>
                                    <span class="fw-bold"><?= date('Y-m-d', strtotime($log['created_at'])) ?></span>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= date('H:i:s', strtotime($log['created_at'])) ?></div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا توجد سجلات تدقيق مطابقة للبحث.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
