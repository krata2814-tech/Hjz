<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Financial Reports, Platform Commission & Analytics Module
 * File: admin/reports.php
 */

$page_title = 'التقارير المالية وحسابات العمولات';
require_once __DIR__ . '/includes/admin_header.php';

// Commission setting (from database or default 5.0%)
$commSetting = Database::fetchOne("SELECT setting_value FROM platform_settings WHERE setting_key = 'platform_commission_percentage'");
$commissionRate = $commSetting ? (float)$commSetting['setting_value'] : 5.0; // 5%

// 1. Strict financial calculations from actual verified payment_records
$totalVerifiedPayments = 0.0;
$totalPendingPayments = 0.0;
$totalRefundedPayments = 0.0;

try {
    $rowV = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'verified'");
    $totalVerifiedPayments = (float)($rowV['s'] ?? 0.0);

    $rowP = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'pending_verification'");
    $totalPendingPayments = (float)($rowP['s'] ?? 0.0);

    $rowR = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'refunded'");
    $totalRefundedPayments = (float)($rowR['s'] ?? 0.0);
} catch (Exception $e) {
    // Graceful
}

// Net Platform Commission and Owner Share (Calculated strictly from verified payments)
$platformCommissionTotal = $totalVerifiedPayments * ($commissionRate / 100.0);
$hallOwnersNetTotal = $totalVerifiedPayments - $platformCommissionTotal;

// 2. Total Gross Booking Contract Value (All confirmed bookings)
$grossBookingContracts = 0.0;
try {
    $grossRow = Database::fetchOne("SELECT SUM(total_amount) as s FROM bookings WHERE status = 'confirmed'");
    $grossBookingContracts = (float)($grossRow['s'] ?? 0.0);
} catch (Exception $e) {
    $grossBookingContracts = 0.0;
}

// 3. Hall-by-Hall Financial Breakdown (Only verified transactions)
$hallFinancials = [];
try {
    $hallFinancials = Database::fetchAll("
        SELECT h.id, h.name_ar as hall_name, h.city, u.name as owner_name,
               COUNT(p.id) as transactions_count,
               COALESCE(SUM(p.amount), 0) as verified_collected
        FROM halls h
        JOIN users u ON h.owner_id = u.id
        LEFT JOIN bookings b ON h.id = b.hall_id
        LEFT JOIN payment_records p ON b.id = p.booking_id AND p.status = 'verified'
        GROUP BY h.id, h.name_ar, h.city, u.name
        ORDER BY verified_collected DESC
    ");
} catch (Exception $e) {
    $hallFinancials = [];
}

// 4. Recent Real Payment Transactions
$recentPayments = [];
try {
    $recentPayments = Database::fetchAll("
        SELECT p.*, b.booking_code, h.name_ar as hall_name, u.name as customer_name
        FROM payment_records p
        LEFT JOIN bookings b ON p.booking_id = b.id
        LEFT JOIN halls h ON b.hall_id = h.id
        LEFT JOIN users u ON p.user_id = u.id
        ORDER BY p.created_at DESC
        LIMIT 15
    ");
} catch (Exception $e) {
    $recentPayments = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-graph-up-arrow text-gold me-2 ms-2"></i> التقارير المالية واحتساب العمولات (Financial Reports)
                </h4>
                <p class="text-muted small mb-0">
                    تقارير مالية دقيقة ومحسوبة <strong class="text-dark">حصراً من المعاملات المسددة والمحققة فعلياً</strong>، مع تمييز دقيق بين إيرادات الملاك وعمولة المنصة.
                </p>
            </div>

            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-dark-green btn-sm fw-bold" onclick="window.print();">
                    <i class="bi bi-printer me-1 ms-1"></i> طباعة التقرير المالي
                </button>
            </div>
        </div>
    </div>

    <!-- Financial KPI Cards: Strict separation as requested -->
    <div class="row g-3 mb-4">
        <!-- 1. Total Booking Value (Gross Contracts) -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-top border-4 border-primary">
                <span class="text-muted small fw-medium">إجمالي قيمة العقود المؤكدة (Gross Contracts)</span>
                <div class="fs-3 fw-bold text-dark-green font-heading mt-1"><?= formatMoney($grossBookingContracts) ?></div>
                <div class="small text-muted mt-2 pt-2 border-top">
                    <i class="bi bi-file-earmark-text"></i> القيمة الاسمية الكلية لكافة الحجوزات
                </div>
            </div>
        </div>

        <!-- 2. Actual Verified Collected Payments -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-top border-4 border-success">
                <span class="text-muted small fw-medium">المدفوعات المحصلة المؤكدة (Verified Payments)</span>
                <div class="fs-3 fw-bold text-success font-heading mt-1"><?= formatMoney($totalVerifiedPayments) ?></div>
                <div class="small text-muted mt-2 pt-2 border-top">
                    <i class="bi bi-check2-circle text-success"></i> المبالغ المقبوضة بسندات رسمية
                </div>
            </div>
        </div>

        <!-- 3. Platform Commission Earned -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-top border-4 border-gold">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted small fw-medium">عمولة المنصة الصافية (Platform Commission)</span>
                    <span class="badge bg-gold text-dark fs-8"><?= $commissionRate ?>%</span>
                </div>
                <div class="fs-3 fw-bold text-gold font-heading mt-1"><?= formatMoney($platformCommissionTotal) ?></div>
                <div class="small text-muted mt-2 pt-2 border-top">
                    <i class="bi bi-pie-chart-fill text-gold"></i> الدخل الفعلي لمنصة إيوان
                </div>
            </div>
        </div>

        <!-- 4. Hall Owners Share / Net Revenue -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-top border-4 border-dark-green">
                <span class="text-muted small fw-medium">صافي مستحقات ملاك القاعات (Owners Net)</span>
                <div class="fs-3 fw-bold text-dark-green font-heading mt-1"><?= formatMoney($hallOwnersNetTotal) ?></div>
                <div class="small text-muted mt-2 pt-2 border-top">
                    <i class="bi bi-wallet2 text-dark-green"></i> بعد خصم عمولة المنصة
                </div>
            </div>
        </div>
    </div>

    <!-- Secondary Indicators: Pending Payments & Refunds -->
    <div class="row g-3 mb-4">
        <div class="col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm d-flex flex-row justify-content-between align-items-center">
                <div>
                    <div class="text-muted small">مدفوعات قيد التحقق والتدقيق (Pending Verification)</div>
                    <div class="fs-4 fw-bold text-warning font-heading"><?= formatMoney($totalPendingPayments) ?></div>
                    <span class="text-muted" style="font-size: 0.75rem;">لا تُحتسب كدخل حتى يتم التحقق البنكي منها</span>
                </div>
                <div class="rounded-circle bg-warning-subtle text-warning p-3 fs-4">
                    <i class="bi bi-hourglass-split"></i>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm d-flex flex-row justify-content-between align-items-center">
                <div>
                    <div class="text-muted small">المبالغ المستردة للعملاء (Refunds)</div>
                    <div class="fs-4 fw-bold text-danger font-heading"><?= formatMoney($totalRefundedPayments) ?></div>
                    <span class="text-muted" style="font-size: 0.75rem;">عمليات إلغاء معتمدة ومسترجعة</span>
                </div>
                <div class="rounded-circle bg-danger-subtle text-danger p-3 fs-4">
                    <i class="bi bi-arrow-return-left"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Hall-by-Hall Financial Performance Table -->
    <div class="card border rounded-3 p-4 mb-4 bg-white shadow-sm">
        <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-building text-gold"></i> التوزيع المالي حسب القاعات والصالات (Hall Financial Breakdown)
        </h5>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>القاعة</th>
                        <th>المدينة</th>
                        <th>المالك</th>
                        <th>حركات السداد المقبوضة</th>
                        <th>إجمالي المقبوض المؤكد</th>
                        <th>عمولة المنصة (<?= $commissionRate ?>%)</th>
                        <th>صافي المالك المستحق</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($hallFinancials)): ?>
                        <?php foreach ($hallFinancials as $hf): ?>
                            <?php
                                $col = (float)$hf['verified_collected'];
                                $hallComm = $col * ($commissionRate / 100.0);
                                $hallOwnerNet = $col - $hallComm;
                            ?>
                            <tr>
                                <td class="fw-bold text-dark-green"><?= e($hf['hall_name']) ?></td>
                                <td><?= e(getCityName($hf['city'])) ?></td>
                                <td><?= e($hf['owner_name']) ?></td>
                                <td><span class="badge bg-light text-dark border"><?= $hf['transactions_count'] ?> سند</span></td>
                                <td class="fw-bold text-dark"><?= formatMoney($col) ?></td>
                                <td class="fw-bold text-gold"><?= formatMoney($hallComm) ?></td>
                                <td class="fw-bold text-dark-green"><?= formatMoney($hallOwnerNet) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-3 text-muted">لا توجد بيانات قاعات.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Actual Payment Transactions Feed -->
    <div class="card border rounded-3 p-4 bg-white shadow-sm">
        <h5 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-cash-stack text-gold"></i> سجل المقبوضات والتحويلات المالية المسجلة (Payment Records)
        </h5>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>رقم السند</th>
                        <th>الحجز</th>
                        <th>القاعة</th>
                        <th>العميل</th>
                        <th>المبلغ المقبوض</th>
                        <th>طريقة الدفع</th>
                        <th>رقم العملية / الإشعار</th>
                        <th>النوع</th>
                        <th>الحالة</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($recentPayments)): ?>
                        <?php foreach ($recentPayments as $p): ?>
                            <tr>
                                <td class="font-monospace fw-bold text-dark-green"><?= e($p['payment_reference']) ?></td>
                                <td class="font-monospace"><?= e($p['booking_code'] ?? '-') ?></td>
                                <td><?= e($p['hall_name'] ?? '-') ?></td>
                                <td><?= e($p['customer_name'] ?? '-') ?></td>
                                <td class="fw-bold text-success"><?= formatMoney($p['amount'], $p['currency']) ?></td>
                                <td>
                                    <?php
                                        switch ($p['payment_method']) {
                                            case 'kuraimi_pay': echo '<span class="badge bg-light text-dark border">الكريمي جوال</span>'; break;
                                            case 'bank_transfer': echo '<span class="badge bg-light text-dark border">تحويل بنكي</span>'; break;
                                            default: echo '<span class="badge bg-light text-dark border">نقداً</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="font-monospace text-muted"><?= e($p['transaction_number'] ?? '-') ?></td>
                                <td>
                                    <?= ($p['payment_type'] === 'full_payment') ? 'سداد كامل' : 'عربون' ?>
                                </td>
                                <td>
                                    <?php
                                        switch ($p['status']) {
                                            case 'verified': echo '<span class="badge bg-success">معتمد ومقبوض</span>'; break;
                                            case 'pending_verification': echo '<span class="badge bg-warning text-dark">بانتظار التحقق</span>'; break;
                                            case 'refunded': echo '<span class="badge bg-danger">مسترجع</span>'; break;
                                            default: echo '<span class="badge bg-secondary">' . e($p['status']) . '</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td><?= date('Y-m-d H:i', strtotime($p['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center py-3 text-muted">لا توجد سجلات مدفوعات مسجلة بعد.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
