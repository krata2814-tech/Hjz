<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Review Moderation & Quality Assurance Module
 * File: admin/reviews.php
 */

$page_title = 'مراجعة واعتماد تقييمات العملاء';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $reviewId = (int)post('review_id');

    if ($reviewId > 0) {
        $review = Database::fetchOne("SELECT * FROM reviews WHERE id = ?", [$reviewId]);

        // 1. Approve or Reject Review
        if (in_array($action, ['approve_review', 'reject_review'])) {
            $newStatus = ($action === 'approve_review') ? 'approved' : 'rejected';
            try {
                Database::query("UPDATE reviews SET status = ? WHERE id = ?", [$newStatus, $reviewId]);

                // Recalculate average rating for the hall
                if (!empty($review['hall_id'])) {
                    $hallId = (int)$review['hall_id'];
                    $avgRow = Database::fetchOne("
                        SELECT AVG(rating_overall) as avg_rating, COUNT(*) as cnt 
                        FROM reviews 
                        WHERE hall_id = ? AND status = 'approved'
                    ", [$hallId]);

                    $newRating = $avgRow ? round((float)$avgRow['avg_rating'], 1) : 0.0;
                    $newCount = (int)($avgRow['cnt'] ?? 0);

                    Database::query("UPDATE halls SET rating = ?, reviews_count = ? WHERE id = ?", [$newRating, $newCount, $hallId]);
                }

                // Audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'review_moderated', 'reviews', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId, $reviewId,
                    json_encode(['status' => $newStatus, 'hall_id' => $review['hall_id']], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', ($newStatus === 'approved') ? 'تم اعتماد ونشر التقييم بنجاح وتحديث معدل تقييم القاعة.' : 'تم حجب التقييم.');
                redirect(BASE_URL . '/admin/reviews.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }

        // 2. Delete Fake / Inappropriate Review
        elseif ($action === 'delete_review') {
            try {
                Database::query("DELETE FROM reviews WHERE id = ?", [$reviewId]);

                if (!empty($review['hall_id'])) {
                    $hallId = (int)$review['hall_id'];
                    $avgRow = Database::fetchOne("
                        SELECT AVG(rating_overall) as avg_rating, COUNT(*) as cnt 
                        FROM reviews 
                        WHERE hall_id = ? AND status = 'approved'
                    ", [$hallId]);
                    $newRating = $avgRow ? round((float)$avgRow['avg_rating'], 1) : 0.0;
                    $newCount = (int)($avgRow['cnt'] ?? 0);
                    Database::query("UPDATE halls SET rating = ?, reviews_count = ? WHERE id = ?", [$newRating, $newCount, $hallId]);
                }

                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'review_deleted', 'reviews', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId, $reviewId,
                    json_encode(['deleted_review_id' => $reviewId], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', 'تم حذف التقييم نهائياً من المنظومة.');
                redirect(BASE_URL . '/admin/reviews.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    }
}

// Fetch all reviews
$statusFilter = trim($_GET['status'] ?? '');
$sql = "
    SELECT r.*, h.name_ar as hall_name, h.city as hall_city,
           u.name as customer_name, u.phone as customer_phone, u.email as customer_email,
           b.booking_code
    FROM reviews r
    JOIN halls h ON r.hall_id = h.id
    JOIN users u ON r.customer_id = u.id
    LEFT JOIN bookings b ON r.booking_id = b.id
    WHERE 1=1
";
$params = [];
if (!empty($statusFilter)) {
    $sql .= " AND r.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY (CASE WHEN r.status = 'pending' THEN 0 ELSE 1 END), r.created_at DESC";

$reviews = [];
try {
    $reviews = Database::fetchAll($sql, $params);
} catch (Exception $e) {
    $reviews = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-star-fill text-gold me-2 ms-2"></i> مراجعة واعتماد تقييمات العملاء (Review Moderation)
                </h4>
                <p class="text-muted small mb-0">ضمان مصداقية التقييمات، اعتماد آراء العملاء الحقيقية، وحجب التقييمات الوهمية أو غير اللائقة.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($reviews) ?> تقييم
            </span>
        </div>
    </div>

    <!-- Filters -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/admin/reviews.php" class="btn btn-sm <?= empty($statusFilter) ? 'btn-dark-green' : 'btn-outline-secondary' ?>">الكل</a>
            <a href="<?= BASE_URL ?>/admin/reviews.php?status=pending" class="btn btn-sm <?= ($statusFilter === 'pending') ? 'btn-warning text-dark' : 'btn-outline-warning' ?>">بانتظار المراجعة (Pending)</a>
            <a href="<?= BASE_URL ?>/admin/reviews.php?status=approved" class="btn btn-sm <?= ($statusFilter === 'approved') ? 'btn-success' : 'btn-outline-success' ?>">معتمدة ومنشورة (Approved)</a>
            <a href="<?= BASE_URL ?>/admin/reviews.php?status=rejected" class="btn btn-sm <?= ($statusFilter === 'rejected') ? 'btn-danger' : 'btn-outline-danger' ?>">مرفوضة (Rejected)</a>
        </div>
    </div>

    <!-- Reviews Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>القاعة</th>
                        <th>العميل</th>
                        <th>كود الحجز</th>
                        <th>التقييم العام</th>
                        <th>المعايير (نظافة / ضيافة / خدمات)</th>
                        <th>التعليق المكتوب</th>
                        <th>الحالة</th>
                        <th class="text-center">القرار والإجراء</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($reviews)): ?>
                        <?php foreach ($reviews as $rev): ?>
                            <tr class="<?= ($rev['status'] === 'pending') ? 'table-warning' : '' ?>">
                                <td>
                                    <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $rev['hall_id'] ?>" target="_blank" class="fw-bold text-dark-green text-decoration-none">
                                        <?= e($rev['hall_name']) ?>
                                    </a>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= e(getCityName($rev['hall_city'])) ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= e($rev['customer_name']) ?></div>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= e($rev['customer_phone']) ?></div>
                                </td>
                                <td>
                                    <?= !empty($rev['booking_code']) ? '<span class="badge bg-light text-dark font-monospace border">' . e($rev['booking_code']) . '</span>' : '<span class="text-muted">-</span>' ?>
                                </td>
                                <td>
                                    <div class="text-warning fw-bold fs-6">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="bi <?= ($i <= $rev['rating_overall']) ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                        <?php endfor; ?>
                                        <span class="text-dark small ms-1">(<?= $rev['rating_overall'] ?>/5)</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-muted" style="font-size: 0.72rem;">
                                        نظافة: <strong><?= $rev['rating_cleanliness'] ?? '-' ?></strong> &bull; 
                                        ضيافة: <strong><?= $rev['rating_hospitality'] ?? '-' ?></strong> &bull; 
                                        خدمات: <strong><?= $rev['rating_services'] ?? '-' ?></strong>
                                    </div>
                                </td>
                                <td style="max-width: 250px;">
                                    <p class="mb-0 text-dark"><?= e($rev['comment'] ?? 'بدون تعليق نصي') ?></p>
                                    <div class="text-muted" style="font-size: 0.7rem;"><?= date('Y-m-d H:i', strtotime($rev['created_at'])) ?></div>
                                </td>
                                <td>
                                    <?php
                                        switch ($rev['status']) {
                                            case 'approved': echo '<span class="badge bg-success">معتمد ومنشور</span>'; break;
                                            case 'rejected': echo '<span class="badge bg-danger">مرفوض ومحجوب</span>'; break;
                                            default: echo '<span class="badge bg-warning text-dark">قيد المراجعة</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <?php if ($rev['status'] !== 'approved'): ?>
                                            <form method="POST" action="<?= BASE_URL ?>/admin/reviews.php" class="d-inline">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="action" value="approve_review">
                                                <input type="hidden" name="review_id" value="<?= $rev['id'] ?>">
                                                <button type="submit" class="btn btn-success btn-sm py-1 px-2" title="اعتماد ونشر">
                                                    <i class="bi bi-check-lg"></i> اعتماد
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <?php if ($rev['status'] !== 'rejected'): ?>
                                            <form method="POST" action="<?= BASE_URL ?>/admin/reviews.php" class="d-inline">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="action" value="reject_review">
                                                <input type="hidden" name="review_id" value="<?= $rev['id'] ?>">
                                                <button type="submit" class="btn btn-outline-warning btn-sm py-1 px-2" title="حجب">
                                                    <i class="bi bi-eye-slash"></i> حجب
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <form method="POST" action="<?= BASE_URL ?>/admin/reviews.php" class="d-inline" onsubmit="return confirm('حذف هذا التقييم نهائياً؟');">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="action" value="delete_review">
                                            <input type="hidden" name="review_id" value="<?= $rev['id'] ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm py-1 px-2" title="حذف">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا توجد تقييمات مسجلة حالياً.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
