<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Super Admin Master Dashboard
 * File: admin/index.php
 */

$page_title = 'لوحة الإدارة العليا والتحكم المركزي';
require_once __DIR__ . '/includes/admin_header.php';

// Handle Direct Quick Actions (Approve or Reject Hall with Reason)
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    if ($action === 'approve_hall') {
        $hallId = (int)post('hall_id');
        if ($hallId > 0) {
            try {
                Database::query("UPDATE halls SET status = 'active', rejection_reason = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$hallId]);
                
                // Get hall details
                $hall = Database::fetchOne("SELECT name_ar, owner_id FROM halls WHERE id = ?", [$hallId]);

                // Create audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'hall_approved', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId,
                    $hallId,
                    json_encode(['hall_name' => $hall['name_ar'] ?? '', 'status' => 'active'], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                // Notify owner if owner exists
                if (!empty($hall['owner_id'])) {
                    Database::query("
                        INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                        VALUES (?, 'تم اعتماد قاعتكم بنجاح!', 'Hall Approved', ?, ?, 'hall_approved', ?, CURRENT_TIMESTAMP)
                    ", [
                        $hall['owner_id'],
                        "تهانينا، تمت مراجعة واعتماد قاعتكم (" . ($hall['name_ar'] ?? '') . ") وأصبحت متاحة للجمهور الآن.",
                        "Congratulations, your hall has been approved and is now active.",
                        BASE_URL . "/hall-details.php?id=" . $hallId
                    ]);
                }

                setFlash('success', 'تم اعتماد ونشر القاعة بنجاح وأصبحت ظاهرة للجمهور.');
                redirect(BASE_URL . '/admin/index.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ أثناء اعتماد القاعة: ' . $e->getMessage());
            }
        }
    } elseif ($action === 'reject_hall') {
        $hallId = (int)post('hall_id');
        $reason = trim(post('rejection_reason', ''));

        if ($hallId > 0) {
            if (empty($reason)) {
                setFlash('warning', 'يرجى كتابة سبب الرفض لتوضيحه لمالك القاعة.');
            } else {
                try {
                    Database::query("UPDATE halls SET status = 'rejected', rejection_reason = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$reason, $hallId]);
                    
                    $hall = Database::fetchOne("SELECT name_ar, owner_id FROM halls WHERE id = ?", [$hallId]);

                    // Audit log
                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'hall_rejected', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId,
                        $hallId,
                        json_encode(['hall_name' => $hall['name_ar'] ?? '', 'status' => 'rejected', 'reason' => $reason], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    // Notify owner
                    if (!empty($hall['owner_id'])) {
                        Database::query("
                            INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                            VALUES (?, 'تم رفض إدراج القاعة', 'Hall Rejected', ?, ?, 'hall_rejected', ?, CURRENT_TIMESTAMP)
                        ", [
                            $hall['owner_id'],
                            "نعتذر، تم رفض طلب إدراج قاعتكم (" . ($hall['name_ar'] ?? '') . ") للسبب التالي: " . $reason,
                            "Your hall listing was rejected: " . $reason,
                            BASE_URL . "/dashboard.php"
                        ]);
                    }

                    setFlash('warning', 'تم رفض إدراج القاعة مع توثيق السبب وإرسال إشعار للمالك.');
                    redirect(BASE_URL . '/admin/index.php');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ أثناء رفض القاعة: ' . $e->getMessage());
                }
            }
        }
    }
}

// 1. Database-backed Comprehensive Statistics
$stats = [
    'total_users' => 0,
    'total_customers' => 0,
    'total_owners' => 0,
    'total_employees' => 0,
    'total_halls' => 0,
    'pending_halls' => 0,
    'active_halls' => 0,
    'rejected_halls' => 0,
    'pending_bookings' => 0,
    'confirmed_bookings' => 0,
    'cancelled_bookings' => 0,
    'completed_bookings' => 0,
    'total_bookings' => 0,
    // Real Financial Transactions
    'gross_booking_value' => 0.0,
    'verified_payments' => 0.0,
    'pending_payments' => 0.0,
    'platform_commission' => 0.0,
    'owner_net_revenue' => 0.0,
    'refunds' => 0.0,
];

try {
    // User role breakdown
    $userCounts = Database::fetchAll("
        SELECT r.slug, COUNT(u.id) as count 
        FROM roles r 
        LEFT JOIN users u ON r.id = u.role_id 
        GROUP BY r.slug
    ");
    foreach ($userCounts as $uc) {
        if ($uc['slug'] === 'customer') $stats['total_customers'] = (int)$uc['count'];
        elseif ($uc['slug'] === 'hall_owner') $stats['total_owners'] = (int)$uc['count'];
        elseif ($uc['slug'] === 'employee') $stats['total_employees'] = (int)$uc['count'];
    }
    $stats['total_users'] = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM users")['c'] ?? 0);

    // Halls breakdown
    $hallCounts = Database::fetchAll("SELECT status, COUNT(*) as c FROM halls GROUP BY status");
    foreach ($hallCounts as $hc) {
        if ($hc['status'] === 'active') $stats['active_halls'] = (int)$hc['c'];
        elseif ($hc['status'] === 'pending_approval') $stats['pending_halls'] = (int)$hc['c'];
        elseif ($hc['status'] === 'rejected') $stats['rejected_halls'] = (int)$hc['c'];
    }
    $stats['total_halls'] = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM halls")['c'] ?? 0);

    // Bookings breakdown
    $bookingCounts = Database::fetchAll("SELECT status, COUNT(*) as c, SUM(total_amount) as sum_total FROM bookings GROUP BY status");
    foreach ($bookingCounts as $bc) {
        if ($bc['status'] === 'pending') $stats['pending_bookings'] = (int)$bc['c'];
        elseif ($bc['status'] === 'confirmed') $stats['confirmed_bookings'] = (int)$bc['c'];
        elseif ($bc['status'] === 'cancelled') $stats['cancelled_bookings'] = (int)$bc['c'];
        elseif ($bc['status'] === 'completed') $stats['completed_bookings'] = (int)$bc['c'];
        $stats['total_bookings'] += (int)$bc['c'];
        $stats['gross_booking_value'] += (float)($bc['sum_total'] ?? 0);
    }

    // Real financial records from payment_records
    $payVerified = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'verified'")['s'] ?? 0.0;
    $payPending = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'pending_verification'")['s'] ?? 0.0;
    $payRefunded = Database::fetchOne("SELECT SUM(amount) as s FROM payment_records WHERE status = 'refunded'")['s'] ?? 0.0;

    $stats['verified_payments'] = (float)$payVerified;
    $stats['pending_payments'] = (float)$payPending;
    $stats['refunds'] = (float)$payRefunded;

    // Platform commission rate (from settings or default 5%)
    $commSetting = Database::fetchOne("SELECT setting_value FROM platform_settings WHERE setting_key = 'platform_commission_percentage'");
    $commissionRate = $commSetting ? (float)$commSetting['setting_value'] : 5.0; // 5% default

    // Calculate platform income strictly from actual recorded verified transactions
    $stats['platform_commission'] = ($stats['verified_payments'] * ($commissionRate / 100.0));
    $stats['owner_net_revenue'] = $stats['verified_payments'] - $stats['platform_commission'];

} catch (Exception $e) {
    // Graceful error logging
}

// 2. Pending Hall Approvals Queue
$pendingHalls = [];
try {
    $pendingHalls = Database::fetchAll("
        SELECT h.*, u.name as owner_name, u.email as owner_email, u.phone as owner_phone,
               (SELECT image_url FROM hall_images WHERE hall_id = h.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) as cover_img
        FROM halls h
        JOIN users u ON h.owner_id = u.id
        WHERE h.status = 'pending_approval'
        ORDER BY h.created_at ASC
    ");
} catch (Exception $e) {
    $pendingHalls = [];
}

// 3. Recent Registrations
$recentUsers = [];
try {
    $recentUsers = Database::fetchAll("
        SELECT u.*, r.name_ar as role_name, r.slug as role_slug
        FROM users u
        JOIN roles r ON u.role_id = r.id
        ORDER BY u.created_at DESC
        LIMIT 6
    ");
} catch (Exception $e) {
    $recentUsers = [];
}

// 4. Recent Booking Activity
$recentBookings = [];
try {
    $recentBookings = Database::fetchAll("
        SELECT b.*, h.name_ar as hall_name, h.city as hall_city, u.name as customer_name, u.phone as customer_phone
        FROM bookings b
        JOIN halls h ON b.hall_id = h.id
        JOIN users u ON b.customer_id = u.id
        ORDER BY b.created_at DESC
        LIMIT 6
    ");
} catch (Exception $e) {
    $recentBookings = [];
}

// 5. Recent Security Audit Logs
$recentAuditLogs = [];
try {
    $recentAuditLogs = Database::fetchAll("
        SELECT a.*, u.name as user_name, u.email as user_email
        FROM audit_logs a
        LEFT JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
        LIMIT 6
    ");
} catch (Exception $e) {
    $recentAuditLogs = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Top Admin Welcome & Status Banner -->
    <div class="card border rounded-3 p-4 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <div class="d-flex align-items-center gap-2 mb-1">
                    <span class="badge bg-gold text-dark fs-7 px-2 py-1 fw-bold">Super Admin</span>
                    <h1 class="h4 fw-bold text-dark-green mb-0">لوحة التحكم والرقابة الإدارية الشاملة</h1>
                </div>
                <p class="text-muted small mb-0">
                    مرحباً بك، <span class="fw-bold text-dark-green"><?= e($adminUser['name']) ?></span>. نظام إدارة وحجز قاعات الأفراح والمناسبات يعمل بكفاءة وأمان كامل.
                </p>
            </div>

            <div class="d-flex flex-wrap gap-2">
                <a href="<?= BASE_URL ?>/admin/halls.php?status=pending_approval" class="btn btn-warning btn-sm fw-bold">
                    <i class="bi bi-clock-history me-1 ms-1"></i> طلبات اعتماد القاعات (<?= $stats['pending_halls'] ?>)
                </a>
                <a href="<?= BASE_URL ?>/admin/reports.php" class="btn btn-outline-dark-green btn-sm fw-bold">
                    <i class="bi bi-graph-up me-1 ms-1"></i> التقارير والعمولات
                </a>
                <a href="<?= BASE_URL ?>/admin/users.php?action=create" class="btn btn-dark-green btn-sm fw-bold">
                    <i class="bi bi-person-plus-fill me-1 ms-1"></i> إضافة موظف / مشرف
                </a>
            </div>
        </div>
    </div>

    <!-- KPI Section: 1. Users, 2. Halls, 3. Bookings, 4. Verified Finances -->
    <div class="row g-3 mb-4">
        <!-- Users Breakdown -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-start border-4 border-primary">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small fw-medium">إجمالي المستخدمين</span>
                    <div class="rounded-circle bg-primary-subtle text-primary p-2 fs-6">
                        <i class="bi bi-people-fill"></i>
                    </div>
                </div>
                <div class="fs-2 fw-bold text-dark-green font-heading"><?= number_format($stats['total_users']) ?></div>
                <div class="d-flex justify-content-between align-items-center pt-2 mt-2 border-top small text-muted">
                    <span>ملاك: <strong class="text-gold"><?= $stats['total_owners'] ?></strong></span>
                    <span>عملاء: <strong class="text-primary"><?= $stats['total_customers'] ?></strong></span>
                    <span>موظفين: <strong class="text-info"><?= $stats['total_employees'] ?></strong></span>
                </div>
            </div>
        </div>

        <!-- Halls Breakdown -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-start border-4 border-gold">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small fw-medium">إجمالي القاعات والقصور</span>
                    <div class="rounded-circle bg-warning-subtle text-warning p-2 fs-6">
                        <i class="bi bi-building"></i>
                    </div>
                </div>
                <div class="fs-2 fw-bold text-dark-green font-heading"><?= number_format($stats['total_halls']) ?></div>
                <div class="d-flex justify-content-between align-items-center pt-2 mt-2 border-top small text-muted">
                    <span>نشطة: <strong class="text-success"><?= $stats['active_halls'] ?></strong></span>
                    <span>قيد المراجعة: <strong class="text-danger"><?= $stats['pending_halls'] ?></strong></span>
                    <span>مرفوضة: <strong class="text-muted"><?= $stats['rejected_halls'] ?></strong></span>
                </div>
            </div>
        </div>

        <!-- Bookings Breakdown -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-start border-4 border-success">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small fw-medium">إجمالي الحجوزات والمناسبات</span>
                    <div class="rounded-circle bg-success-subtle text-success p-2 fs-6">
                        <i class="bi bi-calendar-check-fill"></i>
                    </div>
                </div>
                <div class="fs-2 fw-bold text-dark-green font-heading"><?= number_format($stats['total_bookings']) ?></div>
                <div class="d-flex justify-content-between align-items-center pt-2 mt-2 border-top small text-muted">
                    <span>مؤكد: <strong class="text-success"><?= $stats['confirmed_bookings'] ?></strong></span>
                    <span>جديد: <strong class="text-warning"><?= $stats['pending_bookings'] ?></strong></span>
                    <span>ملغي: <strong class="text-danger"><?= $stats['cancelled_bookings'] ?></strong></span>
                    <span>مكتمل: <strong class="text-info"><?= $stats['completed_bookings'] ?></strong></span>
                </div>
            </div>
        </div>

        <!-- Financial Real Transactions (Part 4 requirement) -->
        <div class="col-xl-3 col-md-6 col-12">
            <div class="card border rounded-3 p-3 bg-white shadow-sm h-100 border-start border-4 border-dark-green">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted small fw-medium">المدفوعات المحصلة والمحققة</span>
                    <div class="rounded-circle bg-success-subtle text-success p-2 fs-6">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                </div>
                <div class="fs-2 fw-bold text-dark-green font-heading"><?= formatMoney($stats['verified_payments']) ?></div>
                <div class="d-flex justify-content-between align-items-center pt-2 mt-2 border-top small text-muted">
                    <span>عمولة المنصة: <strong class="text-gold"><?= formatMoney($stats['platform_commission']) ?></strong></span>
                    <span>صافي الملاك: <strong class="text-dark-green"><?= formatMoney($stats['owner_net_revenue']) ?></strong></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Navigation to All 18 Admin Modules -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <h6 class="fw-bold text-dark-green mb-3 d-flex align-items-center gap-2">
            <i class="bi bi-grid-3x3-gap-fill text-gold"></i> وحدات الرقابة والإدارة المركزية (Modules)
        </h6>
        <div class="row g-2">
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/halls.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-building fs-3 text-gold d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">اعتماد القاعات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/users.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-people fs-3 text-primary d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">إدارة المستخدمين</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/owners.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-briefcase fs-3 text-success d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">ملاك القاعات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/customers.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-person-lines-fill fs-3 text-info d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">إدارة العملاء</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/employees.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-person-badge fs-3 text-secondary d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">طاقم العمل</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/bookings.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-calendar-check fs-3 text-danger d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">رقابة الحجوزات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/inquiries.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-chat-quote fs-3 text-primary d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">الاستفسارات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/reviews.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-star-half fs-3 text-warning d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">مراجعة التقييمات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/reports.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-graph-up-arrow fs-3 text-dark-green d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">التقارير المالية</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/subscriptions.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-card-checklist fs-3 text-info d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">خطط الاشتراكات</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/settings.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-sliders fs-3 text-dark d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">إعدادات المنصة</span>
                </a>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <a href="<?= BASE_URL ?>/admin/audit-logs.php" class="card border text-decoration-none p-2 text-center h-100 hover-gold transition">
                    <i class="bi bi-shield-shaded fs-3 text-success d-block mb-1"></i>
                    <span class="small fw-bold text-dark-green">سجلات التدقيق</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Critical Section: Pending Hall Approvals Queue (Workflow requirement) -->
    <div class="card border rounded-3 p-4 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold text-dark-green mb-0 d-flex align-items-center gap-2">
                <i class="bi bi-hourglass-split text-warning"></i> طلبات إدراج القاعات بانتظار الاعتماد (Approval Workflow)
            </h5>
            <span class="badge bg-warning text-dark px-3 py-2 small">
                <?= count($pendingHalls) ?> قاعة بانتظار المراجعة
            </span>
        </div>

        <?php if (!empty($pendingHalls)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th>القاعة</th>
                            <th>المدينة والحي</th>
                            <th>مالك القاعة</th>
                            <th>السعة</th>
                            <th>تاريخ التقديم</th>
                            <th>الإجراءات والقرار</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingHalls as $ph): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="<?= e($ph['cover_img'] ?? 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=150&q=80') ?>" class="rounded object-fit-cover" width="50" height="50" alt="<?= e($ph['name_ar']) ?>">
                                        <div>
                                            <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $ph['id'] ?>" target="_blank" class="fw-bold text-dark-green text-decoration-none">
                                                <?= e($ph['name_ar']) ?>
                                            </a>
                                            <div class="text-muted" style="font-size: 0.75rem;"><?= e($ph['name_en'] ?? '') ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= e(getCityName($ph['city'])) ?></span>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= e($ph['district'] ?? $ph['address']) ?></div>
                                </td>
                                <td>
                                    <strong><?= e($ph['owner_name']) ?></strong>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= e($ph['owner_phone']) ?></div>
                                </td>
                                <td><?= number_format($ph['capacity_min']) ?> - <?= number_format($ph['capacity_max']) ?> ضيف</td>
                                <td><?= date('Y-m-d H:i', strtotime($ph['created_at'])) ?></td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <!-- One-click approve -->
                                        <form method="POST" action="<?= BASE_URL ?>/admin/index.php" class="d-inline" onsubmit="return confirm('هل أنت متأكد من اعتماد ونشر هذه القاعة في المنصة للجمهور؟');">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="action" value="approve_hall">
                                            <input type="hidden" name="hall_id" value="<?= $ph['id'] ?>">
                                            <button type="submit" class="btn btn-success btn-sm px-2 py-1" title="اعتماد ونشر">
                                                <i class="bi bi-check-lg"></i> اعتماد
                                            </button>
                                        </form>

                                        <!-- Reject with Reason Button (opens modal) -->
                                        <button type="button" class="btn btn-outline-danger btn-sm px-2 py-1" data-bs-toggle="modal" data-bs-target="#rejectModal<?= $ph['id'] ?>" title="رفض مع إبداء السبب">
                                            <i class="bi bi-x-lg"></i> رفض
                                        </button>

                                        <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $ph['id'] ?>" target="_blank" class="btn btn-outline-secondary btn-sm px-2 py-1" title="معاينة كاملة">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </div>

                                    <!-- Reject Modal with Reason Input -->
                                    <div class="modal fade" id="rejectModal<?= $ph['id'] ?>" tabindex="-1" aria-labelledby="rejectModalLabel<?= $ph['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content text-start text-rtl">
                                                <form method="POST" action="<?= BASE_URL ?>/admin/index.php">
                                                    <?= CSRF::field() ?>
                                                    <input type="hidden" name="action" value="reject_hall">
                                                    <input type="hidden" name="hall_id" value="<?= $ph['id'] ?>">

                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title fs-6 fw-bold" id="rejectModalLabel<?= $ph['id'] ?>">
                                                            <i class="bi bi-exclamation-octagon me-1 ms-1"></i> رفض إدراج القاعة: <?= e($ph['name_ar']) ?>
                                                        </h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="alert alert-warning small mb-3">
                                                            سيتم حفظ سبب الرفض وإشعار مالك القاعة به لتعديل البيانات وإعادة التقديم. لن تظهر القاعة للجمهور.
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">سبب الرفض والملاحظات المطلوبة <span class="text-danger">*</span></label>
                                                            <textarea name="rejection_reason" class="form-control" rows="3" required placeholder="مثال: الصور غير واضحة، أو السجل التجاري غير مطابق للاسم، يرجى إعادة رفع صور عالية الجودة."></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                                                        <button type="submit" class="btn btn-danger btn-sm">تأكيد الرفض وتوثيق السبب</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="p-4 bg-light rounded text-center text-muted small">
                <i class="bi bi-check-circle-fill text-success fs-3 d-block mb-2"></i>
                لا توجد طلبات قاعات معلقة حالياً. جميع القاعات المفحوصة تم اتخاذ القرار بشأنها.
            </div>
        <?php endif; ?>
    </div>

    <!-- Dual Row: Recent Bookings & Recent Registrations -->
    <div class="row g-4 mb-4">
        <!-- Recent Bookings -->
        <div class="col-lg-7 col-12">
            <div class="card border rounded-3 p-4 bg-white shadow-sm h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-dark-green mb-0 d-flex align-items-center gap-2">
                        <i class="bi bi-calendar-range text-gold"></i> أحدث حجوزات المنصة
                    </h5>
                    <a href="<?= BASE_URL ?>/admin/bookings.php" class="small text-gold text-decoration-none fw-bold">عرض الكل &larr;</a>
                </div>

                <?php if (!empty($recentBookings)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead class="table-light">
                                <tr>
                                    <th>رقم الحجز</th>
                                    <th>القاعة</th>
                                    <th>العميل</th>
                                    <th>التاريخ</th>
                                    <th>المبلغ</th>
                                    <th>الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentBookings as $b): ?>
                                    <tr>
                                        <td class="font-monospace fw-bold text-dark-green"><?= e($b['booking_code']) ?></td>
                                        <td>
                                            <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $b['hall_id'] ?>" class="text-dark-green fw-bold text-decoration-none">
                                                <?= e($b['hall_name']) ?>
                                            </a>
                                            <div class="text-muted" style="font-size: 0.75rem;"><?= e(getCityName($b['hall_city'])) ?></div>
                                        </td>
                                        <td>
                                            <div><?= e($b['customer_name']) ?></div>
                                            <a href="tel:<?= e($b['customer_phone']) ?>" class="text-muted" style="font-size: 0.75rem;"><?= e($b['customer_phone']) ?></a>
                                        </td>
                                        <td class="fw-bold text-primary"><?= e($b['event_date']) ?></td>
                                        <td class="fw-bold"><?= formatMoney($b['total_amount'], $b['currency']) ?></td>
                                        <td>
                                            <?php
                                                switch ($b['status']) {
                                                    case 'confirmed': echo '<span class="badge bg-success">مؤكد</span>'; break;
                                                    case 'cancelled': echo '<span class="badge bg-danger">ملغي</span>'; break;
                                                    case 'completed': echo '<span class="badge bg-info text-dark">مكتمل</span>'; break;
                                                    default: echo '<span class="badge bg-warning text-dark">بانتظار التأكيد</span>'; break;
                                                }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted small mb-0">لا توجد حجوزات مسجلة بعد.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Registrations -->
        <div class="col-lg-5 col-12">
            <div class="card border rounded-3 p-4 bg-white shadow-sm h-100">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-dark-green mb-0 d-flex align-items-center gap-2">
                        <i class="bi bi-person-check text-gold"></i> أحدث التسجيلات بالمنصة
                    </h5>
                    <a href="<?= BASE_URL ?>/admin/users.php" class="small text-gold text-decoration-none fw-bold">إدارة الكل &larr;</a>
                </div>

                <?php if (!empty($recentUsers)): ?>
                    <div class="list-group list-group-flush small">
                        <?php foreach ($recentUsers as $ru): ?>
                            <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="fw-bold text-dark-green"><?= e($ru['name']) ?></div>
                                    <div class="text-muted" style="font-size: 0.75rem;">
                                        <i class="bi bi-envelope"></i> <?= e($ru['email']) ?> &bull; 
                                        <i class="bi bi-telephone"></i> <?= e($ru['phone']) ?>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <span class="badge <?php
                                        switch ($ru['role_slug']) {
                                            case 'super_admin': echo 'bg-dark'; break;
                                            case 'hall_owner': echo 'bg-gold text-dark'; break;
                                            case 'employee': echo 'bg-info text-dark'; break;
                                            default: echo 'bg-light text-dark border'; break;
                                        }
                                    ?> mb-1 d-block">
                                        <?= e($ru['role_name']) ?>
                                    </span>
                                    <span class="badge <?= ($ru['status'] === 'active') ? 'bg-success' : 'bg-danger' ?>" style="font-size: 0.7rem;">
                                        <?= ($ru['status'] === 'active') ? 'نشط' : 'موقف' ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted small mb-0">لا توجد حسابات مسجلة.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Security Audit Logs Preview -->
    <div class="card border rounded-3 p-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold text-dark-green mb-0 d-flex align-items-center gap-2">
                <i class="bi bi-shield-shaded text-gold"></i> أحدث العمليات بسجل التدقيق الأمني (Audit Logs)
            </h5>
            <a href="<?= BASE_URL ?>/admin/audit-logs.php" class="small text-gold text-decoration-none fw-bold">عرض السجل الكامل &larr;</a>
        </div>

        <?php if (!empty($recentAuditLogs)): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 small">
                    <thead class="table-light">
                        <tr>
                            <th>المعرف</th>
                            <th>المسؤول / المستخدم</th>
                            <th>الإجراء (Action)</th>
                            <th>الكيان (Entity)</th>
                            <th>التفاصيل</th>
                            <th>عنوان IP</th>
                            <th>التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentAuditLogs as $log): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $log['id'] ?></td>
                                <td>
                                    <strong><?= e($log['user_name'] ?: 'النظام / تلقائي') ?></strong>
                                    <?php if (!empty($log['user_email'])): ?>
                                        <div class="text-muted" style="font-size: 0.72rem;"><?= e($log['user_email']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark-green border font-monospace">
                                        <?= e($log['action']) ?>
                                    </span>
                                </td>
                                <td><?= e($log['entity_type'] ?? '-') ?> #<?= e($log['entity_id'] ?? '') ?></td>
                                <td class="text-truncate text-muted" style="max-width: 260px;" title="<?= e($log['details_json'] ?? '') ?>">
                                    <?= e($log['details_json'] ?? '-') ?>
                                </td>
                                <td class="font-monospace text-muted"><?= e($log['ip_address'] ?? '127.0.0.1') ?></td>
                                <td><?= date('Y-m-d H:i:s', strtotime($log['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted small mb-0">لا توجد سجلات تدقيق مسجلة حتى الآن.</p>
        <?php endif; ?>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
