<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * User Management & Staff Creation Module
 * File: admin/users.php
 */

$page_title = 'إدارة المستخدمين وحسابات الإدارة';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    // 1. Toggle User Suspension
    if ($action === 'toggle_status') {
        $targetUserId = (int)post('user_id');
        $newStatus = post('new_status');

        if ($targetUserId === $adminId) {
            setFlash('danger', 'خطأ أمني: لا يمكنك تجميد أو إيقاف حسابك الإداري الحالي.');
        } elseif (in_array($newStatus, ['active', 'suspended'])) {
            try {
                Database::query("UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $targetUserId]);

                // Record audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, ?, 'users', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId,
                    ($newStatus === 'suspended' ? 'user_suspended' : 'user_reactivated'),
                    $targetUserId,
                    json_encode(['new_status' => $newStatus, 'admin_id' => $adminId], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', ($newStatus === 'suspended') ? 'تم إيقاف الحساب بنجاح، ولن يتمكن من الدخول للمنظومة.' : 'تم إعادة تفعيل الحساب بنجاح.');
                redirect(BASE_URL . '/admin/users.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ أثناء تغيير حالة الحساب: ' . $e->getMessage());
            }
        }
    }

    // 2. Create Authorized Staff / Admin Account (Server-side strict role validation)
    if ($action === 'create_staff') {
        $name = sanitize(post('name'));
        $email = strtolower(sanitize(post('email')));
        $phone = sanitize(post('phone'));
        $roleSlug = post('role_slug');
        $password = post('password', '');

        // Allowed roles to create from admin: 'employee', 'admin', 'hall_owner'
        $permittedRoles = ['employee', 'admin', 'hall_owner'];
        
        if (empty($name) || empty($email) || empty($phone) || empty($password)) {
            setFlash('danger', 'يرجى ملء جميع الحقول المطلوبة لإنشاء الحساب.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            setFlash('danger', 'البريد الإلكتروني غير صالح.');
        } elseif (strlen($password) < 8) {
            setFlash('danger', 'يجب ألا تقل كلمة المرور عن 8 خانات.');
        } elseif (!in_array($roleSlug, $permittedRoles)) {
            setFlash('danger', 'الدور المختار غير مسموح بإنشائه.');
        } else {
            try {
                // Check email uniqueness
                $exists = Database::fetchOne("SELECT id FROM users WHERE email = ? LIMIT 1", [$email]);
                if ($exists) {
                    setFlash('warning', 'البريد الإلكتروني مسجل مسبقاً في المنصة.');
                } else {
                    // Resolve role id
                    $roleRow = Database::fetchOne("SELECT id FROM roles WHERE slug = ?", [$roleSlug]);
                    $roleId = (int)($roleRow['id'] ?? 4);

                    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

                    Database::query("
                        INSERT INTO users (role_id, name, email, phone, password_hash, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ", [$roleId, $name, $email, $phone, $hash]);

                    $newId = Database::lastInsertId();

                    // If hall owner, create owner profile placeholder
                    if ($roleSlug === 'hall_owner') {
                        Database::query("
                            INSERT INTO owner_profiles (user_id, business_name, is_verified, created_at, updated_at)
                            VALUES (?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                        ", [$newId, $name]);
                    }

                    // Audit log
                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'staff_created', 'users', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId,
                        $newId,
                        json_encode(['name' => $name, 'email' => $email, 'role' => $roleSlug], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    setFlash('success', "تم إنشاء حساب المستخدم ($name) بالدور المعتمد بنجاح.");
                    redirect(BASE_URL . '/admin/users.php');
                }
            } catch (Exception $e) {
                setFlash('danger', 'خطأ أثناء إنشاء الحساب: ' . $e->getMessage());
            }
        }
    }
}

// Search & Filter Parameters
$search = trim($_GET['search'] ?? '');
$roleFilter = trim($_GET['role'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$sql = "
    SELECT u.*, r.name_ar as role_name, r.slug as role_slug,
           (SELECT COUNT(*) FROM bookings WHERE customer_id = u.id) as customer_bookings_count,
           (SELECT COUNT(*) FROM halls WHERE owner_id = u.id) as owner_halls_count
    FROM users u
    JOIN roles r ON u.role_id = r.id
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if (!empty($roleFilter)) {
    $sql .= " AND r.slug = ?";
    $params[] = $roleFilter;
}

if (!empty($statusFilter)) {
    $sql .= " AND u.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY u.created_at DESC";

$users = [];
try {
    $users = Database::fetchAll($sql, $params);
} catch (Exception $e) {
    $users = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header & Action Row -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-people-fill text-gold me-2 ms-2"></i> إدارة المستخدمين وحسابات النظام
                </h4>
                <p class="text-muted small mb-0">البحث والفلترة، مراقبة النشاط، إيقاف وتفعيل الحسابات، وإنشاء حسابات إدارية معتمدة.</p>
            </div>

            <div>
                <button type="button" class="btn btn-gold btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createStaffModal">
                    <i class="bi bi-person-plus-fill me-1 ms-1"></i> إضافة حساب موظف / مشرف
                </button>
            </div>
        </div>
    </div>

    <!-- Search & Filters Toolbar -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <form method="GET" action="<?= BASE_URL ?>/admin/users.php" class="row g-2 align-items-center">
            <div class="col-md-5 col-12">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="بحث بالاسم، البريد الإلكتروني، أو رقم الهاتف..." value="<?= e($search) ?>">
                </div>
            </div>

            <div class="col-md-3 col-6">
                <select name="role" class="form-select form-select-sm">
                    <option value="">جميع الأدوار والصلاحيات</option>
                    <option value="super_admin" <?= ($roleFilter === 'super_admin') ? 'selected' : '' ?>>مدير عام للنظام (Super Admin)</option>
                    <option value="hall_owner" <?= ($roleFilter === 'hall_owner') ? 'selected' : '' ?>>مالك / مدير قاعة</option>
                    <option value="customer" <?= ($roleFilter === 'customer') ? 'selected' : '' ?>>عميل</option>
                    <option value="employee" <?= ($roleFilter === 'employee') ? 'selected' : '' ?>>موظف قاعة</option>
                </select>
            </div>

            <div class="col-md-2 col-6">
                <select name="status" class="form-select form-select-sm">
                    <option value="">جميع الحالات</option>
                    <option value="active" <?= ($statusFilter === 'active') ? 'selected' : '' ?>>نشط</option>
                    <option value="suspended" <?= ($statusFilter === 'suspended') ? 'selected' : '' ?>>موقف / معطل</option>
                </select>
            </div>

            <div class="col-md-2 col-12 d-flex gap-1">
                <button type="submit" class="btn btn-dark-green btn-sm w-100">تصفية</button>
                <a href="<?= BASE_URL ?>/admin/users.php" class="btn btn-outline-secondary btn-sm" title="إعادة ضبط"><i class="bi bi-arrow-counterclockwise"></i></a>
            </div>
        </form>
    </div>

    <!-- Users Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th># المعرف</th>
                        <th>المستخدم</th>
                        <th>الدور بالمنظومة</th>
                        <th>بيانات الاتصال</th>
                        <th>إحصائيات النشاط</th>
                        <th>تاريخ التسجيل</th>
                        <th>الحالة</th>
                        <th class="text-center">الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $u['id'] ?></td>
                                <td>
                                    <div class="fw-bold text-dark-green"><?= e($u['name']) ?></div>
                                    <?php if ($u['id'] === $adminId): ?>
                                        <span class="badge bg-gold-subtle text-dark" style="font-size: 0.7rem;">أنت (الحساب الحالي)</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?php
                                        switch ($u['role_slug']) {
                                            case 'super_admin': echo 'bg-dark'; break;
                                            case 'hall_owner': echo 'bg-gold text-dark'; break;
                                            case 'employee': echo 'bg-info text-dark'; break;
                                            default: echo 'bg-light text-dark border'; break;
                                        }
                                    ?>">
                                        <?= e($u['role_name']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div><i class="bi bi-envelope text-muted me-1 ms-1"></i> <?= e($u['email']) ?></div>
                                    <div class="text-muted"><i class="bi bi-telephone text-muted me-1 ms-1"></i> <?= e($u['phone']) ?></div>
                                </td>
                                <td>
                                    <?php if ($u['role_slug'] === 'hall_owner'): ?>
                                        <span class="badge bg-light text-dark border"><?= $u['owner_halls_count'] ?> قاعات</span>
                                    <?php elseif ($u['role_slug'] === 'customer'): ?>
                                        <span class="badge bg-light text-dark border"><?= $u['customer_bookings_count'] ?> حجوزات</span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('Y-m-d', strtotime($u['created_at'])) ?></td>
                                <td>
                                    <span class="badge <?= ($u['status'] === 'active') ? 'bg-success' : 'bg-danger' ?>">
                                        <?= ($u['status'] === 'active') ? 'نشط' : 'موقف' ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <?php if ($u['id'] !== $adminId && $u['role_slug'] !== 'super_admin'): ?>
                                        <form method="POST" action="<?= BASE_URL ?>/admin/users.php" class="d-inline" onsubmit="return confirm('هل أنت متأكد من تغيير حالة هذا الحساب؟');">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                            <input type="hidden" name="new_status" value="<?= ($u['status'] === 'active') ? 'suspended' : 'active' ?>">
                                            <button type="submit" class="btn btn-sm <?= ($u['status'] === 'active') ? 'btn-outline-danger' : 'btn-outline-success' ?> py-1 px-2" title="<?= ($u['status'] === 'active') ? 'إيقاف الحساب' : 'إعادة تفعيل' ?>">
                                                <i class="bi <?= ($u['status'] === 'active') ? 'bi-lock-fill' : 'bi-unlock-fill' ?>"></i>
                                                <?= ($u['status'] === 'active') ? 'إيقاف' : 'تفعيل' ?>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small" title="محمي">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">
                                لا توجد حسابات مطابقة لمعايير البحث المحددة.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Modal: Create Staff Account -->
<div class="modal fade" id="createStaffModal" tabindex="-1" aria-labelledby="createStaffModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start text-rtl">
            <form method="POST" action="<?= BASE_URL ?>/admin/users.php">
                <?= CSRF::field() ?>
                <input type="hidden" name="action" value="create_staff">

                <div class="modal-header bg-dark-green text-white">
                    <h5 class="modal-title fs-6 fw-bold" id="createStaffModalLabel">
                        <i class="bi bi-person-plus-fill me-1 ms-1 text-gold"></i> إضافة حساب معتمد بالنظام
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">الاسم الكامل <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control form-control-sm" required placeholder="مثال: صالح علي المحمدي">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">البريد الإلكتروني <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control form-control-sm" required placeholder="staff@example.ye">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">رقم الهاتف / الواتساب <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control form-control-sm" required placeholder="777123456">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">الدور والصلاحيات الممنوحة <span class="text-danger">*</span></label>
                        <select name="role_slug" class="form-select form-select-sm" required>
                            <option value="employee">موظف قاعة / استقبال (صلاحيات تشغيلية فقط)</option>
                            <option value="admin">مشرف إداري (مراجعة واعتماد تحت إشراف المدير العام)</option>
                            <option value="hall_owner">مالك قاعة (إدارة قاعات وحجوزات)</option>
                        </select>
                        <div class="form-text small">يتم فحص الصلاحيات على الخادم بدقة ومنع أي تصعيد غير مصرح به.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">كلمة المرور الأولية <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control form-control-sm" required minlength="8" placeholder="8 خانات على الأقل">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-dark-green btn-sm fw-bold">إنشاء الحساب وتأمينه</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
