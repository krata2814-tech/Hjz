<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Super Admin Suite - Shared Secure Header & Navigation
 */

require_once __DIR__ . '/../../config/app.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/security.php';
require_once __DIR__ . '/../../includes/language.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

// Strict server-side access control: only super_admin and admin
Auth::requireRole(['super_admin', 'admin']);

$adminUser = Auth::user();
$adminRole = Auth::role();
$adminId = Auth::id();
$isSuperAdmin = Auth::isSuperAdmin();

// Active script detection
$currentAdminScript = basename($_SERVER['SCRIPT_NAME'] ?? '');

// Real-time Badge Counters from Database
$pendingHallsBadge = 0;
$pendingReviewsBadge = 0;
$pendingPaymentsBadge = 0;
try {
    $pendingHallsBadge = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM halls WHERE status = 'pending_approval'")['c'] ?? 0);
    $pendingReviewsBadge = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM reviews WHERE status = 'pending'")['c'] ?? 0);
    $pendingPaymentsBadge = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM payment_records WHERE status = 'pending_verification'")['c'] ?? 0);
} catch (Exception $e) {
    // Graceful fallback
}

// Include universal HTML head
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Admin Top Bar -->
<header class="admin-topbar bg-dark-green text-white py-2 border-bottom border-gold-dark shadow-sm">
    <div class="container-fluid px-lg-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div class="d-flex align-items-center gap-2">
                <a href="<?= BASE_URL ?>/admin/index.php" class="text-white text-decoration-none d-flex align-items-center gap-2">
                    <span class="badge bg-gold text-dark fs-7 px-2 py-1 fw-bold">
                        <i class="bi bi-shield-lock-fill"></i> الإدارة العليا
                    </span>
                    <span class="fw-bold d-none d-sm-inline"><?= e(__('app_name')) ?></span>
                </a>
                <span class="text-white-50 small d-none d-md-inline">|</span>
                <span class="text-gold small fw-medium d-none d-md-inline">لوحة التحكم المركزية (Super Admin Console)</span>
            </div>

            <div class="d-flex align-items-center gap-2">
                <a href="<?= BASE_URL ?>/index.php" class="btn btn-outline-light btn-sm px-2 py-1 small" title="عرض الموقع العام">
                    <i class="bi bi-globe me-1 ms-1"></i> <span class="d-none d-sm-inline">الموقع العام</span>
                </a>
                <a href="<?= BASE_URL ?>/dashboard.php" class="btn btn-outline-gold btn-sm px-2 py-1 small" title="لوحة المستخدم">
                    <i class="bi bi-speedometer me-1 ms-1"></i> <span class="d-none d-sm-inline">لوحتي</span>
                </a>

                <div class="dropdown">
                    <button class="btn btn-sm btn-light dropdown-toggle d-flex align-items-center gap-1 shadow-none" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle text-dark-green"></i>
                        <span class="fw-bold text-dark-green small"><?= e(explode(' ', $adminUser['name'] ?? 'Admin')[0]) ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 small mt-1">
                        <li>
                            <div class="dropdown-item-text">
                                <div class="fw-bold"><?= e($adminUser['name']) ?></div>
                                <div class="text-muted small"><?= e($adminUser['email']) ?></div>
                                <span class="badge bg-success mt-1">مدير عام موثق</span>
                            </div>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/admin/settings.php"><i class="bi bi-gear me-2 ms-2"></i> إعدادات المنظومة</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>/admin/audit-logs.php"><i class="bi bi-shield-shaded me-2 ms-2"></i> سجلات الأمان</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right me-2 ms-2"></i> تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Admin Navigation Tabs (Mobile Responsive & Scrollable) -->
<nav class="admin-nav bg-white border-bottom shadow-xs sticky-top">
    <div class="container-fluid px-lg-4">
        <ul class="nav nav-pills flex-nowrap overflow-x-auto py-2 gap-1 align-items-center" style="-webkit-overflow-scrolling: touch;">
            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'index.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/index.php">
                    <i class="bi bi-grid-1x2-fill me-1 ms-1"></i> الرئيسة
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'halls.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill position-relative" href="<?= BASE_URL ?>/admin/halls.php">
                    <i class="bi bi-building me-1 ms-1"></i> اعتماد وإدارة القاعات
                    <?php if ($pendingHallsBadge > 0): ?>
                        <span class="badge bg-danger rounded-pill ms-1"><?= $pendingHallsBadge ?></span>
                    <?php endif; ?>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'users.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/users.php">
                    <i class="bi bi-people-fill me-1 ms-1"></i> المستخدمين
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'owners.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/owners.php">
                    <i class="bi bi-briefcase-fill me-1 ms-1"></i> ملاك القاعات
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'customers.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/customers.php">
                    <i class="bi bi-person-lines-fill me-1 ms-1"></i> العملاء
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'employees.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/employees.php">
                    <i class="bi bi-person-badge-fill me-1 ms-1"></i> موظفو القاعات
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'bookings.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/bookings.php">
                    <i class="bi bi-calendar-check-fill me-1 ms-1"></i> الحجوزات
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'inquiries.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/inquiries.php">
                    <i class="bi bi-chat-quote-fill me-1 ms-1"></i> الاستفسارات
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'reviews.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill position-relative" href="<?= BASE_URL ?>/admin/reviews.php">
                    <i class="bi bi-star-fill me-1 ms-1"></i> التقييمات
                    <?php if ($pendingReviewsBadge > 0): ?>
                        <span class="badge bg-warning text-dark rounded-pill ms-1"><?= $pendingReviewsBadge ?></span>
                    <?php endif; ?>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'reports.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/reports.php">
                    <i class="bi bi-graph-up-arrow me-1 ms-1"></i> التقارير والعمولات
                    <?php if ($pendingPaymentsBadge > 0): ?>
                        <span class="badge bg-info text-dark rounded-pill ms-1"><?= $pendingPaymentsBadge ?></span>
                    <?php endif; ?>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'subscriptions.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/subscriptions.php">
                    <i class="bi bi-card-checklist me-1 ms-1"></i> باقات الاشتراك
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'settings.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/settings.php">
                    <i class="bi bi-sliders me-1 ms-1"></i> إعدادات المنصة
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'audit-logs.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/audit-logs.php">
                    <i class="bi bi-journal-text me-1 ms-1"></i> سجلات التدقيق
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-nowrap <?= ($currentAdminScript === 'notifications.php') ? 'active bg-dark-green text-white' : 'text-secondary' ?> py-1 px-3 small rounded-pill" href="<?= BASE_URL ?>/admin/notifications.php">
                    <i class="bi bi-bell-fill me-1 ms-1"></i> الإشعارات
                </a>
            </li>
        </ul>
    </div>
</nav>

<!-- System Flash Messages in Admin Panel -->
<?php if (hasFlash()): $flash = getFlash(); ?>
    <div class="container-fluid px-lg-4 mt-3">
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm d-flex align-items-center rounded-3 border-0" role="alert">
            <i class="bi <?= ($flash['type'] === 'success') ? 'bi-check-circle-fill text-success' : 'bi-exclamation-triangle-fill text-warning' ?> me-2 ms-2 fs-5"></i>
            <div class="fw-medium"><?= e($flash['message']) ?></div>
            <button type="button" class="btn-close shadow-none" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
<?php endif; ?>
