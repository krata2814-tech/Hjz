<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Super Admin Suite - Shared Secure Footer
 */
?>

<footer class="admin-footer bg-light border-top py-4 mt-5">
    <div class="container-fluid px-lg-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small text-muted">
            <div>
                <span class="fw-bold text-dark-green"><?= e(__('app_name')) ?></span> &bull; 
                <span>إصدار المنظومة: <?= APP_VERSION ?></span> &bull; 
                <span>التوقيت: <?= date('Y-m-d H:i:s') ?> (<?= date_default_timezone_get() ?>)</span>
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="badge bg-success-subtle text-success border border-success-subtle">
                    <i class="bi bi-shield-check"></i> الجلسة مشفرة ومحمية بـ CSRF
                </span>
                <a href="<?= BASE_URL ?>/index.php" class="text-secondary text-decoration-none hover-gold">الموقع العام</a>
                <a href="<?= BASE_URL ?>/admin/audit-logs.php" class="text-secondary text-decoration-none hover-gold">سجل الأمان</a>
            </div>
        </div>
    </div>
</footer>

<!-- Shared JavaScript Bundle -->
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
