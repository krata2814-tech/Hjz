<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Hall Owner Management & Commercial Verification
 * File: admin/owners.php
 */

$page_title = 'إدارة ملاك القاعات والتحقق التجاري';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $ownerId = (int)post('owner_id');

    if ($ownerId > 0 && $action === 'toggle_verification') {
        $newVerified = (int)post('new_verified');
        try {
            // Check if owner_profile exists
            $prof = Database::fetchOne("SELECT id FROM owner_profiles WHERE user_id = ?", [$ownerId]);
            if ($prof) {
                Database::query("
                    UPDATE owner_profiles 
                    SET is_verified = ?, verified_at = CURRENT_TIMESTAMP, verified_by = ?, updated_at = CURRENT_TIMESTAMP 
                    WHERE user_id = ?
                ", [$newVerified, $adminId, $ownerId]);
            } else {
                Database::query("
                    INSERT INTO owner_profiles (user_id, is_verified, verified_at, verified_by, created_at, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ", [$ownerId, $newVerified, $adminId]);
            }

            // Audit log
            Database::query("
                INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                VALUES (?, 'owner_verification_changed', 'users', ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ", [
                $adminId, $ownerId,
                json_encode(['owner_id' => $ownerId, 'is_verified' => $newVerified], JSON_UNESCAPED_UNICODE),
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
            ]);

            setFlash('success', ($newVerified === 1) ? 'تم اعتماد توثيق المالك رسمياً.' : 'تم إلغاء اعتماد التوثيق للمالك.');
            redirect(BASE_URL . '/admin/owners.php');
        } catch (Exception $e) {
            setFlash('danger', 'خطأ: ' . $e->getMessage());
        }
    }
}

// Fetch all hall owners joined with their profiles and statistics
$owners = [];
try {
    $owners = Database::fetchAll("
        SELECT u.*, op.business_name, op.commercial_registration_no, op.tax_number, 
               op.is_verified, op.verified_at, op.bank_name, op.bank_account_number,
               (SELECT COUNT(*) FROM halls WHERE owner_id = u.id) as halls_count,
               (SELECT COUNT(*) FROM halls WHERE owner_id = u.id AND status = 'active') as active_halls_count,
               (SELECT COALESCE(SUM(b.total_amount), 0) FROM bookings b JOIN halls h ON b.hall_id = h.id WHERE h.owner_id = u.id AND b.status = 'confirmed') as total_revenue
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN owner_profiles op ON u.id = op.user_id
        WHERE r.slug = 'hall_owner'
        ORDER BY u.created_at DESC
    ");
} catch (Exception $e) {
    $owners = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-briefcase-fill text-gold me-2 ms-2"></i> إدارة ملاك ومدراء القاعات (Hall Owners)
                </h4>
                <p class="text-muted small mb-0">بيانات السجل التجاري، الاعتماد المالي، القاعات المملوكة، والإيرادات المحققة.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($owners) ?> مالك مسجل
            </span>
        </div>
    </div>

    <!-- Owners List -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>المالك</th>
                        <th>الكيان التجاري والسجل</th>
                        <th>بيانات الاتصال</th>
                        <th>القاعات المسجلة</th>
                        <th>حجم الحجوزات</th>
                        <th>التوثيق الرسمي</th>
                        <th class="text-center">الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($owners)): ?>
                        <?php foreach ($owners as $o): ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark-green"><?= e($o['name']) ?></div>
                                    <span class="text-muted" style="font-size: 0.75rem;">عضو منذ <?= date('Y-m-d', strtotime($o['created_at'])) ?></span>
                                </td>
                                <td>
                                    <strong><?= e($o['business_name'] ?: 'فردي / شخصي') ?></strong>
                                    <?php if (!empty($o['commercial_registration_no'])): ?>
                                        <div class="text-muted" style="font-size: 0.75rem;">
                                            سجل تجاري: <span class="font-monospace text-dark"><?= e($o['commercial_registration_no']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (!empty($o['tax_number'])): ?>
                                        <div class="text-muted" style="font-size: 0.75rem;">
                                            رقم ضريبي: <span class="font-monospace text-dark"><?= e($o['tax_number']) ?></span>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><i class="bi bi-telephone text-muted me-1 ms-1"></i> <a href="tel:<?= e($o['phone']) ?>" class="text-dark text-decoration-none"><?= e($o['phone']) ?></a></div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><i class="bi bi-envelope text-muted me-1 ms-1"></i> <?= e($o['email']) ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= $o['halls_count'] ?> قاعات (<?= $o['active_halls_count'] ?> نشطة)</span>
                                </td>
                                <td class="fw-bold text-dark-green">
                                    <?= formatMoney($o['total_revenue']) ?>
                                </td>
                                <td>
                                    <?php if (!empty($o['is_verified'])): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">
                                            <i class="bi bi-patch-check-fill"></i> موثق رسمياً
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle">
                                            <i class="bi bi-hourglass-split"></i> غير موثق
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <!-- Toggle Verification Button -->
                                        <form method="POST" action="<?= BASE_URL ?>/admin/owners.php" class="d-inline">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="action" value="toggle_verification">
                                            <input type="hidden" name="owner_id" value="<?= $o['id'] ?>">
                                            <input type="hidden" name="new_verified" value="<?= empty($o['is_verified']) ? 1 : 0 ?>">
                                            <button type="submit" class="btn btn-sm <?= empty($o['is_verified']) ? 'btn-outline-success' : 'btn-outline-secondary' ?> py-1 px-2" title="<?= empty($o['is_verified']) ? 'اعتماد التوثيق' : 'إلغاء التوثيق' ?>">
                                                <i class="bi <?= empty($o['is_verified']) ? 'bi-shield-check' : 'bi-shield-x' ?>"></i>
                                                <?= empty($o['is_verified']) ? 'توثيق' : 'إلغاء' ?>
                                            </button>
                                        </form>

                                        <a href="<?= BASE_URL ?>/admin/halls.php?search=<?= urlencode($o['name']) ?>" class="btn btn-outline-dark-green btn-sm py-1 px-2" title="استعراض قاعات المالك">
                                            <i class="bi bi-building"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">لا يوجد ملاك قاعات مسجلون حالياً.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
