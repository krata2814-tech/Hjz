<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Employee Account Oversight Module
 * File: admin/employees.php
 */

$page_title = 'إدارة طاقم العمل وموظفي القاعات';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    if ($action === 'create_employee') {
        $name = sanitize(post('name'));
        $email = strtolower(sanitize(post('email')));
        $phone = sanitize(post('phone'));
        $password = post('password', '');

        if (empty($name) || empty($email) || empty($phone) || empty($password)) {
            setFlash('danger', 'يرجى إدخال جميع الحقول المطلوبة للموظف.');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            setFlash('danger', 'البريد الإلكتروني غير صالح.');
        } elseif (strlen($password) < 8) {
            setFlash('danger', 'كلمة المرور يجب ألا تقل عن 8 خانات.');
        } else {
            try {
                $exists = Database::fetchOne("SELECT id FROM users WHERE email = ? LIMIT 1", [$email]);
                if ($exists) {
                    setFlash('warning', 'البريد الإلكتروني مسجل مسبقاً.');
                } else {
                    $roleRow = Database::fetchOne("SELECT id FROM roles WHERE slug = 'employee'");
                    $roleId = (int)($roleRow['id'] ?? 4);

                    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

                    Database::query("
                        INSERT INTO users (role_id, name, email, phone, password_hash, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ", [$roleId, $name, $email, $phone, $hash]);

                    $newEmpId = Database::lastInsertId();

                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'employee_created', 'users', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId, $newEmpId,
                        json_encode(['name' => $name, 'email' => $email], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    setFlash('success', 'تم إنشاء حساب موظف القاعة بنجاح.');
                    redirect(BASE_URL . '/admin/employees.php');
                }
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    } elseif ($action === 'toggle_status') {
        $empId = (int)post('employee_id');
        $newStatus = post('new_status');
        if ($empId > 0 && in_array($newStatus, ['active', 'suspended'])) {
            try {
                Database::query("UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $empId]);
                setFlash('success', 'تم تحديث حالة الموظف.');
                redirect(BASE_URL . '/admin/employees.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    }
}

// Fetch all employees
$employees = [];
try {
    $employees = Database::fetchAll("
        SELECT u.*, r.name_ar as role_name
        FROM users u
        JOIN roles r ON u.role_id = r.id
        WHERE r.slug IN ('employee', 'admin')
        ORDER BY u.created_at DESC
    ");
} catch (Exception $e) {
    $employees = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-person-badge-fill text-gold me-2 ms-2"></i> رقابة وإدارة طاقم العمل وموظفي الاستقبال
                </h4>
                <p class="text-muted small mb-0">متابعة حسابات موظفي الاستقبال ومسؤولي التنسيق وجدولة الحجوزات.</p>
            </div>

            <button type="button" class="btn btn-dark-green btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createEmployeeModal">
                <i class="bi bi-person-plus-fill me-1 ms-1"></i> إضافة موظف جديد
            </button>
        </div>
    </div>

    <!-- Employee Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th># المعرف</th>
                        <th>الموظف</th>
                        <th>الدور الوظيفي</th>
                        <th>بيانات الاتصال</th>
                        <th>آخر تسجيل دخول</th>
                        <th>تاريخ الإضافة</th>
                        <th>الحالة</th>
                        <th class="text-center">الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($employees)): ?>
                        <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $emp['id'] ?></td>
                                <td>
                                    <div class="fw-bold text-dark-green"><?= e($emp['name']) ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-info text-dark"><?= e($emp['role_name']) ?></span>
                                </td>
                                <td>
                                    <div><i class="bi bi-telephone text-muted me-1 ms-1"></i> <?= e($emp['phone']) ?></div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><i class="bi bi-envelope text-muted me-1 ms-1"></i> <?= e($emp['email']) ?></div>
                                </td>
                                <td><?= !empty($emp['last_login_at']) ? date('Y-m-d H:i', strtotime($emp['last_login_at'])) : '<span class="text-muted">لم يسجل بعد</span>' ?></td>
                                <td><?= date('Y-m-d', strtotime($emp['created_at'])) ?></td>
                                <td>
                                    <span class="badge <?= ($emp['status'] === 'active') ? 'bg-success' : 'bg-danger' ?>">
                                        <?= ($emp['status'] === 'active') ? 'نشط' : 'موقف' ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <?php if ($emp['id'] !== $adminId): ?>
                                        <form method="POST" action="<?= BASE_URL ?>/admin/employees.php" class="d-inline" onsubmit="return confirm('تأكيد تغيير حالة الموظف؟');">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                            <input type="hidden" name="new_status" value="<?= ($emp['status'] === 'active') ? 'suspended' : 'active' ?>">
                                            <button type="submit" class="btn btn-sm <?= ($emp['status'] === 'active') ? 'btn-outline-danger' : 'btn-outline-success' ?> py-1 px-2">
                                                <?= ($emp['status'] === 'active') ? 'إيقاف' : 'تفعيل' ?>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا يوجد موظفون مسجلون حالياً.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Modal: Create Employee -->
<div class="modal fade" id="createEmployeeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start text-rtl">
            <form method="POST" action="<?= BASE_URL ?>/admin/employees.php">
                <?= CSRF::field() ?>
                <input type="hidden" name="action" value="create_employee">

                <div class="modal-header bg-dark-green text-white">
                    <h5 class="modal-title fs-6 fw-bold">إضافة حساب موظف جديد</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">اسم الموظف الكامل <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control form-control-sm" required placeholder="مثال: نبيل المقطري">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">البريد الإلكتروني <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control form-control-sm" required placeholder="nabil@example.ye">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">رقم الهاتف <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control form-control-sm" required placeholder="777998877">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">كلمة المرور الأولية <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control form-control-sm" required minlength="8" placeholder="8 خانات على الأقل">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-dark-green btn-sm fw-bold">إضافة الموظف</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
