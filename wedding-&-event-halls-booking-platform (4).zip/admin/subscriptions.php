<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Subscription Plans & Owner Tiers Management Module
 * File: admin/subscriptions.php
 */

$page_title = 'إدارة باقات وخطط اشتراكات الملاك';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    if ($action === 'create_plan') {
        $nameAr = sanitize(post('name_ar'));
        $nameEn = sanitize(post('name_en'));
        $price = (float)post('price', 0);
        $period = (int)post('billing_period_months', 1);
        $maxHalls = (int)post('max_halls_allowed', 1);
        $quota = (int)post('featured_halls_quota', 0);
        $commRate = (float)post('commission_rate_percentage', 5.0);
        $desc = sanitize(post('description', ''));

        if (!empty($nameAr)) {
            try {
                $slug = 'plan-' . time();
                Database::query("
                    INSERT INTO subscription_plans (name_ar, name_en, slug, description, price, billing_period_months, max_halls_allowed, featured_halls_quota, commission_rate_percentage, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
                ", [$nameAr, $nameEn, $slug, $desc, $price, $period, $maxHalls, $quota, $commRate]);

                // Audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'subscription_plan_created', 'subscription_plans', 1, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId,
                    json_encode(['name_ar' => $nameAr, 'price' => $price], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', 'تم إنشاء باقة الاشتراك الجديدة بنجاح.');
                redirect(BASE_URL . '/admin/subscriptions.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    } elseif ($action === 'toggle_plan') {
        $planId = (int)post('plan_id');
        $newActive = (int)post('new_active');
        try {
            Database::query("UPDATE subscription_plans SET is_active = ? WHERE id = ?", [$newActive, $planId]);
            setFlash('success', 'تم تحديث حالة الباقة.');
            redirect(BASE_URL . '/admin/subscriptions.php');
        } catch (Exception $e) {
            setFlash('danger', 'خطأ: ' . $e->getMessage());
        }
    }
}

// Fetch all plans
$plans = [];
try {
    $plans = Database::fetchAll("SELECT * FROM subscription_plans ORDER BY price ASC");
} catch (Exception $e) {
    $plans = [];
}

// Fetch active subscriptions
$ownerSubs = [];
try {
    $ownerSubs = Database::fetchAll("
        SELECT os.*, u.name as owner_name, u.phone as owner_phone, sp.name_ar as plan_name
        FROM owner_subscriptions os
        JOIN users u ON os.owner_id = u.id
        JOIN subscription_plans sp ON os.plan_id = sp.id
        ORDER BY os.created_at DESC
    ");
} catch (Exception $e) {
    $ownerSubs = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-card-checklist text-gold me-2 ms-2"></i> إدارة باقات وخطط اشتراكات الملاك (Subscription Plans)
                </h4>
                <p class="text-muted small mb-0">باقات إدراج القاعات، خصومات العمولات، حصص القاعات المميزة في الواجهة، وفترات التجديد.</p>
            </div>

            <button type="button" class="btn btn-gold btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#createPlanModal">
                <i class="bi bi-plus-circle-fill me-1 ms-1"></i> إضافة باقة اشتراك جديدة
            </button>
        </div>
    </div>

    <!-- Plans Cards -->
    <div class="row g-3 mb-4">
        <?php foreach ($plans as $p): ?>
            <div class="col-md-4 col-12">
                <div class="card border rounded-3 p-4 bg-white shadow-sm h-100 position-relative <?= ($p['is_active'] ? 'border-top border-4 border-gold' : 'opacity-75') ?>">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h5 class="fw-bold text-dark-green mb-0"><?= e($p['name_ar']) ?></h5>
                        <span class="badge <?= $p['is_active'] ? 'bg-success' : 'bg-secondary' ?>">
                            <?= $p['is_active'] ? 'نشطة' : 'معطلة' ?>
                        </span>
                    </div>
                    <div class="text-muted small mb-3"><?= e($p['name_en'] ?? '') ?></div>

                    <div class="mb-3">
                        <span class="fs-3 fw-bold text-dark-green"><?= number_format($p['price']) ?></span>
                        <span class="text-muted small">ر.ي / <?= $p['billing_period_months'] ?> شهر</span>
                    </div>

                    <ul class="list-unstyled small mb-4 text-secondary">
                        <li class="mb-2"><i class="bi bi-check-circle-fill text-gold me-1 ms-1"></i> أقصى عدد قاعات: <strong><?= $p['max_halls_allowed'] ?></strong></li>
                        <li class="mb-2"><i class="bi bi-star-fill text-warning me-1 ms-1"></i> حصة القاعات المميزة: <strong><?= $p['featured_halls_quota'] ?></strong></li>
                        <li class="mb-2"><i class="bi bi-percent text-success me-1 ms-1"></i> نسبة عمولة الحجز: <strong><?= $p['commission_rate_percentage'] ?>%</strong></li>
                        <?php if (!empty($p['description'])): ?>
                            <li class="mt-2 text-muted"><?= e($p['description']) ?></li>
                        <?php endif; ?>
                    </ul>

                    <div class="mt-auto pt-3 border-top">
                        <form method="POST" action="<?= BASE_URL ?>/admin/subscriptions.php">
                            <?= CSRF::field() ?>
                            <input type="hidden" name="action" value="toggle_plan">
                            <input type="hidden" name="plan_id" value="<?= $p['id'] ?>">
                            <input type="hidden" name="new_active" value="<?= $p['is_active'] ? 0 : 1 ?>">
                            <button type="submit" class="btn btn-sm <?= $p['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?> w-100">
                                <?= $p['is_active'] ? 'إيقاف الباقة' : 'تفعيل الباقة' ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Modal: Create Plan -->
<div class="modal fade" id="createPlanModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start text-rtl">
            <form method="POST" action="<?= BASE_URL ?>/admin/subscriptions.php">
                <?= CSRF::field() ?>
                <input type="hidden" name="action" value="create_plan">

                <div class="modal-header bg-dark-green text-white">
                    <h5 class="modal-title fs-6 fw-bold">إضافة باقة اشتراك جديدة</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">اسم الباقة بالعربية <span class="text-danger">*</span></label>
                        <input type="text" name="name_ar" class="form-control form-control-sm" required placeholder="مثال: الباقة الفضية المتقدمة">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">اسم الباقة بالإنجليزية</label>
                        <input type="text" name="name_en" class="form-control form-control-sm" placeholder="Silver Advanced Tier">
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">السعر (ر.ي) <span class="text-danger">*</span></label>
                            <input type="number" name="price" class="form-control form-control-sm" required step="1000" value="50000">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">الفترة (بالأشهر)</label>
                            <input type="number" name="billing_period_months" class="form-control form-control-sm" required min="1" max="12" value="3">
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">الحد الأقصى للقاعات</label>
                            <input type="number" name="max_halls_allowed" class="form-control form-control-sm" required min="1" value="2">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">حصة القاعات المميزة</label>
                            <input type="number" name="featured_halls_quota" class="form-control form-control-sm" required min="0" value="1">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">نسبة العمولة المطبقة (%)</label>
                        <input type="number" name="commission_rate_percentage" class="form-control form-control-sm" step="0.1" value="4.0">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">الوصف والمزايا</label>
                        <textarea name="description" class="form-control form-control-sm" rows="2" placeholder="مزايا ترويجية ودعم فني على مدار الساعة..."></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-dark-green btn-sm fw-bold">حفظ الباقة</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
