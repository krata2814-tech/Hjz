<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Platform Settings, Localization & Commission Settings
 * File: admin/settings.php
 */

$page_title = 'إعدادات المنظومة والعمولات والعملات';
require_once __DIR__ . '/includes/admin_header.php';

// Handle Settings Update
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    if ($action === 'update_settings') {
        $settingsToUpdate = [
            'site_name_ar' => sanitize(post('site_name_ar')),
            'site_name_en' => sanitize(post('site_name_en')),
            'admin_email' => strtolower(sanitize(post('admin_email'))),
            'contact_phone' => sanitize(post('contact_phone')),
            'whatsapp_support' => sanitize(post('whatsapp_support')),
            'default_currency' => sanitize(post('default_currency')),
            'supported_currencies' => sanitize(post('supported_currencies')),
            'platform_commission_percentage' => (string)max(0.0, min(100.0, (float)post('platform_commission_percentage', 5.0))),
            'platform_timezone' => sanitize(post('platform_timezone', 'Asia/Aden')),
            'require_owner_verification' => post('require_owner_verification') ? '1' : '0',
            'min_password_length' => (string)max(6, min(32, (int)post('min_password_length', 8))),
        ];

        try {
            foreach ($settingsToUpdate as $key => $val) {
                $existingSetting = Database::fetchOne("SELECT id FROM platform_settings WHERE setting_key = ? LIMIT 1", [$key]);
                if ($existingSetting) {
                    Database::query("
                        UPDATE platform_settings
                        SET setting_value = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE setting_key = ?
                    ", [$val, $adminId, $key]);
                } else {
                    Database::query("
                        INSERT INTO platform_settings (setting_key, setting_value, updated_by, updated_at)
                        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ", [$key, $val, $adminId]);
                }
            }

            // Audit log
            Database::query("
                INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                VALUES (?, 'platform_settings_updated', 'platform_settings', 1, ?, ?, ?, CURRENT_TIMESTAMP)
            ", [
                $adminId,
                json_encode($settingsToUpdate, JSON_UNESCAPED_UNICODE),
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
            ]);

            setFlash('success', 'تم حفظ وتحديث كافة إعدادات المنظومة والعمولات والعملات بنجاح.');
            redirect(BASE_URL . '/admin/settings.php');
        } catch (Exception $e) {
            setFlash('danger', 'خطأ أثناء حفظ الإعدادات: ' . $e->getMessage());
        }
    }
}

// Fetch all settings from database into key => value array
$settings = [];
try {
    $rows = Database::fetchAll("SELECT setting_key, setting_value FROM platform_settings");
    foreach ($rows as $r) {
        $settings[$r['setting_key']] = $r['setting_value'];
    }
} catch (Exception $e) {
    // Graceful
}

// Default fallbacks if empty
$siteNameAr = $settings['site_name_ar'] ?? APP_NAME_AR;
$siteNameEn = $settings['site_name_en'] ?? APP_NAME_EN;
$adminEmail = $settings['admin_email'] ?? 'admin@wedding.ye';
$contactPhone = $settings['contact_phone'] ?? '+967-1-445566';
$whatsappSupport = $settings['whatsapp_support'] ?? '+967770000001';
$defaultCurrency = $settings['default_currency'] ?? 'YER';
$supportedCurrencies = $settings['supported_currencies'] ?? 'YER,SAR,USD';
$commissionRate = $settings['platform_commission_percentage'] ?? '5.0';
$timezone = $settings['platform_timezone'] ?? 'Asia/Aden';
$requireVerification = ($settings['require_owner_verification'] ?? '1') === '1';
$minPasswordLen = $settings['min_password_length'] ?? '8';
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-sliders text-gold me-2 ms-2"></i> إعدادات المنصة والعمولات والتوطين (Platform Settings)
                </h4>
                <p class="text-muted small mb-0">التحكم في بيانات الهوية، العملات المدعومة، نسب عمولة الحجز، التوقيت، ومعايير الأمان.</p>
            </div>
        </div>
    </div>

    <!-- Settings Form -->
    <form method="POST" action="<?= BASE_URL ?>/admin/settings.php">
        <?= CSRF::field() ?>
        <input type="hidden" name="action" value="update_settings">

        <div class="row g-4">
            <!-- 1. General Identity & Contact -->
            <div class="col-lg-6 col-12">
                <div class="card border rounded-3 p-4 bg-white shadow-sm h-100">
                    <h5 class="fw-bold text-dark-green mb-3 border-bottom pb-2">
                        <i class="bi bi-info-circle text-gold me-1 ms-1"></i> الهوية ومعلومات التواصل
                    </h5>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">اسم المنصة باللغة العربية <span class="text-danger">*</span></label>
                        <input type="text" name="site_name_ar" class="form-control form-control-sm" required value="<?= e($siteNameAr) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">اسم المنصة باللغة الإنجليزية</label>
                        <input type="text" name="site_name_en" class="form-control form-control-sm" value="<?= e($siteNameEn) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">البريد الإلكتروني الرسمي للإدارة <span class="text-danger">*</span></label>
                        <input type="email" name="admin_email" class="form-control form-control-sm" required value="<?= e($adminEmail) ?>">
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">هاتف خدمة العملاء</label>
                            <input type="text" name="contact_phone" class="form-control form-control-sm" value="<?= e($contactPhone) ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">رقم واتساب الدعم الفني</label>
                            <input type="text" name="whatsapp_support" class="form-control form-control-sm" value="<?= e($whatsappSupport) ?>">
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Financial, Commission & Currency -->
            <div class="col-lg-6 col-12">
                <div class="card border rounded-3 p-4 bg-white shadow-sm h-100">
                    <h5 class="fw-bold text-dark-green mb-3 border-bottom pb-2">
                        <i class="bi bi-cash-coin text-gold me-1 ms-1"></i> العمولات المالية والعملات المدعومة
                    </h5>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">نسبة عمولة المنصة من الحجوزات (%) <span class="text-danger">*</span></label>
                        <div class="input-group input-group-sm">
                            <input type="number" name="platform_commission_percentage" class="form-control" step="0.1" min="0" max="50" required value="<?= e($commissionRate) ?>">
                            <span class="input-group-text bg-light fw-bold">%</span>
                        </div>
                        <div class="form-text small">تُحتسب هذه النسبة تلقائياً على كافة الحجوزات المؤكدة والمدفوعة.</div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">العملة الأساسية للنظام</label>
                            <select name="default_currency" class="form-select form-select-sm">
                                <option value="YER" <?= ($defaultCurrency === 'YER') ? 'selected' : '' ?>>ريال يمني (YER)</option>
                                <option value="SAR" <?= ($defaultCurrency === 'SAR') ? 'selected' : '' ?>>ريال سعودي (SAR)</option>
                                <option value="USD" <?= ($defaultCurrency === 'USD') ? 'selected' : '' ?>>دولار أمريكي (USD)</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">العملات الإضافية المتاحة</label>
                            <input type="text" name="supported_currencies" class="form-control form-control-sm" value="<?= e($supportedCurrencies) ?>" placeholder="YER,SAR,USD">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">النطاق الزمني للمنظومة</label>
                        <select name="platform_timezone" class="form-select form-select-sm">
                            <option value="Asia/Aden" <?= ($timezone === 'Asia/Aden') ? 'selected' : '' ?>>توقيت صنعاء وعدن (Asia/Aden - GMT+3)</option>
                            <option value="Asia/Riyadh" <?= ($timezone === 'Asia/Riyadh') ? 'selected' : '' ?>>توقيت الرياض (Asia/Riyadh - GMT+3)</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- 3. Security & Owner Verification -->
            <div class="col-12">
                <div class="card border rounded-3 p-4 bg-white shadow-sm">
                    <h5 class="fw-bold text-dark-green mb-3 border-bottom pb-2">
                        <i class="bi bi-shield-check text-gold me-1 ms-1"></i> ضوابط الأمان والتحقق من الملاك
                    </h5>

                    <div class="row g-3">
                        <div class="col-md-6 col-12">
                            <div class="form-check form-switch pt-2">
                                <input class="form-check-input" type="checkbox" role="switch" id="requireVerificationCheck" name="require_owner_verification" value="1" <?= $requireVerification ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold small" for="requireVerificationCheck">
                                    اشتراط فحص السجل التجاري واعتماد مالك القاعة قبل تفعيل نشر الصالات للجمهور
                                </label>
                            </div>
                            <div class="form-text small mt-1">يضمن حماية العملاء من القاعات الوهمية أو غير المرخصة رسمياً.</div>
                        </div>

                        <div class="col-md-6 col-12">
                            <label class="form-label fw-bold small">الحد الأدنى لطول كلمات المرور (خانة)</label>
                            <input type="number" name="min_password_length" class="form-control form-control-sm" min="8" max="32" value="<?= e($minPasswordLen) ?>">
                            <div class="form-text small">يتم تطبيقه على كافة التسجيلات وتغييرات كلمات المرور.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-dark-green fw-bold px-4 py-2">
                <i class="bi bi-save2 me-1 ms-1"></i> حفظ وتحديث كافة الإعدادات
            </button>
        </div>
    </form>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
