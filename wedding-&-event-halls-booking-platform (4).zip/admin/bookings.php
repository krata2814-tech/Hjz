<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Booking Oversight & Schedule Moderation Module
 * File: admin/bookings.php
 */

$page_title = 'رقابة وإدارة حجوزات المنظومة';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $bookingId = (int)post('booking_id');

    if ($bookingId > 0) {
        $booking = Database::fetchOne("SELECT * FROM bookings WHERE id = ?", [$bookingId]);

        // 1. Update Booking Status
        if ($action === 'update_status') {
            $newStatus = post('new_status');
            $adminNotes = trim(post('admin_notes', ''));

            if (in_array($newStatus, ['pending', 'confirmed', 'cancelled', 'completed'])) {
                try {
                    $cancelledAt = ($newStatus === 'cancelled') ? date('Y-m-d H:i:s') : null;
                    $confirmedAt = ($newStatus === 'confirmed') ? date('Y-m-d H:i:s') : null;

                    Database::query("
                        UPDATE bookings 
                        SET status = ?, 
                            admin_notes = COALESCE(NULLIF(?, ''), admin_notes),
                            confirmed_at = COALESCE(?, confirmed_at),
                            cancelled_at = COALESCE(?, cancelled_at),
                            updated_at = CURRENT_TIMESTAMP 
                        WHERE id = ?
                    ", [$newStatus, $adminNotes, $confirmedAt, $cancelledAt, $bookingId]);

                    // Audit log
                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'booking_status_updated', 'bookings', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId, $bookingId,
                        json_encode(['booking_code' => $booking['booking_code'], 'old_status' => $booking['status'], 'new_status' => $newStatus, 'notes' => $adminNotes], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    // Record in booking_status_history
                    Database::query("
                        INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, notes, created_at)
                        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [$bookingId, $booking['status'], $newStatus, $adminId, $adminNotes]);

                    // Notify customer
                    if (!empty($booking['customer_id'])) {
                        Database::query("
                            INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                            VALUES (?, 'تحديث حالة الحجز', 'Booking Status Update', ?, ?, 'booking_update', ?, CURRENT_TIMESTAMP)
                        ", [
                            $booking['customer_id'],
                            "تم تحديث حالة حجزكم (" . $booking['booking_code'] . ") إلى: " . $newStatus,
                            "Your booking " . $booking['booking_code'] . " status updated to " . $newStatus,
                            BASE_URL . "/dashboard.php"
                        ]);
                    }

                    setFlash('success', 'تم تحديث حالة الحجز بنجاح وإرسال الإشعار وتوثيق سجل التغيير.');
                    redirect(BASE_URL . '/admin/bookings.php');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ: ' . $e->getMessage());
                }
            }
        }

        // 2. Update Payment Status & Record Verified Payment
        elseif ($action === 'update_payment_status') {
            $newPayStatus = post('new_payment_status');
            $paidAmount = (float)post('paid_amount', 0);
            $payMethod = post('payment_method', 'cash');
            $txnNumber = trim(post('txn_number', ''));

            if (in_array($newPayStatus, ['unpaid', 'deposit_paid', 'fully_paid', 'refunded'])) {
                try {
                    Database::query("UPDATE bookings SET payment_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newPayStatus, $bookingId]);

                    // If money was paid and verified, record in payment_records
                    if ($paidAmount > 0 && in_array($newPayStatus, ['deposit_paid', 'fully_paid'])) {
                        $payRef = 'PAY-' . date('Ymd') . '-' . rand(100, 999);
                        Database::query("
                            INSERT INTO payment_records (payment_reference, booking_id, user_id, amount, currency, payment_method, transaction_number, payment_type, status, verified_by, verified_at, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'verified', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                        ", [
                            $payRef, $bookingId, $booking['customer_id'], $paidAmount, $booking['currency'],
                            $payMethod, $txnNumber ?: ('TXN-' . time()),
                            ($newPayStatus === 'fully_paid' ? 'full_payment' : 'deposit'),
                            $adminId
                        ]);
                    }

                    // Audit log
                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'payment_status_updated', 'bookings', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId, $bookingId,
                        json_encode(['booking_code' => $booking['booking_code'], 'payment_status' => $newPayStatus, 'paid_amount' => $paidAmount], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    setFlash('success', 'تم تحديث حالة السداد وقيد الدفعة في سجلات المدفوعات بنجاح.');
                    redirect(BASE_URL . '/admin/bookings.php');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ: ' . $e->getMessage());
                }
            }
        }
    }
}

// Filters
$statusFilter = trim($_GET['status'] ?? '');
$payFilter = trim($_GET['pay_status'] ?? '');
$hallFilter = (int)($_GET['hall_id'] ?? 0);
$search = trim($_GET['search'] ?? '');

$sql = "
    SELECT b.*, h.name_ar as hall_name, h.city as hall_city, 
           u.name as customer_name, u.phone as customer_phone, u.email as customer_email,
           o.name as owner_name, o.phone as owner_phone
    FROM bookings b
    JOIN halls h ON b.hall_id = h.id
    JOIN users u ON b.customer_id = u.id
    JOIN users o ON h.owner_id = o.id
    WHERE 1=1
";
$params = [];

if (!empty($statusFilter)) {
    $sql .= " AND b.status = ?";
    $params[] = $statusFilter;
}

if (!empty($payFilter)) {
    $sql .= " AND b.payment_status = ?";
    $params[] = $payFilter;
}

if ($hallFilter > 0) {
    $sql .= " AND b.hall_id = ?";
    $params[] = $hallFilter;
}

if (!empty($search)) {
    $sql .= " AND (b.booking_code LIKE ? OR u.name LIKE ? OR u.phone LIKE ? OR h.name_ar LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY b.created_at DESC";

$bookings = [];
try {
    $bookings = Database::fetchAll($sql, $params);
} catch (Exception $e) {
    $bookings = [];
}

// Fetch all halls for dropdown
$allHalls = [];
try {
    $allHalls = Database::fetchAll("SELECT id, name_ar FROM halls ORDER BY name_ar ASC");
} catch (Exception $e) {
    $allHalls = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-calendar-check-fill text-gold me-2 ms-2"></i> رقابة وإدارة حجوزات القاعات (Bookings Oversight)
                </h4>
                <p class="text-muted small mb-0">متابعة الحجوزات، تأكيد المواعيد، تسجيل الدفعات والعربون، وإلغاء أو إكمال الحجوزات.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($bookings) ?> حجز مسجل
            </span>
        </div>
    </div>

    <!-- Filters Toolbar -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <form method="GET" action="<?= BASE_URL ?>/admin/bookings.php" class="row g-2 align-items-center">
            <div class="col-md-3 col-12">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="كود الحجز، العميل، الهاتف، القاعة..." value="<?= e($search) ?>">
                </div>
            </div>

            <div class="col-md-3 col-6">
                <select name="status" class="form-select form-select-sm">
                    <option value="">جميع حالات الحجز</option>
                    <option value="pending" <?= ($statusFilter === 'pending') ? 'selected' : '' ?>>جديد بانتظار التأكيد (Pending)</option>
                    <option value="confirmed" <?= ($statusFilter === 'confirmed') ? 'selected' : '' ?>>مؤكد (Confirmed)</option>
                    <option value="completed" <?= ($statusFilter === 'completed') ? 'selected' : '' ?>>مكتمل ومنفذ (Completed)</option>
                    <option value="cancelled" <?= ($statusFilter === 'cancelled') ? 'selected' : '' ?>>ملغي (Cancelled)</option>
                </select>
            </div>

            <div class="col-md-2 col-6">
                <select name="pay_status" class="form-select form-select-sm">
                    <option value="">جميع حالات السداد</option>
                    <option value="unpaid" <?= ($payFilter === 'unpaid') ? 'selected' : '' ?>>غير مسدد</option>
                    <option value="deposit_paid" <?= ($payFilter === 'deposit_paid') ? 'selected' : '' ?>>مدفوع العربون</option>
                    <option value="fully_paid" <?= ($payFilter === 'fully_paid') ? 'selected' : '' ?>>مسدد بالكامل</option>
                    <option value="refunded" <?= ($payFilter === 'refunded') ? 'selected' : '' ?>>مسترد (Refunded)</option>
                </select>
            </div>

            <div class="col-md-2 col-6">
                <select name="hall_id" class="form-select form-select-sm">
                    <option value="">جميع القاعات</option>
                    <?php foreach ($allHalls as $hallItem): ?>
                        <option value="<?= $hallItem['id'] ?>" <?= ($hallFilter === (int)$hallItem['id']) ? 'selected' : '' ?>>
                            <?= e($hallItem['name_ar']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2 col-6 d-flex gap-1">
                <button type="submit" class="btn btn-dark-green btn-sm w-100">تصفية</button>
                <a href="<?= BASE_URL ?>/admin/bookings.php" class="btn btn-outline-secondary btn-sm" title="إعادة ضبط"><i class="bi bi-arrow-counterclockwise"></i></a>
            </div>
        </form>
    </div>

    <!-- Bookings Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>رقم الحجز</th>
                        <th>القاعة والمدينة</th>
                        <th>العميل</th>
                        <th>المناسبة والتاريخ</th>
                        <th>المبلغ الإجمالي</th>
                        <th>حالة الحجز</th>
                        <th>حالة السداد</th>
                        <th class="text-center">إدارة الحجز والدفع</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($bookings)): ?>
                        <?php foreach ($bookings as $b): ?>
                            <tr>
                                <td class="font-monospace fw-bold text-dark-green">
                                    <?= e($b['booking_code']) ?>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= date('Y-m-d', strtotime($b['created_at'])) ?></div>
                                </td>
                                <td>
                                    <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $b['hall_id'] ?>" target="_blank" class="fw-bold text-dark-green text-decoration-none">
                                        <?= e($b['hall_name']) ?>
                                    </a>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= e(getCityName($b['hall_city'])) ?> &bull; المالك: <?= e($b['owner_name']) ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= e($b['customer_name']) ?></div>
                                    <a href="tel:<?= e($b['customer_phone']) ?>" class="text-muted" style="font-size: 0.75rem;"><?= e($b['customer_phone']) ?></a>
                                </td>
                                <td>
                                    <div class="fw-bold text-primary"><?= e($b['event_date']) ?></div>
                                    <span class="badge bg-light text-dark border" style="font-size: 0.72rem;">
                                        <?= ($b['shift'] === 'morning') ? 'صباحية' : (($b['shift'] === 'full_day') ? 'يوم كامل' : 'مسائية') ?>
                                    </span>
                                    <span class="text-muted" style="font-size: 0.72rem;">(<?= $b['guest_count'] ?> ضيف)</span>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark-green"><?= formatMoney($b['total_amount'], $b['currency']) ?></div>
                                    <?php if ($b['deposit_amount'] > 0): ?>
                                        <div class="text-muted" style="font-size: 0.72rem;">عربون: <?= formatMoney($b['deposit_amount'], $b['currency']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                        switch ($b['status']) {
                                            case 'confirmed': echo '<span class="badge bg-success">مؤكد</span>'; break;
                                            case 'cancelled': echo '<span class="badge bg-danger">ملغي</span>'; break;
                                            case 'completed': echo '<span class="badge bg-info text-dark">مكتمل</span>'; break;
                                            default: echo '<span class="badge bg-warning text-dark">قيد الانتظار</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        switch ($b['payment_status']) {
                                            case 'fully_paid': echo '<span class="badge bg-success">مسدد بالكامل</span>'; break;
                                            case 'deposit_paid': echo '<span class="badge bg-primary">مدفوع العربون</span>'; break;
                                            case 'refunded': echo '<span class="badge bg-dark">مسترد</span>'; break;
                                            default: echo '<span class="badge bg-light text-muted border">غير مسدد</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <!-- Update Status Modal Button -->
                                        <button type="button" class="btn btn-outline-dark-green btn-sm py-1 px-2" data-bs-toggle="modal" data-bs-target="#statusModal<?= $b['id'] ?>" title="تغيير حالة الحجز">
                                            <i class="bi bi-arrow-repeat"></i> الحالة
                                        </button>

                                        <!-- Update Payment Modal Button -->
                                        <button type="button" class="btn btn-gold btn-sm py-1 px-2 text-dark" data-bs-toggle="modal" data-bs-target="#paymentModal<?= $b['id'] ?>" title="تحديث السداد">
                                            <i class="bi bi-cash"></i> الدفع
                                        </button>
                                    </div>

                                    <!-- Status Modal -->
                                    <div class="modal fade" id="statusModal<?= $b['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content text-start text-rtl">
                                                <form method="POST" action="<?= BASE_URL ?>/admin/bookings.php">
                                                    <?= CSRF::field() ?>
                                                    <input type="hidden" name="action" value="update_status">
                                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">

                                                    <div class="modal-header bg-dark-green text-white">
                                                        <h5 class="modal-title fs-6 fw-bold">تحديث حالة الحجز: <?= e($b['booking_code']) ?></h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body p-3">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">الحالة الجديدة</label>
                                                            <select name="new_status" class="form-select form-select-sm" required>
                                                                <option value="pending" <?= ($b['status'] === 'pending') ? 'selected' : '' ?>>قيد الانتظار (Pending)</option>
                                                                <option value="confirmed" <?= ($b['status'] === 'confirmed') ? 'selected' : '' ?>>تأكيد الحجز (Confirmed)</option>
                                                                <option value="completed" <?= ($b['status'] === 'completed') ? 'selected' : '' ?>>إكمال وتنفيذ المناسبة (Completed)</option>
                                                                <option value="cancelled" <?= ($b['status'] === 'cancelled') ? 'selected' : '' ?>>إلغاء الحجز (Cancelled)</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">ملاحظات الإدارة للعميل والمالك</label>
                                                            <textarea name="admin_notes" class="form-control form-control-sm" rows="2" placeholder="أدخل أي ملاحظات إدارية لتسجيلها في سجل التغييرات..."><?= e($b['admin_notes'] ?? '') ?></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                                                        <button type="submit" class="btn btn-dark-green btn-sm fw-bold">حفظ الحالة</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Payment Modal -->
                                    <div class="modal fade" id="paymentModal<?= $b['id'] ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content text-start text-rtl">
                                                <form method="POST" action="<?= BASE_URL ?>/admin/bookings.php">
                                                    <?= CSRF::field() ?>
                                                    <input type="hidden" name="action" value="update_payment_status">
                                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">

                                                    <div class="modal-header bg-gold text-dark">
                                                        <h5 class="modal-title fs-6 fw-bold">تسجيل وتأكيد الدفع: <?= e($b['booking_code']) ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body p-3">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">حالة السداد الجديدة</label>
                                                            <select name="new_payment_status" class="form-select form-select-sm" required>
                                                                <option value="deposit_paid" <?= ($b['payment_status'] === 'deposit_paid') ? 'selected' : '' ?>>مدفوع العربون (Deposit Paid)</option>
                                                                <option value="fully_paid" <?= ($b['payment_status'] === 'fully_paid') ? 'selected' : '' ?>>مدفوع بالكامل (Fully Paid)</option>
                                                                <option value="unpaid" <?= ($b['payment_status'] === 'unpaid') ? 'selected' : '' ?>>غير مسدد (Unpaid)</option>
                                                                <option value="refunded" <?= ($b['payment_status'] === 'refunded') ? 'selected' : '' ?>>مسترد للعميل (Refunded)</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">المبلغ المحصل فعلياً (<?= e($b['currency']) ?>)</label>
                                                            <input type="number" name="paid_amount" class="form-control form-control-sm" step="0.01" value="<?= $b['deposit_amount'] > 0 ? $b['deposit_amount'] : $b['total_amount'] ?>" placeholder="المبلغ">
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">طريقة الدفع</label>
                                                            <select name="payment_method" class="form-select form-select-sm">
                                                                <option value="kuraimi_pay">الكريمي جوال / حاسب</option>
                                                                <option value="bank_transfer">تحويل بنكي رسمي</option>
                                                                <option value="cash">نقداً بالإدارة / سند قبض</option>
                                                            </select>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">رقم الإشعار / الحوالة</label>
                                                            <input type="text" name="txn_number" class="form-control form-control-sm" placeholder="مثال: TXN-998811">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                                                        <button type="submit" class="btn btn-dark-green btn-sm fw-bold">توثيق السداد في الحسابات</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا توجد حجوزات مطابقة للفلاتر المحددة.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
