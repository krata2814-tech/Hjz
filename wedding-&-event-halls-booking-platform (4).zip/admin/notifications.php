<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * System Notification & Broadcast Management Module
 * File: admin/notifications.php
 */

$page_title = 'إدارة الإشعارات والتعميمات الإدارية';
require_once __DIR__ . '/includes/admin_header.php';

// Handle Send Broadcast Notification
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');

    if ($action === 'send_broadcast') {
        $targetAudience = post('target_audience'); // 'all', 'owners', 'customers'
        $title = sanitize(post('title'));
        $message = sanitize(post('message'));
        $linkUrl = sanitize(post('link_url', ''));

        if (empty($title) || empty($message)) {
            setFlash('danger', 'يرجى إدخال عنوان ونص الإشعار.');
        } else {
            try {
                // Determine target user IDs
                $targetUserIds = [];
                if ($targetAudience === 'all') {
                    $rows = Database::fetchAll("SELECT id FROM users WHERE status = 'active'");
                    $targetUserIds = array_column($rows, 'id');
                } elseif ($targetAudience === 'owners') {
                    $rows = Database::fetchAll("SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.slug = 'hall_owner' AND u.status = 'active'");
                    $targetUserIds = array_column($rows, 'id');
                } elseif ($targetAudience === 'customers') {
                    $rows = Database::fetchAll("SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.slug = 'customer' AND u.status = 'active'");
                    $targetUserIds = array_column($rows, 'id');
                }

                $count = 0;
                foreach ($targetUserIds as $uId) {
                    Database::query("
                        INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                        VALUES (?, ?, ?, ?, ?, 'system_broadcast', ?, CURRENT_TIMESTAMP)
                    ", [$uId, $title, $title, $message, $message, $linkUrl ?: (BASE_URL . '/index.php')]);
                    $count++;
                }

                // Audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'broadcast_notification_sent', 'notifications', 1, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId,
                    json_encode(['audience' => $targetAudience, 'recipients_count' => $count, 'title' => $title], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', "تم إرسال التعميم الإداري بنجاح إلى $count مستخدم.");
                redirect(BASE_URL . '/admin/notifications.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    }
}

// Fetch sent notifications
$notifications = [];
try {
    $notifications = Database::fetchAll("
        SELECT n.*, u.name as recipient_name, u.email as recipient_email, r.slug as role_slug
        FROM notifications n
        LEFT JOIN users u ON n.user_id = u.id
        LEFT JOIN roles r ON u.role_id = r.id
        ORDER BY n.created_at DESC
        LIMIT 50
    ");
} catch (Exception $e) {
    $notifications = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-bell-fill text-gold me-2 ms-2"></i> إدارة الإشعارات والتعميمات الإدارية (Notification Management)
                </h4>
                <p class="text-muted small mb-0">بث الإشعارات الجماعية لملاك القاعات أو العملاء ومتابعة سجل التنبيهات الصادرة.</p>
            </div>

            <button type="button" class="btn btn-gold btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#broadcastModal">
                <i class="bi bi-megaphone-fill me-1 ms-1"></i> إرسال تعميم إداري جديد
            </button>
        </div>
    </div>

    <!-- Notifications Log -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="card-header bg-light py-3 border-bottom">
            <h6 class="fw-bold text-dark-green mb-0">سجل الإشعارات المرسلة للمستخدمين</h6>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>المستلم</th>
                        <th>العنوان</th>
                        <th>نص الإشعار</th>
                        <th>النوع</th>
                        <th>حالة القراءة</th>
                        <th>التاريخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($notifications)): ?>
                        <?php foreach ($notifications as $n): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $n['id'] ?></td>
                                <td>
                                    <strong><?= e($n['recipient_name'] ?: 'مستخدم عام') ?></strong>
                                    <div class="text-muted" style="font-size: 0.72rem;"><?= e($n['recipient_email'] ?? '') ?></div>
                                </td>
                                <td class="fw-bold text-dark-green"><?= e($n['title_ar']) ?></td>
                                <td style="max-width: 320px;"><?= e($n['message_ar']) ?></td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= e($n['type'] ?? 'general') ?></span>
                                </td>
                                <td>
                                    <?= !empty($n['is_read']) ? '<span class="text-success"><i class="bi bi-check2-all"></i> مقروء</span>' : '<span class="text-muted">جديد</span>' ?>
                                </td>
                                <td><?= date('Y-m-d H:i', strtotime($n['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4 text-muted">لا توجد إشعارات مسجلة حتى الآن.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Modal: Send Broadcast Notification -->
<div class="modal fade" id="broadcastModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start text-rtl">
            <form method="POST" action="<?= BASE_URL ?>/admin/notifications.php">
                <?= CSRF::field() ?>
                <input type="hidden" name="action" value="send_broadcast">

                <div class="modal-header bg-dark-green text-white">
                    <h5 class="modal-title fs-6 fw-bold">إرسال تعميم وتنبيه للمستخدمين</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">الفئة المستهدفة <span class="text-danger">*</span></label>
                        <select name="target_audience" class="form-select form-select-sm" required>
                            <option value="all">كافة مستخدمي المنظومة (ملاك وعملاء وموظفين)</option>
                            <option value="owners">ملاك ومدراء القاعات فقط</option>
                            <option value="customers">العملاء والباحثون عن قاعات فقط</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">عنوان الإشعار <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control form-control-sm" required placeholder="مثال: تحديث شروط الحجز أو عطلة عيد الأضحى...">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">نص الرسالة <span class="text-danger">*</span></label>
                        <textarea name="message" class="form-control form-control-sm" rows="3" required placeholder="اكتب نص التعميم الإداري..."></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold small">رابط التوجيه (اختياري)</label>
                        <input type="text" name="link_url" class="form-control form-control-sm" placeholder="مثال: <?= BASE_URL ?>/halls.php">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-dark-green btn-sm fw-bold">إرسال التعميم فوراً</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
