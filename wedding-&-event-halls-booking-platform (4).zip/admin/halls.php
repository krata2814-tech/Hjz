<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Hall Listing Approval, Rejection with Reasons, and Moderation
 * File: admin/halls.php
 */

$page_title = 'اعتماد وإدارة القاعات والقصور';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $hallId = (int)post('hall_id');

    if ($hallId > 0) {
        $hall = Database::fetchOne("SELECT name_ar, owner_id FROM halls WHERE id = ?", [$hallId]);

        // 1. Approve Hall
        if ($action === 'approve_hall') {
            try {
                Database::query("UPDATE halls SET status = 'active', rejection_reason = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$hallId]);

                // Audit log
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'hall_approved', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId, $hallId,
                    json_encode(['hall_name' => $hall['name_ar'] ?? '', 'status' => 'active'], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                // Notify owner
                if (!empty($hall['owner_id'])) {
                    Database::query("
                        INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                        VALUES (?, 'تم اعتماد قاعتكم بنجاح!', 'Hall Approved', ?, ?, 'hall_approved', ?, CURRENT_TIMESTAMP)
                    ", [
                        $hall['owner_id'],
                        "تهانينا، تمت مراجعة واعتماد قاعتكم (" . ($hall['name_ar'] ?? '') . ") وأصبحت متاحة للجمهور الآن.",
                        "Your hall has been approved and is now active.",
                        BASE_URL . "/hall-details.php?id=" . $hallId
                    ]);
                }

                setFlash('success', 'تم اعتماد ونشر القاعة بنجاح وأصبحت ظاهرة للجمهور.');
                redirect(BASE_URL . '/admin/halls.php?status=active');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ أثناء اعتماد القاعة: ' . $e->getMessage());
            }
        }

        // 2. Reject Hall with Reason
        elseif ($action === 'reject_hall') {
            $reason = trim(post('rejection_reason', ''));
            if (empty($reason)) {
                setFlash('warning', 'يرجى كتابة سبب الرفض لتوضيحه لمالك القاعة.');
            } else {
                try {
                    Database::query("UPDATE halls SET status = 'rejected', rejection_reason = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$reason, $hallId]);

                    // Audit log
                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'hall_rejected', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId, $hallId,
                        json_encode(['hall_name' => $hall['name_ar'] ?? '', 'status' => 'rejected', 'reason' => $reason], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    // Notify owner
                    if (!empty($hall['owner_id'])) {
                        Database::query("
                            INSERT INTO notifications (user_id, title_ar, title_en, message_ar, message_en, type, link_url, created_at)
                            VALUES (?, 'تم رفض إدراج القاعة', 'Hall Listing Rejected', ?, ?, 'hall_rejected', ?, CURRENT_TIMESTAMP)
                        ", [
                            $hall['owner_id'],
                            "نعتذر، تم رفض طلب إدراج قاعتكم (" . ($hall['name_ar'] ?? '') . ") للسبب التالي: " . $reason,
                            "Your hall listing was rejected: " . $reason,
                            BASE_URL . "/dashboard.php"
                        ]);
                    }

                    setFlash('warning', 'تم رفض إدراج القاعة مع توثيق السبب وإرسال إشعار للمالك.');
                    redirect(BASE_URL . '/admin/halls.php?status=rejected');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ أثناء رفض القاعة: ' . $e->getMessage());
                }
            }
        }

        // 3. Toggle Featured
        elseif ($action === 'toggle_featured') {
            $currentFeatured = (int)post('current_featured');
            $newFeatured = ($currentFeatured === 1) ? 0 : 1;
            try {
                Database::query("UPDATE halls SET featured = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newFeatured, $hallId]);
                
                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, 'hall_featured_toggled', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId, $hallId,
                    json_encode(['hall_name' => $hall['name_ar'] ?? '', 'featured' => $newFeatured], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', ($newFeatured === 1) ? 'تم تمييز القاعة ووضعها في صدارة الصفحة الرئيسية.' : 'تم إلغاء تمييز القاعة.');
                redirect(BASE_URL . '/admin/halls.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }

        // 4. Suspend or Reactivate Hall
        elseif ($action === 'toggle_status') {
            $newStatus = post('new_status');
            if (in_array($newStatus, ['active', 'suspended'])) {
                try {
                    Database::query("UPDATE halls SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $hallId]);

                    Database::query("
                        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                        VALUES (?, 'hall_status_changed', 'halls', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ", [
                        $adminId, $hallId,
                        json_encode(['hall_name' => $hall['name_ar'] ?? '', 'new_status' => $newStatus], JSON_UNESCAPED_UNICODE),
                        $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                        substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                    ]);

                    setFlash('success', ($newStatus === 'suspended') ? 'تم تعليق القاعة وحجبها عن البحث مؤقتاً.' : 'تم إعادة تنشيط القاعة.');
                    redirect(BASE_URL . '/admin/halls.php');
                } catch (Exception $e) {
                    setFlash('danger', 'خطأ: ' . $e->getMessage());
                }
            }
        }
    }
}

// Filters
$statusFilter = trim($_GET['status'] ?? '');
$cityFilter = trim($_GET['city'] ?? '');
$search = trim($_GET['search'] ?? '');

$sql = "
    SELECT h.*, u.name as owner_name, u.phone as owner_phone, u.email as owner_email,
           (SELECT image_url FROM hall_images WHERE hall_id = h.id ORDER BY is_primary DESC, sort_order ASC LIMIT 1) as cover_img,
           (SELECT COUNT(*) FROM bookings WHERE hall_id = h.id) as bookings_count
    FROM halls h
    JOIN users u ON h.owner_id = u.id
    WHERE 1=1
";
$params = [];

if (!empty($statusFilter)) {
    $sql .= " AND h.status = ?";
    $params[] = $statusFilter;
}

if (!empty($cityFilter)) {
    $sql .= " AND h.city = ?";
    $params[] = $cityFilter;
}

if (!empty($search)) {
    $sql .= " AND (h.name_ar LIKE ? OR h.district LIKE ? OR u.name LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY (CASE WHEN h.status = 'pending_approval' THEN 0 ELSE 1 END), h.created_at DESC";

$halls = [];
try {
    $halls = Database::fetchAll($sql, $params);
} catch (Exception $e) {
    $halls = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header & Stats Bar -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-building text-gold me-2 ms-2"></i> اعتماد وإدارة القاعات والقصور (Listing Moderation)
                </h4>
                <p class="text-muted small mb-0">مراجعة طلبات الانضمام، اعتماد القاعات أو رفضها مع كتابة الأسباب، ضبط التمييز، والرقابة المستمرة.</p>
            </div>

            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>/admin/halls.php?status=pending_approval" class="btn btn-warning btn-sm fw-bold">
                    <i class="bi bi-hourglass-split me-1 ms-1"></i> طلبات بانتظار الاعتماد (<?= $pendingHallsBadge ?>)
                </a>
            </div>
        </div>
    </div>

    <!-- Filter Toolbar -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <form method="GET" action="<?= BASE_URL ?>/admin/halls.php" class="row g-2 align-items-center">
            <div class="col-md-4 col-12">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="بحث باسم القاعة، الحي، أو المالك..." value="<?= e($search) ?>">
                </div>
            </div>

            <div class="col-md-3 col-6">
                <select name="status" class="form-select form-select-sm">
                    <option value="">جميع الحالات</option>
                    <option value="pending_approval" <?= ($statusFilter === 'pending_approval') ? 'selected' : '' ?>>قيد المراجعة والاعتماد (Pending)</option>
                    <option value="active" <?= ($statusFilter === 'active') ? 'selected' : '' ?>>نشطة ومعتمدة (Active)</option>
                    <option value="rejected" <?= ($statusFilter === 'rejected') ? 'selected' : '' ?>>مرفوضة (Rejected)</option>
                    <option value="suspended" <?= ($statusFilter === 'suspended') ? 'selected' : '' ?>>معلقة مؤقتاً (Suspended)</option>
                </select>
            </div>

            <div class="col-md-3 col-6">
                <select name="city" class="form-select form-select-sm">
                    <option value="">جميع المحافظات اليمنية</option>
                    <?php foreach (getYemenGovernorates() as $govCode => $govName): ?>
                        <option value="<?= e($govCode) ?>" <?= ($cityFilter === $govCode) ? 'selected' : '' ?>><?= e($govName) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2 col-12 d-flex gap-1">
                <button type="submit" class="btn btn-dark-green btn-sm w-100">تصفية</button>
                <a href="<?= BASE_URL ?>/admin/halls.php" class="btn btn-outline-secondary btn-sm" title="إعادة ضبط"><i class="bi bi-arrow-counterclockwise"></i></a>
            </div>
        </form>
    </div>

    <!-- Halls List Table -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th>القاعة والصورة</th>
                        <th>الموقع</th>
                        <th>المالك</th>
                        <th>السعة</th>
                        <th>الحجوزات</th>
                        <th>التمييز (Featured)</th>
                        <th>الحالة</th>
                        <th class="text-center">القرار والإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($halls)): ?>
                        <?php foreach ($halls as $h): ?>
                            <tr class="<?= ($h['status'] === 'pending_approval') ? 'table-warning' : '' ?>">
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="<?= e($h['cover_img'] ?? 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=150&q=80') ?>" class="rounded object-fit-cover" width="55" height="55" alt="<?= e($h['name_ar']) ?>">
                                        <div>
                                            <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $h['id'] ?>" target="_blank" class="fw-bold text-dark-green text-decoration-none">
                                                <?= e($h['name_ar']) ?>
                                            </a>
                                            <div class="text-muted" style="font-size: 0.75rem;"><?= e($h['name_en'] ?? '') ?></div>
                                            <?php if (!empty($h['rejection_reason'])): ?>
                                                <div class="text-danger small mt-1">
                                                    <i class="bi bi-info-circle"></i> سبب الرفض: <?= e($h['rejection_reason']) ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?= e(getCityName($h['city'])) ?></span>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= e($h['district'] ?? $h['address']) ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= e($h['owner_name']) ?></div>
                                    <a href="tel:<?= e($h['owner_phone']) ?>" class="text-muted" style="font-size: 0.75rem;"><?= e($h['owner_phone']) ?></a>
                                </td>
                                <td><?= number_format($h['capacity_min']) ?> - <?= number_format($h['capacity_max']) ?> ضيف</td>
                                <td><span class="badge bg-light text-dark border"><?= $h['bookings_count'] ?> حجز</span></td>
                                <td>
                                    <form method="POST" action="<?= BASE_URL ?>/admin/halls.php" class="d-inline">
                                        <?= CSRF::field() ?>
                                        <input type="hidden" name="action" value="toggle_featured">
                                        <input type="hidden" name="hall_id" value="<?= $h['id'] ?>">
                                        <input type="hidden" name="current_featured" value="<?= $h['featured'] ?>">
                                        <button type="submit" class="btn btn-sm <?= ($h['featured'] == 1) ? 'btn-gold text-dark' : 'btn-outline-secondary' ?> py-0 px-2" title="تبديل ميزة الواجهة">
                                            <i class="bi <?= ($h['featured'] == 1) ? 'bi-star-fill text-warning' : 'bi-star' ?>"></i>
                                            <?= ($h['featured'] == 1) ? 'مميزة' : 'عادية' ?>
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <?php
                                        switch ($h['status']) {
                                            case 'active': echo '<span class="badge bg-success">معتمدة ونشطة</span>'; break;
                                            case 'pending_approval': echo '<span class="badge bg-warning text-dark"><i class="bi bi-clock"></i> قيد المراجعة</span>'; break;
                                            case 'rejected': echo '<span class="badge bg-danger">مرفوضة</span>'; break;
                                            default: echo '<span class="badge bg-secondary">معلقة</span>'; break;
                                        }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <?php if ($h['status'] === 'pending_approval' || $h['status'] === 'rejected'): ?>
                                            <!-- Approve Button -->
                                            <form method="POST" action="<?= BASE_URL ?>/admin/halls.php" class="d-inline" onsubmit="return confirm('تأكيد اعتماد هذه القاعة ونشرها فوراً؟');">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="action" value="approve_hall">
                                                <input type="hidden" name="hall_id" value="<?= $h['id'] ?>">
                                                <button type="submit" class="btn btn-success btn-sm py-1 px-2" title="اعتماد">
                                                    <i class="bi bi-check-lg"></i> اعتماد
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <?php if ($h['status'] === 'pending_approval' || $h['status'] === 'active'): ?>
                                            <!-- Reject with Reason Button -->
                                            <button type="button" class="btn btn-outline-danger btn-sm py-1 px-2" data-bs-toggle="modal" data-bs-target="#rejectModal<?= $h['id'] ?>" title="رفض مع سبب">
                                                <i class="bi bi-x-lg"></i> رفض
                                            </button>
                                        <?php endif; ?>

                                        <?php if ($h['status'] === 'active'): ?>
                                            <!-- Suspend Button -->
                                            <form method="POST" action="<?= BASE_URL ?>/admin/halls.php" class="d-inline" onsubmit="return confirm('هل تريد تعليق ظهور هذه القاعة؟');">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="hall_id" value="<?= $h['id'] ?>">
                                                <input type="hidden" name="new_status" value="suspended">
                                                <button type="submit" class="btn btn-outline-secondary btn-sm py-1 px-2" title="تعليق">
                                                    <i class="bi bi-pause-circle"></i>
                                                </button>
                                            </form>
                                        <?php elseif ($h['status'] === 'suspended'): ?>
                                            <!-- Reactivate Button -->
                                            <form method="POST" action="<?= BASE_URL ?>/admin/halls.php" class="d-inline">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="hall_id" value="<?= $h['id'] ?>">
                                                <input type="hidden" name="new_status" value="active">
                                                <button type="submit" class="btn btn-outline-success btn-sm py-1 px-2" title="تفعيل">
                                                    <i class="bi bi-play-circle"></i> تفعيل
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $h['id'] ?>" target="_blank" class="btn btn-outline-dark-green btn-sm py-1 px-2" title="معاينة">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </div>

                                    <!-- Rejection Modal -->
                                    <div class="modal fade" id="rejectModal<?= $h['id'] ?>" tabindex="-1" aria-labelledby="rejectModalLabel<?= $h['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content text-start text-rtl">
                                                <form method="POST" action="<?= BASE_URL ?>/admin/halls.php">
                                                    <?= CSRF::field() ?>
                                                    <input type="hidden" name="action" value="reject_hall">
                                                    <input type="hidden" name="hall_id" value="<?= $h['id'] ?>">

                                                    <div class="modal-header bg-danger text-white">
                                                        <h5 class="modal-title fs-6 fw-bold" id="rejectModalLabel<?= $h['id'] ?>">
                                                            <i class="bi bi-x-circle me-1 ms-1"></i> رفض إدراج: <?= e($h['name_ar']) ?>
                                                        </h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body p-3">
                                                        <div class="mb-3">
                                                            <label class="form-label fw-bold small">سبب الرفض والملاحظات للمالك <span class="text-danger">*</span></label>
                                                            <textarea name="rejection_reason" class="form-control" rows="3" required placeholder="وضح لمالك القاعة الأسباب بدقة (مثال: مستندات غير مكتملة، جودة الصور، بيانات الأسعار)..."></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إلغاء</button>
                                                        <button type="submit" class="btn btn-danger btn-sm">تأكيد الرفض مع الملاحظة</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">
                                لا توجد قاعات مطابقة لمعايير البحث المحددة.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
