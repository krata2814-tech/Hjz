<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Customer Management Module
 * File: admin/customers.php
 */

$page_title = 'إدارة العملاء والباحثين عن قاعات';
require_once __DIR__ . '/includes/admin_header.php';

// Handle State-Changing Post Actions (Suspend / Reactivate)
if (isPost()) {
    CSRF::verifyOrDie();
    $action = post('action');
    $customerId = (int)post('customer_id');

    if ($customerId > 0 && $action === 'toggle_status') {
        $newStatus = post('new_status');
        if (in_array($newStatus, ['active', 'suspended'])) {
            try {
                Database::query("UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $customerId]);

                Database::query("
                    INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent, created_at)
                    VALUES (?, ?, 'users', ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ", [
                    $adminId, ($newStatus === 'suspended' ? 'customer_suspended' : 'customer_reactivated'), $customerId,
                    json_encode(['customer_id' => $customerId, 'status' => $newStatus], JSON_UNESCAPED_UNICODE),
                    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    substr($_SERVER['HTTP_USER_AGENT'] ?? 'Web', 0, 255)
                ]);

                setFlash('success', 'تم تعديل حالة حساب العميل بنجاح.');
                redirect(BASE_URL . '/admin/customers.php');
            } catch (Exception $e) {
                setFlash('danger', 'خطأ: ' . $e->getMessage());
            }
        }
    }
}

// Fetch all customers joined with profiles and activity
$customers = [];
try {
    $customers = Database::fetchAll("
        SELECT u.*, cp.preferred_city, cp.wedding_date_estimate, cp.emergency_phone,
               (SELECT COUNT(*) FROM bookings WHERE customer_id = u.id) as bookings_count,
               (SELECT COUNT(*) FROM inquiries WHERE user_id = u.id) as inquiries_count,
               (SELECT COUNT(*) FROM reviews WHERE customer_id = u.id) as reviews_count
        FROM users u
        JOIN roles r ON u.role_id = r.id
        LEFT JOIN customer_profiles cp ON u.id = cp.user_id
        WHERE r.slug = 'customer'
        ORDER BY u.created_at DESC
    ");
} catch (Exception $e) {
    $customers = [];
}
?>

<div class="container-fluid px-lg-4 py-4">

    <!-- Header -->
    <div class="card border rounded-3 p-3 mb-4 bg-white shadow-sm">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="fw-bold text-dark-green mb-1">
                    <i class="bi bi-person-lines-fill text-gold me-2 ms-2"></i> إدارة العملاء والمستخدمين (Customers)
                </h4>
                <p class="text-muted small mb-0">بيانات العملاء، الحجوزات المطلوبة، الاستفسارات، التقييمات، والرقابة على الحسابات.</p>
            </div>
            <span class="badge bg-gold text-dark fs-7 px-3 py-2">
                <?= count($customers) ?> عميل مسجل
            </span>
        </div>
    </div>

    <!-- Customers List -->
    <div class="card border rounded-3 bg-white shadow-sm overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 small">
                <thead class="table-light">
                    <tr>
                        <th># المعرف</th>
                        <th>العميل</th>
                        <th>بيانات التواصل</th>
                        <th>المدينة المفضلة</th>
                        <th>تاريخ المناسبة المتوقع</th>
                        <th>النشاط (حجوزات / استفسارات / تقييمات)</th>
                        <th>الحالة</th>
                        <th class="text-center">الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($customers)): ?>
                        <?php foreach ($customers as $c): ?>
                            <tr>
                                <td class="font-monospace text-muted">#<?= $c['id'] ?></td>
                                <td>
                                    <div class="fw-bold text-dark-green"><?= e($c['name']) ?></div>
                                    <span class="text-muted" style="font-size: 0.75rem;">انضم <?= date('Y-m-d', strtotime($c['created_at'])) ?></span>
                                </td>
                                <td>
                                    <div><i class="bi bi-telephone text-muted me-1 ms-1"></i> <a href="tel:<?= e($c['phone']) ?>" class="text-dark text-decoration-none"><?= e($c['phone']) ?></a></div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><i class="bi bi-envelope text-muted me-1 ms-1"></i> <?= e($c['email']) ?></div>
                                </td>
                                <td><?= e($c['preferred_city'] ? getCityName($c['preferred_city']) : 'غير محدد') ?></td>
                                <td><?= e($c['wedding_date_estimate'] ?: 'غير محدد') ?></td>
                                <td>
                                    <span class="badge bg-primary-subtle text-primary border me-1"><?= $c['bookings_count'] ?> حجز</span>
                                    <span class="badge bg-info-subtle text-info border me-1"><?= $c['inquiries_count'] ?> استفسار</span>
                                    <span class="badge bg-warning-subtle text-dark border"><?= $c['reviews_count'] ?> تقييم</span>
                                </td>
                                <td>
                                    <span class="badge <?= ($c['status'] === 'active') ? 'bg-success' : 'bg-danger' ?>">
                                        <?= ($c['status'] === 'active') ? 'نشط' : 'موقف' ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <form method="POST" action="<?= BASE_URL ?>/admin/customers.php" class="d-inline" onsubmit="return confirm('تأكيد تغيير حالة حساب العميل؟');">
                                        <?= CSRF::field() ?>
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="customer_id" value="<?= $c['id'] ?>">
                                        <input type="hidden" name="new_status" value="<?= ($c['status'] === 'active') ? 'suspended' : 'active' ?>">
                                        <button type="submit" class="btn btn-sm <?= ($c['status'] === 'active') ? 'btn-outline-danger' : 'btn-outline-success' ?> py-1 px-2" title="<?= ($c['status'] === 'active') ? 'إيقاف الحساب' : 'تفعيل الحساب' ?>">
                                            <i class="bi <?= ($c['status'] === 'active') ? 'bi-lock-fill' : 'bi-unlock-fill' ?>"></i>
                                            <?= ($c['status'] === 'active') ? 'إيقاف' : 'تفعيل' ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">لا يوجد عملاء مسجلون حالياً.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
