<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Halls & Venues Directory with Advanced Multi-Facet Filtering & Pagination
 */

$page_title = 'استكشاف القاعات والقصور | دليل قاعات الأفراح في اليمن';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

// Filter Inputs Sanitization
$keyword = sanitize(get('q', ''));
$selectedCity = sanitize(get('city', ''));
$district = sanitize(get('district', ''));
$selectedType = sanitize(get('type', ''));
$targetDate = sanitize(get('date', ''));
$selectedCapacity = (int) get('capacity', 0);
$minPrice = (float) get('min_price', 0);
$maxPrice = (float) get('max_price', 0);
$venueType = sanitize(get('venue_type', '')); // indoor, outdoor
$selectedFacilities = isset($_GET['facilities']) && is_array($_GET['facilities']) 
    ? array_map('intval', $_GET['facilities']) 
    : [];
$sort = sanitize(get('sort', 'rating_desc'));
$page = max(1, (int) get('page', 1));
$perPage = 6;

// Fetch All Facilities for the sidebar filter checklist
try {
    $allFacilities = Database::fetchAll("SELECT * FROM facilities ORDER BY id ASC");
} catch (Exception $e) {
    $allFacilities = [];
}

// Build Dynamic SQL Query with Prepared Statements
$whereClauses = ["h.status = 'active'"];
$params = [];

if (!empty($keyword)) {
    $whereClauses[] = "(h.name_ar LIKE ? OR h.name_en LIKE ? OR h.address LIKE ? OR h.description_ar LIKE ?)";
    $kwTerm = '%' . $keyword . '%';
    $params[] = $kwTerm;
    $params[] = $kwTerm;
    $params[] = $kwTerm;
    $params[] = $kwTerm;
}

if (!empty($selectedCity)) {
    $whereClauses[] = "h.city = ?";
    $params[] = $selectedCity;
}

if (!empty($district)) {
    $whereClauses[] = "h.address LIKE ?";
    $params[] = '%' . $district . '%';
}

if (!empty($selectedType)) {
    $whereClauses[] = "h.hall_type = ?";
    $params[] = $selectedType;
}

if ($selectedCapacity > 0) {
    $whereClauses[] = "h.capacity_max >= ?";
    $params[] = $selectedCapacity;
}

if ($minPrice > 0) {
    $whereClauses[] = "h.price_evening >= ?";
    $params[] = $minPrice;
}

if ($maxPrice > 0) {
    $whereClauses[] = "h.price_evening <= ?";
    $params[] = $maxPrice;
}

if (!empty($venueType)) {
    if ($venueType === 'indoor') {
        $whereClauses[] = "h.description_ar NOT LIKE '%مفتوح%'";
    } elseif ($venueType === 'outdoor') {
        $whereClauses[] = "(h.description_ar LIKE '%مفتوح%' OR h.description_ar LIKE '%حديق%')";
    }
}

if (!empty($selectedFacilities)) {
    foreach ($selectedFacilities as $facId) {
        if ($facId > 0) {
            $whereClauses[] = "EXISTS (SELECT 1 FROM hall_facilities hf WHERE hf.hall_id = h.id AND hf.facility_id = ?)";
            $params[] = $facId;
        }
    }
}

$whereSql = implode(' AND ', $whereClauses);

// Count Total for Pagination
$countSql = "SELECT COUNT(*) as total FROM halls h WHERE {$whereSql}";
$totalHalls = 0;
try {
    $countRow = Database::fetchOne($countSql, $params);
    $totalHalls = (int)($countRow['total'] ?? 0);
} catch (Exception $e) {
    $totalHalls = 0;
}

$totalPages = max(1, ceil($totalHalls / $perPage));
$offset = ($page - 1) * $perPage;

// Order By
$orderBy = "h.featured DESC, h.rating DESC";
if ($sort === 'price_asc') {
    $orderBy = "h.price_evening ASC";
} elseif ($sort === 'price_desc') {
    $orderBy = "h.price_evening DESC";
} elseif ($sort === 'capacity_desc') {
    $orderBy = "h.capacity_max DESC";
} elseif ($sort === 'newest') {
    $orderBy = "h.id DESC";
}

// Fetch halls with availability check if date is supplied
$dataParams = $params;
$availabilitySelect = "0 as is_booked_on_date";
if (!empty($targetDate)) {
    $availabilitySelect = "(SELECT COUNT(*) FROM bookings b WHERE b.hall_id = h.id AND b.event_date = ? AND b.status IN ('confirmed', 'approved')) as is_booked_on_date";
    array_unshift($dataParams, $targetDate);
}

$sql = "
    SELECT h.*, 
           (SELECT image_url FROM hall_images WHERE hall_id = h.id AND is_primary = 1 LIMIT 1) as primary_image,
           {$availabilitySelect}
    FROM halls h
    WHERE {$whereSql}
    ORDER BY {$orderBy}
    LIMIT {$perPage} OFFSET {$offset}
";

try {
    $halls = Database::fetchAll($sql, $dataParams);
} catch (Exception $e) {
    $halls = [];
}

// Fetch amenities for each hall to display icons
$hallIds = array_column($halls, 'id');
$hallAmenitiesMap = [];
if (!empty($hallIds)) {
    $placeholders = implode(',', array_fill(0, count($hallIds), '?'));
    try {
        $amenityRows = Database::fetchAll("
            SELECT ha.hall_id, f.name_ar, f.name_en, f.icon 
            FROM hall_facilities ha 
            JOIN facilities f ON ha.facility_id = f.id 
            WHERE ha.hall_id IN ({$placeholders})
        ", $hallIds);
        foreach ($amenityRows as $row) {
            $hallAmenitiesMap[$row['hall_id']][] = $row;
        }
    } catch (Exception $e) {
        $hallAmenitiesMap = [];
    }
}

// Helper to preserve filter query parameters in pagination
function buildCatalogPageUrl($targetPage) {
    $q = $_GET;
    $q['page'] = $targetPage;
    return BASE_URL . '/halls.php?' . http_build_query($q);
}
?>

<div class="bg-white border-bottom py-4 mb-4">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
            <div>
                <h1 class="h3 fw-bold text-dark-green mb-1"><?= Lang::isRtl() ? 'دليل قاعات الأعراس والمناسبات' : 'Venues & Halls Directory' ?></h1>
                <p class="text-muted small mb-0">
                    <?= Lang::isRtl() ? 'استعرض أفضل الصالات والقصور المعتمدة في اليمن مع تصفية ذكية حسب المدينة، السعة، الأسعار، والمرافق' : 'Explore top rated celebration venues with smart filtering by city, capacity, and amenities' ?>
                </p>
            </div>
            <a href="<?= BASE_URL ?>/inquiry.php" class="btn btn-gold btn-sm d-inline-flex align-items-center gap-1 align-self-start align-self-md-auto">
                <i class="bi bi-calendar2-check"></i>
                <span><?= Lang::isRtl() ? 'طلب استشارة ترشيح قاعة' : 'Consultation' ?></span>
            </a>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        <!-- Sidebar Filter Form -->
        <div class="col-lg-3 col-12">
            <div class="bg-white p-3 p-md-4 rounded-3 border shadow-sm sticky-top" style="top: 85px;">
                <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                    <h5 class="fw-bold text-dark-green mb-0 d-flex align-items-center gap-2">
                        <i class="bi bi-funnel-fill text-gold"></i> <?= e(__('filter')) ?>
                    </h5>
                    <a href="<?= BASE_URL ?>/halls.php" class="small text-danger text-decoration-none">
                        <i class="bi bi-arrow-counterclockwise"></i> <?= Lang::isRtl() ? 'إعادة ضبط' : 'Reset' ?>
                    </a>
                </div>

                <form action="<?= BASE_URL ?>/halls.php" method="GET" id="catalogFilterForm">
                    <!-- Text Keyword -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'البحث بالاسم أو الوصف' : 'Search' ?></label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                            <input type="text" name="q" class="form-control" placeholder="<?= Lang::isRtl() ? 'اسم القاعة...' : 'Venue name...' ?>" value="<?= e($keyword) ?>">
                        </div>
                    </div>

                    <!-- City Filter (All 22 Yemeni Governorates) -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'المحافظة / المدينة' : 'Governorate / City' ?></label>
                        <select name="city" class="form-select form-select-sm">
                            <option value=""><?= e(__('all_cities')) ?></option>
                            <?php foreach (getYemenGovernorates() as $govCode => $govName): ?>
                                <option value="<?= e($govCode) ?>" <?= ($selectedCity === $govCode) ? 'selected' : '' ?>><?= e($govName) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- District / Neighborhood -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'الحي / المنطقة' : 'District' ?></label>
                        <input type="text" name="district" class="form-control form-control-sm" placeholder="<?= Lang::isRtl() ? 'مثال: حدة، خور مكسر...' : 'e.g. Hadda...' ?>" value="<?= e($district) ?>">
                    </div>

                    <!-- Type Filter -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'نوع المناسبة' : 'Occasion Type' ?></label>
                        <select name="type" class="form-select form-select-sm">
                            <option value=""><?= e(__('all_types')) ?></option>
                            <option value="wedding" <?= ($selectedType === 'wedding') ? 'selected' : '' ?>><?= e(__('type_wedding')) ?></option>
                            <option value="engagement" <?= ($selectedType === 'engagement') ? 'selected' : '' ?>><?= e(__('type_engagement')) ?></option>
                            <option value="graduation" <?= ($selectedType === 'graduation') ? 'selected' : '' ?>><?= e(__('type_graduation')) ?></option>
                            <option value="conference" <?= ($selectedType === 'conference') ? 'selected' : '' ?>><?= e(__('type_conference')) ?></option>
                            <option value="family" <?= ($selectedType === 'family') ? 'selected' : '' ?>><?= e(__('type_family')) ?></option>
                        </select>
                    </div>

                    <!-- Event Date for Availability -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green">
                            <i class="bi bi-calendar2-check text-gold"></i> <?= Lang::isRtl() ? 'فحص تاريخ المناسبة' : 'Check Date Availability' ?>
                        </label>
                        <input type="date" name="date" class="form-control form-control-sm min-today" value="<?= e($targetDate) ?>">
                        <div class="form-text small" style="font-size: 0.75rem;"><?= Lang::isRtl() ? 'يعرض حالة التوفر في الموعد المحدد' : 'Checks if booked on selected date' ?></div>
                    </div>

                    <!-- Capacity Filter -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('capacity')) ?></label>
                        <select name="capacity" class="form-select form-select-sm">
                            <option value=""><?= Lang::isRtl() ? 'أي سعة' : 'Any' ?></option>
                            <option value="200" <?= ($selectedCapacity == 200) ? 'selected' : '' ?>>200+ <?= e(__('guest')) ?></option>
                            <option value="400" <?= ($selectedCapacity == 400) ? 'selected' : '' ?>>400+ <?= e(__('guest')) ?></option>
                            <option value="600" <?= ($selectedCapacity == 600) ? 'selected' : '' ?>>600+ <?= e(__('guest')) ?></option>
                            <option value="800" <?= ($selectedCapacity == 800) ? 'selected' : '' ?>>800+ <?= e(__('guest')) ?></option>
                        </select>
                    </div>

                    <!-- Price Range -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'نطاق السعر المسائي (ريال)' : 'Price Range (YER)' ?></label>
                        <div class="row g-1">
                            <div class="col-6">
                                <input type="number" name="min_price" class="form-control form-control-sm" placeholder="<?= Lang::isRtl() ? 'الحد الأدنى' : 'Min' ?>" value="<?= $minPrice > 0 ? $minPrice : '' ?>">
                            </div>
                            <div class="col-6">
                                <input type="number" name="max_price" class="form-control form-control-sm" placeholder="<?= Lang::isRtl() ? 'الحد الأقصى' : 'Max' ?>" value="<?= $maxPrice > 0 ? $maxPrice : '' ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Venue Environment -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'طبيعة القاعة' : 'Venue Type' ?></label>
                        <select name="venue_type" class="form-select form-select-sm">
                            <option value=""><?= Lang::isRtl() ? 'الكل (مغلق وخارجي)' : 'All' ?></option>
                            <option value="indoor" <?= ($venueType === 'indoor') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'صالة مغلقة ومكيفة' : 'Indoor Climatized' ?></option>
                            <option value="outdoor" <?= ($venueType === 'outdoor') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'حديقة أو ساحة مفتوحة' : 'Outdoor / Garden' ?></option>
                        </select>
                    </div>

                    <!-- Facilities Checklist -->
                    <?php if (!empty($allFacilities)): ?>
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-dark-green d-block mb-2"><?= Lang::isRtl() ? 'المرافق والتجهيزات المهمة' : 'Key Amenities' ?></label>
                            <div class="facilities-filter-list">
                                <?php foreach ($allFacilities as $fac): ?>
                                    <div class="form-check facility-check-item">
                                        <input class="form-check-input" type="checkbox" name="facilities[]" value="<?= $fac['id'] ?>" id="fac_<?= $fac['id'] ?>" <?= in_array($fac['id'], $selectedFacilities) ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="fac_<?= $fac['id'] ?>">
                                            <i class="bi <?= e($fac['icon']) ?>"></i>
                                            <span><?= e(Lang::isRtl() ? $fac['name_ar'] : ($fac['name_en'] ?? $fac['name_ar'])) ?></span>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Sorting -->
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'ترتيب النتائج' : 'Sort by' ?></label>
                        <select name="sort" class="form-select form-select-sm">
                            <option value="rating_desc" <?= ($sort === 'rating_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأعلى تقييماً' : 'Highest Rated' ?></option>
                            <option value="price_asc" <?= ($sort === 'price_asc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأقل سعراً أولاً' : 'Lowest Price' ?></option>
                            <option value="price_desc" <?= ($sort === 'price_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأعلى سعراً' : 'Highest Price' ?></option>
                            <option value="capacity_desc" <?= ($sort === 'capacity_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأكبر سعة' : 'Largest Capacity' ?></option>
                            <option value="newest" <?= ($sort === 'newest') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأحدث إضافة' : 'Newest' ?></option>
                        </select>
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-sm btn-gold fw-bold">
                            <i class="bi bi-funnel"></i> <?= Lang::isRtl() ? 'تطبيق الفلتر والبحث' : 'Apply Filters' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Venues Listing Grid -->
        <div class="col-lg-9 col-12">
            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <span class="text-muted small">
                    <?= Lang::isRtl() ? 'إجمالي النتائج:' : 'Total Venues:' ?> <strong class="text-dark-green"><?= $totalHalls ?></strong> <?= Lang::isRtl() ? 'قاعة وقصر معتمد' : 'venues' ?>
                    <?php if ($totalPages > 1): ?>
                        - <?= Lang::isRtl() ? 'صفحة ' . $page . ' من ' . $totalPages : 'Page ' . $page . ' of ' . $totalPages ?>
                    <?php endif; ?>
                </span>
            </div>

            <?php if (!empty($halls)): ?>
                <div class="row g-4">
                    <?php foreach ($halls as $hall): ?>
                        <div class="col-md-6 col-12">
                            <div class="hall-card h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <div class="hall-card-img-wrap">
                                        <?php if ($hall['featured']): ?>
                                            <span class="badge-featured">
                                                <i class="bi bi-award-fill"></i> <?= Lang::isRtl() ? 'قاعة مميزة' : 'Featured' ?>
                                            </span>
                                        <?php endif; ?>
                                        <span class="badge-city">
                                            <i class="bi bi-geo-alt"></i> <?= e(getCityName($hall['city'])) ?>
                                        </span>

                                        <?php if (!empty($targetDate)): ?>
                                            <?php if ($hall['is_booked_on_date'] > 0): ?>
                                                <span class="badge bg-danger position-absolute" style="top: 10px; left: 10px; z-index: 2;">
                                                    <i class="bi bi-x-circle-fill me-1"></i> <?= Lang::isRtl() ? 'محجوز بهذا التاريخ' : 'Booked on Date' ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-success position-absolute" style="top: 10px; left: 10px; z-index: 2;">
                                                    <i class="bi bi-check-circle-fill me-1"></i> <?= Lang::isRtl() ? 'متاح في تاريخك' : 'Available on Date' ?>
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <img src="<?= e($hall['primary_image'] ?: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80') ?>" alt="<?= e($hall['name_ar']) ?>" class="hall-card-img" loading="lazy">
                                    </div>
                                    <div class="hall-card-body pb-0">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="badge bg-light text-dark-green border small">
                                                <?= e(getOccasionTypeName($hall['hall_type'])) ?>
                                            </span>
                                            <span class="text-gold small fw-bold">
                                                <i class="bi bi-star-fill"></i> <?= number_format($hall['rating'], 1) ?> (<?= $hall['reviews_count'] ?>)
                                            </span>
                                        </div>
                                        <h3 class="hall-card-title"><?= e($hall['name_ar']) ?></h3>
                                        <div class="hall-location">
                                            <i class="bi bi-pin-map-fill text-danger"></i>
                                            <span class="text-truncate"><?= e($hall['address']) ?></span>
                                        </div>

                                        <p class="text-muted small mb-3" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                            <?= e($hall['description_ar']) ?>
                                        </p>

                                        <!-- Facilities Icons -->
                                        <?php if (!empty($hallAmenitiesMap[$hall['id']])): ?>
                                            <div class="d-flex flex-wrap gap-2 mb-3">
                                                <?php foreach (array_slice($hallAmenitiesMap[$hall['id']], 0, 3) as $am): ?>
                                                    <span class="facility-badge">
                                                        <i class="bi <?= e($am['icon']) ?>"></i>
                                                        <span><?= e($am['name_ar']) ?></span>
                                                    </span>
                                                <?php endforeach; ?>
                                                <?php if (count($hallAmenitiesMap[$hall['id']]) > 3): ?>
                                                    <span class="facility-badge text-muted">
                                                        +<?= count($hallAmenitiesMap[$hall['id']]) - 3 ?> <?= Lang::isRtl() ? 'مرافق إضافية' : 'more' ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                        <div class="d-flex flex-wrap gap-2 mb-3">
                                            <span class="hall-meta-pill">
                                                <i class="bi bi-people"></i> <?= $hall['capacity_min'] ?> - <?= $hall['capacity_max'] ?> <?= e(__('guest')) ?>
                                            </span>
                                            <span class="hall-meta-pill">
                                                <i class="bi bi-sun"></i> <?= formatMoney($hall['price_morning'], $hall['currency']) ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="hall-card-body pt-0">
                                    <div class="hall-price-box mt-2">
                                        <div>
                                            <div class="text-muted" style="font-size: 0.75rem;"><?= Lang::isRtl() ? 'المسائي يبدأ من' : 'Evening from' ?></div>
                                            <div class="hall-price-val">
                                                <?= formatMoney($hall['price_evening'], $hall['currency']) ?>
                                            </div>
                                        </div>
                                        <div class="d-flex gap-1">
                                            <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $hall['id'] ?>" class="btn btn-sm btn-outline-dark-green">
                                                <?= e(__('view_details')) ?>
                                            </a>
                                            <a href="<?= BASE_URL ?>/inquiry.php?hall_id=<?= $hall['id'] ?>&date=<?= urlencode($targetDate) ?>" class="btn btn-sm btn-gold">
                                                <i class="bi bi-calendar2-check"></i> <?= Lang::isRtl() ? 'حجز' : 'Book' ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination Controls -->
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Catalog pagination" class="my-5">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= buildCatalogPageUrl($page - 1) ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo; <?= Lang::isRtl() ? 'السابق' : 'Prev' ?></span>
                                </a>
                            </li>
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= buildCatalogPageUrl($i) ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= buildCatalogPageUrl($page + 1) ?>" aria-label="Next">
                                    <span aria-hidden="true"><?= Lang::isRtl() ? 'التالي' : 'Next' ?> &raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>

            <?php else: ?>
                <div class="text-center py-5 bg-white rounded-3 border">
                    <i class="bi bi-search text-muted fs-1 mb-2 d-block"></i>
                    <h5 class="fw-bold text-dark-green"><?= Lang::isRtl() ? 'لم يتم العثور على قاعات تطابق الفلتر' : 'No venues matching criteria' ?></h5>
                    <p class="text-muted small mb-3"><?= Lang::isRtl() ? 'جرب تخفيف شروط البحث أو إزالة بعض المرافق.' : 'Try adjusting your search criteria.' ?></p>
                    <a href="<?= BASE_URL ?>/halls.php" class="btn btn-sm btn-gold"><?= Lang::isRtl() ? 'عرض جميع القاعات' : 'View all venues' ?></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
