<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Frequently Asked Questions (FAQ)
 */

$page_title = 'الأسئلة الشائعة | كل ما تود معرفته عن حجز القاعات';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero Header -->
<section class="py-5 text-white" style="background: linear-gradient(135deg, var(--dark-green) 0%, var(--dark-green-hover) 100%); border-bottom: 3px solid var(--gold-primary);">
    <div class="container text-center py-3">
        <span class="badge bg-gold text-white px-3 py-2 rounded-pill fw-bold mb-3 shadow-sm">
            <i class="bi bi-patch-question me-1 ms-1"></i> <?= Lang::isRtl() ? 'إجابات واضحة ومباشرة' : 'Clear Answers' ?>
        </span>
        <h1 class="display-6 fw-bold text-white mb-2"><?= Lang::isRtl() ? 'الأسئلة الأكثر شيوعاً' : 'Frequently Asked Questions' ?></h1>
        <p class="text-white-50 mx-auto small fs-6" style="max-width: 650px;">
            <?= Lang::isRtl() 
                ? 'جمعنا لك أهم التساؤلات حول طريقة البحث، تأكيد مواعيد الحجز، سياسة دفع العربون، والضمانات التي توفرها منصة إيوان لجميع الأطراف.' 
                : 'Everything you need to know about venue discovery, booking steps, deposits, and safety guarantees.' ?>
        </p>
    </div>
</section>

<div class="container py-5">
    <div class="row justify-content-center mb-4">
        <div class="col-lg-8 col-12">
            <!-- FAQ Search Bar -->
            <div class="input-group shadow-sm rounded-pill overflow-hidden border">
                <span class="input-group-text bg-white border-0 ps-3 text-gold fs-5"><i class="bi bi-search"></i></span>
                <input type="text" id="faqSearch" class="form-control border-0 py-3 shadow-none" placeholder="<?= Lang::isRtl() ? 'ابحث في الأسئلة (مثال: العربون، التكييف، الإلغاء، المولدات)...' : 'Search questions (e.g. deposit, generator, cancellation)...' ?>">
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-9 col-12">
            
            <!-- Category 1: Booking & Reservation -->
            <div class="mb-5 faq-section">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-wrapper" style="width: 36px; height: 36px; font-size: 1.1rem;">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                    <h3 class="h5 fw-bold text-dark-green mb-0"><?= Lang::isRtl() ? '1. حجز القاعات والمواعيد' : '1. Booking & Schedules' ?></h3>
                </div>

                <div class="accordion shadow-sm rounded-3 overflow-hidden" id="accordionBooking">
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqB1">
                                <?= Lang::isRtl() ? 'كيف يمكنني التأكد من أن القاعة شاغرة في تاريخ مناسبتي؟' : 'How do I check if a venue is available on my date?' ?>
                            </button>
                        </h2>
                        <div id="faqB1" class="accordion-collapse collapse" data-bs-parent="#accordionBooking">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'يمكنك إدخال تاريخ مناسبتك مباشرة في شريط البحث في الصفحة الرئيسية أو دليل القاعات. يعرض النظام تلقائياً القاعات المتوفرة في ذلك التاريخ، كما يمكنك الاطلاع على جدول الفترات (صباحية ومسائية) في صفحة كل قاعة وإرسال طلب استفسار فوري لإدارة القاعة لتأكيد الموعد.'
                                    : 'You can enter your event date in the search bar. The system will filter available venues. You can also view morning and evening slot details on the hall page and send an inquiry.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqB2">
                                <?= Lang::isRtl() ? 'هل يمكنني زيارة القاعة ومعاينتها قبل إتمام الحجز؟' : 'Can I inspect the venue in person before booking?' ?>
                            </button>
                        </h2>
                        <div id="faqB2" class="accordion-collapse collapse" data-bs-parent="#accordionBooking">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'نعم بكل تأكيد! نحن نشجع جميع العرسان والعائلات على زيارة القاعة. عند تقديم طلب استفسار عبر المنصة، يتم تزويدك بأرقام إدارة القاعة وموقعها الجغرافي الدقيق لتنسيق موعد معاينة ميداني بصحبة مدير الصالة.'
                                    : 'Absolutely! We encourage visiting the venue. When submitting an inquiry, you will receive direct contact details and location to coordinate a site tour with hall management.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqB3">
                                <?= Lang::isRtl() ? 'ما الفرق بين حجز الفترة الصباحية والفترة المسائية؟' : 'What is the difference between morning and evening shifts?' ?>
                            </button>
                        </h2>
                        <div id="faqB3" class="accordion-collapse collapse" data-bs-parent="#accordionBooking">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'الفترة الصباحية مخصصة عادة لحفلات التخرج، الندوات، والمؤتمرات (من 8:00 صباحاً حتى 2:00 ظهراً) وتكون بتكلفة أقل. بينما الفترة المسائية مخصصة لحفلات الأعراس والزفاف الكبرى (من 4:00 عصراً حتى منتصف الليل) وتتضمن كامل خدمات الزفة والإضاءة وكوشة العروس.'
                                    : 'Morning shifts are typically for graduation ceremonies and conferences (8 AM - 2 PM), with lower pricing. Evening shifts are for wedding banquets and galas (4 PM - midnight) including full lighting and bridal arrangements.' ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category 2: Pricing, Deposit & Cancellation -->
            <div class="mb-5 faq-section">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-wrapper" style="width: 36px; height: 36px; font-size: 1.1rem;">
                        <i class="bi bi-currency-dollar"></i>
                    </div>
                    <h3 class="h5 fw-bold text-dark-green mb-0"><?= Lang::isRtl() ? '2. الأسعار، العربون، وسياسة الإلغاء' : '2. Pricing, Deposits & Cancellations' ?></h3>
                </div>

                <div class="accordion shadow-sm rounded-3 overflow-hidden" id="accordionPricing">
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqP1">
                                <?= Lang::isRtl() ? 'هل الأسعار المعروضة في المنصة نهائية أم قابلة للتفاوض؟' : 'Are prices shown on the platform final?' ?>
                            </button>
                        </h2>
                        <div id="faqP1" class="accordion-collapse collapse" data-bs-parent="#accordionPricing">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'الأسعار المعروضة هي الأسعار الرسمية المعتمدة من إدارة كل قاعة وتوضح ما تشمله الباقة الأساسية. كما توفر بعض القاعات باقات مخفضة لمناسبات وسط الأسبوع (الأحد إلى الأربعاء) أو عروضاً موسمية يمكنك مناقشتها مباشرة مع إدارة الصالة.'
                                    : 'Listed rates are the official prices approved by hall management. Mid-week discounts and seasonal promotional packages are often available upon inquiry.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqP2">
                                <?= Lang::isRtl() ? 'كم يبلغ مبلغ العربون المطلوب لتثبيت حجز القاعة؟' : 'How much deposit is required to confirm booking?' ?>
                            </button>
                        </h2>
                        <div id="faqP2" class="accordion-collapse collapse" data-bs-parent="#accordionPricing">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'يحدد مالك كل قاعة نسبة العربون، والتي تتراوح عادة بين 25% إلى 50% من إجمالي قيمة العقد لتثبيت التاريخ نهائياً في سجلات القاعة، ويتم سداد المبلغ المتبقي قبل موعد المناسبة بيومين أو بحسب بنود العقد المبرم.'
                                    : 'Deposits typically range between 25% to 50% to secure the reservation on the venue calendar, with the remaining balance due before event day according to contract terms.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqP3">
                                <?= Lang::isRtl() ? 'ما هي سياسة استرجاع العربون أو تأجيل الموعد؟' : 'What is the refund and rescheduling policy?' ?>
                            </button>
                        </h2>
                        <div id="faqP3" class="accordion-collapse collapse" data-bs-parent="#accordionPricing">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'في حال رغبة العميل بتأجيل الموعد قبل 30 يوماً على الأقل من تاريخ المناسبة، يتاح ترحيل الحجز لتاريخ شاغر آخر دون خصم رسوم. أما في حال الإلغاء النهائي فتحكمه سياسة الإلغاء المنصوص عليها في العقد المبرم والموضحة في صفحة كل قاعة.'
                                    : 'Rescheduling is usually permitted at least 30 days prior without penalty, subject to open dates. Cancellation refunds adhere to individual venue contract terms published on each hall details page.' ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category 3: Quality Guarantees & Generators -->
            <div class="mb-5 faq-section">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-wrapper" style="width: 36px; height: 36px; font-size: 1.1rem;">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h3 class="h5 fw-bold text-dark-green mb-0"><?= Lang::isRtl() ? '3. معايير الجودة، التكييف، والمولدات' : '3. Quality Standards, AC & Power' ?></h3>
                </div>

                <div class="accordion shadow-sm rounded-3 overflow-hidden" id="accordionQuality">
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqQ1">
                                <?= Lang::isRtl() ? 'هل توفر القاعات مولدات كهربائية تضمن عدم انقطاع التيار؟' : 'Do venues guarantee continuous backup power?' ?>
                            </button>
                        </h2>
                        <div id="faqQ1" class="accordion-collapse collapse" data-bs-parent="#accordionQuality">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'نعم، تشترط منصة إيوان على جميع القاعات والقصور المعتمدة توفير مولدات كهرباء ديزل صناعية تعمل بنظام التحويل التلقائي (ATS) لضمان استمرار الإضاءة والتكييف والصوتيات دون أي انقطاع طوال فترة الاحتفال.'
                                    : 'Yes, our platform mandates that all verified halls maintain backup industrial diesel generators with automatic transfer switches (ATS) for uninterrupted lighting, climate control, and audio.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqQ2">
                                <?= Lang::isRtl() ? 'هل تتضمن القاعات طاقم حراسة ومشرفات صالة نسائية؟' : 'Do halls include female hostesses and security?' ?>
                            </button>
                        </h2>
                        <div id="faqQ2" class="accordion-collapse collapse" data-bs-parent="#accordionQuality">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'نعم، توفر معظم صالات الأعراس طاقماً متخصصاً من المشرفات لحفظ النظام، الإشراف على الضيافة، ومنع التصوير بالهواتف في الأعراس النسائية لضمان الخصوصية التامة، بالإضافة لحراسة أمنية خارجية للمواقف.'
                                    : 'Yes, venues feature professional female event coordinators to manage hospitality and enforce photo privacy policies in women celebrations, in addition to exterior security staff.' ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category 4: For Venue Owners -->
            <div class="mb-5 faq-section">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-wrapper" style="width: 36px; height: 36px; font-size: 1.1rem;">
                        <i class="bi bi-building"></i>
                    </div>
                    <h3 class="h5 fw-bold text-dark-green mb-0"><?= Lang::isRtl() ? '4. لأصحاب القاعات والقصور' : '4. For Venue & Palace Owners' ?></h3>
                </div>

                <div class="accordion shadow-sm rounded-3 overflow-hidden" id="accordionOwners">
                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqO1">
                                <?= Lang::isRtl() ? 'كيف يمكنني كمالك قاعة تسجيل صالتي في المنصة؟' : 'How can I register my hall on the platform?' ?>
                            </button>
                        </h2>
                        <div id="faqO1" class="accordion-collapse collapse" data-bs-parent="#accordionOwners">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'يمكنك التوجه مباشرة إلى صفحة <a href="' . BASE_URL . '/register.php?role=hall_owner" class="text-gold fw-bold text-decoration-none">تسجيل مالك قاعة</a>، وإدخال بياناتك واسم منشأتك. بعد إنشاء الحساب، يتاح لك إضافة صور القاعة، مرافقها، أسعار الفترات، وتلقي استفسارات العملاء فوراً.'
                                    : 'Navigate to the Hall Owner Registration page, submit your business information. You can then upload photos, set pricing, define amenities, and receive booking inquiries directly.' ?>
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item border mb-2 rounded-3">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold text-dark-green" type="button" data-bs-toggle="collapse" data-bs-target="#faqO2">
                                <?= Lang::isRtl() ? 'هل توجد اشتراكات أو رسوم شهرية على أصحاب القاعات؟' : 'Are there monthly subscriptions or fees for hall owners?' ?>
                            </button>
                        </h2>
                        <div id="faqO2" class="accordion-collapse collapse" data-bs-parent="#accordionOwners">
                            <div class="accordion-body text-secondary small leading-relaxed">
                                <?= Lang::isRtl() 
                                    ? 'توفر المنصة باقة تسجيل مجانية أساسية تتيح لأي قاعة الظهور واستقبال الطلبات، بالإضافة إلى باقات تسويقية ذهبية وماسية اختيارية لأصحاب القاعات الراغبين في تمييز قاعاتهم في الصفحة الرئيسية وتكثيف حملات الترويج.'
                                    : 'A free basic plan is available for all registered venues to receive inquiries, alongside optional VIP premium packages for featured homepage promotions.' ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Still have questions? -->
            <div class="p-4 rounded-3 border bg-white shadow-sm text-center">
                <h4 class="h5 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'لم تجد إجابة لسؤالك؟' : 'Didn\'t find what you are looking for?' ?></h4>
                <p class="text-muted small mb-3"><?= Lang::isRtl() ? 'فريق خدمة العملاء جاهز للإجابة على جميع استفساراتك وتقديم المساعدة المجانية.' : 'Our customer support team is ready to assist you anytime.' ?></p>
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <a href="<?= BASE_URL ?>/contact.php" class="btn btn-gold">
                        <i class="bi bi-headset me-1 ms-1"></i> <?= Lang::isRtl() ? 'تواصل مع الدعم الفني' : 'Contact Support' ?>
                    </a>
                    <a href="https://wa.me/967770000001" target="_blank" class="btn btn-outline-success">
                        <i class="bi bi-whatsapp me-1 ms-1"></i> <?= Lang::isRtl() ? 'واتساب مباشر' : 'WhatsApp Us' ?>
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('faqSearch');
    if (!searchInput) return;

    searchInput.addEventListener('input', function () {
        const query = this.value.trim().toLowerCase();
        const items = document.querySelectorAll('.accordion-item');
        const sections = document.querySelectorAll('.faq-section');

        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            if (text.includes(query)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });

        // Hide empty sections
        sections.forEach(sec => {
            const visibleItems = sec.querySelectorAll('.accordion-item:not([style*="display: none"])');
            sec.style.display = visibleItems.length > 0 ? '' : 'none';
        });
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
