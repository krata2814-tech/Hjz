<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * User Registration (Customers and Hall Owners ONLY)
 * Note: Super Admin can NEVER be registered through this public endpoint.
 */

$page_title = 'إنشاء حساب جديد';
require_once __DIR__ . '/includes/auth.php';

if (Auth::check()) {
    redirect(Auth::isSuperAdmin() ? (BASE_URL . '/admin/index.php') : (BASE_URL . '/dashboard.php'));
}

$error = null;
$preselectedRole = get('role', 'customer');
if (!in_array($preselectedRole, ['customer', 'hall_owner'])) {
    $preselectedRole = 'customer';
}

if (isPost()) {
    CSRF::verifyOrDie();
    $name = sanitize(post('name'));
    $email = strtolower(sanitize(post('email')));
    $phone = sanitize(post('phone'));
    $submittedRole = sanitize(post('role', 'customer'));
    $businessName = sanitize(post('business_name'));
    $password = post('password', '');
    $passwordConfirm = post('password_confirm', '');

    // Strictly enforce that public registration only permits customer or hall_owner
    $roleSlug = in_array($submittedRole, ['customer', 'hall_owner']) ? $submittedRole : 'customer';

    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'يرجى ملء جميع الحقول المطلوبة.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'يرجى إدخال عنوان بريد إلكتروني صحيح.';
    } elseif (strlen($password) < 8) {
        $error = 'يجب ألا تقل كلمة المرور عن 8 أحرف وأرقام لضمان الأمان.';
    } elseif ($password !== $passwordConfirm) {
        $error = 'كلمتا المرور غير متطابقتين.';
    } elseif ($roleSlug === 'hall_owner' && empty($businessName)) {
        $error = 'يرجى إدخال الاسم التجاري أو اسم المنشأة / القاعة لمالك القاعة.';
    } else {
        $existing = Database::fetchOne("SELECT id FROM users WHERE email = ? LIMIT 1", [$email]);
        if ($existing) {
            $error = 'هذا البريد الإلكتروني مسجل بالفعل، يرجى تسجيل الدخول.';
        } else {
            try {
                // Fetch role ID from database
                $roleRow = Database::fetchOne("SELECT id FROM roles WHERE slug = ? LIMIT 1", [$roleSlug]);
                $roleId = (int)($roleRow['id'] ?? ($roleSlug === 'hall_owner' ? 2 : 3));

                $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

                Database::transaction(function (PDO $pdo) use ($roleId, $roleSlug, $name, $email, $phone, $passwordHash, $businessName) {
                    // 1. Insert user
                    $stmt = $pdo->prepare("
                        INSERT INTO users (role_id, name, email, phone, password_hash, status, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ");
                    $stmt->execute([$roleId, $name, $email, $phone, $passwordHash]);
                    $userId = (int)$pdo->lastInsertId();

                    // 2. Insert profile according to role
                    if ($roleSlug === 'hall_owner') {
                        $profStmt = $pdo->prepare("
                            INSERT INTO owner_profiles (user_id, business_name, is_verified, created_at, updated_at)
                            VALUES (?, ?, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                        ");
                        $profStmt->execute([$userId, $businessName ?: $name]);
                    } else {
                        $profStmt = $pdo->prepare("
                            INSERT INTO customer_profiles (user_id, created_at, updated_at)
                            VALUES (?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                        ");
                        $profStmt->execute([$userId]);
                    }

                    // 3. Auto login user securely
                    $userObj = [
                        'id' => $userId,
                        'name' => $name,
                        'email' => $email,
                        'role_id' => $roleId,
                        'role_slug' => $roleSlug,
                    ];
                    Auth::establishSession($userObj);
                });

                setFlash('success', 'تم إنشاء حسابك بنجاح! أهلاً بك في منصة قاعات الأفراح.');
                redirect(BASE_URL . '/dashboard.php');
            } catch (Exception $e) {
                $error = 'حدث خطأ أثناء إنشاء الحساب: ' . $e->getMessage();
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<div class="container py-4 py-md-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8 col-12">
            <div class="card border rounded-3 shadow-sm p-4 p-md-5 bg-white">
                <div class="text-center mb-4">
                    <div class="brand-icon-wrapper mx-auto mb-3" style="width: 52px; height: 52px; font-size: 1.5rem;">
                        <i class="bi bi-person-plus-fill"></i>
                    </div>
                    <h2 class="h4 fw-bold text-dark-green"><?= e(__('register')) ?></h2>
                    <p class="text-muted small"><?= Lang::isRtl() ? 'انضم إلى منصة إيوان كعميل أو كمالك صالة مناسبات' : 'Join as a customer or venue owner' ?></p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger py-2 small shadow-sm rounded-3"><?= e($error) ?></div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/register.php" method="POST" class="needs-validation" novalidate id="registerForm">
                    <?= CSRF::getFormField() ?>

                    <!-- Account Type Selection -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'نوع الحساب' : 'Account Type' ?></label>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="border rounded-3 p-3 d-block text-center cursor-pointer h-100 <?= ($preselectedRole === 'customer') ? 'border-gold bg-light' : '' ?>" style="cursor: pointer;">
                                    <input type="radio" name="role" value="customer" <?= ($preselectedRole === 'customer') ? 'checked' : '' ?> class="form-check-input me-1" onchange="toggleOwnerFields(this.value)">
                                    <span class="d-block fw-bold small text-dark-green mt-1"><?= e(__('role_customer')) ?></span>
                                    <small class="text-muted" style="font-size: 0.72rem;"><?= Lang::isRtl() ? 'للبحث وحجز القاعات' : 'To book & inquire' ?></small>
                                </label>
                            </div>
                            <div class="col-6">
                                <label class="border rounded-3 p-3 d-block text-center cursor-pointer h-100 <?= ($preselectedRole === 'hall_owner') ? 'border-gold bg-light' : '' ?>" style="cursor: pointer;">
                                    <input type="radio" name="role" value="hall_owner" <?= ($preselectedRole === 'hall_owner') ? 'checked' : '' ?> class="form-check-input me-1" onchange="toggleOwnerFields(this.value)">
                                    <span class="d-block fw-bold small text-dark-green mt-1"><?= e(__('role_hall_owner')) ?></span>
                                    <small class="text-muted" style="font-size: 0.72rem;"><?= Lang::isRtl() ? 'لإدارة القاعات والأسعار' : 'To manage halls' ?></small>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('full_name')) ?> *</label>
                        <input type="text" name="name" class="form-control" placeholder="مثال: أحمد عبد الله اليماني" value="<?= e(post('name')) ?>" required>
                    </div>

                    <!-- Business Name (Only if Hall Owner) -->
                    <div class="mb-3" id="businessNameGroup" style="display: <?= ($preselectedRole === 'hall_owner') ? 'block' : 'none' ?>;">
                        <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'الاسم التجاري للمنشأة / القاعة' : 'Business / Hall Name' ?> *</label>
                        <input type="text" name="business_name" id="businessNameInput" class="form-control" placeholder="مثال: قصر الفخامة للأفراح" value="<?= e(post('business_name')) ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('email')) ?> *</label>
                        <input type="email" name="email" class="form-control" placeholder="user@example.com" value="<?= e(post('email')) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark-green"><?= e(__('phone')) ?> (واتساب) *</label>
                        <input type="tel" name="phone" class="form-control" placeholder="+967 77..." value="<?= e(post('phone')) ?>" required>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green"><?= e(__('password')) ?> * (8 أحرف كحد أدنى)</label>
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required minlength="8">
                        </div>
                        <div class="col-md-6 col-12">
                            <label class="form-label small fw-bold text-dark-green"><?= Lang::isRtl() ? 'تأكيد كلمة المرور' : 'Confirm Password' ?> *</label>
                            <input type="password" name="password_confirm" class="form-control" placeholder="••••••••" required minlength="8">
                        </div>
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" id="terms" required checked>
                        <label class="form-check-label small text-muted" for="terms">
                            <?= Lang::isRtl() ? 'أوافق على شروط الاستخدام وسياسة خصوصية المنصة' : 'I agree to the terms and privacy policy' ?>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-gold w-100 py-2 fw-bold">
                        <i class="bi bi-person-check-fill me-1 ms-1"></i> <?= e(__('register')) ?>
                    </button>
                </form>

                <div class="text-center mt-4">
                    <p class="small text-muted mb-0">
                        <?= e(__('already_have_account')) ?> 
                        <a href="<?= BASE_URL ?>/login.php" class="text-gold fw-bold"><?= e(__('login')) ?></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleOwnerFields(role) {
    var grp = document.getElementById('businessNameGroup');
    if (role === 'hall_owner') {
        grp.style.display = 'block';
    } else {
        grp.style.display = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
