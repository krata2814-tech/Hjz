-- ============================================================================
-- Wedding & Event Halls Booking Platform
-- منصة حجز قاعات الأفراح والمناسبات
-- Database Schema for MySQL / MariaDB (XAMPP & Shared Hosting)
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `wedding_halls_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `wedding_halls_db`;

-- Drop existing tables in reverse dependency order
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `platform_settings`;
DROP TABLE IF EXISTS `hall_employees`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `inquiry_replies`;
DROP TABLE IF EXISTS `inquiries`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `hall_packages`;
DROP TABLE IF EXISTS `hall_amenities`;
DROP TABLE IF EXISTS `amenities`;
DROP TABLE IF EXISTS `hall_images`;
DROP TABLE IF EXISTS `halls`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table (Administrators, Hall Owners, Customers, Employees)
CREATE TABLE `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(30) NOT NULL,
    `role` ENUM('admin', 'hall_owner', 'customer', 'employee') NOT NULL DEFAULT 'customer',
    `status` ENUM('active', 'pending', 'suspended') NOT NULL DEFAULT 'active',
    `avatar` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_role` (`role`),
    INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Venues & Halls Table
CREATE TABLE `halls` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `owner_id` INT UNSIGNED NOT NULL,
    `name_ar` VARCHAR(191) NOT NULL,
    `name_en` VARCHAR(191) NULL,
    `slug` VARCHAR(191) NOT NULL UNIQUE,
    `description_ar` TEXT NOT NULL,
    `description_en` TEXT NULL,
    `city` VARCHAR(50) NOT NULL,
    `address` VARCHAR(255) NOT NULL,
    `map_lat` DECIMAL(10, 8) NULL,
    `map_lng` DECIMAL(11, 8) NULL,
    `capacity_min` INT UNSIGNED NOT NULL DEFAULT 100,
    `capacity_max` INT UNSIGNED NOT NULL DEFAULT 800,
    `price_morning` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `price_evening` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `price_full_day` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `hall_type` ENUM('wedding', 'engagement', 'graduation', 'conference', 'family', 'multi_purpose') NOT NULL DEFAULT 'wedding',
    `featured` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('active', 'pending_approval', 'maintenance') NOT NULL DEFAULT 'active',
    `rating` DECIMAL(3, 2) NOT NULL DEFAULT 5.00,
    `reviews_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_halls_city` (`city`),
    INDEX `idx_halls_type` (`hall_type`),
    INDEX `idx_halls_status` (`status`),
    INDEX `idx_halls_featured` (`featured`),
    CONSTRAINT `fk_halls_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Hall Images Gallery
CREATE TABLE `hall_images` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `image_url` VARCHAR(255) NOT NULL,
    `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
    `caption` VARCHAR(150) NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_images_hall` (`hall_id`),
    CONSTRAINT `fk_images_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Amenities Master Table
CREATE TABLE `amenities` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name_ar` VARCHAR(100) NOT NULL,
    `name_en` VARCHAR(100) NOT NULL,
    `icon` VARCHAR(50) NOT NULL DEFAULT 'bi-stars',
    `category` VARCHAR(50) NOT NULL DEFAULT 'general'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Hall Amenities Mapping
CREATE TABLE `hall_amenities` (
    `hall_id` INT UNSIGNED NOT NULL,
    `amenity_id` INT UNSIGNED NOT NULL,
    `details` VARCHAR(255) NULL,
    PRIMARY KEY (`hall_id`, `amenity_id`),
    CONSTRAINT `fk_ha_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ha_amenity` FOREIGN KEY (`amenity_id`) REFERENCES `amenities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Hall Service Packages & Offers
CREATE TABLE `hall_packages` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `title_ar` VARCHAR(150) NOT NULL,
    `title_en` VARCHAR(150) NULL,
    `description_ar` TEXT NULL,
    `price` DECIMAL(12, 2) NOT NULL,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `included_services` TEXT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_packages_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Bookings Table
CREATE TABLE `bookings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `booking_code` VARCHAR(30) NOT NULL UNIQUE,
    `hall_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED NOT NULL,
    `package_id` INT UNSIGNED NULL,
    `event_date` DATE NOT NULL,
    `shift` ENUM('morning', 'evening', 'full_day') NOT NULL DEFAULT 'evening',
    `guest_count` INT UNSIGNED NOT NULL DEFAULT 200,
    `total_amount` DECIMAL(12, 2) NOT NULL,
    `deposit_amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `currency` VARCHAR(10) NOT NULL DEFAULT 'YER',
    `status` ENUM('pending', 'confirmed', 'cancelled', 'completed') NOT NULL DEFAULT 'pending',
    `payment_status` ENUM('unpaid', 'deposit_paid', 'fully_paid') NOT NULL DEFAULT 'unpaid',
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_bookings_date` (`event_date`),
    INDEX `idx_bookings_status` (`status`),
    INDEX `idx_bookings_shift` (`shift`),
    CONSTRAINT `fk_bookings_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bookings_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_bookings_package` FOREIGN KEY (`package_id`) REFERENCES `hall_packages` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Customer Inquiries Table
CREATE TABLE `inquiries` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NULL,
    `sender_name` VARCHAR(150) NOT NULL,
    `sender_phone` VARCHAR(30) NOT NULL,
    `sender_email` VARCHAR(191) NULL,
    `event_type` VARCHAR(50) NOT NULL DEFAULT 'wedding',
    `event_date` DATE NULL,
    `guest_estimate` INT UNSIGNED NULL,
    `message` TEXT NOT NULL,
    `status` ENUM('new', 'replied', 'closed') NOT NULL DEFAULT 'new',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_inquiries_hall` (`hall_id`),
    INDEX `idx_inquiries_status` (`status`),
    CONSTRAINT `fk_inquiries_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_inquiries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Inquiry Replies Table
CREATE TABLE `inquiry_replies` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `inquiry_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `reply_message` TEXT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ir_inquiry` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiries` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ir_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Reviews & Ratings Table
CREATE TABLE `reviews` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `customer_id` INT UNSIGNED NOT NULL,
    `booking_id` INT UNSIGNED NULL,
    `rating` TINYINT UNSIGNED NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
    `comment` TEXT NOT NULL,
    `status` ENUM('approved', 'pending', 'rejected') NOT NULL DEFAULT 'approved',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_reviews_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_reviews_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Hall Employees Table
CREATE TABLE `hall_employees` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `hall_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `job_title` VARCHAR(100) NOT NULL,
    `permissions` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_he_hall` FOREIGN KEY (`hall_id`) REFERENCES `halls` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_he_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Platform Settings Table
CREATE TABLE `platform_settings` (
    `setting_key` VARCHAR(100) PRIMARY KEY,
    `setting_value` TEXT NOT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
