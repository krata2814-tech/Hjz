<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Database Initializer & Migration Helper
 * Supports MySQL / MariaDB and SQLite for local environments
 */

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

/**
 * Check if a Super Admin user already exists in the database
 */
function hasSuperAdmin(): bool {
    try {
        $pdo = Database::getInstance();
        $row = Database::fetchOne("
            SELECT COUNT(*) as count 
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE r.slug = 'super_admin' AND u.status = 'active'
        ");
        return (int)($row['count'] ?? 0) > 0;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Register the Initial Super Administrator safely inside an ACID transaction
 */
function createFirstSuperAdmin(array $data): array {
    $lockFile = dirname(__DIR__) . '/config/installed.lock';

    // 1. Strict check: Lock file or existing Super Admin
    if (file_exists($lockFile) || hasSuperAdmin()) {
        return [
            'success' => false,
            'error' => 'عذراً، تم تسجيل وتثبيت المدير العام للنظام مسبقاً. عملية التثبيت مقفلة لأسباب أمنية.'
        ];
    }

    $name = trim($data['name'] ?? '');
    $email = strtolower(trim($data['email'] ?? ''));
    $phone = trim($data['phone'] ?? '');
    $password = $data['password'] ?? '';
    $passwordConfirm = $data['password_confirm'] ?? '';

    // 2. Validate inputs
    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        return ['success' => false, 'error' => 'يرجى ملء جميع الحقول المطلوبة للمدير العام.'];
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'error' => 'يرجى إدخال بريد إلكتروني صالح للمدير العام.'];
    }

    if (strlen($password) < 8) {
        return ['success' => false, 'error' => 'يجب ألا تقل كلمة المرور عن 8 أحرف وأرقام لضمان أمان المدير العام.'];
    }

    if ($password !== $passwordConfirm) {
        return ['success' => false, 'error' => 'كلمتا المرور غير متطابقتين.'];
    }

    // 3. Execute in atomic transaction with race-condition prevention
    try {
        $result = Database::transaction(function (PDO $pdo) use ($name, $email, $phone, $password, $lockFile) {
            // Find super_admin role ID
            $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE slug = 'super_admin' LIMIT 1");
            $roleStmt->execute();
            $role = $roleStmt->fetch();

            if (!$role) {
                throw new Exception("تعذر العثور على دور 'super_admin' في جدول الأدوار.");
            }
            $superAdminRoleId = (int)$role['id'];

            // Double check no admin was created in concurrent race
            $checkStmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM users WHERE role_id = ?");
            $checkStmt->execute([$superAdminRoleId]);
            $existingAdmin = $checkStmt->fetch();
            if ((int)($existingAdmin['cnt'] ?? 0) > 0) {
                throw new Exception("تم إنشاء حساب مدير عام للنظام من قبل مستخدم آخر بالفعل.");
            }

            // Check if email already used
            $emailStmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $emailStmt->execute([$email]);
            if ($emailStmt->fetch()) {
                throw new Exception("البريد الإلكتروني المدخل مسجل بالفعل.");
            }

            // Hash password with bcrypt cost 12
            $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            // Insert Super Admin
            $insertStmt = $pdo->prepare("
                INSERT INTO users (role_id, name, email, phone, password_hash, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ");
            $insertStmt->execute([$superAdminRoleId, $name, $email, $phone, $passwordHash]);
            $adminId = $pdo->lastInsertId();

            // Record security audit log
            $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? 'CLI', 0, 255);
            $auditStmt = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details_json, ip_address, user_agent)
                VALUES (?, 'setup_super_admin', 'users', ?, ?, ?, ?)
            ");
            $auditDetails = json_encode([
                'event' => 'Initial Super Admin Created',
                'email' => $email,
                'name' => $name,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE);
            $auditStmt->execute([$adminId, $adminId, $auditDetails, $ip, $ua]);

            // Create lock file to permanently prevent future installer execution
            $lockContent = json_encode([
                'installed_at' => date('c'),
                'super_admin_email' => $email,
                'installer_ip' => $ip,
                'platform_version' => APP_VERSION
            ], JSON_PRETTY_PRINT);
            @file_put_contents($lockFile, $lockContent);

            return [
                'id' => $adminId,
                'name' => $name,
                'email' => $email,
                'role' => 'super_admin'
            ];
        });

        return ['success' => true, 'admin' => $result];
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Initialize all database tables and system master data
 */
function initializeDatabase(?string $forceDriver = null): array {
    $results = [];
    $sqlitePath = dirname(__DIR__) . '/database/wedding_halls.sqlite';
    $driver = $forceDriver ?: (getenv('DB_DRIVER') ?: 'sqlite');

    try {
        if ($driver === 'mysql') {
            $pdo = Database::getInstance();
            $results[] = "الاتصال بقاعدة بيانات MySQL نشط.";

            $sql = file_get_contents(dirname(__DIR__) . '/database.sql');
            $pdo->exec($sql);
            $results[] = "تم تنفيذ المخطط الكامل database.sql في MySQL بنجاح.";

            return ['success' => true, 'messages' => $results];
        } else {
            // Setup SQLite with identical relational structure
            if (file_exists($sqlitePath)) {
                @unlink($sqlitePath);
            }
            $pdo = new PDO('sqlite:' . $sqlitePath, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            $pdo->exec("PRAGMA foreign_keys = ON;");
            $results[] = "تم إنشاء ملف SQLite: " . $sqlitePath;

            // 1. Roles & Permissions
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS roles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name_ar TEXT NOT NULL,
                    name_en TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    description TEXT,
                    is_system INTEGER NOT NULL DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS permissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name_ar TEXT NOT NULL,
                    name_en TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    module TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS role_permissions (
                    role_id INTEGER NOT NULL,
                    permission_id INTEGER NOT NULL,
                    PRIMARY KEY (role_id, permission_id),
                    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
                    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    role_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    phone TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active',
                    avatar TEXT,
                    last_login_at DATETIME,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (role_id) REFERENCES roles(id)
                );

                CREATE TABLE IF NOT EXISTS user_permissions (
                    user_id INTEGER NOT NULL,
                    permission_id INTEGER NOT NULL,
                    is_granted INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (user_id, permission_id),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS owner_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL UNIQUE,
                    business_name TEXT NOT NULL,
                    commercial_registration_no TEXT,
                    tax_number TEXT,
                    national_id_number TEXT,
                    id_document_path TEXT,
                    bank_name TEXT,
                    bank_account_number TEXT,
                    bank_iban TEXT,
                    is_verified INTEGER NOT NULL DEFAULT 0,
                    verified_at DATETIME,
                    verified_by INTEGER,
                    notes TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS customer_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL UNIQUE,
                    preferred_city TEXT,
                    wedding_date_estimate TEXT,
                    emergency_phone TEXT,
                    notes TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS halls (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    owner_id INTEGER NOT NULL,
                    name_ar TEXT NOT NULL,
                    name_en TEXT,
                    slug TEXT NOT NULL UNIQUE,
                    description_ar TEXT NOT NULL,
                    description_en TEXT,
                    city TEXT NOT NULL,
                    district TEXT,
                    address TEXT NOT NULL,
                    map_lat REAL,
                    map_lng REAL,
                    capacity_min INTEGER NOT NULL DEFAULT 100,
                    capacity_max INTEGER NOT NULL DEFAULT 800,
                    hall_type TEXT NOT NULL DEFAULT 'wedding',
                    featured INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL DEFAULT 'active',
                    rejection_reason TEXT,
                    rating REAL NOT NULL DEFAULT 5.0,
                    reviews_count INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (owner_id) REFERENCES users(id)
                );

                CREATE TABLE IF NOT EXISTS employee_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL UNIQUE,
                    owner_id INTEGER NOT NULL,
                    hall_id INTEGER,
                    job_title TEXT NOT NULL,
                    department TEXT,
                    hire_date TEXT,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS hall_images (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hall_id INTEGER NOT NULL,
                    image_url TEXT NOT NULL,
                    is_primary INTEGER NOT NULL DEFAULT 0,
                    caption TEXT,
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS facilities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name_ar TEXT NOT NULL,
                    name_en TEXT NOT NULL,
                    icon TEXT NOT NULL DEFAULT 'bi-stars',
                    category TEXT NOT NULL DEFAULT 'comfort',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS hall_facilities (
                    hall_id INTEGER NOT NULL,
                    facility_id INTEGER NOT NULL,
                    details TEXT,
                    is_complimentary INTEGER NOT NULL DEFAULT 1,
                    extra_charge REAL NOT NULL DEFAULT 0.0,
                    PRIMARY KEY (hall_id, facility_id),
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE,
                    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS hall_pricing (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hall_id INTEGER NOT NULL,
                    title_ar TEXT NOT NULL,
                    title_en TEXT,
                    shift TEXT NOT NULL DEFAULT 'evening',
                    day_type TEXT NOT NULL DEFAULT 'all_days',
                    base_price REAL NOT NULL,
                    deposit_required REAL NOT NULL DEFAULT 0.0,
                    currency TEXT NOT NULL DEFAULT 'YER',
                    season TEXT NOT NULL DEFAULT 'regular',
                    valid_from TEXT,
                    valid_to TEXT,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS hall_availability (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hall_id INTEGER NOT NULL,
                    date TEXT NOT NULL,
                    shift TEXT NOT NULL DEFAULT 'evening',
                    status TEXT NOT NULL DEFAULT 'available',
                    booking_id INTEGER,
                    reason TEXT,
                    updated_by INTEGER,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(hall_id, date, shift),
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS subscription_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name_ar TEXT NOT NULL,
                    name_en TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    description TEXT,
                    price REAL NOT NULL DEFAULT 0.0,
                    billing_period_months INTEGER NOT NULL DEFAULT 1,
                    max_halls_allowed INTEGER NOT NULL DEFAULT 1,
                    featured_halls_quota INTEGER NOT NULL DEFAULT 0,
                    commission_rate_percentage REAL NOT NULL DEFAULT 0.0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS owner_subscriptions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    owner_id INTEGER NOT NULL,
                    plan_id INTEGER NOT NULL,
                    starts_at DATETIME NOT NULL,
                    expires_at DATETIME NOT NULL,
                    amount_paid REAL NOT NULL,
                    currency TEXT NOT NULL DEFAULT 'YER',
                    payment_status TEXT NOT NULL DEFAULT 'pending',
                    auto_renew INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (plan_id) REFERENCES subscription_plans(id)
                );

                CREATE TABLE IF NOT EXISTS bookings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    booking_code TEXT NOT NULL UNIQUE,
                    hall_id INTEGER NOT NULL,
                    customer_id INTEGER NOT NULL,
                    pricing_id INTEGER,
                    event_date TEXT NOT NULL,
                    shift TEXT NOT NULL DEFAULT 'evening',
                    guest_count INTEGER NOT NULL DEFAULT 200,
                    subtotal_amount REAL NOT NULL,
                    discount_amount REAL NOT NULL DEFAULT 0.0,
                    tax_amount REAL NOT NULL DEFAULT 0.0,
                    total_amount REAL NOT NULL,
                    deposit_amount REAL NOT NULL DEFAULT 0.0,
                    remaining_amount REAL NOT NULL DEFAULT 0.0,
                    currency TEXT NOT NULL DEFAULT 'YER',
                    status TEXT NOT NULL DEFAULT 'pending',
                    payment_status TEXT NOT NULL DEFAULT 'unpaid',
                    customer_notes TEXT,
                    admin_notes TEXT,
                    confirmed_at DATETIME,
                    cancelled_at DATETIME,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (hall_id) REFERENCES halls(id),
                    FOREIGN KEY (customer_id) REFERENCES users(id),
                    FOREIGN KEY (pricing_id) REFERENCES hall_pricing(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS booking_status_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    booking_id INTEGER NOT NULL,
                    old_status TEXT,
                    new_status TEXT NOT NULL,
                    changed_by INTEGER NOT NULL,
                    comment TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
                    FOREIGN KEY (changed_by) REFERENCES users(id)
                );

                CREATE TABLE IF NOT EXISTS payment_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    payment_reference TEXT NOT NULL UNIQUE,
                    booking_id INTEGER,
                    subscription_id INTEGER,
                    user_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    currency TEXT NOT NULL DEFAULT 'YER',
                    payment_method TEXT NOT NULL DEFAULT 'cash_on_site',
                    transaction_number TEXT,
                    proof_document_path TEXT,
                    payment_type TEXT NOT NULL DEFAULT 'booking_deposit',
                    status TEXT NOT NULL DEFAULT 'pending_verification',
                    verified_by INTEGER,
                    verified_at DATETIME,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
                    FOREIGN KEY (subscription_id) REFERENCES owner_subscriptions(id) ON DELETE SET NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                );

                CREATE TABLE IF NOT EXISTS inquiries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    inquiry_code TEXT NOT NULL UNIQUE,
                    hall_id INTEGER NOT NULL,
                    user_id INTEGER,
                    sender_name TEXT NOT NULL,
                    sender_phone TEXT NOT NULL,
                    sender_email TEXT,
                    event_type TEXT NOT NULL DEFAULT 'wedding',
                    event_date TEXT,
                    shift TEXT,
                    guest_estimate INTEGER,
                    subject TEXT,
                    status TEXT NOT NULL DEFAULT 'new',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS inquiry_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    inquiry_id INTEGER NOT NULL,
                    sender_id INTEGER,
                    is_owner_reply INTEGER NOT NULL DEFAULT 0,
                    message TEXT NOT NULL,
                    attachment_path TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (inquiry_id) REFERENCES inquiries(id) ON DELETE CASCADE,
                    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hall_id INTEGER NOT NULL,
                    customer_id INTEGER NOT NULL,
                    booking_id INTEGER,
                    rating_cleanliness INTEGER NOT NULL DEFAULT 5,
                    rating_hospitality INTEGER NOT NULL DEFAULT 5,
                    rating_services INTEGER NOT NULL DEFAULT 5,
                    rating_overall INTEGER NOT NULL CHECK (rating_overall BETWEEN 1 AND 5),
                    comment TEXT NOT NULL,
                    owner_response TEXT,
                    owner_responded_at DATETIME,
                    status TEXT NOT NULL DEFAULT 'approved',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE,
                    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS favorites (
                    user_id INTEGER NOT NULL,
                    hall_id INTEGER NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, hall_id),
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    title_ar TEXT NOT NULL,
                    title_en TEXT,
                    message_ar TEXT NOT NULL,
                    message_en TEXT,
                    type TEXT NOT NULL DEFAULT 'booking_update',
                    link_url TEXT,
                    is_read INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    action TEXT NOT NULL,
                    entity_type TEXT,
                    entity_id INTEGER,
                    details_json TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
                );

                CREATE TABLE IF NOT EXISTS platform_settings (
                    setting_key TEXT PRIMARY KEY,
                    setting_value TEXT NOT NULL,
                    setting_group TEXT NOT NULL DEFAULT 'general',
                    description TEXT,
                    updated_by INTEGER,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS contact_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL,
                    phone TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    message TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'new',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS password_resets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT NOT NULL,
                    token TEXT NOT NULL,
                    expires_at DATETIME NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
            ");
            $results[] = "تم إنشاء الجداول العلائقية في SQLite بنجاح.";

            // Seed Master Roles
            $pdo->exec("
                INSERT INTO roles (id, name_ar, name_en, slug, description, is_system) VALUES
                (1, 'المدير العام للنظام', 'Super Administrator', 'super_admin', 'صلاحيات كاملة للمنصة والتدقيق', 1),
                (2, 'مالك / مدير قاعة', 'Hall Owner', 'hall_owner', 'إدارة القاعات والأسعار والحجوزات', 1),
                (3, 'عميل / باحث عن قاعة', 'Customer', 'customer', 'حجز القاعات والاستفسار والتقييم', 1),
                (4, 'موظف قاعة', 'Hall Employee', 'employee', 'استقبال وجدولة مواعيد القاعة', 1);
            ");

            // Seed Master Permissions
            $pdo->exec("
                INSERT INTO permissions (id, name_ar, name_en, slug, module) VALUES
                (1, 'إدارة جميع المستخدمين', 'Manage Users', 'manage_users', 'users'),
                (2, 'اعتماد وتعليق ملاك القاعات', 'Verify Owners', 'verify_owners', 'users'),
                (3, 'إدارة إعدادات النظام', 'Manage System Settings', 'manage_settings', 'system'),
                (4, 'الاطلاع على سجلات التدقيق', 'View Audit Logs', 'view_audit_logs', 'security'),
                (5, 'إدارة باقات اشتراك الملاك', 'Manage Subscription Plans', 'manage_subscriptions', 'billing'),
                (6, 'اعتماد وتعديل القاعات العامة', 'Moderate Halls', 'moderate_halls', 'halls'),
                (7, 'إضافة وتعديل قاعاتي الخاصة', 'Manage Own Halls', 'manage_own_halls', 'halls'),
                (8, 'إدارة أسعار وباقات القاعة', 'Manage Hall Pricing', 'manage_hall_pricing', 'pricing'),
                (9, 'إدارة تقويم مواعيد القاعة', 'Manage Availability', 'manage_availability', 'calendar'),
                (10, 'قبول وتأكيد حجوزات القاعة', 'Manage Hall Bookings', 'manage_hall_bookings', 'bookings'),
                (11, 'الرد على استفسارات الزوار', 'Respond Inquiries', 'respond_inquiries', 'inquiries'),
                (12, 'إدارة طاقم عمل القاعة', 'Manage Hall Staff', 'manage_hall_staff', 'staff'),
                (13, 'حجز قاعات واستعراض العقود', 'Create Bookings', 'create_bookings', 'customer'),
                (14, 'إرسال استفسارات لملاك القاعات', 'Send Inquiries', 'send_inquiries', 'customer'),
                (15, 'تقييم القاعات المحجوزة', 'Review Halls', 'review_halls', 'customer');
            ");

            // Seed Role Permissions
            $pdo->exec("
                INSERT INTO role_permissions (role_id, permission_id) VALUES
                (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15),
                (2, 7), (2, 8), (2, 9), (2, 10), (2, 11), (2, 12),
                (3, 13), (3, 14), (3, 15),
                (4, 9), (4, 10), (4, 11);
            ");

            // Seed Facilities
            $pdo->exec("
                INSERT INTO facilities (id, name_ar, name_en, icon, category) VALUES
                (1, 'تكييف مركزي متطور', 'Central AC & Climate Control', 'bi-snow', 'comfort'),
                (2, 'كوشة عصرية وتصميم ديكور فاخر', 'Modern Kosha & Luxury Decor', 'bi-gem', 'decor'),
                (3, 'إضاءة مسرحية وليزر ومؤثرات ضوئية', 'Stage Lighting & Fog FX', 'bi-stars', 'lighting'),
                (4, 'نظام صوتيات دي جي احترافي', 'Pro Sound System & DJ', 'bi-soundwave', 'audio'),
                (5, 'جناح ملكي خاص للعروس', 'Private Bridal Suite', 'bi-heart-fill', 'comfort'),
                (6, 'مواقف سيارات محروسة تتسع لأكثر من 150 سيارة', 'Spacious Secure Parking', 'bi-p-circle', 'parking'),
                (7, 'مولدات كهرباء ديزل متواصلة (صفر انقطاع)', 'Backup Diesel Generators', 'bi-lightning-charge-fill', 'utility'),
                (8, 'ضيافة قهوة عربية وبوفيه مفتوح', 'Hospitality & Open Buffet', 'bi-cup-hot-fill', 'hospitality'),
                (9, 'طاقم أمني مدرب ومشرفات صالة نسائية', 'Security & Hostess Staff', 'bi-shield-check', 'security'),
                (10, 'شاشات عرض عملاقة LED وتصوير احترافي', 'Giant LED Screens & Pro Video', 'bi-tv', 'multimedia');
            ");

            // Seed Subscription Plans
            $pdo->exec("
                INSERT INTO subscription_plans (id, name_ar, name_en, slug, description, price, billing_period_months, max_halls_allowed, featured_halls_quota, commission_rate_percentage, is_active) VALUES
                (1, 'الباقة المجانية الأساسية', 'Basic Free Plan', 'free_starter', 'تمكّن مالك القاعة من إدراج قاعة واحدة مع عمولة 5%', 0.0, 12, 1, 0, 5.0, 1),
                (2, 'الباقة الذهبية المميزة', 'Golden Venue Plan', 'golden_owner', 'إدراج حتى 3 صالات + قاعة مميزة في الصفحة الرئيسية', 75000.0, 6, 3, 1, 2.5, 1),
                (3, 'الباقة الماسية للقصور الكبرى', 'Diamond Grand Plan', 'diamond_vip', 'إدراج غير محدود + بدون أي عمولة إضافية', 140000.0, 12, 10, 3, 0.0, 1);
            ");

            // Seed Platform Settings
            $pdo->exec("
                INSERT INTO platform_settings (setting_key, setting_value, setting_group, description) VALUES
                ('site_name_ar', 'منصة إيوان لحجز قاعات الأفراح والمناسبات', 'general', 'الاسم الرسمي باللغة العربية'),
                ('site_name_en', 'Iwan Halls Booking Platform', 'general', 'Official name in English'),
                ('default_currency', 'YER', 'financial', 'العملة الأساسية'),
                ('supported_currencies', 'YER,SAR,USD', 'financial', 'العملات الإضافية'),
                ('platform_timezone', 'Asia/Aden', 'localization', 'توقيت اليمن GMT+3'),
                ('admin_email', 'krata2814@gmail.com', 'general', 'بريد الإدارة العامة'),
                ('contact_phone', '+967-1-445566', 'general', 'هاتف خدمة العملاء'),
                ('whatsapp_support', '+967770000001', 'general', 'دعم واتساب'),
                ('require_owner_verification', '1', 'security', 'اشتراط فحص السجل التجاري'),
                ('min_password_length', '8', 'security', 'الحد الأدنى لكلمة المرور');
            ");

            // Ensure Super Admin (id=1) exists with krata2814@gmail.com / 781802671
            $pdo->exec("
                INSERT OR REPLACE INTO users (id, role_id, name, email, phone, password_hash, status)
                VALUES (1, 1, 'المدير العام للنظام (Super Admin)', 'krata2814@gmail.com', '+967781802671', '\$2y\$10\$MunasabatiAdminSalt22u63Dcv.8lR4R9rD0zJ22fqvtzAZQswsG', 'active');
            ");

            $results[] = "تم بذر الجداول الأساسية (الأدوار، الصلاحيات، التجهيزات، باقات الاشتراك، الإعدادات).";
            return ['success' => true, 'messages' => $results];
        }
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Seed initial sample demo halls and users (for preview testing)
 */
function seedDemoData(): void {
    $pdo = Database::getInstance();

    // Check if hall owners already exist
    $check = $pdo->query("SELECT COUNT(*) as c FROM users WHERE role_id = 2")->fetch();
    if ((int)($check['c'] ?? 0) > 0) {
        return; // Already seeded
    }

    // Owner 1: Sana'a Palace
    $pdo->exec("
        INSERT INTO users (id, role_id, name, email, phone, password_hash, status)
        VALUES (2, 2, 'الشيخ عبد الله السنحاني (مالك قصر التاج)', 'owner@tajsanaa.ye', '+967771234567', '\$2y\$10\$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', 'active');

        INSERT INTO owner_profiles (user_id, business_name, commercial_registration_no, is_verified)
        VALUES (2, 'مجموعة قصر التاج الفندقية للمناسبات', 'CR-SAN-2024-889', 1);

        INSERT INTO users (id, role_id, name, email, phone, password_hash, status)
        VALUES (3, 2, 'الكابتن طارق العدني (مالك قاعة لؤلؤة عدن)', 'owner@adenpearl.ye', '+967733456789', '$2y$10$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', 'active');

        INSERT INTO owner_profiles (user_id, business_name, commercial_registration_no, is_verified)
        VALUES (3, 'شركة لؤلؤة خليج عدن السياحية', 'CR-ADE-2023-412', 1);

        INSERT INTO users (id, role_id, name, email, phone, password_hash, status)
        VALUES (4, 3, 'أحمد فؤاد العريقي (عميل)', 'customer@gmail.com', '+967775554433', '$2y$10$3iuLkRYDK7yk2MxH/LZDPuqtOtS9wcgCuwr1ZP7WvHvMZhgQTJe.y', 'active');

        INSERT INTO customer_profiles (user_id, preferred_city)
        VALUES (4, 'sanaa');

        INSERT INTO users (id, role_id, name, email, phone, password_hash, status)
        VALUES (5, 4, 'خالد الشامي (مشرف الاستقبال)', 'staff@tajsanaa.ye', '+967778899001', '$2y$10$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', 'active');

        INSERT INTO employee_profiles (user_id, owner_id, job_title, department)
        VALUES (5, 2, 'مشرف الحجوزات والاستقبال', 'إدارة العلاقات العامة');
    ");

    // Seed Halls
    $pdo->exec("
        INSERT INTO halls (id, owner_id, name_ar, name_en, slug, description_ar, description_en, city, address, capacity_min, capacity_max, hall_type, featured, status, rating, reviews_count)
        VALUES
        (1, 2, 'قصر التاج الملكي للمناسبات والأفراح', 'Royal Crown Grand Palace', 'taj-royal-palace-sanaa',
        'أفخم وأكبر صالة أفراح ومؤتمرات في العاصمة صنعاء. صممت على الطراز المعماري الأندلسي الملكي الممزوج بالحداثة، تتسع لما يصل إلى 1000 شخص مع أرقى كوشة زفاف، شاشات عملاقة، وإضاءة سينمائية ساحرة.',
        'The premier and most luxurious wedding and conference palace in Sana''a. Designed with Andalusian grandeur combined with modern elegance.',
        'sanaa', 'صنعاء - حدة، جولة المدينة، خلف مجمع السعيد', 300, 1000, 'wedding', 1, 'active', 4.95, 28),

        (2, 3, 'قاعة لؤلؤة عدن الكبرى', 'Aden Pearl Grand Hall', 'aden-pearl-grand-hall',
        'إطلالة بحرية ساحرة وأجواء احتفالية راقية على ساحل خور مكسر بعدن. مجهزة بأحدث أنظمة التكييف الصامت والمسارح المضيئة وطاقم ضيافة متميز.',
        'Magnificent coastal wedding hall in Khormaksar, Aden with ocean views and high-end banquet amenities.',
        'aden', 'عدن - خور مكسر، كورنيش قحطان الشعبي', 200, 750, 'wedding', 1, 'active', 4.88, 19),

        (3, 2, 'قاعة النرجس الملكية للمؤتمرات والأعراس', 'Al-Narjis Royal Hall', 'al-narjis-royal-hall-taiz',
        'تتميز قاعة النرجس بموقعها الاستراتيجي في قلب الحوبان بمحافظة تعز. ديكورات عصرية، أسقف عالية مع ثريات كريستال فاخرة.',
        'Strategically located luxury hall in Taiz featuring high crystal chandelier ceilings and VIP seating arrangements.',
        'taiz', 'تعز - الحوبان، جوار حديقة دريم لاند', 150, 600, 'wedding', 1, 'active', 4.75, 12),

        (4, 3, 'قصر الأميرة للمناسبات الخاصة', 'The Princess Palace Hall', 'princess-palace-ibb',
        'جوهرة اللواء الأخضر في محافظة إب، صالة فاخرة بإطلالة خضراء بديعة، كوشة فخمة مجهزة بأحدث تصاميم الورد الطبيعي والصوتيات المتقدمة.',
        'Elegance in the green city of Ibb, tailored for VIP celebrations and weddings with exquisite natural floral designs.',
        'ibb', 'إب - الدائري الغربي، قرب فندق برج إب', 100, 500, 'engagement', 0, 'active', 4.90, 8);
    ");

    // Seed Pricing
    $pdo->exec("
        INSERT INTO hall_pricing (hall_id, title_ar, shift, day_type, base_price, deposit_required, currency)
        VALUES
        (1, 'الفترة الصباحية (عادية)', 'morning', 'all_days', 350000.0, 100000.0, 'YER'),
        (1, 'الفترة المسائية (العرس الكبير)', 'evening', 'all_days', 650000.0, 200000.0, 'YER'),
        (1, 'حجز يوم كامل', 'full_day', 'all_days', 900000.0, 300000.0, 'YER'),

        (2, 'الفترة الصباحية (عدن)', 'morning', 'all_days', 250000.0, 80000.0, 'YER'),
        (2, 'الفترة المسائية (العرس على البحر)', 'evening', 'all_days', 500000.0, 150000.0, 'YER'),
        (2, 'حجز يوم كامل', 'full_day', 'all_days', 700000.0, 250000.0, 'YER'),

        (3, 'الفترة الصباحية (تعز)', 'morning', 'all_days', 200000.0, 50000.0, 'YER'),
        (3, 'الفترة المسائية', 'evening', 'all_days', 420000.0, 100000.0, 'YER'),

        (4, 'الفترة المسائية (إب)', 'evening', 'all_days', 380000.0, 100000.0, 'YER');
    ");

    // Seed Images
    $pdo->exec("
        INSERT INTO hall_images (hall_id, image_url, is_primary, caption, sort_order) VALUES
        (1, 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80', 1, 'المسرح الملكي والكوشة الفاخرة', 1),
        (1, 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1200&q=80', 0, 'إضاءة المسرح والثريات الكريستالية', 2),
        (1, 'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80', 0, 'ترتيب طاولة العرسان والورود', 3),
        (2, 'https://images.unsplash.com/photo-1545232979-fbf68fe9b1af?auto=format&fit=crop&w=1200&q=80', 1, 'الصالة الرئيسية وقوس الورود في قاعة لؤلؤة عدن', 1),
        (2, 'https://images.unsplash.com/photo-1478146896981-b80fe463b330?auto=format&fit=crop&w=1200&q=80', 0, 'طاولات الضيوف والضيافة الراقية', 2),
        (3, 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80', 1, 'الإطلالة الداخلية لقاعة النرجس بتعز', 1),
        (4, 'https://images.unsplash.com/photo-1532712938310-34cb3982ef74?auto=format&fit=crop&w=1200&q=80', 1, 'قصر الأميرة في محافظة إب الخضراء', 1);
    ");

    // Seed Facilities Link
    $pdo->exec("
        INSERT INTO hall_facilities (hall_id, facility_id, details, is_complimentary) VALUES
        (1, 1, 'مكيفات مركزية بقدرة 120 طن تبريد', 1),
        (1, 2, 'كوشة ملكية إيطالية مع إمكانية التخصيص', 1),
        (1, 3, '4 أجهزة ليزر سداسية + ماكينات دخان ثقيل', 1),
        (1, 4, 'سماعات JBL خطية احترافية مع هندسة صوتية', 1),
        (1, 5, 'غرفة VIP مع سرير استراحة ومرآة هوليوود', 1),
        (1, 6, 'موقف سيارات مظلل مع كاميرات مراقبة وحراسة', 1),
        (1, 7, 'مولدان كهربائيان بقدرة 250 KVA أوتوماتيكي', 1),
        (1, 8, 'مباشرين وضيافة مجانية من إدارة القصر', 1),
        (1, 9, 'طاقم أمني متخصص 8 أفراد', 1),
        (1, 10, '3 شاشات LED قياس 4x3 أمتار', 1),
        (2, 1, 'تكييف سبليت مركزي على مدار الساعة', 1),
        (2, 2, 'ديكورات لؤلؤية بحرية حديثة', 1),
        (2, 4, 'صوتيات دي جي ومكروفونات شور لاسلكية', 1),
        (2, 6, 'مواقف تتسع لـ 120 سيارة على كورنيش الخور', 1),
        (2, 7, 'مولد كهربائي كمنز كاتم صوت', 1);
    ");

    // Seed Bookings
    $pdo->exec("
        INSERT INTO bookings (id, booking_code, hall_id, customer_id, pricing_id, event_date, shift, guest_count, subtotal_amount, total_amount, deposit_amount, status, payment_status, customer_notes)
        VALUES
        (1, 'BK-2026-001', 1, 4, 2, '2026-11-15', 'evening', 500, 650000.0, 650000.0, 200000.0, 'confirmed', 'deposit_paid', 'حفل زفاف المهندس أحمد - تجهيز الكوشة الملكية قبل العصر'),
        (2, 'BK-2026-002', 2, 4, 5, '2026-11-20', 'evening', 350, 500000.0, 500000.0, 150000.0, 'confirmed', 'deposit_paid', 'مناسبة خاصة - تزيين المدخل بالورود البيضاء'),
        (3, 'BK-2026-003', 1, 4, 1, '2026-12-05', 'morning', 250, 350000.0, 350000.0, 0.0, 'pending', 'unpaid', 'حفل تخرج الدفعة 18 كلية الهندسة');
    ");

    // Seed Inquiries
    $pdo->exec("
        INSERT INTO inquiries (id, inquiry_code, hall_id, user_id, sender_name, sender_phone, sender_email, event_type, event_date, guest_estimate, subject, status)
        VALUES
        (1, 'INQ-2026-01', 1, 4, 'أحمد فؤاد', '+967775554433', 'customer@gmail.com', 'wedding', '2026-12-25', 600, 'استفسار عن أسعار الجمعة', 'new'),
        (2, 'INQ-2026-02', 2, NULL, 'حسام باوزير', '+967733221100', 'hussam@yahoo.com', 'engagement', '2026-11-28', 250, 'عقد قران صباحي', 'replied');

        INSERT INTO inquiry_messages (inquiry_id, sender_id, is_owner_reply, message)
        VALUES
        (1, 4, 0, 'السلام عليكم، هل القاعة متاحة يوم الجمعة 25 ديسمبر للفترة المسائية؟ وما هو الخصم المتاح؟'),
        (2, NULL, 0, 'مرحباً، نستفسر عن أسعار الفترة الصباحية لعقد القران وتوفر جناح العروسة.'),
        (2, 3, 1, 'وعليكم السلام ورحمة الله، نعم الفترة الصباحية متاحة وجناح العروسة مجهز بالكامل ومجاني.');
    ");

    // Seed Reviews
    $pdo->exec("
        INSERT INTO reviews (hall_id, customer_id, booking_id, rating_overall, comment, status)
        VALUES
        (1, 4, 1, 5, 'من أفخم وأروع القاعات في صنعاء بلا منازع، تعامل راقٍ وخدمات فاخرة وتكييف ممتاز جداً.', 'approved'),
        (2, 4, 2, 5, 'قاعة ممتازة على البحر مباشرة، الأجواء كانت خيالية والضيوف انبسطوا جداً.', 'approved');
    ");
}

// CLI Execution
if (php_sapi_name() === 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    echo "=== Initializing Database Schema (Part 2 Relational Structure) ===\n";
    $res = initializeDatabase();
    if ($res['success']) {
        foreach ($res['messages'] as $msg) {
            echo "[OK] " . $msg . "\n";
        }
        seedDemoData();
        echo "[OK] Seeded demo venues and accounts for preview testing.\n";
        echo "Database initialization complete!\n";
    } else {
        echo "[ERROR] " . $res['error'] . "\n";
        exit(1);
    }
}
