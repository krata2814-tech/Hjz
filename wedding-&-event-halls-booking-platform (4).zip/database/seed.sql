-- ============================================================================
-- Wedding & Event Halls Booking Platform
-- منصة حجز قاعات الأفراح والمناسبات
-- Initial Seed Data
-- ============================================================================

USE `wedding_halls_db`;

-- 1. Insert Initial Users
-- Passwords:
-- admin@wedding.ye => admin123
-- owner@tajsanaa.ye => owner123
-- owner@adenpearl.ye => owner123
-- customer@gmail.com => customer123
-- staff@tajsanaa.ye => owner123
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `phone`, `role`, `status`) VALUES
(1, 'المهندس مازن العزي (مدير المنصة العام)', 'admin@wedding.ye', '$2y$10$63C/h9/.Rx4C9DflLUici.TDlSh2RJUe05ioEEyj4Wv/AfPjJMjz.', '+967770000001', 'admin', 'active'),
(2, 'الشيخ عبد الله السنحاني (مالك قصر التاج)', 'owner@tajsanaa.ye', '$2y$10$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', '+967771234567', 'hall_owner', 'active'),
(3, 'الكابتن طارق العدني (مالك قاعة لؤلؤة عدن)', 'owner@adenpearl.ye', '$2y$10$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', '+967733456789', 'hall_owner', 'active'),
(4, 'أحمد فؤاد العريقي', 'customer@gmail.com', '$2y$10$3iuLkRYDK7yk2MxH/LZDPuqtOtS9wcgCuwr1ZP7WvHvMZhgQTJe.y', '+967775554433', 'customer', 'active'),
(5, 'خالد الشامي (مشرف الاستقبال)', 'staff@tajsanaa.ye', '$2y$10$9FPaD0LFY62x3cwyMpBQd.UQHnCcvHh9ujZldJM8R6F8HrbJ0w2/G', '+967778899001', 'employee', 'active');

-- 2. Insert Master Amenities
INSERT INTO `amenities` (`id`, `name_ar`, `name_en`, `icon`, `category`) VALUES
(1, 'تكييف مركزي متطور', 'Central AC & Climate Control', 'bi-snow', 'comfort'),
(2, 'كوشة عصرية وتصميم ديكور فاخر', 'Modern Kosha & Luxury Decor', 'bi-gem', 'decor'),
(3, 'إضاءة مسرحية وليزر ومؤثرات دخانية', 'Stage Lighting & Fog FX', 'bi-stars', 'lighting'),
(4, 'نظام صوتيات دي جي احترافي ومكروفونات لاسلكية', 'Pro Sound System & DJ', 'bi-soundwave', 'audio'),
(5, 'جناح ملكي خاص للعروس وأهلها مع حمام مستقل', 'Private Bridal Suite', 'bi-heart-fill', 'comfort'),
(6, 'مواقف سيارات محروسة تتسع لأكثر من 150 سيارة', 'Spacious Secure Parking', 'bi-p-circle', 'parking'),
(7, 'مولدات كهرباء ديزل متواصلة (صفر انقطاع)', 'Backup Diesel Generators', 'bi-lightning-charge-fill', 'utility'),
(8, 'ضيافة قهوة عربية ومشروبات وبوفيه مفتوح', 'Hospitality & Open Buffet', 'bi-cup-hot-fill', 'hospitality'),
(9, 'طاقم أمني مدرب ومشرفات صالة نسائية', 'Security & Hostess Staff', 'bi-shield-check', 'service'),
(10, 'شاشات عرض عملاقة LED وتصوير احترافي', 'Giant LED Screens & Pro Video', 'bi-tv', 'multimedia');

-- 3. Insert Venues (Halls)
INSERT INTO `halls` (
    `id`, `owner_id`, `name_ar`, `name_en`, `slug`,
    `description_ar`, `description_en`,
    `city`, `address`, `map_lat`, `map_lng`,
    `capacity_min`, `capacity_max`,
    `price_morning`, `price_evening`, `price_full_day`,
    `currency`, `hall_type`, `featured`, `status`, `rating`, `reviews_count`
) VALUES
(
    1, 2, 'قصر التاج الملكي للمناسبات والأفراح', 'Royal Crown Grand Palace', 'taj-royal-palace-sanaa',
    'أفخم وأكبر صالة أفراح ومؤتمرات في العاصمة صنعاء. صممت على الطراز المعماري الأندلسي الملكي الممزوج بالحداثة، تتسع لما يصل إلى 1000 شخص مع أرقى كوشة زفاف، شاشات عملاقة، وإضاءة سينمائية ساحرة.',
    'The premier and most luxurious wedding and conference palace in Sana''a. Designed with Andalusian grandeur combined with modern elegance.',
    'sanaa', 'صنعاء - حدة، جولة المدينة، خلف مجمع السعيد', 15.3125, 44.1872,
    300, 1000,
    350000.00, 650000.00, 900000.00,
    'YER', 'wedding', 1, 'active', 4.95, 28
),
(
    2, 3, 'قاعة لؤلؤة عدن الكبرى', 'Aden Pearl Grand Hall', 'aden-pearl-grand-hall',
    'إطلالة بحرية ساحرة وأجواء احتفالية راقية على ساحل خور مكسر بعدن. قاعة لؤلؤة عدن توفر أرقى الخدمات لليلة العمر، مجهزة بأحدث أنظمة التكييف الصامت والمسارح المضيئة وطاقم ضيافة متميز.',
    'Magnificent coastal wedding hall in Khormaksar, Aden with ocean views and high-end banquet amenities.',
    'aden', 'عدن - خور مكسر، كورنيش قحطان الشعبي', 12.8250, 45.0340,
    200, 750,
    250000.00, 500000.00, 700000.00,
    'YER', 'wedding', 1, 'active', 4.88, 19
),
(
    3, 2, 'قاعة النرجس الملكية للمؤتمرات والأعراس', 'Al-Narjis Royal Hall', 'al-narjis-royal-hall-taiz',
    'تتميز قاعة النرجس بموقعها الاستراتيجي في قلب الحوبان بمحافظة تعز. ديكورات عصرية، أسقف عالية مع ثريات كريستال فاخرة، مجهزة بالكامل لجميع مناسبات الأعراس والتخرج والمؤتمرات.',
    'Strategically located luxury hall in Taiz featuring high crystal chandelier ceilings and VIP seating arrangements.',
    'taiz', 'تعز - الحوبان، جوار حديقة دريم لاند', 13.5850, 44.0200,
    150, 600,
    200000.00, 420000.00, 580000.00,
    'YER', 'wedding', 1, 'active', 4.75, 12
),
(
    4, 3, 'قصر الأميرة للمناسبات الخاصة', 'The Princess Palace Hall', 'princess-palace-ibb',
    'جوهرة اللواء الأخضر في محافظة إب، صالة فاخرة بإطلالة خضراء بديعة، كوشة فخمة مجهزة بأحدث تصاميم الورد الطبيعي والصوتيات المتقدمة.',
    'Elegance in the green city of Ibb, tailored for VIP celebrations and weddings with exquisite natural floral designs.',
    'ibb', 'إب - الدائري الغربي، قرب فندق برج إب', 13.9700, 44.1700,
    100, 500,
    180000.00, 380000.00, 520000.00,
    'YER', 'engagement', 0, 'active', 4.90, 8
);

-- 4. Insert Hall Gallery Images
INSERT INTO `hall_images` (`hall_id`, `image_url`, `is_primary`, `caption`, `sort_order`) VALUES
(1, 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=1200&q=80', 1, 'المسرح الملكي والكوشة الفاخرة', 1),
(1, 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1200&q=80', 0, 'إضاءة المسرح والثريات الكريستالية', 2),
(1, 'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80', 0, 'ترتيب طاولة العرسان والورود', 3),

(2, 'https://images.unsplash.com/photo-1545232979-fbf68fe9b1af?auto=format&fit=crop&w=1200&q=80', 1, 'الصالة الرئيسية وقوس الورود في قاعة لؤلؤة عدن', 1),
(2, 'https://images.unsplash.com/photo-1478146896981-b80fe463b330?auto=format&fit=crop&w=1200&q=80', 0, 'طاولات الضيوف والضيافة الراقية', 2),

(3, 'https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80', 1, 'الإطلالة الداخلية لقاعة النرجس بتعز', 1),
(4, 'https://images.unsplash.com/photo-1532712938310-34cb3982ef74?auto=format&fit=crop&w=1200&q=80', 1, 'قصر الأميرة في محافظة إب الخضراء', 1);

-- 5. Link Hall Amenities
INSERT INTO `hall_amenities` (`hall_id`, `amenity_id`, `details`) VALUES
(1, 1, 'مكيفات مركزية بقدرة 120 طن تبريد'),
(1, 2, 'كوشة ملكية إيطالية مع إمكانية التخصيص'),
(1, 3, '4 أجهزة ليزر سداسية + ماكينات دخان ثقيل'),
(1, 4, 'سماعات JBL خطية احترافية مع هندسة صوتية متخصصة'),
(1, 5, 'غرفة VIP مع سرير استراحة ومرآة إضاءة هوليوود'),
(1, 6, 'موقف سيارات مظلل مع كاميرات مراقبة وحراسة'),
(1, 7, 'مولدان كهربائيان بقدرة 250 KVA أوتوماتيكي'),
(1, 8, 'مباشرين وضيافة مجانية من إدارة القصر'),
(1, 9, 'طاقم أمني متخصص 8 أفراد'),
(1, 10, '3 شاشات LED قياس 4x3 أمتار'),

(2, 1, 'تكييف سبليت مركزي على مدار الساعة'),
(2, 2, 'ديكورات لؤلؤية بحرية حديثة'),
(2, 4, 'صوتيات دي جي ومكروفونات شور لاسلكية'),
(2, 5, 'جناح خاص للعروس متصل بالمسرح مباشرة'),
(2, 6, 'مواقف تتسع لـ 120 سيارة على كورنيش الخور'),
(2, 7, 'مولد كهربائي كمنز كاتم صوت'),

(3, 1, 'تكييف هواء فائق التبريد'),
(3, 2, 'كوشة مزينة بالورود والأقمشة الحريرية'),
(3, 7, 'مولد كهربائي احتياطي جاهز'),
(3, 9, 'طاقم تنظيف واستقبال مستمر');

-- 6. Insert Packages
INSERT INTO `hall_packages` (`hall_id`, `title_ar`, `title_en`, `description_ar`, `price`, `included_services`, `is_active`) VALUES
(1, 'الباقة الماسية الشاملة', 'Diamond Royal All-Inclusive Package', 'تشمل حجز القاعة للفترة المسائية + الكوشة الفاخرة + الإضاءة والصوتيات + شاشات العرض + بوفيه حلويات ومشروبات لـ 500 شخص + تصوير فوتوغرافي وفيديو 4K بطائرة درون.', 1200000.00, 'قاعة كاملة + كوشة + تصوير 4K + صوت وإضاءة + بوفيه ضيافة + جناح عروس', 1),
(1, 'باقة الأفراح الذهبية', 'Golden Wedding Package', 'تشمل حجز القاعة للفترة المسائية + الكوشة + الصوتيات والمؤثرات الضوئية + القهوة والشاي العربي والمياه المعدنية للضيوف.', 850000.00, 'حجز مسائي + كوشة + صوت وإضاءة + ضيافة شاي وقهوة', 1),
(2, 'باقة لؤلؤة البحر', 'Sea Pearl Package', 'تشمل حجز القاعة المسائية مع إطلالة الكورنيش + الكوشة + الدي جي + مولد الكهرباء المستمر وضيافة الاستقبال.', 650000.00, 'قاعة + كوشة لؤلؤية + دي جي + ضيافة', 1);

-- 7. Insert Initial Sample Bookings
INSERT INTO `bookings` (`id`, `booking_code`, `hall_id`, `customer_id`, `package_id`, `event_date`, `shift`, `guest_count`, `total_amount`, `deposit_amount`, `status`, `payment_status`, `notes`) VALUES
(1, 'BK-2026-001', 1, 4, 1, '2026-11-15', 'evening', 500, 1200000.00, 500000.00, 'confirmed', 'deposit_paid', 'حفل زفاف المهندس أحمد - مطلوب تجهيز الكوشة الملكية قبل العصر'),
(2, 'BK-2026-002', 2, 4, 3, '2026-11-20', 'evening', 350, 650000.00, 200000.00, 'confirmed', 'deposit_paid', 'مناسبة عائلية خاصة - تزيين المدخل بالورود البيضاء'),
(3, 'BK-2026-003', 1, 4, 2, '2026-12-05', 'morning', 250, 350000.00, 0.00, 'pending', 'unpaid', 'حفل تخرج الدفعة 18 كلية الهندسة');

-- 8. Insert Inquiries
INSERT INTO `inquiries` (`id`, `hall_id`, `user_id`, `sender_name`, `sender_phone`, `sender_email`, `event_type`, `event_date`, `guest_estimate`, `message`, `status`) VALUES
(1, 1, 4, 'أحمد فؤاد', '+967775554433', 'customer@gmail.com', 'wedding', '2026-12-25', 600, 'السلام عليكم، هل القاعة متاحة يوم الجمعة 25 ديسمبر للفترة المسائية؟ وما هو الخصم المتاح للباقة الماسية؟', 'new'),
(2, 2, NULL, 'حسام باوزير', '+967733221100', 'hussam@yahoo.com', 'engagement', '2026-11-28', 250, 'مرحباً، نستفسر عن أسعار الفترة الصباحية لعقد القران وتوفر جناح العروسة.', 'replied');

-- 9. Insert Reviews
INSERT INTO `reviews` (`hall_id`, `customer_id`, `booking_id`, `rating`, `comment`, `status`) VALUES
(1, 4, 1, 5, 'من أفخم وأروع القاعات في صنعاء بلا منازع، تعامل راقٍ وخدمات فاخرة وتكييف ممتاز جداً، بيض الله وجوهكم.', 'approved'),
(2, 4, 2, 5, 'قاعة ممتازة على البحر مباشرة، الأجواء كانت خيالية والضيوف انبسطوا جداً.', 'approved');

-- 10. Platform Settings
INSERT INTO `platform_settings` (`setting_key`, `setting_value`) VALUES
('site_name_ar', 'منصة إيوان لحجز قاعات الأفراح والمناسبات'),
('site_name_en', 'Iwan Halls Booking Platform'),
('default_currency', 'YER'),
('supported_currencies', 'YER,SAR,USD'),
('admin_email', 'admin@wedding.ye'),
('contact_phone', '+967-1-445566'),
('whatsapp_support', '+967770000001'),
('timezone', 'Asia/Aden');
