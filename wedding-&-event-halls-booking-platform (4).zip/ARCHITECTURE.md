# Munasabati (مناسبتي) — Architecture & Migration Blueprint

## 1. Existing Project Audit & Data Preservation Strategy

### Audit Findings
1. **Existing Database (`database/wedding_halls.sqlite`)**:
   - Contains 22 relational tables with foreign-key enforcement (`PRAGMA foreign_keys = ON`):
     - **Identity & RBAC**: `roles`, `permissions`, `role_permissions`, `users`, `user_permissions`, `owner_profiles`, `customer_profiles`, `employee_profiles`, `password_resets`.
     - **Venue Inventory & Catalog**: `halls`, `hall_images`, `facilities`, `hall_facilities`, `hall_pricing`, `hall_availability`.
     - **Commerce, Billing & Subscriptions**: `bookings`, `booking_status_history`, `payment_records`, `subscription_plans`, `owner_subscriptions`.
     - **Trust, Communication & Governance**: `inquiries`, `inquiry_messages`, `reviews`, `favorites`, `notifications`, `audit_logs`, `platform_settings`, `contact_messages`.
2. **Legacy PHP Layer**:
   - The previous iteration used server-rendered PHP pages (`index.php`, `halls.php`, `admin/*.php`) proxied through `server.ts`.
   - External Unsplash URLs were seeded in `hall_images`, which can fail in restricted network sandboxes.

### Non-Destructive Migration Plan
- **100% Data Preservation**: Rather than discarding `database/wedding_halls.sqlite`, our new TypeScript backend connects directly to `database/wedding_halls.sqlite` via Node 22's native `node:sqlite` (`DatabaseSync`) driver with `PRAGMA foreign_keys = ON` and `WAL` mode enabled.
- **Zero-Loss Schema Evolution**:
  - Adds the `support_agent` role (`id = 5`, `slug = 'support_agent'`) for Customer Support Agents.
  - Adds `support_tickets` and `support_ticket_messages` tables for structured dispute, complaint, and inquiry resolution.
  - Adds `commission_rate` and `platform_fee_amount` tracking to financial calculations, computing platform income strictly from verified `payment_records` (`status = 'verified'`) and confirmed/completed bookings.
  - Replaces fragile external image links with high-craft, deterministic local SVG architectural venue photography endpoints (`/api/artwork/:scene`) and uploaded asset storage (`/uploads/*`).

---

## 2. System Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   CLIENT LAYER (React 19 + TypeScript)                     │
│  • RTL Arabic-First & English Localization Engine                          │
│  • Tailwind CSS v4 (Ivory #FAF8F5, Deep Emerald #0B3B2B, Gold #C5A059)     │
│  • Framer Motion (motion/react) Compositor-Only Transitions                │
│  • 4 Role-Specific Workspaces:                                             │
│    1. Customer Marketplace & Live Availability Booking Engine              │
│    2. Hall Owner Studio (Venues, Pricing, Calendar, Reservations)          │
│    3. Customer Support & Dispute Resolution Center                         │
│    4. Super Admin Command Center (18 Governance & Financial Modules)       │
└───────────────────────────────┬────────────────────────────────────────────┘
                                │ HTTPS / REST JSON + X-CSRF-Token + Bearer
┌───────────────────────────────▼────────────────────────────────────────────┐
│                   APPLICATION SERVER (Express + TypeScript)                │
│  • Authentication & Session Manager (HMAC-SHA256 Signed Tokens + CSRF)     │
│  • Server-Side RBAC Middleware (requireAuth, requireRole)                  │
│  • Atomic Booking Engine (BEGIN IMMEDIATE Transactions, Conflict Guard)    │
│  • Financial Ledger Calculator (Gross, Owner Net, Commission, Refunds)     │
│  • Local Architectural Venue Artwork Renderer (/api/artwork/:scene)        │
│  • Comprehensive Security Audit Logger (audit_logs)                        │
└───────────────────────────────┬────────────────────────────────────────────┘
                                │ Native Synchronous SQL + ACID Transactions
┌───────────────────────────────▼────────────────────────────────────────────┐
│            PERSISTENCE LAYER (database/wedding_halls.sqlite)               │
│  • 24 Relational Tables with Strict Foreign Keys & Unique Constraints      │
│  • Unique Index on hall_availability(hall_id, date, shift)                 │
│  • Conflict-Free Confirmed Reservation Guard on bookings                   │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Core Security & Engineering Guarantees

1. **Server-Side Authorization (RBAC)**: Every `/api/admin/*`, `/api/owner/*`, `/api/support/*`, and `/api/customer/*` route verifies the caller's authenticated session and role directly against the `users` and `roles` tables (`status === 'active'`). Suspended accounts are immediately rejected at the middleware layer.
2. **CSRF Protection**: State-changing requests (`POST`, `PUT`, `PATCH`, `DELETE`) validate the `X-CSRF-Token` header issued by the server session.
3. **ACID Booking Conflict Prevention**: Creating or confirming a reservation runs inside an atomic `BEGIN IMMEDIATE` transaction that checks both `bookings` (`status = 'confirmed'`) and `hall_availability` (`status IN ('booked', 'blocked')`) for the target `(hall_id, event_date, shift)`. Conflicting requests are rolled back with HTTP `409 Conflict`.
4. **Verified Financial Accounting**: Platform revenue and commission metrics are calculated exclusively from verified payment records (`payment_records.status = 'verified'`), cleanly separating Gross Booking Value, Verified Paid Revenue, Platform Commission, Hall Owner Net Revenue, Pending Verification Payments, and Refunds.
5. **Audit Trail (`audit_logs`)**: Every sensitive operation (venue approval/rejection, user suspension, role assignment, staff creation, payment verification, platform setting updates) writes an immutable record to `audit_logs`.
