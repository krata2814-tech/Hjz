<?php
/**
 * Wedding & Event Halls Booking Platform
 * منصة حجز قاعات الأفراح والمناسبات
 *
 * Dedicated Search Results & Discovery Engine
 */

$page_title = 'نتائج البحث عن القاعات والقصور';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

// Sanitize incoming search parameters
$keyword = sanitize(get('q', ''));
$selectedCity = sanitize(get('city', ''));
$district = sanitize(get('district', ''));
$selectedType = sanitize(get('type', ''));
$targetDate = sanitize(get('date', ''));
$selectedCapacity = (int) get('capacity', 0);
$minPrice = (float) get('min_price', 0);
$maxPrice = (float) get('max_price', 0);
$facility = sanitize(get('facility', ''));
$sort = sanitize(get('sort', 'rating_desc'));
$page = max(1, (int) get('page', 1));
$perPage = 6;

// Build Prepared Query
$whereClauses = ["h.status = 'active'"];
$params = [];

if (!empty($keyword)) {
    $whereClauses[] = "(h.name_ar LIKE ? OR h.address LIKE ? OR h.description_ar LIKE ?)";
    $likeKw = '%' . $keyword . '%';
    $params[] = $likeKw;
    $params[] = $likeKw;
    $params[] = $likeKw;
}

if (!empty($selectedCity)) {
    $whereClauses[] = "h.city = ?";
    $params[] = $selectedCity;
}

if (!empty($district)) {
    $whereClauses[] = "h.address LIKE ?";
    $params[] = '%' . $district . '%';
}

if (!empty($selectedType)) {
    $whereClauses[] = "h.hall_type = ?";
    $params[] = $selectedType;
}

if ($selectedCapacity > 0) {
    $whereClauses[] = "h.capacity_max >= ?";
    $params[] = $selectedCapacity;
}

if ($minPrice > 0) {
    $whereClauses[] = "h.price_evening >= ?";
    $params[] = $minPrice;
}

if ($maxPrice > 0) {
    $whereClauses[] = "h.price_evening <= ?";
    $params[] = $maxPrice;
}

if (!empty($facility)) {
    $whereClauses[] = "EXISTS (
        SELECT 1 FROM hall_facilities hf 
        JOIN facilities f ON hf.facility_id = f.id 
        WHERE hf.hall_id = h.id AND (f.name_ar LIKE ? OR f.name_en LIKE ?)
    )";
    $params[] = '%' . $facility . '%';
    $params[] = '%' . $facility . '%';
}

$whereSql = implode(' AND ', $whereClauses);

// Count Total Matching Halls for Pagination
$countSql = "SELECT COUNT(*) as total FROM halls h WHERE {$whereSql}";
$totalHalls = 0;
try {
    $totalRow = Database::fetchOne($countSql, $params);
    $totalHalls = (int)($totalRow['total'] ?? 0);
} catch (Exception $e) {
    $totalHalls = 0;
}

$totalPages = max(1, ceil($totalHalls / $perPage));
$offset = ($page - 1) * $perPage;

// Sorting
$orderBy = "h.featured DESC, h.rating DESC";
if ($sort === 'price_asc') {
    $orderBy = "h.price_evening ASC";
} elseif ($sort === 'price_desc') {
    $orderBy = "h.price_evening DESC";
} elseif ($sort === 'capacity_desc') {
    $orderBy = "h.capacity_max DESC";
} elseif ($sort === 'newest') {
    $orderBy = "h.id DESC";
}

// Fetch Halls with Primary Image & Availability Check
$dataParams = $params;
$availabilitySelect = "0 as is_booked_on_date";
if (!empty($targetDate)) {
    $availabilitySelect = "(SELECT COUNT(*) FROM bookings b WHERE b.hall_id = h.id AND b.event_date = ? AND b.status IN ('confirmed', 'approved')) as is_booked_on_date";
    array_unshift($dataParams, $targetDate);
}

$sql = "
    SELECT h.*, 
           (SELECT image_url FROM hall_images WHERE hall_id = h.id AND is_primary = 1 LIMIT 1) as primary_image,
           {$availabilitySelect}
    FROM halls h
    WHERE {$whereSql}
    ORDER BY {$orderBy}
    LIMIT {$perPage} OFFSET {$offset}
";

try {
    $halls = Database::fetchAll($sql, $dataParams);
} catch (Exception $e) {
    $halls = [];
}

// Helper function to build page link preserving other query params
function buildSearchPageUrl($targetPage) {
    $queryParams = $_GET;
    $queryParams['page'] = $targetPage;
    return BASE_URL . '/search.php?' . http_build_query($queryParams);
}
?>

<!-- Search Hero Bar -->
<section class="py-4 bg-white border-bottom shadow-sm">
    <div class="container">
        <form action="<?= BASE_URL ?>/search.php" method="GET" class="row g-2 align-items-center">
            <div class="col-lg-3 col-md-6 col-12">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light text-muted"><i class="bi bi-search"></i></span>
                    <input type="text" name="q" class="form-control" placeholder="<?= Lang::isRtl() ? 'اسم القاعة أو الحي...' : 'Hall name or area...' ?>" value="<?= e($keyword) ?>">
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <select name="city" class="form-select form-select-sm">
                    <option value=""><?= e(__('all_cities')) ?></option>
                    <?php foreach (getYemenGovernorates() as $govCode => $govName): ?>
                        <option value="<?= e($govCode) ?>" <?= ($selectedCity === $govCode) ? 'selected' : '' ?>><?= e($govName) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <select name="type" class="form-select form-select-sm">
                    <option value=""><?= e(__('all_types')) ?></option>
                    <option value="wedding" <?= ($selectedType === 'wedding') ? 'selected' : '' ?>><?= e(__('type_wedding')) ?></option>
                    <option value="engagement" <?= ($selectedType === 'engagement') ? 'selected' : '' ?>><?= e(__('type_engagement')) ?></option>
                    <option value="graduation" <?= ($selectedType === 'graduation') ? 'selected' : '' ?>><?= e(__('type_graduation')) ?></option>
                    <option value="conference" <?= ($selectedType === 'conference') ? 'selected' : '' ?>><?= e(__('type_conference')) ?></option>
                </select>
            </div>
            <div class="col-lg-2 col-md-4 col-6">
                <input type="date" name="date" class="form-control form-control-sm min-today" value="<?= e($targetDate) ?>" title="<?= Lang::isRtl() ? 'تاريخ المناسبة' : 'Event Date' ?>">
            </div>
            <div class="col-lg-2 col-md-4 col-6">
                <select name="capacity" class="form-select form-select-sm">
                    <option value=""><?= Lang::isRtl() ? 'أي سعة' : 'Any capacity' ?></option>
                    <option value="200" <?= ($selectedCapacity == 200) ? 'selected' : '' ?>>200+ <?= e(__('guest')) ?></option>
                    <option value="400" <?= ($selectedCapacity == 400) ? 'selected' : '' ?>>400+ <?= e(__('guest')) ?></option>
                    <option value="600" <?= ($selectedCapacity == 600) ? 'selected' : '' ?>>600+ <?= e(__('guest')) ?></option>
                    <option value="800" <?= ($selectedCapacity == 800) ? 'selected' : '' ?>>800+ <?= e(__('guest')) ?></option>
                </select>
            </div>
            <div class="col-lg-1 col-md-4 col-12">
                <button type="submit" class="btn btn-gold btn-sm w-100 fw-bold">
                    <i class="bi bi-search"></i>
                </button>
            </div>
        </form>
    </div>
</section>

<!-- Active Filters Summary & Count -->
<div class="container py-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h1 class="h4 fw-bold text-dark-green mb-1 d-flex align-items-center gap-2">
                <i class="bi bi-geo-alt-fill text-gold"></i>
                <?= Lang::isRtl() ? 'نتائج البحث عن القاعات المتاحة' : 'Search Results for Venues' ?>
            </h1>
            <p class="text-muted small mb-0">
                <?= Lang::isRtl() ? 'تم العثور على' : 'Found' ?> 
                <strong class="text-dark-green"><?= $totalHalls ?></strong> 
                <?= Lang::isRtl() ? 'قاعة وقصر تطابق معاييرك' : 'venues matching your criteria' ?>
                <?php if ($totalPages > 1): ?>
                    (<?= Lang::isRtl() ? 'صفحة ' . $page . ' من ' . $totalPages : 'Page ' . $page . ' of ' . $totalPages ?>)
                <?php endif; ?>
            </p>
        </div>

        <!-- Sort Select -->
        <div class="d-flex align-items-center gap-2">
            <span class="text-muted small flex-shrink-0"><?= Lang::isRtl() ? 'ترتيب حسب:' : 'Sort by:' ?></span>
            <form action="<?= BASE_URL ?>/search.php" method="GET" class="d-inline">
                <?php foreach ($_GET as $k => $v): if ($k !== 'sort' && $k !== 'page'): ?>
                    <input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>">
                <?php endif; endforeach; ?>
                <select name="sort" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="rating_desc" <?= ($sort === 'rating_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأعلى تقييماً' : 'Highest Rated' ?></option>
                    <option value="price_asc" <?= ($sort === 'price_asc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأقل سعراً أولاً' : 'Lowest Price' ?></option>
                    <option value="price_desc" <?= ($sort === 'price_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأعلى سعراً' : 'Highest Price' ?></option>
                    <option value="capacity_desc" <?= ($sort === 'capacity_desc') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأكبر سعة' : 'Largest Capacity' ?></option>
                    <option value="newest" <?= ($sort === 'newest') ? 'selected' : '' ?>><?= Lang::isRtl() ? 'الأحدث إضافة' : 'Newest' ?></option>
                </select>
            </form>
        </div>
    </div>

    <!-- Active Filter Chips -->
    <?php
    $hasActiveFilters = !empty($keyword) || !empty($selectedCity) || !empty($selectedType) || !empty($targetDate) || $selectedCapacity > 0 || $minPrice > 0 || $maxPrice > 0;
    ?>
    <?php if ($hasActiveFilters): ?>
        <div class="d-flex flex-wrap align-items-center gap-2 mb-4 p-2 bg-light rounded-3 border">
            <span class="small fw-bold text-dark-green"><i class="bi bi-funnel-fill text-gold"></i> <?= Lang::isRtl() ? 'الفلاتر النشطة:' : 'Active filters:' ?></span>
            
            <?php if (!empty($keyword)): ?>
                <span class="badge bg-white text-dark border">
                    <?= Lang::isRtl() ? 'الكلمة:' : 'Keyword:' ?> <?= e($keyword) ?>
                </span>
            <?php endif; ?>

            <?php if (!empty($selectedCity)): ?>
                <span class="badge bg-white text-dark border">
                    <?= Lang::isRtl() ? 'المدينة:' : 'City:' ?> <?= e(getCityName($selectedCity)) ?>
                </span>
            <?php endif; ?>

            <?php if (!empty($selectedType)): ?>
                <span class="badge bg-white text-dark border">
                    <?= Lang::isRtl() ? 'المناسبة:' : 'Type:' ?> <?= e(getOccasionTypeName($selectedType)) ?>
                </span>
            <?php endif; ?>

            <?php if (!empty($targetDate)): ?>
                <span class="badge bg-white text-dark border">
                    <i class="bi bi-calendar-event me-1"></i> <?= e($targetDate) ?>
                </span>
            <?php endif; ?>

            <?php if ($selectedCapacity > 0): ?>
                <span class="badge bg-white text-dark border">
                    <?= $selectedCapacity ?>+ <?= e(__('guest')) ?>
                </span>
            <?php endif; ?>

            <a href="<?= BASE_URL ?>/search.php" class="btn btn-sm text-danger text-decoration-none py-0 px-1 small">
                <i class="bi bi-x-circle me-1"></i> <?= Lang::isRtl() ? 'مسح الكل' : 'Clear all' ?>
            </a>
        </div>
    <?php endif; ?>

    <!-- Venues Grid -->
    <?php if (!empty($halls)): ?>
        <div class="row g-4 mb-5">
            <?php foreach ($halls as $hall): ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="hall-card h-100">
                        <div class="hall-card-img-wrap">
                            <?php if ($hall['featured']): ?>
                                <span class="badge-featured">
                                    <i class="bi bi-award-fill"></i> <?= Lang::isRtl() ? 'قاعة مميزة' : 'Featured' ?>
                                </span>
                            <?php endif; ?>
                            <span class="badge-city">
                                <i class="bi bi-geo-alt"></i> <?= e(getCityName($hall['city'])) ?>
                            </span>

                            <!-- Availability Badge if Date is selected -->
                            <?php if (!empty($targetDate)): ?>
                                <?php if ($hall['is_booked_on_date'] > 0): ?>
                                    <span class="badge bg-danger position-absolute" style="top: 10px; left: 10px; z-index: 2;">
                                        <i class="bi bi-x-circle-fill me-1"></i> <?= Lang::isRtl() ? 'محجوز بهذا التاريخ' : 'Booked on Date' ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success position-absolute" style="top: 10px; left: 10px; z-index: 2;">
                                        <i class="bi bi-check-circle-fill me-1"></i> <?= Lang::isRtl() ? 'متاح للحجز في تاريخك' : 'Available on Date' ?>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>

                            <img src="<?= e($hall['primary_image'] ?: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&w=800&q=80') ?>" alt="<?= e($hall['name_ar']) ?>" class="hall-card-img" loading="lazy">
                        </div>
                        <div class="hall-card-body d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="badge bg-light text-dark-green border small">
                                        <?= e(getOccasionTypeName($hall['hall_type'])) ?>
                                    </span>
                                    <span class="text-gold small fw-bold">
                                        <i class="bi bi-star-fill"></i> <?= number_format($hall['rating'], 1) ?> (<?= $hall['reviews_count'] ?>)
                                    </span>
                                </div>
                                <h3 class="hall-card-title"><?= e($hall['name_ar']) ?></h3>
                                <div class="hall-location">
                                    <i class="bi bi-pin-map-fill text-danger"></i>
                                    <span class="text-truncate"><?= e($hall['address']) ?></span>
                                </div>

                                <p class="text-muted small mb-3" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                    <?= e($hall['description_ar']) ?>
                                </p>

                                <div class="d-flex flex-wrap gap-2 mb-3">
                                    <span class="hall-meta-pill">
                                        <i class="bi bi-people"></i> <?= $hall['capacity_min'] ?> - <?= $hall['capacity_max'] ?> <?= e(__('guest')) ?>
                                    </span>
                                    <span class="hall-meta-pill">
                                        <i class="bi bi-moon-stars"></i> <?= Lang::isRtl() ? 'مسائي' : 'Evening' ?>
                                    </span>
                                </div>
                            </div>

                            <div class="hall-price-box mt-2">
                                <div>
                                    <div class="text-muted" style="font-size: 0.75rem;"><?= Lang::isRtl() ? 'يبدأ من' : 'Starts from' ?></div>
                                    <div class="hall-price-val">
                                        <?= formatMoney($hall['price_evening'], $hall['currency']) ?>
                                    </div>
                                </div>
                                <div class="d-flex gap-1">
                                    <a href="<?= BASE_URL ?>/hall-details.php?id=<?= $hall['id'] ?>" class="btn btn-sm btn-outline-dark-green">
                                        <?= e(__('view_details')) ?>
                                    </a>
                                    <a href="<?= BASE_URL ?>/inquiry.php?hall_id=<?= $hall['id'] ?>&date=<?= urlencode($targetDate) ?>" class="btn btn-sm btn-gold">
                                        <i class="bi bi-calendar2-check"></i> <?= Lang::isRtl() ? 'حجز / استفسار' : 'Book' ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination Controls -->
        <?php if ($totalPages > 1): ?>
            <nav aria-label="Search pagination" class="my-5">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= buildSearchPageUrl($page - 1) ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo; <?= Lang::isRtl() ? 'السابق' : 'Prev' ?></span>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                            <a class="page-link" href="<?= buildSearchPageUrl($i) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                        <a class="page-link" href="<?= buildSearchPageUrl($page + 1) ?>" aria-label="Next">
                            <span aria-hidden="true"><?= Lang::isRtl() ? 'التالي' : 'Next' ?> &raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    <?php else: ?>
        <!-- No Results Fallback -->
        <div class="text-center py-5 bg-white rounded-3 border shadow-sm my-4">
            <div class="brand-icon-wrapper mx-auto mb-3" style="width: 64px; height: 64px; font-size: 2rem;">
                <i class="bi bi-search text-gold"></i>
            </div>
            <h3 class="h4 fw-bold text-dark-green mb-2"><?= Lang::isRtl() ? 'عذراً، لم نجد قاعات تطابق خيارات بحثك' : 'No venues matching criteria' ?></h3>
            <p class="text-muted small mb-4" style="max-width: 500px; margin: 0 auto;">
                <?= Lang::isRtl() 
                    ? 'جرب توسيع نطاق البحث باختيار "جميع المدن" أو إزالة شروط السعة أو تاريخ المناسبة للاطلاع على كافة القاعات المتاحة.' 
                    : 'Try clearing some filters or searching for all cities to view available venues.' ?>
            </p>
            <div class="d-flex justify-content-center gap-2">
                <a href="<?= BASE_URL ?>/halls.php" class="btn btn-gold">
                    <i class="bi bi-grid-fill me-1 ms-1"></i> <?= Lang::isRtl() ? 'عرض كل القاعات والقصور' : 'Browse All Venues' ?>
                </a>
                <a href="<?= BASE_URL ?>/inquiry.php" class="btn btn-outline-dark-green">
                    <i class="bi bi-headset me-1 ms-1"></i> <?= Lang::isRtl() ? 'طلب استشارة ترشيح قاعة' : 'Consultation' ?>
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
